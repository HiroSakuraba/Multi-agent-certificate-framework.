# Certified Cognitive Glue v0.9 / Framework v0.3 Changelog

## Paper: v0.8 -> v0.9

### 1. Repaired budget-space conservation claim
- Replaced the previous raw-positive-payout version of Lemma 3 with **Net ledger conservation across budgets**.
- The new lemma distinguishes legitimate gross compensation from forbidden net extraction.
- Closed cycles with no exogenous/governance deposits now imply non-positive **net extractable surplus**, not zero gross payouts.
- Updated the proof, default-attack language, and conservation remark accordingly.

### 2. Updated attribution/solvency worked example
- Clarified that agent `b` may legitimately receive a gross repair payment when agent `a`'s posted collateral is charged.
- Clarified that the joint scope `{a,b}` has net surplus zero in that case.
- Preserved the default-blocking result: if `a` is insolvent or disappears, `b`'s credit is not spendable.

### 3. Normalized scarcity pricing
- Added normalized repair debt `\tilde d_i(x)=W_i(x)/\epsilon_i` directly in the glue-price section.
- Made the default interface scarcity price use normalized time-denominated debt:
  `q_e(x)=sum_i alpha_{e,i} W_i(x)/epsilon_i`.
- Kept raw-scale `sum_i alpha_i W_i(x)` only as an allowed variant when the glue contract declares commensurability.

### 4. Global-liveness caveat
- Added the condition that `H_r=0` must mean component `r` is discharged/inactive according to the certified monitor, not silently pending outside the indicator.
- Clarified that Corollary 1 exports the aggregate bounded-response monitor only.
- Clarified that local Streett guarantees still need local stopped-pair certificates or an explicit proof that exiting `H_r=1` coincides with discharge.

### 5. Claim-language updates
- Replaced “positive net ledger credit” / raw payout claims with “positive net extractable surplus” language.
- Updated the experiment section and Appendix T3 theorem-obligation wording.

## Implementation framework: v0.2 -> v0.3

### 1. Net-surplus gate added
- Added `GATE-NET-SURPLUS` beside `GATE-LEDGER-CONSERVATION`.
- The checker now distinguishes gross payouts from net extractable surplus:
  `gross_withdrawals - collectible_debits - collateral_locks - escrow_charges`.

### 2. Ledger entry schema extended
- Added exact rational fields:
  - `gross_payout`
  - `funding_charge`
  - `net_surplus_delta`

### 3. Scarcity-price formula updated
- The framework now uses normalized debt `W_i/epsilon_i` as the default scarcity-price input.

### 4. Composition section updated
- Added a global-liveness export caveat requiring certified semantics for local pending indicators `H_r`.

### 5. Attack/test updates
- Solvency/default attacks now fail by `GATE-SOLVENCY`, `GATE-NET-SURPLUS`, and `GATE-LEDGER-CONSERVATION`.
- Added `test_net_surplus_closed_cycle_nonpositive`.
- Updated definition-of-done to require backed gross compensation and non-positive closed-cycle net surplus.

## Build status

- LaTeX compiled successfully with `pdflatex`.
- PDF render check completed at 150 DPI; updated PDF has 20 pages.
