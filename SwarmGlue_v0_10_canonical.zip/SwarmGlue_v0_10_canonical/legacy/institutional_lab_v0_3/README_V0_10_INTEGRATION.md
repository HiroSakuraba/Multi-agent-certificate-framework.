# v0.10 integration status

This directory is the intact SwarmGlue v0.3 institutional laboratory, retained for research continuity. It is **not canonical runtime code**.

- Run its own tests from this directory.
- Treat full episodes/formal records as privileged critic/evaluator data.
- Do not import from this directory in production/canonical modules.
- Port valuable mechanisms through the promotion protocol in `../../docs/CONSOLIDATION_MAP.md`.
