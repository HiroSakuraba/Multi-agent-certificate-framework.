# SwarmGlue v0.10 handoff

## Current state

The project now has a single canonical baseline. v0.9 remains the semantic authority; v0.3 is preserved intact as a quarantined institutional laboratory. The consolidation adds no deployment-safety claim.

## Closed in v0.10

- Resolved ambiguity over which release is current.
- Preserved unique v0.3 corpus/evaluators instead of discarding them.
- Prevented legacy code from silently entering the canonical runtime.
- Added a reproducible combined validation gate.
- Added an explicit promotion protocol for legacy mechanisms.
- Added an agreement-governance commercialization translation.

## Research blockers

1. C3 governed-agent trials remain unperformed.
2. No independent agreement-domain case set exists.
3. No empirical calibration exists for agreement delay, authority misuse, review burden or downstream harm.
4. The v0.3 decision arithmetic remains synthetic and must be ported before it can constrain canonical actions.
5. Real organization deployment evidence (C4) is absent.

## Next work package

1. Define an agreement-domain capability-token vocabulary and state machine.
2. Port the v0.3 dual-sided action/delay evaluator into canonical code.
3. Build 100–300 independently authored agreement-agent adversarial cases.
4. Add multi-principal authority/standing fixtures.
5. Run a small C3 governed-vs-ungoverned agent experiment before using behavioral safety language in sales.
6. Build a read-only “shadow governance” product prototype that can sit in front of an existing e-signature provider and record what an autonomous agreement agent would have been allowed to do.

## Business implication

The strongest wedge is not generic e-signature or generic contract AI. It is **governed delegation for agentic agreement work**: proving who authorized an AI agent to do what, on which agreement state, within which economic/legal limits, with which evidence, for how long, and with what appeal/revocation path.
