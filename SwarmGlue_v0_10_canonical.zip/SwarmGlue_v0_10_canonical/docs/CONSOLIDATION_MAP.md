# v0.10 consolidation map

## Decision rule

Version 0.9 wins every semantic conflict unless a v0.3 component is explicitly promoted through a new canonical interface. Version 0.3 is retained as an **institutional laboratory**, not merged by filename.

| v0.3 component | v0.10 disposition | Rationale |
|---|---|---|
| `scripts/institutional_laboratory.py` | Retained under `legacy/` | Unique exact mechanism/game/coalition analyses; useful research generator, but based on older architecture |
| `scripts/decision_math.py` + `decision_laboratory.py` | Retained under `legacy/` | Valuable symmetric action-vs-delay arithmetic; should be re-expressed against canonical evidence/authority interfaces before promotion |
| Actor views and preference pairs | Retained under `legacy/` | Unique decentralized training material |
| Formal game/mechanism/coalition records | Retained under `legacy/` | Unique audit/evaluation corpus |
| Epistemic cases | Retained under `legacy/` | Relevant to common knowledge, correlated recommendations and later FDT work |
| Constitutional choices/population rollouts | Retained under `legacy/` | Useful synthetic institutional comparisons |
| Training exporters | Retained under `legacy/` | Reusable after schema review |
| v0.3 governance claims | Historical only | v0.9's C1–C4 claim taxonomy is authoritative |
| v0.3 runtime architecture | Superseded | v0.8/v0.9 capability, evidence, constitution, gateway, open-world and adversarial modules are authoritative |
| v0.3 evidence interpretation | Superseded where inconsistent | v0.10 inherits v0.9's stricter distinction between implementation, authored simulations, learned-agent trials and real-world outcomes |

## Promotion protocol

No file should move from `legacy/` to the canonical runtime merely by copy. Promotion requires:

1. State the intended invariant and evidence class.
2. Map privileged vs local information explicitly.
3. Define interaction with constitutional noncompensable constraints.
4. Define capability/authority boundary.
5. Add deterministic tests and known counterexamples.
6. Add adversarial/mutation tests when it affects authorization, evidence, policy or coordination signals.
7. Add corpus leakage/shortcut checks if model-facing.
8. Document what would falsify the claim.
9. Re-run v0.10 validation before release.

## Highest-value promotion candidates

1. **Dual-sided action/delay evaluator.** Useful for agreement review: acting can cause harm, but endless review and missed deadlines can also cause harm.
2. **Affected-nonparticipant accounting.** Useful for contracts that materially affect parties who are not negotiators/signers.
3. **Coalition/core diagnostics.** Useful for multi-party commercial arrangements, procurement consortia and side-deal/collusion stress tests.
4. **Epistemic/common-knowledge tests.** Useful where an agent must distinguish actual shared knowledge from merely inferred or correlated beliefs.
5. **Bounded review / reversible pilot logic.** Useful for agentic workflows in which the system can safely stage a reversible action instead of either full commitment or indefinite delay.
