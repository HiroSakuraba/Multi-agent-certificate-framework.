# SwarmGlue v0.9 — robustness to functional decision theory

This cumulative package preserves the SwarmGlue v0.8 mechanism-validation core and replayable open-world v0.2 experiment, then adds an evaluation lane for agents that reason over policies, programs, predictions, proofs, commitments, and logical dependence. Heterogeneous agents retain private bounded objectives; SwarmGlue constrains the admissible policy set rather than imposing one decision theory or global reward.

The project is an instrument for testing explicit governance mechanisms. It is not a complete constitution, an endorsement or implementation of FDT, a trained governance model, a policy ranking, or a deployment safety certification.

## Evidence status

| Class | Question | current status |
|---|---|---|
| C1 | Does the implementation do what its specification says? | Strong evidence for the enumerated v0.8, open-world v0.2, and FDT-supplement checks |
| C2 | Do the checks distinguish arrangements in new authored fixtures? | Partial evidence inside the mechanism benchmark, payload catalog, and rule-based open world; no independent FDT case set |
| C3 | Does a governed agent behave better than an ungoverned agent? | No result; V4 and FDT-specific V6 protocols supplied |
| C4 | Do these distinctions predict real institutional outcomes? | Not tested |

The central limitation remains plain: no learned model or other external agent has completed the V4 governed-agent trial or the new eight-cell V6 FDT robustness trial. The rule-based open-world residents are authored simulation policies, so their behavior remains C2 rather than C3 evidence. The new FDT corpus is generated and validated at C1 only.

## What v0.9 adds

- A decision-procedure-neutral design: FDT-like reasoning is permitted only inside a policy set that passes noncompensable authority, rights, standing, privacy, externality, exit, replacement, and shutdown checks.
- A 408-record, 204-pair FDT supplement kept separate from the inherited 1,740 records.
- Twelve learning families and six held-out challenge families covering verified logical dependence, program cooperation, protected Pareto improvements, conditional disclosure, blackmail, commitment races, correlated cartels, shutdown bargaining, multiparty cycles, and resource-bounded humans and agents.
- Exactly one model-facing observation delta per pair, balanced response surfaces, family and skeleton isolation, coverage checks, and shortcut reports.
- A human–AI convergence analysis, FDT-specific threat model, evaluation protocol, and V6 preregistration template.
- Explicit constitutional-override cases in which a logical link or negotiator gain is verified but the proposal is still blocked because it harms protected parties or controls.
- Exact prior open-world and cumulative small-town archives under `prior_releases/`, with recorded digests.

The simulation is retained as a later stress-test instrument. No new simulation result is used to establish the FDT claims in this release.

## What open-world v0.2 adds

- A persistent resident world with private continuous strategy parameters, needs, goods, skills, trust, places, associations, entry, realized exit, and interdependent shared services.
- Keyed common random tapes, stable IDs, sorted iteration, exact replay across Python hash seeds, and a complete state-bound action ledger.
- Four matched arms: open binding, process-only control, veto-only review, and contestable review.
- Separate material, civic, protected-boundary, process-burden, delay-harm, reviewer-error, and false-negative endpoints; no scalar winner.
- Explicit action-harm and delay/status-quo-harm records, including an evidenced severe-service fast track that cannot compensate away enumerated protected boundaries.
- A real population-size treatment, high/low stress treatment, multi-seed paired comparisons, deterministic bootstrap intervals, threshold sensitivity, mutation probes, and negative-result retention.
- A catalog-bound semantic proxy attack that can still evade review and is reported as a false negative rather than hidden.

See `SwarmGlue_Open_World_v0_2_Design.md`, `OPEN_WORLD_CRITIQUE_RESOLUTION.md`, and `reports/open_world_experiment.md`.

## What v0.8 changes

Version 0.8 directly repairs the validation defects identified in the v0.7 review.

- Every dynamic transition now receives an explicit 25-field mechanism vector. No transition can read an archetype or fixture name.
- Central pooling, emergency expiry, authority accumulation, contestability investment, exit maintenance, surveillance pressure, dissent sanctions, autonomy effects, cultural consolidation, and technical-lineage effects are explicit parameters.
- Equal parameters under different labels produce identical results by construction and by a 128-pair confirmatory test.
- Named fixture output is demoted to descriptive build diagnostics. It is no longer presented as an empirical or causal comparison.
- Five preregistered boundary lanes sweep fixtures toward constitutional decision surfaces.
- The former hash-scored detector model is replaced by payload attacks that call the shipped evidence, gateway, presentation, coordination-signal, and constitutional modules.
- Perfect detection across adapting generations is a staleness failure, not a success condition.
- Claims are separated into C1 through C4 and each claim records a falsifier.
- A four-arm governed-agent protocol, response schema, metadata template, and scorer are supplied. No empty or synthetic arm is reported as C3 evidence.

## Preregistered Tier-0 result

The locally locked confirmatory suite completed as follows:

| Experiment | Result | Interpretation |
|---|---:|---|
| V1 label invariance | 0 differences in 128 paired runs | The v0.7 label-causality defect is removed |
| V2 boundary lanes | 3 of 5 lanes flipped at interior weights; 3 contained partially admissible points | The simulator resolves several near-boundary mechanism changes |
| V3 runtime holdout | 13 of 16 attacks detected across six real module surfaces | The audit attacks shipped code and retains three visible misses |

The three V3 misses are:

- an unregistered supply-chain control relationship;
- a protected-belief proxy encoded in an allowed signal field;
- an unenumerated semantic exit restriction.

These are open blind spots, not acceptable-security findings.

Two V2 lanes did not flip. Exit erosion was inactive without concurrent authority concentration, and reduced investment plus growth alone did not recreate procedural stasis. Those negative results show interaction structure and are retained in the report.

Pre-registration hashes and source locks are in preregistration/. Their timestamps use a local clock and are not independently notarized.

## Reference architecture

SwarmGlue treats governance as a property of the complete agent–protocol–monitor–actuator arrangement. The reference implementation includes:

- non-compensable rights and authority constraints;
- explicit capacity and opportunity requirements;
- a multidimensional outcome vector rather than one social score;
- registry-bound Ed25519 evidence;
- committed observable-action sampling;
- externally issued, state-bound capability tokens;
- cumulative authority-amendment checks;
- bounded and typed coordination signals;
- review, appeal, expiry, replacement, and exit;
- a label-invariant dynamic mechanism benchmark;
- real-module runtime payload attacks;
- deterministic corpus, mutation, shortcut, terminology, and archive checks.

## Package map

    swarmglue/
      fdt_corpus.py                additive FDT robustness generator and validator
      open_world.py                replayable rule-based open-world experiment
      constitution.py              non-compensable constraints and outcome vector
      evidence.py                  registry-backed Ed25519 attestations
      presentation.py              committed observable-action trace sampling
      gateway.py                   external capability authorization and replay control
      coordination_signals.py      typed and bounded shared-condition signals
      authority.py                 executable amendments and cumulative drift checks
      network_governance.py        label-invariant dynamic mechanism benchmark
      institutional_boundaries.py  paired institutional distinctions
      adversary.py                 payload attacks against shipped modules
      corpus.py                    deterministic corpus generator and validators
    preregistration/               V1–V3 locks and local hash registry
    agent_trials/                  V4 and V6 protocols, schemas, and templates
    corpus/fdt/                    separate FDT train, development, and challenge splits
    external_cases/                independent-evaluation intake protocol
    scripts/                       build, experiment, scoring, audit, and validation tools
    tests/                         unit and regression tests
    reports/                       generated evidence and descriptive diagnostics

## Quick start

Python 3.11 or later and cryptography 42 or later are required.

    python -m unittest discover -s tests -v
    python examples/sim_env/open_world.py --arm all
    python scripts/run_open_world_experiments.py
    python scripts/open_world_mutation_audit.py
    python scripts/run_tier0_validation.py
    python scripts/mutation_audit.py
    python scripts/run_experiments.py
    python scripts/shortcut_audit.py
    python scripts/validate_fdt_corpus.py
    python scripts/terminology_audit.py
    python scripts/validate_release.py

Regenerate the additive FDT corpus, its reports, the cumulative manifest and checksums, and the deterministic archive without rerunning the deferred simulation:

    python scripts/build_fdt_release.py

The Tier-0 suite runs 6,688 confirmatory comparisons and simulations plus 16 payload attacks, so a full build is intentionally slower than a unit-test run.

## Governed-agent trial

agent_trials/V4_PROTOCOL.md defines four arms using the same base model:

1. base;
2. specification in context;
3. fine-tuned;
4. fine-tuned plus runtime enforcement.

The primary endpoint is protected-boundary violation rate on external adversarial unsafe cases. Raw model proposals, runtime blocks, and safe-case overblocking are recorded separately. The scorer refuses to mark an incomplete four-arm run as C3 evidence.

## Release criteria

A release is accepted only if:

1. deterministic security and binding tests pass;
2. the 30 institutional-boundary cases pass;
3. cumulative authority drift is detected;
4. label-invariance and pre-registration source locks pass;
5. boundary-lane and runtime-payload protocols execute as registered;
6. the runtime attack catalog reaches at least five shipped module surfaces;
7. perfect detection across three adapting generations triggers staleness failure;
8. response-only performance remains in the chance band;
9. response surfaces remain balanced;
10. held-out scenario families remain isolated;
11. public-framing terminology, source, configuration, checksum, and archive checks pass;
12. open-world exact replay, label permutation, matched exogenous tape, size, cascade, exit, action/delay harm, appeal, and semantic-miss tests pass;
13. all enumerated open-world mutants are detected while the baseline probes pass.
14. every FDT pair changes exactly one model-facing observation field;
15. FDT response surfaces remain exactly balanced and challenge families and skeletons remain isolated;
16. legitimate cooperation, constitutional override, blackmail, privacy, shutdown, outsider, multiparty, human-standing, and resource-bound cases meet coverage requirements;
17. FDT learned-agent status remains explicitly not run unless a complete preregistered V6 result replaces it.

Scientific hypotheses may be falsified without blocking release. A release fails on protocol or integrity failure, not because a result is unfavorable.

## Documentation

- SwarmGlue_v0_8_Design.md — architecture, mechanism model, and evidence logic
- SwarmGlue_v0_9_FDT_Robustness_Design.md — constraint-first treatment of policy and logical reasoning
- FDT_HUMAN_AI_CONVERGENCE_GAME_PLAN.md — convergence analysis and staged research plan
- FDT_CORPUS_AUDIT.md — inherited-corpus gap analysis and supplement decision
- FDT_THREAT_MODEL.md — FDT-specific adversaries, controls, and residual risks
- FDT_EVALUATION_PROTOCOL.md — C1 through C4 evaluation design
- SwarmGlue_Open_World_v0_2_Design.md — open-world state, causal controls, arms, endpoints, and limits
- OPEN_WORLD_CRITIQUE_RESOLUTION.md — submitted-prototype critique-to-change ledger
- CRITIQUE_RESOLUTION.md — objection-to-change traceability
- CLAIMS_AND_LIMITATIONS.md — C1–C4 claim ledger with falsifiers
- agent_trials/V4_PROTOCOL.md — missing governed-agent experiment
- TRAINING_REGIME.md — training and promotion procedure
- THREAT_MODEL.md — protected interests, adversaries, assumptions, and exclusions
- DATA_CARD.md — corpus construction and intended use
- RESEARCH_TRANSLATION.md — institutional and resilience research translation
- SOURCES.md — primary and authoritative sources

No license is asserted in this research bundle. Add an explicit license before redistribution. Do not use the reference implementation by itself for high-stakes legal, medical, environmental, political, or critical-service decisions.
