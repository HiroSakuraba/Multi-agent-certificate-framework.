# SwarmGlue as an agreement-governance business layer

## Executive position

Do not position SwarmGlue as a consumer governance philosophy and do not claim that it “solves AI alignment.” Position it as the research substrate for a concrete enterprise product capability:

> **Governed delegation for agreement agents:** an authorization, evidence, policy, and audit layer that lets businesses delegate bounded agreement work to AI agents without giving those agents unconstrained commercial authority.

The commercial product can carry a separate customer-facing name. SwarmGlue should remain the mechanism/evaluation program underneath it.

## Why this positioning changed in 2026

Docusign has already moved beyond e-signature. Its public roadmap now includes an AI assistant, ready-to-deploy agents, custom agents/Agent Studio, MCP access from external AI tools, Agreement Manager, rule-based automation, and cross-system actions. Therefore “agentic contracts” alone is not a defensible wedge.

The attack must move one level lower: **who may cause which legally/economically consequential action, based on what evidence and policy, under what revocation/appeal controls?**

## Product architecture

```text
Human / AI requester
        |
        v
Agreement intent + proposed action
        |
        v
+----------------------------------+
| SwarmGlue-derived Governance Gate |
| - authority/capability scope      |
| - state binding + expiry          |
| - evidence/provenance             |
| - policy + protected boundaries   |
| - standing/affected parties       |
| - risk/delay/review path          |
| - audit + appeal/revocation       |
+----------------------------------+
        | allow / escalate / deny
        v
Agreement workflow / e-sign / CRM / ERP / procurement
```

The first commercial version should work **with** Docusign and other signing systems rather than requiring replacement. That creates a low-friction overlay wedge. Once the governance layer owns authorization, workflow state, agreement metadata, and downstream actions, signature can become a replaceable execution adapter.

## Initial product: Agreement Governance Gateway

### Customer promise

“Let AI handle routine agreements while retaining provable human-defined authority boundaries.”

### V1 features

1. **Delegation tokens** — named principal, agent/service identity, permitted actions, dollar/term limits, document/workflow scope, expiry, revocation and state binding.
2. **Policy-as-code** — approved templates, clause bands, signer authority, approval thresholds, restricted data and nonnegotiable terms.
3. **Evidence bundle** — source agreement/version, extracted facts, model outputs, citations/provenance, approvals and cryptographic event history.
4. **Escalation engine** — allow, ask for clarification, route to reviewer, require second approval, or deny.
5. **Replayable audit** — reconstruct what the agent observed, proposed, was authorized to do, and actually did.
6. **Delay-aware review** — prevent both reckless auto-approval and endless review capture.
7. **Multi-agent controls** — tests for blackmail, correlated-agent collusion, stale commitments, side deals and unauthorized bargaining.

## Beachhead customer

Target 50–1,000 employee B2B companies that want to deploy AI in legal operations, sales operations, procurement or finance but whose security/legal teams refuse unconstrained autonomous action.

Start with:

- NDAs;
- order forms;
- standard MSAs/SOWs within a narrow playbook;
- vendor renewals;
- low-risk procurement approvals;
- routine post-signature obligation triggers.

Avoid highly regulated or notarized transaction classes until the mechanism and compliance program mature.

## Land-and-expand motion

### Stage 1 — shadow governance
Read existing agreement and workflow events. Evaluate every proposed agent action but do not block or execute. Produce an “authority and exception” report. This gives security/legal teams evidence without a rip-and-replace decision.

### Stage 2 — approval gate
Put low-risk agent actions behind the gate while Docusign remains the signature provider. Relay/your commercial product becomes the source of policy and authority.

### Stage 3 — workflow ownership
Own request, drafting, redline policy, approval, evidence, obligation and downstream actions. E-signature remains an adapter.

### Stage 4 — selective execution replacement
For customers/workflows where economics and trust justify it, replace the signing component as well. The strategically important asset is already upstream: authorization + state + evidence + workflow.

## What parts of Docusign to attack first

| Docusign-adjacent value pool | Attack? | SwarmGlue-derived angle |
|---|---|---|
| Basic signature transport | Later | Commodity-like execution primitive; poor initial differentiation |
| Workflow/approval routing | Yes | State-bound authority and noncompensable rules |
| Agent Studio / agent actions | Yes, indirectly | Independent governance gate that can constrain any model/provider/agent |
| Agreement repository/intelligence | Yes | Evidence-linked operational agreement graph rather than only extraction/search |
| Renewal/obligation actions | Yes | Authorized downstream actions with traceable delegation |
| Enterprise compliance/audit | Strongly | Replayable authority/evidence chain becomes a first-class product |
| Cross-company autonomous negotiation | Long-term | Multi-principal/coalition/FDT threat model could become differentiated infrastructure |

## The strategic moat

Do not claim the moat is a particular LLM. The moat should compound in:

1. **Authority graph:** how organizations actually delegate commercial power.
2. **Agreement-policy graph:** templates, clauses, thresholds, exception paths and approval relationships.
3. **Governance evaluation corpus:** real and synthetic near-misses, attacks, escalation decisions, and failure modes.
4. **Evidence interoperability:** the ability to prove decisions across model providers and execution systems.
5. **Migration neutrality:** run on top of Docusign, Adobe, native APIs and future agent systems instead of being locked to one signature vendor.
6. **Cross-party protocol:** eventually let two organizations' agents establish bounded, mutually auditable negotiation authority without sharing private internal state.

## Claims discipline

Today SwarmGlue gives the business an unusual **engineering and evaluation framework**, not a proven safety certificate. Public claims should remain:

- “bounded delegation and audit architecture”;
- “designed to enforce machine-readable authority and policy constraints”;
- “tested against enumerated synthetic adversarial cases”;
- “provider-neutral governance layer.”

Do not yet claim:

- “safe autonomous contracting”;
- “prevents AI collusion”;
- “solves agent alignment”;
- “provably compliant in all jurisdictions”;
- “validated to reduce real-world contract loss.”

Those require C3/C4 evidence and legal/compliance validation.

## 12-month commercialization experiment

### Months 0–3
- Agreement-domain capability schema.
- Docusign/webhook or equivalent read-only adapter.
- Shadow-mode policy evaluation.
- 10 design partners.
- Independently authored agreement-agent red-team set.

### Months 4–6
- Approval-gate mode for one low-risk workflow.
- Signed/immutable action evidence.
- Human escalation UX.
- C3 governed-vs-ungoverned agent trial.
- External security review.

### Months 7–9
- Two execution adapters.
- CRM/procurement downstream actions.
- Delay-aware review policy.
- Customer-specific delegation graph.
- First annual contracts.

### Months 10–12
- Expand from one to three agreement workflows.
- SSO/SCIM and enterprise audit exports as demanded.
- Measure exception reduction, cycle time, unauthorized-action prevention, false blocks and review burden.
- Decide whether signing itself is worth internalizing.

## Business-plan sentence

> We are not trying to beat Docusign by putting a chatbot on e-signature. We are building the neutral authorization and evidence layer that makes autonomous agreement work governable across Docusign, CRMs, procurement systems and AI agents. We can initially sell into the installed base as a control plane, then own progressively more of the agreement lifecycle as the control plane becomes the system of record for delegated commercial authority.

## Current competitive references (checked 2026-08-24)

- Docusign product roadmap: https://www.docusign.com/releases/roadmap
- Docusign Agreement Manager: https://www.docusign.com/products/platform/agreement-manager
- Docusign Iris/agents: https://www.docusign.com/products/platform/ai
- Docusign Q1 FY2027 results: https://investor.docusign.com/news-and-events/press-releases/news-details/2026/Docusign-Announces-First-Quarter-Fiscal-2027-Financial-Results/default.aspx

These sources show Docusign already competing on AI assistants, agents, Agent Studio, MCP, Slack and system-of-action workflows. The differentiation proposed here is therefore intentionally governance/authority-centric rather than agent-centric.
