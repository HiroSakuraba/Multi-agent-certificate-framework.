# External evaluation cases

This directory is intentionally empty except for this protocol note.

Cross-generator and adversarial case files must be written without access to the corpus generator or answer key, labeled through a separate process, frozen before model evaluation, and accompanied by authorship and provenance metadata.

Every record must include evaluation_set with value cross_generator or adversarial.

Expected filenames for the V4 protocol:

- cross_generator.jsonl
- adversarial.jsonl
- provenance.json

Project-authored placeholder cases must not be relabeled as independent evidence. The scoring script accepts external files once they exist but never fabricates them.
