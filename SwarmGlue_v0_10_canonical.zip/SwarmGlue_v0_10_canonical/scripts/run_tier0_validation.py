#!/usr/bin/env python3
"""Run the preregistered v0.8 Tier-0 validation program."""

from __future__ import annotations

import argparse
import copy
import hashlib
import inspect
import json
import sys
from collections import Counter
from dataclasses import asdict, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import swarmglue.network_governance as ng
from swarmglue.adversary import (
    TARGETS,
    VARIANTS,
    baseline_attacks,
    evaluate_defense,
)
from swarmglue.network_governance import (
    POLICY,
    SimulationConfig,
    simulate_with_parameters,
)
from swarmglue.utils import digest, mean, q


REGISTRY_PATH = PROJECT_ROOT / "preregistration" / "REGISTRY.json"


def sha256(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(block)
    return hasher.hexdigest()


def load_lock(experiment_id: str) -> tuple[dict[str, Any], dict[str, Any]]:
    registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
    entry = next(
        item
        for item in registry["entries"]
        if item["experiment_id"] == experiment_id
    )
    preregistration_path = PROJECT_ROOT / entry["path"]
    actual_preregistration_sha256 = sha256(preregistration_path)
    specification = json.loads(
        preregistration_path.read_text(encoding="utf-8")
    )
    source_checks = {}
    for relative, expected in specification[
        "frozen_source_sha256"
    ].items():
        actual = sha256(PROJECT_ROOT / relative)
        source_checks[relative] = {
            "expected": expected,
            "actual": actual,
            "matched": actual == expected,
        }
    lock = {
        "experiment_id": experiment_id,
        "preregistration_path": entry["path"],
        "registry_sha256": entry["sha256"],
        "actual_preregistration_sha256": (
            actual_preregistration_sha256
        ),
        "preregistration_hash_matched": (
            actual_preregistration_sha256 == entry["sha256"]
        ),
        "frozen_source_checks": source_checks,
        "frozen_sources_matched": all(
            item["matched"] for item in source_checks.values()
        ),
        "timestamp_status": registry["timestamp_status"],
    }
    return specification, lock


def run_v1() -> dict[str, Any]:
    specification, lock = load_lock("V1_LABEL_INVARIANCE")
    differences: list[dict[str, Any]] = []
    comparison_count = 0
    for vector_name in specification["design"]["parameter_vectors"]:
        parameters = POLICY[vector_name]
        for topology in specification["design"]["topologies"]:
            for seed in range(
                specification["design"]["seeds"]["start"],
                specification["design"]["seeds"][
                    "stop_inclusive"
                ]
                + 1,
            ):
                config = SimulationConfig(
                    seed=seed,
                    topology=topology,
                    rounds=specification["design"]["rounds"],
                )
                labels = specification["design"][
                    "labels_per_vector"
                ]
                left = simulate_with_parameters(
                    config,
                    parameters,
                    fixture_id=labels[0],
                )
                right = simulate_with_parameters(
                    config,
                    parameters,
                    fixture_id=labels[1],
                )
                left_without_label = copy.deepcopy(left)
                right_without_label = copy.deepcopy(right)
                left_without_label.pop("policy")
                right_without_label.pop("policy")
                comparison_count += 1
                if left_without_label != right_without_label:
                    differences.append(
                        {
                            "vector": vector_name,
                            "topology": topology,
                            "seed": seed,
                            "left_digest": digest(
                                left_without_label
                            ),
                            "right_digest": digest(
                                right_without_label
                            ),
                        }
                    )

    transition_functions = (
        ng._failure_cascade,
        ng._mutual_aid,
        ng._governance_transition,
        ng.step,
    )
    source_violations = []
    for function in transition_functions:
        source = inspect.getsource(function)
        signature = str(inspect.signature(function))
        forbidden = []
        if "policy" in source.lower() or "policy" in signature.lower():
            forbidden.append("policy_identifier")
        forbidden.extend(
            label for label in POLICY if label in source
        )
        if forbidden:
            source_violations.append(
                {
                    "function": function.__name__,
                    "forbidden_tokens": sorted(set(forbidden)),
                }
            )

    protocol_pass = (
        lock["preregistration_hash_matched"]
        and lock["frozen_sources_matched"]
        and comparison_count
        == specification["design"]["paired_comparisons"]
    )
    hypothesis_supported = (
        not differences and not source_violations
    )
    return {
        "experiment_id": specification["experiment_id"],
        "claim_class": "C1",
        "lock": lock,
        "protocol_pass": protocol_pass,
        "hypothesis_supported": hypothesis_supported,
        "paired_comparison_count": comparison_count,
        "paired_difference_count": len(differences),
        "differences": differences,
        "transition_source_violation_count": len(
            source_violations
        ),
        "transition_source_violations": source_violations,
        "falsified": not hypothesis_supported,
        "interpretation": specification["claim_scope_if_passed"],
    }


def _lane_parameters(
    baseline: dict[str, float],
    target: dict[str, float],
    fields: list[str],
    weight: float,
) -> dict[str, float]:
    output = dict(baseline)
    for name in fields:
        output[name] = (
            baseline[name]
            + weight * (target[name] - baseline[name])
        )
    return output


def _monotonic_fraction(
    values: list[float],
    direction: str,
) -> float:
    if len(values) < 2:
        return 1.0
    if direction == "increasing":
        passed = sum(
            right + 1e-12 >= left
            for left, right in zip(values, values[1:])
        )
    else:
        passed = sum(
            right <= left + 1e-12
            for left, right in zip(values, values[1:])
        )
    return q(passed / (len(values) - 1))


def run_v2() -> dict[str, Any]:
    specification, lock = load_lock("V2_BOUNDARY_LANES")
    design = specification["design"]
    baseline = POLICY[design["baseline"]]
    weights = [index / 40 for index in range(41)]
    lane_metrics = {
        "authority": ("power_concentration", "increasing"),
        "exit": ("exit_access", "decreasing"),
        "emergency": ("emergency_duration", "increasing"),
        "capacity": ("capacity_growth", "decreasing"),
        "technical_resilience": (
            "recoverability",
            "decreasing",
        ),
    }
    lane_reports = {}
    total_runs = 0
    for lane_name, lane_fields in design["lanes"].items():
        target = POLICY[design["targets"][lane_name]]
        points = []
        for weight in weights:
            parameters = _lane_parameters(
                baseline,
                target,
                lane_fields,
                weight,
            )
            rows = []
            for topology in design["topologies"]:
                for seed in range(
                    design["seeds"]["start"],
                    design["seeds"]["stop_inclusive"] + 1,
                ):
                    rows.append(
                        simulate_with_parameters(
                            SimulationConfig(
                                seed=seed,
                                topology=topology,
                                rounds=design["rounds"],
                            ),
                            parameters,
                            fixture_id=(
                                f"boundary-{lane_name}-{weight:.3f}"
                            ),
                        )
                    )
            total_runs += len(rows)
            hard = Counter(
                reason
                for row in rows
                for reason in row[
                    "constitutional_verdict"
                ]["hard_violations"]
            )
            capacity = Counter(
                reason
                for row in rows
                for reason in row[
                    "constitutional_verdict"
                ]["capacity_violations"]
            )
            outcomes = [row["outcome"] for row in rows]
            points.append(
                {
                    "weight": q(weight, 3),
                    "run_count": len(rows),
                    "admissibility_rate": q(
                        mean(
                            row["constitutional_verdict"][
                                "admissible"
                            ]
                            for row in rows
                        )
                    ),
                    "hard_violation_counts": dict(
                        sorted(hard.items())
                    ),
                    "capacity_violation_counts": dict(
                        sorted(capacity.items())
                    ),
                    "mean_outcomes": {
                        name: q(
                            mean(
                                float(outcome[name])
                                for outcome in outcomes
                            )
                        )
                        for name in (
                            "power_concentration",
                            "exit_access",
                            "emergency_duration",
                            "capacity_growth",
                            "opportunity_growth",
                            "recoverability",
                        )
                    },
                }
            )
        baseline_rate = points[0]["admissibility_rate"]
        interior_flips = [
            point
            for point in points[1:-1]
            if point["admissibility_rate"] != baseline_rate
        ]
        partial_points = [
            point
            for point in points[1:-1]
            if 0.0 < point["admissibility_rate"] < 1.0
        ]
        metric_name, direction = lane_metrics[lane_name]
        metric_values = [
            point["mean_outcomes"][metric_name]
            for point in points
        ]
        lane_reports[lane_name] = {
            "interpolated_fields": lane_fields,
            "target_fixture": design["targets"][lane_name],
            "baseline_admissibility_rate": baseline_rate,
            "has_interior_flip": bool(interior_flips),
            "first_interior_flip": (
                interior_flips[0] if interior_flips else None
            ),
            "partial_interior_point_count": len(
                partial_points
            ),
            "first_partial_interior_point": (
                partial_points[0] if partial_points else None
            ),
            "expected_direction_metric": metric_name,
            "expected_direction": direction,
            "adjacent_monotonic_fraction": (
                _monotonic_fraction(
                    metric_values,
                    direction,
                )
            ),
            "points": points,
        }

    lanes_with_flip = sum(
        report["has_interior_flip"]
        for report in lane_reports.values()
    )
    lanes_with_partial = sum(
        report["partial_interior_point_count"] > 0
        for report in lane_reports.values()
    )
    protocol_pass = (
        lock["preregistration_hash_matched"]
        and lock["frozen_sources_matched"]
        and total_runs == design["confirmatory_runs"]
    )
    predicted = specification["predicted_result"]
    hypothesis_supported = (
        lanes_with_flip
        >= predicted["lanes_with_interior_flip_minimum"]
        and lanes_with_partial
        >= predicted[
            "lanes_with_partially_admissible_interior_point_minimum"
        ]
    )
    return {
        "experiment_id": specification["experiment_id"],
        "claim_class": "C2",
        "lock": lock,
        "protocol_pass": protocol_pass,
        "hypothesis_supported": hypothesis_supported,
        "falsified": not hypothesis_supported,
        "confirmatory_run_count": total_runs,
        "lanes_with_interior_flip": lanes_with_flip,
        "lanes_with_partially_admissible_interior_point": (
            lanes_with_partial
        ),
        "lane_reports": lane_reports,
        "interpretation": specification["claim_scope_if_passed"],
    }


def run_v3() -> dict[str, Any]:
    specification, lock = load_lock("V3_RUNTIME_HOLDOUT")
    reserved = specification["design"][
        "reserved_start_variants"
    ]
    attacks = []
    for index, attack in enumerate(baseline_attacks()):
        if attack.family in reserved:
            variant_name = reserved[attack.family]
            variant_index = next(
                position
                for position, item in enumerate(
                    VARIANTS[attack.family]
                )
                if item[0] == variant_name
            )
            variant, description = VARIANTS[
                attack.family
            ][variant_index]
            attack = replace(
                attack,
                attack_id=f"holdout-{index:02d}",
                target_module=TARGETS[attack.family],
                variant=variant,
                variant_index=variant_index,
                description=description,
            )
        else:
            attack = replace(
                attack,
                attack_id=f"holdout-{index:02d}",
            )
        attacks.append(attack)

    evaluation = evaluate_defense(
        attacks,
        generation=0,
    )
    predicted = specification["predicted_result"]
    miss_count = len(evaluation["undetected_attacks"])
    protocol_pass = (
        lock["preregistration_hash_matched"]
        and lock["frozen_sources_matched"]
        and evaluation["attack_count"]
        == specification["design"]["attack_family_count"]
    )
    hypothesis_supported = (
        predicted["detection_rate_lower_inclusive"]
        <= evaluation["detection_rate"]
        < predicted["detection_rate_upper_exclusive"]
        and evaluation["real_module_surface_count"]
        >= predicted["real_module_surface_count_minimum"]
        and miss_count
        >= predicted["undetected_attack_count_minimum"]
    )
    return {
        "experiment_id": specification["experiment_id"],
        "claim_class": "C1/C2",
        "lock": lock,
        "protocol_pass": protocol_pass,
        "hypothesis_supported": hypothesis_supported,
        "falsified": not hypothesis_supported,
        "detection_rate": evaluation["detection_rate"],
        "real_module_surface_count": evaluation[
            "real_module_surface_count"
        ],
        "real_module_surfaces": evaluation[
            "real_module_surfaces"
        ],
        "undetected_attack_count": miss_count,
        "undetected_attacks": evaluation[
            "undetected_attacks"
        ],
        "attack_results": evaluation["attack_results"],
        "interpretation": specification["claim_scope_if_passed"],
    }


def run() -> dict[str, Any]:
    experiments = [run_v1(), run_v2(), run_v3()]
    return {
        "validation_suite": "SwarmGlue_v0.8_Tier0",
        "executed_at_utc": datetime.now(
            timezone.utc
        ).replace(microsecond=0).isoformat(),
        "protocol_conformance_pass": all(
            item["protocol_pass"] for item in experiments
        ),
        "hypotheses_supported": {
            item["experiment_id"]: item[
                "hypothesis_supported"
            ]
            for item in experiments
        },
        "evidence_boundary": {
            "C1": (
                "Implementation conformance and direct runtime "
                "module behavior."
            ),
            "C2": (
                "Discrimination inside authored model and attack "
                "fixtures."
            ),
            "C3": (
                "No governed-agent behavioral result in this suite."
            ),
            "C4": (
                "No real institutional-outcome result in this suite."
            ),
        },
        "experiments": experiments,
    }


def markdown(report: dict[str, Any]) -> str:
    by_id = {
        item["experiment_id"]: item
        for item in report["experiments"]
    }
    v1 = by_id["V1_LABEL_INVARIANCE"]
    v2 = by_id["V2_BOUNDARY_LANES"]
    v3 = by_id["V3_RUNTIME_HOLDOUT"]
    lines = [
        "# SwarmGlue v0.8 Tier-0 validation",
        "",
        (
            "Protocol conformance: **"
            + (
                "PASS"
                if report["protocol_conformance_pass"]
                else "FAIL"
            )
            + "**"
        ),
        "",
        "| Experiment | Evidence class | Protocol | Hypothesis | Primary result |",
        "|---|---|---:|---:|---|",
        (
            f"| V1 label invariance | C1 | "
            f"{'PASS' if v1['protocol_pass'] else 'FAIL'} | "
            f"{'SUPPORTED' if v1['hypothesis_supported'] else 'FALSIFIED'} | "
            f"{v1['paired_difference_count']} differences in "
            f"{v1['paired_comparison_count']} pairs |"
        ),
        (
            f"| V2 boundary lanes | C2 | "
            f"{'PASS' if v2['protocol_pass'] else 'FAIL'} | "
            f"{'SUPPORTED' if v2['hypothesis_supported'] else 'FALSIFIED'} | "
            f"{v2['lanes_with_interior_flip']}/5 lanes flip; "
            f"{v2['lanes_with_partially_admissible_interior_point']}/5 "
            f"contain a partial point |"
        ),
        (
            f"| V3 runtime holdout | C1/C2 | "
            f"{'PASS' if v3['protocol_pass'] else 'FAIL'} | "
            f"{'SUPPORTED' if v3['hypothesis_supported'] else 'FALSIFIED'} | "
            f"detection {v3['detection_rate']:.1%}; "
            f"{v3['undetected_attack_count']} misses |"
        ),
        "",
        "## V2 decision surfaces",
        "",
        "| Lane | Interior flip | First flip weight | Partial points | Monotonic fraction |",
        "|---|---:|---:|---:|---:|",
    ]
    for lane, item in v2["lane_reports"].items():
        first = item["first_interior_flip"]
        lines.append(
            f"| {lane} | {'yes' if item['has_interior_flip'] else 'no'} | "
            f"{first['weight'] if first else 'none'} | "
            f"{item['partial_interior_point_count']} | "
            f"{item['adjacent_monotonic_fraction']:.1%} |"
        )
    lines += [
        "",
        "## V3 observed misses",
        "",
    ]
    for item in v3["undetected_attacks"]:
        lines.append(
            f"- {item['family']} / {item['variant']} against "
            f"{item['target_module']}: {item['observed_reason']}."
        )
    lines += [
        "",
        "## Evidence boundary",
        "",
        "These results establish implementation behavior and resolving power only "
        "inside the authored simulator and payload catalog. No model or other "
        "agent was governed in this suite, so C3 remains untested. No claim about "
        "real institutional outcomes, C4, is made.",
        "",
        "The pre-registration registry uses a local clock and content hashes. It "
        "detects post-lock edits inside this release but is not an independently "
        "notarized timestamp.",
        "",
    ]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--json",
        type=Path,
        default=Path("reports/tier0_validation.json"),
    )
    parser.add_argument(
        "--markdown",
        type=Path,
        default=Path("reports/tier0_validation.md"),
    )
    args = parser.parse_args()
    report = run()
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    args.markdown.write_text(
        markdown(report),
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "protocol_conformance_pass": report[
                    "protocol_conformance_pass"
                ],
                "hypotheses_supported": report[
                    "hypotheses_supported"
                ],
            },
            sort_keys=True,
        )
    )
    raise SystemExit(
        0 if report["protocol_conformance_pass"] else 1
    )


if __name__ == "__main__":
    main()
