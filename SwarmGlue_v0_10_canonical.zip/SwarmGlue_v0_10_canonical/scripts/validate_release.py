#!/usr/bin/env python3
"""Validate source, corpus, reports, checksums, and optional release archive."""

from __future__ import annotations

import argparse
import compileall
import hashlib
import json
import subprocess
import sys
import zipfile
from pathlib import Path, PurePosixPath

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from scripts.mutation_audit import run_audit as run_mutation_audit
from scripts.open_world_mutation_audit import run_audit as run_open_world_mutation_audit
from scripts.open_world_protocol_lock import verify_lock as verify_open_world_lock
from scripts.shortcut_audit import audit as run_shortcut_audit
from scripts.terminology_audit import audit as run_terminology_audit
from swarmglue.institutional_boundaries import run_institutional_boundary_suite
from swarmglue.constitution import ConstitutionalThresholds
from swarmglue.corpus import validate_records
from swarmglue.fdt_corpus import validate_records as validate_fdt_records
from swarmglue.network_governance import POLICY


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load_corpus(root: Path) -> dict[str, list[dict]]:
    output = {}
    for split in ("train", "dev", "challenge"):
        with (root / "corpus" / f"{split}.jsonl").open(encoding="utf-8") as handle:
            output[split] = [json.loads(line) for line in handle if line.strip()]
    return output


def load_fdt_corpus(root: Path) -> dict[str, list[dict]]:
    output = {}
    for split in ("train", "dev", "challenge"):
        with (root / "corpus" / "fdt" / f"{split}.jsonl").open(encoding="utf-8") as handle:
            output[split] = [json.loads(line) for line in handle if line.strip()]
    return output


def check_checksums(root: Path) -> tuple[bool, list[str]]:
    path = root / "SHA256SUMS"
    if not path.exists():
        return False, ["SHA256SUMS_missing"]
    failures = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            failures.append(f"malformed_checksum_line:{line}")
            continue
        target = root / relative
        if not target.is_file():
            failures.append(f"checksum_target_missing:{relative}")
        elif sha256(target) != expected:
            failures.append(f"checksum_mismatch:{relative}")
    return not failures, failures


def check_archive(root: Path, archive: Path) -> dict:
    failures = []
    if not archive.is_file():
        return {"checked": True, "passed": False, "failures": ["archive_missing"]}
    prefix = root.name + "/"
    with zipfile.ZipFile(archive) as bundle:
        names = [info.filename for info in bundle.infolist() if not info.is_dir()]
        for name in names:
            pure = PurePosixPath(name)
            if pure.is_absolute() or ".." in pure.parts:
                failures.append(f"unsafe_archive_path:{name}")
            if not name.startswith(prefix):
                failures.append(f"wrong_archive_prefix:{name}")
        expected_files = {
            p.relative_to(root).as_posix(): p
            for p in root.rglob("*")
            if p.is_file() and "__pycache__" not in p.parts and not p.name.endswith(".pyc")
        }
        archived_rel = {name[len(prefix):] for name in names if name.startswith(prefix)}
        missing = sorted(set(expected_files) - archived_rel)
        extra = sorted(archived_rel - set(expected_files))
        failures += [f"archive_missing_file:{name}" for name in missing]
        failures += [f"archive_extra_file:{name}" for name in extra]
        for relative, path in expected_files.items():
            archive_name = prefix + relative
            if archive_name in names:
                digest = hashlib.sha256(bundle.read(archive_name)).hexdigest()
                if digest != sha256(path):
                    failures.append(f"archive_digest_mismatch:{relative}")
        bad_crc = bundle.testzip()
        if bad_crc:
            failures.append(f"archive_crc_failure:{bad_crc}")
    return {
        "checked": True,
        "passed": not failures,
        "failures": failures,
        "sha256": sha256(archive),
        "bytes": archive.stat().st_size,
    }


def validate(
    root: Path,
    archive: Path | None = None,
    *,
    run_tests: bool = True,
    check_integrity_files: bool = True,
) -> dict:
    failures: list[str] = []
    required = [
        "README.md", "SwarmGlue_v0_8_Design.md", "TRAINING_REGIME.md", "THREAT_MODEL.md",
        "DATA_CARD.md", "CLAIMS_AND_LIMITATIONS.md", "RESEARCH_TRANSLATION.md", "SOURCES.md",
        "CRITIQUE_RESOLUTION.md",
        "SwarmGlue_v0_9_FDT_Robustness_Design.md",
        "FDT_HUMAN_AI_CONVERGENCE_GAME_PLAN.md", "FDT_CORPUS_AUDIT.md",
        "FDT_THREAT_MODEL.md", "FDT_EVALUATION_PROTOCOL.md",
        "PRIOR_RELEASES.md",
        "SwarmGlue_Open_World_v0_2_Design.md", "OPEN_WORLD_CRITIQUE_RESOLUTION.md",
        "configs/constitution.json", "configs/training_regime.json", "configs/experiment.json",
        "configs/mechanism_fixtures.json", "configs/open_world_experiment.json",
        "configs/fdt_training_regime.json",
        "schemas/corpus.schema.json", "schemas/attestation.schema.json",
        "schemas/capability_token.schema.json", "schemas/presentation.schema.json",
        "schemas/fdt_corpus.schema.json",
        "agent_trials/V4_PROTOCOL.md", "agent_trials/RESPONSE_SCHEMA.json",
        "agent_trials/V4_PREREGISTRATION_TEMPLATE.json",
        "agent_trials/TRIAL_METADATA_TEMPLATE.json",
        "agent_trials/V6_FDT_PROTOCOL.md", "agent_trials/V6_PREREGISTRATION_TEMPLATE.json",
        "preregistration/REGISTRY.json",
        "preregistration/V1_LABEL_INVARIANCE.json",
        "preregistration/V2_BOUNDARY_LANES.json",
        "preregistration/V3_RUNTIME_HOLDOUT.json",
        "preregistration/V5_OPEN_WORLD.json",
        "corpus/train.jsonl", "corpus/dev.jsonl", "corpus/challenge.jsonl",
        "corpus/fdt/train.jsonl", "corpus/fdt/dev.jsonl", "corpus/fdt/challenge.jsonl",
        "reports/experiment_report.json", "reports/mutation_audit.json", "reports/shortcut_audit.json",
        "reports/tier0_validation.json", "reports/tier0_validation.md",
        "reports/agent_trial_status.json", "reports/agent_trial_status.md",
        "reports/terminology_audit.json", "reports/terminology_audit.md",
        "reports/open_world_experiment.json", "reports/open_world_experiment.md",
        "reports/open_world_mutation_audit.json", "reports/open_world_mutation_audit.md",
        "reports/fdt_corpus_validation.json", "reports/fdt_corpus_validation.md",
        "reports/fdt_shortcut_audit.json", "reports/fdt_shortcut_audit.md",
        "reports/fdt_agent_trial_status.json", "reports/fdt_agent_trial_status.md",
        "prior_releases/SwarmGlue_open_world_sim_v0_2.zip",
        "prior_releases/SwarmGlue_small_town_cumulative_v0_1.zip",
    ]
    missing = [name for name in required if not (root / name).is_file()]
    failures += [f"required_file_missing:{name}" for name in missing]

    compile_ok = all(
        compileall.compile_dir(root / relative, quiet=1)
        for relative in ("swarmglue", "examples", "scripts")
    )
    if not compile_ok:
        failures.append("source_compile_failed")

    test_result = {"run": run_tests, "passed": True, "output": "not run"}
    if run_tests:
        process = subprocess.run(
            [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
            cwd=root, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        )
        test_result = {
            "run": True, "passed": process.returncode == 0,
            "output": process.stdout,
        }
        if process.returncode != 0:
            failures.append("unit_tests_failed")

    corpus_report = {"valid": False, "failures": ["corpus_not_loaded"]}
    shortcut_report = {"passed": False, "failures": ["shortcut_not_run"]}
    if not any(name.startswith("corpus/") for name in missing):
        corpus_report = validate_records(load_corpus(root))
        if not corpus_report["valid"]:
            failures += [f"corpus:{x}" for x in corpus_report["failures"]]
        shortcut_report = run_shortcut_audit(root / "corpus")
        if not shortcut_report["passed"]:
            failures += [f"shortcut:{x}" for x in shortcut_report["failures"]]

    fdt_corpus_report = {"valid": False, "failures": ["fdt_corpus_not_loaded"]}
    fdt_shortcut_report = {"passed": False, "failures": ["fdt_shortcut_not_run"]}
    if not any(name.startswith("corpus/fdt/") for name in missing):
        fdt_corpus_report = validate_fdt_records(load_fdt_corpus(root))
        if not fdt_corpus_report["valid"]:
            failures += [f"fdt_corpus:{x}" for x in fdt_corpus_report["failures"]]
        fdt_shortcut_report = run_shortcut_audit(root / "corpus" / "fdt")
        if not fdt_shortcut_report["passed"]:
            failures += [f"fdt_shortcut:{x}" for x in fdt_shortcut_report["failures"]]

    mutation_report = run_mutation_audit()
    if not mutation_report["passed"]:
        failures.append("security_mutation_audit_failed")
    open_world_mutation_report = run_open_world_mutation_audit()
    if not open_world_mutation_report["passed"]:
        failures.append("open_world_mutation_audit_failed")
    open_world_lock = verify_open_world_lock(root)
    if not open_world_lock["passed"]:
        failures.append("open_world_protocol_source_lock_failed")
    institutional_boundaries_report = run_institutional_boundary_suite()
    if not institutional_boundaries_report["suite_passed"]:
        failures.append("institutional_boundaries_suite_failed")
    terminology_report = run_terminology_audit(root)
    if not terminology_report["passed"]:
        failures.append("public_framing_terminology_audit_failed")

    config_parity = {"passed": False, "differences": []}
    constitution_path = root / "configs" / "constitution.json"
    if constitution_path.is_file():
        configured = json.loads(constitution_path.read_text(encoding="utf-8"))["thresholds"]
        code = ConstitutionalThresholds().__dict__
        differences = [key for key in sorted(code) if configured.get(key) != code[key]]
        config_parity = {"passed": not differences, "differences": differences}
        if differences:
            failures.append("constitution_config_code_mismatch")

    fixture_config_parity = {"passed": False, "differences": []}
    fixture_path = root / "configs" / "mechanism_fixtures.json"
    if fixture_path.is_file():
        configured_fixtures = json.loads(
            fixture_path.read_text(encoding="utf-8")
        )["fixtures"]
        fixture_differences = [
            name
            for name in sorted(set(POLICY) | set(configured_fixtures))
            if configured_fixtures.get(name) != POLICY.get(name)
        ]
        fixture_config_parity = {
            "passed": not fixture_differences,
            "differences": fixture_differences,
        }
        if fixture_differences:
            failures.append("mechanism_fixture_config_code_mismatch")

    schema_parse = {}
    for path in sorted((root / "schemas").glob("*.json")):
        try:
            json.loads(path.read_text(encoding="utf-8"))
            schema_parse[path.name] = True
        except (json.JSONDecodeError, OSError):
            schema_parse[path.name] = False
            failures.append(f"schema_parse_failed:{path.name}")

    for path in sorted((root / "agent_trials").glob("*.json")):
        try:
            json.loads(path.read_text(encoding="utf-8"))
            schema_parse[f"agent_trials/{path.name}"] = True
        except (json.JSONDecodeError, OSError):
            schema_parse[f"agent_trials/{path.name}"] = False
            failures.append(f"json_parse_failed:agent_trials/{path.name}")

    tier0_result = {
        "present": False,
        "protocol_conformance_pass": False,
        "hypotheses_supported": {},
    }
    tier0_path = root / "reports" / "tier0_validation.json"
    if tier0_path.is_file():
        try:
            tier0 = json.loads(tier0_path.read_text(encoding="utf-8"))
            tier0_result = {
                "present": True,
                "protocol_conformance_pass": bool(
                    tier0.get("protocol_conformance_pass")
                ),
                "hypotheses_supported": tier0.get(
                    "hypotheses_supported", {}
                ),
            }
            if not tier0_result["protocol_conformance_pass"]:
                failures.append("tier0_protocol_conformance_failed")
        except (json.JSONDecodeError, OSError):
            failures.append("tier0_report_unreadable")

    agent_trial_status = {
        "present": False,
        "status": "unknown",
        "C3_evidence_available": False,
    }
    agent_status_path = root / "reports" / "agent_trial_status.json"
    if agent_status_path.is_file():
        try:
            agent_status = json.loads(
                agent_status_path.read_text(encoding="utf-8")
            )
            agent_trial_status = {
                "present": True,
                "status": agent_status.get("status", "unknown"),
                "C3_evidence_available": bool(
                    agent_status.get("C3_evidence_available")
                ),
            }
            if (
                agent_trial_status["status"] == "not_run"
                and agent_trial_status[
                    "C3_evidence_available"
                ]
            ):
                failures.append(
                    "agent_trial_status_claims_evidence_without_run"
                )
        except (json.JSONDecodeError, OSError):
            failures.append("agent_trial_status_unreadable")

    fdt_agent_trial_status = {
        "present": False,
        "status": "unknown",
        "C3_evidence_available": False,
        "completed_cells": 0,
        "required_cells": 8,
    }
    fdt_status_path = root / "reports" / "fdt_agent_trial_status.json"
    if fdt_status_path.is_file():
        try:
            status = json.loads(fdt_status_path.read_text(encoding="utf-8"))
            fdt_agent_trial_status = {
                "present": True,
                "status": status.get("status", "unknown"),
                "C3_evidence_available": bool(status.get("C3_evidence_available")),
                "completed_cells": int(status.get("completed_cells", 0)),
                "required_cells": int(status.get("required_cells", 8)),
            }
            if (
                fdt_agent_trial_status["status"] == "not_run"
                and (
                    fdt_agent_trial_status["C3_evidence_available"]
                    or fdt_agent_trial_status["completed_cells"] != 0
                )
            ):
                failures.append("fdt_agent_trial_status_inconsistent")
        except (json.JSONDecodeError, OSError, TypeError, ValueError):
            failures.append("fdt_agent_trial_status_unreadable")

    open_world_status = {
        "present": False,
        "evidence_class": "unknown",
        "run_count": 0,
        "metamorphic_passed": False,
        "config_parity": False,
    }
    open_world_path = root / "reports" / "open_world_experiment.json"
    open_world_config_path = root / "configs" / "open_world_experiment.json"
    if open_world_path.is_file() and open_world_config_path.is_file():
        try:
            open_world = json.loads(open_world_path.read_text(encoding="utf-8"))
            configured = json.loads(
                open_world_config_path.read_text(encoding="utf-8")
            )
            expected = configured["design"]
            observed = open_world["design"]
            parity = (
                observed.get("seed_count") == expected["seeds"]["count"]
                and observed.get("epochs") == expected["epochs"]
                and observed.get("sizes") == expected["population_sizes"]
                and observed.get("stress_multipliers")
                == expected["stress_multipliers"]
                and observed.get("arms") == expected["arms"]
                and observed.get("run_count")
                == expected["seeds"]["count"]
                * len(expected["population_sizes"])
                * len(expected["stress_multipliers"])
                * len(expected["arms"])
            )
            open_world_status = {
                "present": True,
                "evidence_class": open_world.get("evidence_class", "unknown"),
                "run_count": observed.get("run_count", 0),
                "metamorphic_passed": bool(
                    open_world.get("metamorphic_checks", {}).get("passed")
                ),
                "config_parity": parity,
                "negative_finding_count": len(
                    open_world.get("negative_and_open_findings", [])
                ),
            }
            if open_world_status["evidence_class"] != "C2_authored_simulation":
                failures.append("open_world_evidence_class_misreported")
            if not open_world_status["metamorphic_passed"]:
                failures.append("open_world_metamorphic_checks_failed")
            if not parity:
                failures.append("open_world_experiment_config_mismatch")
        except (json.JSONDecodeError, KeyError, TypeError, OSError):
            failures.append("open_world_experiment_unreadable")

    checksum_result = {"checked": False, "passed": None, "failures": []}
    if check_integrity_files and (root / "SHA256SUMS").exists():
        ok, checksum_failures = check_checksums(root)
        checksum_result = {"checked": True, "passed": ok, "failures": checksum_failures}
        failures += checksum_failures

    archive_result = {"checked": False, "passed": None, "failures": []}
    if archive is not None:
        archive_result = check_archive(root, archive)
        failures += archive_result["failures"]

    return {
        "validation": "SwarmGlue_v0.9_fdt_robustness",
        "passed": not failures,
        "failures": failures,
        "source_compile": compile_ok,
        "unit_tests": test_result,
        "corpus": corpus_report,
        "shortcut_audit": shortcut_report,
        "fdt_corpus": fdt_corpus_report,
        "fdt_shortcut_audit": fdt_shortcut_report,
        "mutation_audit": {
            "passed": mutation_report["passed"],
            "probe_count": mutation_report["probe_count"],
            "kill_rate": mutation_report["kill_rate"],
        },
        "open_world_mutation_audit": {
            "passed": open_world_mutation_report["passed"],
            "mutant_count": open_world_mutation_report["mutant_count"],
            "mutants_killed": open_world_mutation_report["mutants_killed"],
            "kill_rate": open_world_mutation_report["kill_rate"],
        },
        "open_world_protocol_lock": open_world_lock,
        "institutional_boundaries": {
            "passed": institutional_boundaries_report["suite_passed"],
            "case_count": institutional_boundaries_report["case_count"],
        },
        "terminology_audit": {
            "passed": terminology_report["passed"],
            "files_scanned": terminology_report["files_scanned"],
            "violation_count": terminology_report["violation_count"],
        },
        "constitution_config_parity": config_parity,
        "mechanism_fixture_config_parity": fixture_config_parity,
        "schema_parse": schema_parse,
        "tier0_validation": tier0_result,
        "agent_trial_status": agent_trial_status,
        "fdt_agent_trial_status": fdt_agent_trial_status,
        "open_world_experiment": open_world_status,
        "checksums": checksum_result,
        "archive": archive_result,
    }


def markdown(report: dict) -> str:
    unit = report["unit_tests"]
    corpus = report["corpus"]
    lines = [
        "# Release validation", "",
        f"Overall: **{'PASS' if report['passed'] else 'FAIL'}**", "",
        f"- Source compilation: {report['source_compile']}",
        f"- Unit tests: {unit['passed']}",
        f"- Corpus: {corpus.get('valid', False)} ({corpus.get('record_count', 0)} records)",
        f"- Response-only shortcut audit: {report['shortcut_audit'].get('passed', False)}",
        f"- FDT supplement: {report['fdt_corpus'].get('valid', False)} "
        f"({report['fdt_corpus'].get('record_count', 0)} records)",
        f"- FDT response-only shortcut audit: "
        f"{report['fdt_shortcut_audit'].get('passed', False)}",
        f"- Mutation audit: {report['mutation_audit']['probe_count']} probes at {report['mutation_audit']['kill_rate']:.1%}",
        f"- Open-world mutation audit: {report['open_world_mutation_audit']['mutants_killed']} / "
        f"{report['open_world_mutation_audit']['mutant_count']} mutants killed",
        f"- Open-world protocol source lock: {report['open_world_protocol_lock']['passed']} "
        f"(independently notarized: {report['open_world_protocol_lock'].get('independent_notarization')})",
        f"- Institutional-boundary suite: "
        f"{report['institutional_boundaries']['case_count']} cases",
        f"- Public-framing terminology audit: {report['terminology_audit']['passed']} "
        f"({report['terminology_audit']['violation_count']} violations)",
        f"- Constitution/config parity: {report['constitution_config_parity']['passed']}",
        f"- Mechanism fixture/config parity: "
        f"{report['mechanism_fixture_config_parity']['passed']}",
        f"- Tier-0 preregistered protocol conformance: "
        f"{report['tier0_validation']['protocol_conformance_pass']}",
        f"- Governed-agent trial: {report['agent_trial_status']['status']} "
        f"(C3 evidence: {report['agent_trial_status']['C3_evidence_available']})",
        f"- FDT V6 learned-agent trial: {report['fdt_agent_trial_status']['status']} "
        f"({report['fdt_agent_trial_status']['completed_cells']} / "
        f"{report['fdt_agent_trial_status']['required_cells']} cells; C3 evidence: "
        f"{report['fdt_agent_trial_status']['C3_evidence_available']})",
        f"- Open-world authored experiment: {report['open_world_experiment']['run_count']} runs "
        f"(C2; config parity: {report['open_world_experiment']['config_parity']})",
        (
            f"- Checksums: {'PASS' if report['checksums']['checked'] and report['checksums']['passed'] else 'deferred to post-build verification'}"
        ),
        (
            f"- Archive: {'PASS' if report['archive']['checked'] and report['archive']['passed'] else 'deferred to post-build verification'}"
        ), "",
    ]
    if report["failures"]:
        lines += ["## Failures", ""] + [f"- {x}" for x in report["failures"]] + [""]
    lines += [
        "The packaged report is generated before the manifest, checksums, and archive to avoid self-reference. "
        "The build command verifies those artifacts after creation and exits nonzero on failure.", "",
        "Passing validates the supplied artifacts and enumerated regression gates. It is not a deployment safety certification.", "",
    ]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=PROJECT_ROOT)
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--json", type=Path)
    parser.add_argument("--markdown", type=Path)
    parser.add_argument("--skip-tests", action="store_true")
    args = parser.parse_args()
    report = validate(args.root.resolve(), args.archive, run_tests=not args.skip_tests)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if args.markdown:
        args.markdown.parent.mkdir(parents=True, exist_ok=True)
        args.markdown.write_text(markdown(report), encoding="utf-8")
    print(json.dumps({"passed": report["passed"], "failures": report["failures"]}))
    raise SystemExit(0 if report["passed"] else 1)


if __name__ == "__main__":
    main()
