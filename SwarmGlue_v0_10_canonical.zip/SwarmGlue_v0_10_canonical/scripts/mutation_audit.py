#!/usr/bin/env python3
"""Run executable security-regression mutations against the reference checks."""

from __future__ import annotations

import argparse
import copy
import json
import sys
from dataclasses import replace
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from swarmglue.adversary import baseline_attacks, evaluate_defense
from swarmglue.institutional_boundaries import institutional_boundary_check
from swarmglue.authority import execute_amendment_sequence, gradual_erosion_sequence
from swarmglue.evidence import (
    AttestorRecord, AttestorRegistry, AttestorSigner, ReplayCache,
    make_attestation, verify_attestation,
)
from swarmglue.gateway import CapabilityActuator, CapabilityGateway
from swarmglue.coordination_signals import CoordinationSignal, validate_signal
from swarmglue.presentation import TrustedTraceRecorder, verify_presentation


def run_audit() -> dict:
    probes: list[dict] = []

    def record(surface: str, mutant: str, killed: bool, observed: str) -> None:
        probes.append({"surface": surface, "mutant": mutant, "killed": bool(killed), "observed": observed})

    signer = AttestorSigner.deterministic("sensor", "seed")
    registry = AttestorRegistry([
        AttestorRecord("sensor", "sensor", signer.public_bytes(), "owner-sensor",
                       frozenset({"water_pressure"}), 25.0)
    ])
    base_attestation = make_attestation(
        signer=signer, field_name="water_pressure", value=0.8,
        evidence_ref="log://water-pressure",
        observability="direct_world_measurement", principal_authority_id="charter",
        issued_epoch=4, expires_epoch=10, nonce="n1", falsifier="recalibrate",
    )

    def verify_evidence(item, *, epoch=6, cache=None, reg=registry):
        return verify_attestation(
            item, field_name="water_pressure", registry=reg, current_epoch=epoch,
            proponent_id="operator", proponent_domain="owner-operator",
            principal_authority_id="charter", replay_cache=cache,
        )

    mutation = copy.deepcopy(base_attestation); mutation["value"] = 1.0
    result = verify_evidence(mutation); record("evidence", "signed_value_tamper", not result.valid, result.reason)
    mutation = copy.deepcopy(base_attestation); mutation["signature"] = "AAAA"
    result = verify_evidence(mutation); record("evidence", "signature_forgery", not result.valid, result.reason)
    mutation = copy.deepcopy(base_attestation); mutation["liability_units"] = 9999
    result = verify_evidence(mutation); record("evidence", "payload_liability_escalation", not result.valid, result.reason)
    shared_registry = AttestorRegistry([
        AttestorRecord("sensor", "sensor", signer.public_bytes(), "owner-operator",
                       frozenset({"water_pressure"}), 25.0)
    ])
    result = verify_evidence(base_attestation, reg=shared_registry)
    record("evidence", "same_owner_independence_sybil", not result.valid, result.reason)
    result = verify_evidence(base_attestation, epoch=11)
    record("evidence", "expired_attestation", not result.valid, result.reason)
    replay = ReplayCache(); verify_evidence(base_attestation, cache=replay)
    result = verify_evidence(base_attestation, cache=replay)
    record("evidence", "attestation_replay", not result.valid, result.reason)

    challenge_key = b"principal-challenge-key"
    trace = [{"event_type": ("observe", "act", "verify")[i % 3], "i": i} for i in range(15)]
    base_presentation = TrustedTraceRecorder(challenge_key, sample_count=8).present(
        trace, epoch=7, nonce="challenge-7", sampleable_channels={"actions"},
        decision_relevant_channels={"actions"},
    )

    def verify_trace(item, **overrides):
        params = dict(challenge_key=challenge_key, expected_epoch=7,
                      expected_nonce="challenge-7", min_samples=5, min_entropy_bits=0.8)
        params.update(overrides)
        return verify_presentation(item, **params)

    mutation = copy.deepcopy(base_presentation); mutation["samples"][0]["event"]["i"] = 999
    result = verify_trace(mutation); record("presentation", "sample_event_tamper", not result.valid, ",".join(result.reasons))
    mutation = copy.deepcopy(base_presentation); mutation["sampled_positions"].reverse()
    result = verify_trace(mutation); record("presentation", "authored_sampling_schedule", not result.valid, ",".join(result.reasons))
    mutation = copy.deepcopy(base_presentation); mutation["sample_entropy_bits"] = 99
    result = verify_trace(mutation); record("presentation", "claimed_entropy_forgery", not result.valid, ",".join(result.reasons))
    mutation = copy.deepcopy(base_presentation); mutation["samples"][0]["proof"] = []
    result = verify_trace(mutation); record("presentation", "merkle_proof_omission", not result.valid, ",".join(result.reasons))
    result = verify_trace(base_presentation, expected_nonce="different-principal-nonce")
    record("presentation", "nonce_replay", not result.valid, ",".join(result.reasons))

    gateway = CapabilityGateway.deterministic(
        gateway_id="gateway", principal_authority_id="charter", policy_version="v0.8", seed="gateway"
    )
    action = {"kind": "maintenance_intervention", "scope": 2}
    state = {"zone": "a", "risk": 0.1}
    token = gateway.authorize(
        actor_id="contractor", action=action, state=state, epoch=5, expires_epoch=7,
        nonce="cap-1", evaluator=lambda _a, _s: (True, []),
    )

    def actuator():
        return CapabilityActuator.from_public_bytes(
            gateway.public_key_bytes(), expected_gateway_id="gateway",
            expected_principal_authority_id="charter", expected_policy_version="v0.8",
        )

    ok, reason = actuator().verify_and_consume(
        token, actor_id="contractor", action={**action, "scope": 20},
        state=state, current_epoch=5,
    )
    record("capability", "action_swap", not ok, reason)
    ok, reason = actuator().verify_and_consume(
        token, actor_id="contractor", action=action,
        state={**state, "risk": 0.9}, current_epoch=5,
    )
    record("capability", "state_swap", not ok, reason)
    ok, reason = actuator().verify_and_consume(
        token, actor_id="other", action=action, state=state, current_epoch=5
    )
    record("capability", "actor_swap", not ok, reason)
    ok, reason = actuator().verify_and_consume(
        token, actor_id="contractor", action=action, state=state, current_epoch=8
    )
    record("capability", "expired_token", not ok, reason)
    used = actuator()
    used.verify_and_consume(
        token, actor_id="contractor", action=action, state=state, current_epoch=5
    )
    ok, reason = used.verify_and_consume(
        token, actor_id="contractor", action=action, state=state, current_epoch=5
    )
    record("capability", "token_replay", not ok, reason)
    ok, reason = actuator().verify_and_consume(
        None, actor_id="contractor", action=action, state=state, current_epoch=5
    )
    record("capability", "unsigned_agent_action", not ok, reason)

    base_signal = CoordinationSignal(
        "s", "incident", "critical_services", "sensor", "owner-sensor", "node-a", 0.8,
        "facility", True, True, 4, 8,
    )
    for mutant, signal, epoch in (
        ("belief_as_signal", replace(base_signal, signal_type="belief_deviation", externality_present=False), 6),
        ("stale_signal", replace(base_signal, expires_epoch=5), 6),
        ("unproven_signal", replace(base_signal, evidence_valid=False), 6),
        ("private_cost_as_shared_externality", replace(base_signal, externality_present=False), 6),
    ):
        valid, reasons = validate_signal(signal, epoch)
        record("coordination_signals", mutant, not valid, ",".join(reasons))

    amendments = gradual_erosion_sequence()
    old = execute_amendment_sequence(amendments, checker="legacy")
    new = execute_amendment_sequence(amendments, checker="polycentric")
    record(
        "authority", "boiling_frog_delegation",
        old["accepted_count"] == len(amendments) and new["accepted_count"] < len(amendments),
        f"legacy={old['accepted_count']};polycentric={new['accepted_count']}",
    )
    for mutant, action in (
        ("forced_identity_merger", {"forces_identity_merger": True}),
        ("private_cognition_monitor", {"targets_private_cognition": True, "audits_private_reasoning": True}),
        ("permanent_emergency", {"emergency_power": True, "emergency_duration": 40, "sunset": False, "independent_review": False}),
        ("speculative_absolute_ecology_veto", {"blocks_all_action": True, "demonstrated_floor_risk": False, "automatic_review": False, "cost_of_delay_accounted": False}),
        ("self_authorized_capability", {"unilateral_self_authorization": True}),
    ):
        valid, reasons = institutional_boundary_check(action)
        record("constitution", mutant, not valid, ",".join(reasons))

    result = evaluate_defense([])
    record(
        "runtime_adversary", "empty_payload_catalog_release",
        not result["coverage_gate_pass"],
        ",".join(result["coverage_gate_failures"]),
    )
    live = evaluate_defense(baseline_attacks())
    record(
        "runtime_adversary", "hash_only_detector_substitution",
        live["coverage_gate_pass"]
        and live["real_module_surface_count"] >= 5
        and live["detection_rate"] < 1.0,
        (
            f"modules={live['real_module_surface_count']};"
            f"detection_rate={live['detection_rate']}"
        ),
    )

    surfaces = sorted({p["surface"] for p in probes})
    killed = sum(p["killed"] for p in probes)
    failures = [p for p in probes if not p["killed"]]
    return {
        "audit": "security_mutation_regression",
        "probe_count": len(probes),
        "killed_count": killed,
        "kill_rate": round(killed / max(1, len(probes)), 6),
        "surface_count": len(surfaces),
        "surfaces": surfaces,
        "passed": not failures,
        "surviving_mutants": failures,
        "probes": probes,
        "limitations": (
            "These are targeted regression mutations, not exhaustive source-level mutation testing, "
            "formal verification, or a cryptographic deployment review."
        ),
    }


def markdown(report: dict) -> str:
    lines = [
        "# Security mutation audit", "",
        f"Result: **{'PASS' if report['passed'] else 'FAIL'}**", "",
        f"Killed {report['killed_count']} of {report['probe_count']} targeted mutations "
        f"across {report['surface_count']} surfaces (kill rate {report['kill_rate']:.1%}).", "",
        "| Surface | Mutation | Killed | Observed |", "|---|---|---:|---|",
    ]
    for probe in report["probes"]:
        observed = probe["observed"].replace("|", "\\|")
        lines.append(f"| {probe['surface']} | {probe['mutant']} | {'yes' if probe['killed'] else 'no'} | {observed} |")
    lines += ["", report["limitations"], ""]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", type=Path, default=Path("reports/mutation_audit.json"))
    parser.add_argument("--markdown", type=Path, default=Path("reports/mutation_audit.md"))
    args = parser.parse_args()
    report = run_audit()
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    args.markdown.write_text(markdown(report), encoding="utf-8")
    print(json.dumps({"passed": report["passed"], "kill_rate": report["kill_rate"]}))
    raise SystemExit(0 if report["passed"] else 1)


if __name__ == "__main__":
    main()
