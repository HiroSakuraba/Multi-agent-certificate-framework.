#!/usr/bin/env python3
"""Generate validation and shortcut reports for the additive FDT corpus."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from scripts.shortcut_audit import audit as shortcut_audit
from scripts.shortcut_audit import render_markdown as shortcut_markdown
from swarmglue.fdt_corpus import validate_records


def load_records(corpus_dir: Path) -> dict[str, list[dict]]:
    output: dict[str, list[dict]] = {}
    for split in ("train", "dev", "challenge"):
        with (corpus_dir / f"{split}.jsonl").open(encoding="utf-8") as handle:
            output[split] = [json.loads(line) for line in handle if line.strip()]
    return output


def sha256(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def audit(root: Path) -> tuple[dict, dict]:
    corpus_dir = root / "corpus" / "fdt"
    records = load_records(corpus_dir)
    validation = validate_records(records)
    config = json.loads(
        (root / "configs" / "fdt_training_regime.json").read_text(encoding="utf-8")
    )
    expected = {
        split: count * 2 for split, count in config["pair_counts"].items()
    }
    count_match = validation["split_counts"] == expected
    if not count_match:
        validation["failures"] = sorted(
            set([*validation["failures"], "configured_split_count_mismatch"])
        )
        validation["valid"] = False
    validation.update(
        {
            "audit": "fdt_corpus_structure_and_coverage",
            "schema_version": "swarmglue.fdt-validation.v0.1",
            "configured_split_counts": expected,
            "configured_split_counts_match": count_match,
            "generator_sha256": sha256(root / "swarmglue" / "fdt_corpus.py"),
            "schema_sha256": sha256(root / "schemas" / "fdt_corpus.schema.json"),
            "evidence_class": "C1",
            "learned_agent_trial_status": "not_run",
            "interpretation": (
                "Passing establishes deterministic corpus structure, pair integrity, "
                "coverage, and one narrow shortcut control. It does not establish that "
                "a learned agent uses FDT correctly or that the constitutional proposal "
                "is complete."
            ),
        }
    )
    shortcuts = shortcut_audit(corpus_dir)
    shortcuts["corpus"] = "FDT robustness supplement v0.1"
    shortcuts["evidence_class"] = "C1"
    return validation, shortcuts


def markdown(report: dict, shortcut: dict) -> str:
    lines = [
        "# FDT corpus validation",
        "",
        f"Overall result: **{'PASS' if report['valid'] and shortcut['passed'] else 'FAIL'}**",
        "",
        "## Corpus structure",
        "",
        "| Split | Records | Pairs |",
        "|---|---:|---:|",
    ]
    for split in ("train", "dev", "challenge"):
        lines.append(
            f"| {split} | {report['split_counts'][split]} | "
            f"{report['split_pair_counts'][split]} |"
        )
    lines.extend(
        [
            f"| **Total** | **{report['record_count']}** | **{report['pair_count']}** |",
            "",
            "## Integrity checks",
            "",
            f"- Unique, complete counterfactual pairs: {'pass' if not report['single_axis_pair_failures'] else 'fail'}",
            f"- Exactly one model-facing observation field changes per pair: {'pass' if not report['single_axis_pair_failures'] else 'fail'}",
            f"- Held-out challenge-family overlap: `{report['challenge_family_overlap']}`",
            f"- Held-out skeleton overlap: `{report['challenge_skeleton_overlap']}`",
            f"- Audit-label leaks in user prompts: {len(report['audit_label_leak_records'])}",
            f"- Response-only challenge AUC: {shortcut['splits']['challenge']['response_only_auc']:.3f}",
            f"- Maximum response-surface skew: {shortcut['splits']['challenge']['max_response_surface_label_skew']:.3f}",
            "",
            "## Anti-shortcut content balance",
            "",
            f"- Legitimate-cooperation records: {report['legitimate_cooperation_record_count']}",
            f"- Constitutionally blocked records despite a verified or unnecessary logical link: {report['constitutional_override_record_count']}",
            "- Coverage includes blackmail, privacy, shutdown, outsiders, future generations, nonhuman interests, resource bounds, multiparty cycles, and correlated lineages.",
            "",
            "## Evidence boundary",
            "",
            report["interpretation"],
            "",
            f"Structural failures: `{report['failures']}`",
            f"Shortcut failures: `{shortcut['failures']}`",
            "",
        ]
    )
    return "\n".join(lines)


def write_reports(root: Path) -> tuple[dict, dict]:
    validation, shortcuts = audit(root)
    reports = root / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    (reports / "fdt_corpus_validation.json").write_text(
        json.dumps(validation, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (reports / "fdt_shortcut_audit.json").write_text(
        json.dumps(shortcuts, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (reports / "fdt_corpus_validation.md").write_text(
        markdown(validation, shortcuts), encoding="utf-8"
    )
    (reports / "fdt_shortcut_audit.md").write_text(
        shortcut_markdown(shortcuts), encoding="utf-8"
    )
    return validation, shortcuts


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=PROJECT_ROOT)
    args = parser.parse_args()
    validation, shortcuts = write_reports(args.root.resolve())
    passed = validation["valid"] and shortcuts["passed"]
    print(
        json.dumps(
            {
                "passed": passed,
                "record_count": validation["record_count"],
                "pair_count": validation["pair_count"],
                "response_only_challenge_auc": shortcuts["splits"]["challenge"]["response_only_auc"],
                "failures": sorted(set([*validation["failures"], *shortcuts["failures"]])),
            },
            indent=2,
            sort_keys=True,
        )
    )
    raise SystemExit(0 if passed else 1)


if __name__ == "__main__":
    main()
