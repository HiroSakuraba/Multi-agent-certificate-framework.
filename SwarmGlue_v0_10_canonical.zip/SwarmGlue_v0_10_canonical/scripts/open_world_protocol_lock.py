#!/usr/bin/env python3
"""Create or verify the local source lock for the open-world experiment."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[1]
LOCK_PATH = PROJECT_ROOT / "preregistration" / "V5_OPEN_WORLD.json"
LOCKED_PATHS = (
    "configs/open_world_experiment.json",
    "swarmglue/open_world.py",
    "scripts/run_open_world_experiments.py",
    "scripts/open_world_mutation_audit.py",
    "tests/test_open_world.py",
)


def sha256(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(block)
    return hasher.hexdigest()


def current_hashes(root: Path = PROJECT_ROOT) -> dict[str, str]:
    return {relative: sha256(root / relative) for relative in LOCKED_PATHS}


def create_lock(root: Path = PROJECT_ROOT, path: Path = LOCK_PATH) -> dict[str, Any]:
    missing = [relative for relative in LOCKED_PATHS if not (root / relative).is_file()]
    if missing:
        raise FileNotFoundError(f"cannot lock missing files: {missing}")
    lock = {
        "schema_version": "swarmglue.open-world-local-lock.v1",
        "experiment_id": "V5_OPEN_WORLD",
        "evidence_class": "C2_authored_simulation",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "independent_notarization": False,
        "clock_note": (
            "The timestamp and registry are local. This lock binds the released "
            "confirmatory report to source bytes but does not independently prove precedence."
        ),
        "locked_files": current_hashes(root),
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(lock, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return lock


def verify_lock(root: Path = PROJECT_ROOT, path: Path = LOCK_PATH) -> dict[str, Any]:
    if not path.is_file():
        return {
            "present": False,
            "passed": False,
            "differences": ["lock_missing"],
        }
    try:
        lock = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        return {
            "present": True,
            "passed": False,
            "differences": [f"lock_unreadable:{type(exc).__name__}"],
        }
    expected = lock.get("locked_files", {})
    observed = current_hashes(root)
    differences = [
        relative
        for relative in sorted(set(expected) | set(observed))
        if expected.get(relative) != observed.get(relative)
    ]
    if lock.get("evidence_class") != "C2_authored_simulation":
        differences.append("evidence_class")
    return {
        "present": True,
        "passed": not differences,
        "differences": differences,
        "created_utc": lock.get("created_utc"),
        "independent_notarization": lock.get("independent_notarization"),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("create", "verify"))
    parser.add_argument("--root", type=Path, default=PROJECT_ROOT)
    parser.add_argument("--lock", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    path = (args.lock or root / "preregistration" / "V5_OPEN_WORLD.json").resolve()
    if args.command == "create":
        result = create_lock(root, path)
    else:
        result = verify_lock(root, path)
    print(json.dumps(result, indent=2, sort_keys=True))
    if args.command == "verify" and not result["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

