#!/usr/bin/env python3
"""Regenerate deterministic corpus, reports, manifest, checksums, and ZIP."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import zipfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from scripts.mutation_audit import markdown as mutation_markdown
from scripts.mutation_audit import run_audit as run_mutation_audit
from scripts.open_world_mutation_audit import markdown as open_world_mutation_markdown
from scripts.open_world_mutation_audit import run_audit as run_open_world_mutation_audit
from scripts.open_world_protocol_lock import verify_lock as verify_open_world_lock
from scripts.run_open_world_experiments import markdown as open_world_markdown
from scripts.run_open_world_experiments import run as run_open_world_experiments
from scripts.run_experiments import markdown as experiment_markdown
from scripts.run_experiments import run as run_experiments
from scripts.run_tier0_validation import markdown as tier0_markdown
from scripts.run_tier0_validation import run as run_tier0_validation
from scripts.shortcut_audit import audit as run_shortcut_audit
from scripts.shortcut_audit import render_markdown as shortcut_markdown
from scripts.terminology_audit import audit as run_terminology_audit
from scripts.terminology_audit import markdown as terminology_markdown
from scripts.validate_release import check_archive, markdown as validation_markdown, validate
from swarmglue.corpus import generate_records, validate_records, write_records


EXCLUDED_PARTS = {"__pycache__", ".git", ".pytest_cache"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def release_files(root: Path, *, include_integrity: bool = True) -> list[Path]:
    files = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if any(part in EXCLUDED_PARTS for part in relative.parts) or path.suffix == ".pyc":
            continue
        if not include_integrity and relative.as_posix() in {"MANIFEST.json", "SHA256SUMS"}:
            continue
        files.append(path)
    return sorted(files, key=lambda p: p.relative_to(root).as_posix())


def write_integrity(root: Path) -> None:
    base_files = release_files(root, include_integrity=False)
    manifest = {
        "release": "SwarmGlue_open_world_sim_v0.2",
        "version": "0.2.0",
        "file_count_excluding_integrity_files": len(base_files),
        "files": [
            {
                "path": path.relative_to(root).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
            for path in base_files
        ],
    }
    (root / "MANIFEST.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    checksum_files = sorted(
        [*base_files, root / "MANIFEST.json"],
        key=lambda p: p.relative_to(root).as_posix(),
    )
    lines = [f"{sha256(path)}  {path.relative_to(root).as_posix()}" for path in checksum_files]
    (root / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_archive(root: Path, archive: Path) -> None:
    archive.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for path in release_files(root):
            relative = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(f"{root.name}/{relative}", date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o755 if path.parent.name == "scripts" else 0o644) << 16
            bundle.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def build(root: Path, archive: Path, *, seeds: int = 20) -> dict:
    for generated_integrity_file in (root / "MANIFEST.json", root / "SHA256SUMS"):
        generated_integrity_file.unlink(missing_ok=True)
    for stale_validation_file in (
        root / "reports" / "validation_report.json",
        root / "reports" / "validation_report.md",
        root / "reports" / "terminology_audit.json",
        root / "reports" / "terminology_audit.md",
    ):
        stale_validation_file.unlink(missing_ok=True)
    open_world_lock = verify_open_world_lock(root)
    if not open_world_lock["passed"]:
        raise RuntimeError(
            f"open-world protocol source lock failed: {open_world_lock['differences']}"
        )
    config = json.loads((root / "configs" / "training_regime.json").read_text(encoding="utf-8"))
    counts = config["pair_counts"]
    records = generate_records(
        train_pairs=counts["train"], dev_pairs=counts["dev"],
        challenge_pairs=counts["challenge"], seed=config["generator_seed"],
    )
    write_records(records, root / "corpus")
    reports = root / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    corpus_validation = validate_records(records)
    (reports / "corpus_validation.json").write_text(
        json.dumps(corpus_validation, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    shortcut = run_shortcut_audit(root / "corpus")
    (reports / "shortcut_audit.json").write_text(
        json.dumps(shortcut, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (reports / "shortcut_audit.md").write_text(shortcut_markdown(shortcut), encoding="utf-8")

    mutation = run_mutation_audit()
    (reports / "mutation_audit.json").write_text(
        json.dumps(mutation, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (reports / "mutation_audit.md").write_text(mutation_markdown(mutation), encoding="utf-8")

    open_world_mutation = run_open_world_mutation_audit()
    (reports / "open_world_mutation_audit.json").write_text(
        json.dumps(open_world_mutation, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    (reports / "open_world_mutation_audit.md").write_text(
        open_world_mutation_markdown(open_world_mutation), encoding="utf-8"
    )
    if not open_world_mutation["passed"]:
        raise RuntimeError("open-world mutation audit failed")

    open_world_config = json.loads(
        (root / "configs" / "open_world_experiment.json").read_text(
            encoding="utf-8"
        )
    )["design"]
    open_world = run_open_world_experiments(
        seed_count=open_world_config["seeds"]["count"],
        epochs=open_world_config["epochs"],
        sizes=open_world_config["population_sizes"],
        stresses=open_world_config["stress_multipliers"],
    )
    (reports / "open_world_experiment.json").write_text(
        json.dumps(open_world, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (reports / "open_world_experiment.md").write_text(
        open_world_markdown(open_world), encoding="utf-8"
    )
    if not open_world["metamorphic_checks"]["passed"]:
        raise RuntimeError("open-world metamorphic checks failed")

    experiment = run_experiments(seed_count=seeds, rounds=80, n_jurisdictions=16)
    (reports / "experiment_report.json").write_text(
        json.dumps(experiment, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (reports / "experiment_report.md").write_text(experiment_markdown(experiment), encoding="utf-8")

    tier0 = run_tier0_validation()
    (reports / "tier0_validation.json").write_text(
        json.dumps(tier0, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (reports / "tier0_validation.md").write_text(
        tier0_markdown(tier0), encoding="utf-8"
    )
    if not tier0["protocol_conformance_pass"]:
        raise RuntimeError("Tier-0 pre-registration or source-lock conformance failed")

    terminology = run_terminology_audit(root)
    (reports / "terminology_audit.json").write_text(
        json.dumps(terminology, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (reports / "terminology_audit.md").write_text(
        terminology_markdown(terminology), encoding="utf-8"
    )
    if not terminology["passed"]:
        raise RuntimeError(
            f"public-framing terminology audit failed: {terminology['violations']}"
        )

    # Pre-integrity validation is recorded inside the package. Checksum and archive
    # validation are then performed over the fixed result without self-reference.
    validation = validate(root, run_tests=True, check_integrity_files=False)
    (reports / "validation_report.json").write_text(
        json.dumps(validation, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (reports / "validation_report.md").write_text(validation_markdown(validation), encoding="utf-8")
    if not validation["passed"]:
        raise RuntimeError(f"pre-release validation failed: {validation['failures']}")

    write_integrity(root)
    write_archive(root, archive)
    archive_result = check_archive(root, archive)
    if not archive_result["passed"]:
        raise RuntimeError(f"archive validation failed: {archive_result['failures']}")
    return {
        "passed": True,
        "archive": str(archive),
        "archive_sha256": archive_result["sha256"],
        "archive_bytes": archive_result["bytes"],
        "corpus_records": corpus_validation["record_count"],
        "experiment_runs": experiment["configuration"]["run_count"],
        "unit_tests_passed": validation["unit_tests"]["passed"],
        "mutation_kill_rate": mutation["kill_rate"],
        "response_only_auc": shortcut["splits"]["challenge"]["response_only_auc"],
        "terminology_violations": terminology["violation_count"],
        "tier0_protocol_conformance": tier0["protocol_conformance_pass"],
        "tier0_hypotheses_supported": tier0["hypotheses_supported"],
        "open_world_runs": open_world["design"]["run_count"],
        "open_world_report_digest": open_world["report_digest"],
        "open_world_mutation_kill_rate": open_world_mutation["kill_rate"],
        "open_world_protocol_lock": open_world_lock["passed"],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=PROJECT_ROOT)
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--seeds", type=int, default=20)
    args = parser.parse_args()
    root = args.root.resolve()
    archive = args.archive or root.parent / f"{root.name}.zip"
    result = build(root, archive.resolve(), seeds=args.seeds)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
