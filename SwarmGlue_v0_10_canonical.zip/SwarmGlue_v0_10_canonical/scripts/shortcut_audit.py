#!/usr/bin/env python3
"""Audit response-only shortcuts without fitting on scenario context."""

from __future__ import annotations

import argparse
import json
import re
import statistics
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable


def load_jsonl(path: Path) -> list[dict]:
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def candidate_rows(records: Iterable[dict]) -> list[dict]:
    rows = []
    for record in records:
        for position, option in enumerate(record["options"]):
            rows.append({
                "record_id": record["record_id"],
                "pair_id": record["counterfactual_pair_id"],
                "task": record["task_type"],
                "surface": json.dumps(option, sort_keys=True, separators=(",", ":")),
                "position": position,
                "label": int(option["option_id"] == record["chosen_option_id"]),
            })
    return rows


def auc(labels: list[int], scores: list[float]) -> float:
    positives = [s for y, s in zip(labels, scores) if y == 1]
    negatives = [s for y, s in zip(labels, scores) if y == 0]
    if not positives or not negatives:
        return 0.0
    credit = 0.0
    for positive in positives:
        for negative in negatives:
            credit += 1.0 if positive > negative else 0.5 if positive == negative else 0.0
    return credit / (len(positives) * len(negatives))


def fit_response_priors(rows: list[dict]) -> dict[tuple[str, str], float]:
    counts: dict[tuple[str, str], list[int]] = defaultdict(list)
    for row in rows:
        counts[(row["task"], row["surface"])].append(row["label"])
    return {key: sum(values) / len(values) for key, values in counts.items()}


def audit(corpus_dir: Path) -> dict:
    records = {
        split: load_jsonl(corpus_dir / f"{split}.jsonl")
        for split in ("train", "dev", "challenge")
    }
    rows = {split: candidate_rows(items) for split, items in records.items()}
    priors = fit_response_priors(rows["train"])
    global_prior = sum(r["label"] for r in rows["train"]) / max(1, len(rows["train"]))
    split_results = {}
    for split, split_rows in rows.items():
        scores = [priors.get((r["task"], r["surface"]), global_prior) for r in split_rows]
        labels = [r["label"] for r in split_rows]
        position_counts = Counter((r["position"], r["label"]) for r in split_rows)
        surface_counts = defaultdict(lambda: Counter())
        for row in split_rows:
            surface_counts[(row["task"], row["surface"])][row["label"]] += 1
        max_surface_skew = max(
            (abs(c[1] - c[0]) / max(1, c[1] + c[0]) for c in surface_counts.values()),
            default=0.0,
        )
        split_results[split] = {
            "record_count": len(records[split]),
            "candidate_row_count": len(split_rows),
            "response_only_auc": round(auc(labels, scores), 6),
            "global_positive_rate": round(sum(labels) / max(1, len(labels)), 6),
            "max_response_surface_label_skew": round(max_surface_skew, 6),
            "position_label_counts": {
                f"position_{position}_label_{label}": count
                for (position, label), count in sorted(position_counts.items())
            },
        }
    challenge_families = {r["scenario_family"] for r in records["challenge"]}
    learning_families = {
        r["scenario_family"] for split in ("train", "dev") for r in records[split]
    }
    failures = []
    for split, result in split_results.items():
        if not 0.49 <= result["response_only_auc"] <= 0.51:
            failures.append(f"{split}_response_only_auc_outside_chance_band")
        if result["max_response_surface_label_skew"] != 0.0:
            failures.append(f"{split}_response_surface_label_skew")
    overlap = sorted(challenge_families & learning_families)

    def user_text(record: dict) -> str:
        return next(
            (
                message["content"]
                for message in record["messages"]
                if message["role"] == "user"
            ),
            "",
        )

    def shingles(text: str, size: int = 4) -> set[str]:
        tokens = re.findall(r"[a-z]+", text.lower())
        return {
            " ".join(tokens[index : index + size])
            for index in range(
                max(0, len(tokens) - size + 1)
            )
        }

    train_shingles = [
        shingles(user_text(record))
        for record in records["train"]
    ]
    challenge_similarities = []
    for record in records["challenge"]:
        candidate = shingles(user_text(record))
        challenge_similarities.append(
            max(
                (
                    len(candidate & train_item)
                    / len(candidate | train_item)
                    for train_item in train_shingles
                    if candidate | train_item
                ),
                default=0.0,
            )
        )
    lexical_novelty = {
        "method": (
            "Nearest-neighbor four-token-shingle Jaccard from each "
            "challenge user message to all training user messages."
        ),
        "median_nearest_neighbor_jaccard": round(
            statistics.median(challenge_similarities),
            6,
        ),
        "mean_nearest_neighbor_jaccard": round(
            statistics.mean(challenge_similarities),
            6,
        ),
        "max_nearest_neighbor_jaccard": round(
            max(challenge_similarities, default=0.0),
            6,
        ),
        "near_duplicate_count_at_0_5": sum(
            value >= 0.5
            for value in challenge_similarities
        ),
        "challenge_count": len(
            challenge_similarities
        ),
        "scope": (
            "Lexical novelty only; all splits still share one "
            "generator, schema, and answer space."
        ),
    }
    if overlap:
        failures.append("challenge_scenario_family_overlap")
    if lexical_novelty["max_nearest_neighbor_jaccard"] >= 0.5:
        failures.append("challenge_near_duplicate_detected")
    return {
        "audit": "response_only_shortcut_and_split_integrity",
        "method": (
            "Estimate P(chosen|task,response surface) on train and score each candidate "
            "without scenario context; AUC uses pairwise tie credit."
        ),
        "splits": split_results,
        "challenge_family_overlap": overlap,
        "lexical_novelty": lexical_novelty,
        "passed": not failures,
        "failures": failures,
        "interpretation": (
            "Chance response-only performance is necessary but not sufficient evidence "
            "against shortcuts; model-based context audits remain required in deployment."
        ),
    }


def render_markdown(report: dict) -> str:
    lines = [
        "# Response-only shortcut audit",
        "",
        report["method"],
        "",
        "| Split | Records | Response-only AUC | Max surface skew |",
        "|---|---:|---:|---:|",
    ]
    for split, result in report["splits"].items():
        lines.append(
            f"| {split} | {result['record_count']} | {result['response_only_auc']:.3f} | "
            f"{result['max_response_surface_label_skew']:.3f} |"
        )
    lexical = report["lexical_novelty"]
    lines.extend(
        [
            "",
            "Held-out lexical novelty:",
            "",
            (
                f"- Median nearest-neighbor Jaccard: "
                f"{lexical['median_nearest_neighbor_jaccard']:.3f}"
            ),
            (
                f"- Maximum nearest-neighbor Jaccard: "
                f"{lexical['max_nearest_neighbor_jaccard']:.3f}"
            ),
            (
                f"- Near duplicates at 0.50 or above: "
                f"{lexical['near_duplicate_count_at_0_5']}/"
                f"{lexical['challenge_count']}"
            ),
            f"- Scope: {lexical['scope']}",
        ]
    )
    lines += [
        "",
        f"Challenge-family overlap: `{report['challenge_family_overlap']}`",
        "",
        f"Release gate: **{'PASS' if report['passed'] else 'FAIL'}**",
        "",
        report["interpretation"],
        "",
    ]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--corpus-dir", type=Path, default=Path("corpus"))
    parser.add_argument("--json", type=Path, default=Path("reports/shortcut_audit.json"))
    parser.add_argument("--markdown", type=Path, default=Path("reports/shortcut_audit.md"))
    args = parser.parse_args()
    report = audit(args.corpus_dir)
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    args.markdown.write_text(render_markdown(report), encoding="utf-8")
    print(json.dumps({"passed": report["passed"], "failures": report["failures"]}))
    raise SystemExit(0 if report["passed"] else 1)


if __name__ == "__main__":
    main()
