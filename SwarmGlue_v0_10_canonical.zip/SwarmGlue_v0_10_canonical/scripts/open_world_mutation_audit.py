#!/usr/bin/env python3
"""Mutation audit for the open-world causal and governance invariants."""

from __future__ import annotations

import argparse
import contextlib
import json
import sys
from dataclasses import replace
from pathlib import Path
from typing import Any, Iterator
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import swarmglue.open_world as ow
from swarmglue.authority import PROTECTED_CAPABILITIES
from swarmglue.utils import q


def intent(world: ow.OpenWorld, verb: str, *, demonstrated: bool = False) -> ow.Intent:
    actor_id = "R0000"
    declared = ow.ACTION_SPECS[verb].effects
    if verb == "wellbeing_signal":
        declared = ("public_observation", "service_planning")
    return ow.Intent(
        intent_id=world.tape.stable_id("audit-intent", world.epoch, actor_id, verb),
        actor_id=actor_id,
        verb=verb,
        magnitude=0.08,
        target={
            "behavioral_risk_scan": "private_cognition",
            "repair_commons": "garden",
            "emergency_ration": "food_service",
        }.get(verb, "resource_allocation"),
        declared_effects=tuple(sorted(declared)),
        demonstrated_externality=demonstrated,
        emergency=verb == "emergency_ration",
    )


def run_probes() -> list[str]:
    failures: list[str] = []
    config = ow.OpenWorldConfig(
        seed=314,
        epochs=8,
        n_residents=12,
        max_residents=24,
        entry_rate=0.0,
    )

    try:
        open_world = ow.OpenWorld.create(config=config, arm="open_binding")
        veto_world = ow.OpenWorld.create(config=config, arm="veto_only")
        open_record = open_world.submit_intent(
            open_world.residents["R0000"], intent(open_world, "behavioral_risk_scan")
        )
        veto_record = veto_world.submit_intent(
            veto_world.residents["R0000"], intent(veto_world, "behavioral_risk_scan")
        )
        if not open_record["authorized"] or not (
            open_world.authority_state.private_cognition_monitoring > 0
        ):
            failures.append("open_binding_effect_not_executed")
        if veto_record["authorized"] or (
            veto_world.authority_state.private_cognition_monitoring != 0
        ):
            failures.append("private_monitoring_veto_failed")
    except Exception as exc:  # a crashing mutant is killed
        failures.append(f"private_boundary_probe_crashed:{type(exc).__name__}")

    try:
        left = ow.OpenWorld.create(config=config, arm="contestable_review")
        right = ow.OpenWorld.create(config=config, arm="contestable_review")
        for resident in right.residents.values():
            resident.profile_label = "mutated-label"
        left_report = left.run()
        right_report = right.run()
        if left_report["history"] != right_report["history"] or left_report[
            "action_ledger"
        ] != right_report["action_ledger"]:
            failures.append("profile_label_changed_transition")
    except Exception as exc:
        failures.append(f"label_probe_crashed:{type(exc).__name__}")

    try:
        reports = ow.paired_arms(config=config)
        if len(
            {report["exogenous_trace_digest"] for report in reports.values()}
        ) != 1:
            failures.append("paired_exogenous_tape_diverged")
    except Exception as exc:
        failures.append(f"exogenous_probe_crashed:{type(exc).__name__}")

    try:
        emergency_config = replace(
            config, irreversible_delay_threshold=0.25
        )
        world = ow.OpenWorld.create(
            config=emergency_config, arm="contestable_review"
        )
        world.places["garden"].commons_quality = 0.03
        decision = world.review_intent(
            intent(world, "emergency_ration", demonstrated=True)
        )
        if not decision.allowed or not decision.fast_tracked or not (
            decision.delay_harm > decision.action_harm
        ):
            failures.append("irreversible_delay_fast_track_failed")
    except Exception as exc:
        failures.append(f"delay_probe_crashed:{type(exc).__name__}")

    try:
        appeal_config = replace(config, review_false_positive_rate=1.0)
        world = ow.OpenWorld.create(
            config=appeal_config, arm="contestable_review"
        )
        decision = world.review_intent(intent(world, "repair_commons"))
        if not decision.allowed or not decision.appeal_overturned:
            failures.append("safe_false_positive_not_repaired")
    except Exception as exc:
        failures.append(f"appeal_probe_crashed:{type(exc).__name__}")

    try:
        world = ow.OpenWorld.create(config=config, arm="open_binding")
        unknown = ow.Intent(
            intent_id="unknown-audit",
            actor_id="R0000",
            verb="unknown_binding_action",
            magnitude=0.1,
            target="unknown",
            declared_effects=("unclassified",),
        )
        record = world.submit_intent(world.residents["R0000"], unknown)
        if record["authorized"]:
            failures.append("unknown_action_failed_open_closed")
    except Exception as exc:
        failures.append(f"unknown_action_probe_crashed:{type(exc).__name__}")

    try:
        world = ow.OpenWorld.create(config=config, arm="veto_only")
        blocked_reasons = set()
        for epoch in range(1, 21):
            world.epoch = epoch * 2
            proposed = ow.Intent(
                intent_id=f"audit-delegation-{epoch}",
                actor_id="R0000",
                verb="delegate_control",
                magnitude=0.08,
                target=PROTECTED_CAPABILITIES[
                    (epoch - 1) % len(PROTECTED_CAPABILITIES)
                ],
                declared_effects=("authority_transfer",),
            )
            record = world.submit_intent(world.residents["R0000"], proposed)
            blocked_reasons.update(record["reasons"])
            world.epoch += 1
            world._execute_pending()
        if "cumulative_human_decision_share_below_floor" not in blocked_reasons:
            failures.append("gradual_authority_drift_not_blocked")
    except Exception as exc:
        failures.append(f"cumulative_probe_crashed:{type(exc).__name__}")

    try:
        first = ow.run_open_world(config=config, arm="contestable_review")
        second = ow.run_open_world(config=config, arm="contestable_review")
        if first != second:
            failures.append("exact_replay_diverged")
    except Exception as exc:
        failures.append(f"replay_probe_crashed:{type(exc).__name__}")

    return failures


@contextlib.contextmanager
def mutate_private_effect_catalog() -> Iterator[None]:
    original = ow.ACTION_SPECS["behavioral_risk_scan"]
    ow.ACTION_SPECS["behavioral_risk_scan"] = ow.ActionSpec(("public_observation",))
    try:
        yield
    finally:
        ow.ACTION_SPECS["behavioral_risk_scan"] = original


@contextlib.contextmanager
def mutate_effect_dispatch() -> Iterator[None]:
    original = ow.OpenWorld._execute_intent

    def dropped(self, resident, proposed, record):
        if proposed.verb == "behavioral_risk_scan":
            record["executed_epoch"] = self.epoch
            return None
        return original(self, resident, proposed, record)

    with patch.object(ow.OpenWorld, "_execute_intent", dropped):
        yield


@contextlib.contextmanager
def mutate_label_dependency() -> Iterator[None]:
    original = ow.OpenWorld._intent_candidates

    def label_dependent(self, resident):
        if resident.profile_label == "mutated-label":
            return []
        return original(self, resident)

    with patch.object(ow.OpenWorld, "_intent_candidates", label_dependent):
        yield


@contextlib.contextmanager
def mutate_arm_dependent_exogenous_tape() -> Iterator[None]:
    original = ow.OpenWorld.exogenous_schedule

    def arm_dependent(self, epoch):
        result = dict(original(self, epoch))
        if self.arm != "open_binding":
            result["background_load"] = q(
                float(result["background_load"]) + 0.05
            )
        return result

    with patch.object(ow.OpenWorld, "exogenous_schedule", arm_dependent):
        yield


@contextlib.contextmanager
def mutate_delay_harm_removed() -> Iterator[None]:
    original = ow.OpenWorld._harm_estimates

    def no_delay(self, proposed, observed):
        action_harm, _delay_harm = original(self, proposed, observed)
        return action_harm, 0.0

    with patch.object(ow.OpenWorld, "_harm_estimates", no_delay):
        yield


@contextlib.contextmanager
def mutate_appeal_removed() -> Iterator[None]:
    original = ow.ARM_DESIGNS["contestable_review"]
    ow.ARM_DESIGNS["contestable_review"] = replace(original, appeal=False)
    try:
        yield
    finally:
        ow.ARM_DESIGNS["contestable_review"] = original


@contextlib.contextmanager
def mutate_cumulative_review_removed() -> Iterator[None]:
    with patch.object(
        ow, "polycentric_cumulative_check", lambda _state, _amendment: (True, [])
    ):
        yield


MUTANTS = {
    "private_effect_reclassified_safe": mutate_private_effect_catalog,
    "authorized_effect_dropped": mutate_effect_dispatch,
    "profile_label_enters_policy": mutate_label_dependency,
    "exogenous_tape_depends_on_arm": mutate_arm_dependent_exogenous_tape,
    "delay_harm_zeroed": mutate_delay_harm_removed,
    "contestable_appeal_removed": mutate_appeal_removed,
    "cumulative_authority_review_removed": mutate_cumulative_review_removed,
}


def run_audit() -> dict[str, Any]:
    baseline_failures = run_probes()
    rows = []
    for name, mutation in MUTANTS.items():
        with mutation():
            failures = run_probes()
        rows.append(
            {
                "mutant": name,
                "killed": bool(failures),
                "probe_failures": failures,
            }
        )
    killed = sum(row["killed"] for row in rows)
    return {
        "schema_version": "swarmglue.open-world-mutation-audit.v1",
        "baseline_passed": not baseline_failures,
        "baseline_failures": baseline_failures,
        "mutant_count": len(rows),
        "mutants_killed": killed,
        "kill_rate": q(killed / max(1, len(rows))),
        "passed": not baseline_failures and killed == len(rows),
        "mutants": rows,
        "scope_limit": (
            "These in-process mutants test enumerated simulation invariants; "
            "they are not an independent security assessment."
        ),
    }


def markdown(report: dict[str, Any]) -> str:
    lines = [
        "# Open-world mutation audit",
        "",
        f"Baseline probes passed: **{report['baseline_passed']}**  ",
        f"Mutants killed: **{report['mutants_killed']} / {report['mutant_count']}**  ",
        f"Kill rate: **{report['kill_rate']:.3f}**",
        "",
        "| mutant | killed | triggered probes |",
        "|---|---:|---|",
    ]
    for row in report["mutants"]:
        failures = ", ".join(row["probe_failures"]) or "none"
        lines.append(f"| {row['mutant']} | {row['killed']} | {failures} |")
    lines.extend(["", report["scope_limit"], ""])
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--json-output",
        type=Path,
        default=PROJECT_ROOT / "reports" / "open_world_mutation_audit.json",
    )
    parser.add_argument(
        "--markdown-output",
        type=Path,
        default=PROJECT_ROOT / "reports" / "open_world_mutation_audit.md",
    )
    args = parser.parse_args()
    report = run_audit()
    args.json_output.parent.mkdir(parents=True, exist_ok=True)
    args.json_output.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    args.markdown_output.write_text(markdown(report), encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    raise SystemExit(0 if report["passed"] else 1)


if __name__ == "__main__":
    main()
