#!/usr/bin/env python3
"""Validate the SwarmGlue v0.10 canonical consolidation.

This gate composes the canonical v0.9-derived validation with the quarantined
v0.3 institutional-laboratory validation, then checks the consolidation
boundary itself. Passing this script is not a deployment-safety certification.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
LEGACY = ROOT / "legacy" / "institutional_lab_v0_3"

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.validate_release import validate as validate_canonical  # noqa: E402

EXPECTED_VERSION = "0.10.0"
EXPECTED_SOURCE_HASHES = {
    "SwarmGlue_v0_9_fdt_robustness.zip": "54adcffe5784a745bbb749c78382f57d14833ce4e75ba283b23ded8db8160521",
    "SwarmGlue_v0_3_bundle.zip": "285a4939a968e4891ef97d4b9e568e03feb44af3bc7643d0579a4ef65d720f4b",
}
REQUIRED_V010 = [
    "VERSION",
    "PROVENANCE.json",
    "SwarmGlue_v0_10_Canonical_Design.md",
    "docs/CONSOLIDATION_MAP.md",
    "docs/V0_10_HANDOFF.md",
    "docs/AGREEMENT_GOVERNANCE_BUSINESS_POSITIONING.md",
    "docs/README_v0_9_snapshot.md",
    "docs/MANIFEST_v0_9_snapshot.json",
    "docs/SHA256SUMS_v0_9_snapshot.txt",
    "legacy/institutional_lab_v0_3/README.md",
    "legacy/institutional_lab_v0_3/SwarmGlue_v0_3_Design.md",
    "legacy/institutional_lab_v0_3/ORIGIN.txt",
    "legacy/institutional_lab_v0_3/README_V0_10_INTEGRATION.md",
    "legacy/institutional_lab_v0_3/scripts/institutional_laboratory.py",
    "legacy/institutional_lab_v0_3/scripts/decision_math.py",
    "legacy/institutional_lab_v0_3/corpus/manifest.json",
]


def run(cmd: list[str], cwd: Path) -> dict:
    p = subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return {"passed": p.returncode == 0, "returncode": p.returncode, "output": p.stdout}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def check_namespace_quarantine() -> dict:
    offenders: list[str] = []
    roots = [ROOT / "swarmglue", ROOT / "examples", ROOT / "tests"]
    # Canonical scripts are checked too, except this validator because it must refer to the legacy path.
    files = []
    for base in roots:
        if base.exists():
            files.extend(base.rglob("*.py"))
    files.extend(p for p in (ROOT / "scripts").glob("*.py") if p.name != "validate_v010.py")
    needles = ("legacy.institutional_lab_v0_3", "legacy/institutional_lab_v0_3", "legacy\\institutional_lab_v0_3")
    for path in sorted(files):
        text = path.read_text(encoding="utf-8")
        if any(n in text for n in needles):
            offenders.append(path.relative_to(ROOT).as_posix())
    return {"passed": not offenders, "offenders": offenders}


def check_checksums() -> dict:
    path = ROOT / "SHA256SUMS"
    if not path.is_file():
        return {"checked": False, "passed": None, "failures": []}
    failures: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            failures.append(f"malformed_checksum_line:{line}")
            continue
        target = ROOT / relative
        if not target.is_file():
            failures.append(f"checksum_target_missing:{relative}")
        elif sha256(target) != expected:
            failures.append(f"checksum_mismatch:{relative}")
    return {"checked": True, "passed": not failures, "failures": failures}


def check_manifest() -> dict:
    path = ROOT / "MANIFEST.json"
    if not path.is_file():
        return {"checked": False, "passed": None, "failures": []}
    failures: list[str] = []
    try:
        m = json.loads(path.read_text(encoding="utf-8"))
        if m.get("version") != EXPECTED_VERSION:
            failures.append("manifest_version_mismatch")
        expected = {
            p.relative_to(ROOT).as_posix(): p
            for p in ROOT.rglob("*")
            if p.is_file() and "__pycache__" not in p.parts and not p.name.endswith(".pyc")
            and p.name not in {"MANIFEST.json", "SHA256SUMS"}
        }
        listed = {row["path"]: row for row in m.get("files", [])}
        for rel in sorted(set(expected) - set(listed)):
            failures.append(f"manifest_missing_file:{rel}")
        for rel in sorted(set(listed) - set(expected)):
            failures.append(f"manifest_extra_file:{rel}")
        for rel, target in expected.items():
            row = listed.get(rel)
            if row and (row.get("sha256") != sha256(target) or row.get("bytes") != target.stat().st_size):
                failures.append(f"manifest_digest_or_size_mismatch:{rel}")
    except Exception as exc:
        failures.append(f"manifest_unreadable:{exc!r}")
    return {"checked": True, "passed": not failures, "failures": failures}


def check_archive(archive: Path) -> dict:
    failures: list[str] = []
    if not archive.is_file():
        return {"checked": True, "passed": False, "failures": ["archive_missing"]}
    prefix = ROOT.name + "/"
    expected = {
        p.relative_to(ROOT).as_posix(): p
        for p in ROOT.rglob("*")
        if p.is_file() and "__pycache__" not in p.parts and not p.name.endswith(".pyc")
    }
    with zipfile.ZipFile(archive) as z:
        names = [i.filename for i in z.infolist() if not i.is_dir()]
        for name in names:
            pure = PurePosixPath(name)
            if pure.is_absolute() or ".." in pure.parts:
                failures.append(f"unsafe_archive_path:{name}")
            if not name.startswith(prefix):
                failures.append(f"wrong_archive_prefix:{name}")
        archived = {n[len(prefix):] for n in names if n.startswith(prefix)}
        failures += [f"archive_missing_file:{x}" for x in sorted(set(expected) - archived)]
        failures += [f"archive_extra_file:{x}" for x in sorted(archived - set(expected))]
        bad = z.testzip()
        if bad:
            failures.append(f"archive_crc_failure:{bad}")
    return {
        "checked": True,
        "passed": not failures,
        "failures": failures,
        "sha256": sha256(archive),
        "bytes": archive.stat().st_size,
    }


def validate(archive: Path | None = None) -> dict:
    failures: list[str] = []
    missing = [p for p in REQUIRED_V010 if not (ROOT / p).is_file()]
    failures.extend(f"required_file_missing:{p}" for p in missing)

    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip() if (ROOT / "VERSION").is_file() else "missing"
    version_ok = version == EXPECTED_VERSION
    if not version_ok:
        failures.append(f"version_mismatch:{version}")

    provenance_ok = False
    provenance = {}
    try:
        provenance = json.loads((ROOT / "PROVENANCE.json").read_text(encoding="utf-8"))
        observed = {x["archive"]: x["sha256"] for x in provenance.get("built_from", [])}
        provenance_ok = all(observed.get(k) == v for k, v in EXPECTED_SOURCE_HASHES.items())
    except Exception as exc:  # validation boundary, report exact error text
        provenance = {"error": repr(exc)}
    if not provenance_ok:
        failures.append("source_provenance_mismatch")

    # Run canonical validator without integrity files because v0.10 has its own manifest/checksum lifecycle.
    canonical = validate_canonical(ROOT, run_tests=True, check_integrity_files=False)
    if not canonical["passed"]:
        failures.extend(f"canonical:{x}" for x in canonical["failures"])

    legacy_unit = run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"], LEGACY)
    if not legacy_unit["passed"]:
        failures.append("legacy_unit_tests_failed")

    legacy_corpus = run([sys.executable, "scripts/validate_corpus.py", "--corpus", "corpus"], LEGACY)
    if not legacy_corpus["passed"]:
        failures.append("legacy_corpus_validation_failed")
    legacy_formal = run([sys.executable, "scripts/validate_formal_records.py", "--corpus", "corpus"], LEGACY)
    if not legacy_formal["passed"]:
        failures.append("legacy_formal_validation_failed")
    legacy_decision = run([sys.executable, "scripts/validate_decision_records.py", "--corpus", "corpus"], LEGACY)
    if not legacy_decision["passed"]:
        failures.append("legacy_decision_validation_failed")

    quarantine = check_namespace_quarantine()
    if not quarantine["passed"]:
        failures.extend(f"legacy_import:{x}" for x in quarantine["offenders"])

    manifest_result = check_manifest()
    if manifest_result["checked"] and not manifest_result["passed"]:
        failures.extend(manifest_result["failures"])
    checksum_result = check_checksums()
    if checksum_result["checked"] and not checksum_result["passed"]:
        failures.extend(checksum_result["failures"])

    archive_result = {"checked": False, "passed": None, "failures": []}
    if archive is not None:
        archive_result = check_archive(archive)
        if not archive_result["passed"]:
            failures.extend(archive_result["failures"])

    return {
        "validation": "SwarmGlue_v0.10_canonical",
        "passed": not failures,
        "failures": failures,
        "version": {"expected": EXPECTED_VERSION, "observed": version, "passed": version_ok},
        "provenance": {"passed": provenance_ok, "observed": provenance},
        "canonical_v09_derived_gate": {
            "passed": canonical["passed"],
            "unit_tests_passed": canonical["unit_tests"]["passed"],
            "canonical_validation_label": canonical["validation"],
            "fdt_agent_trial_status": canonical["fdt_agent_trial_status"],
            "open_world_evidence_class": canonical["open_world_experiment"].get("evidence_class"),
        },
        "legacy_v03": {
            "unit_tests": legacy_unit,
            "corpus_validation": legacy_corpus,
            "formal_validation": legacy_formal,
            "decision_validation": legacy_decision,
        },
        "namespace_quarantine": quarantine,
        "manifest": manifest_result,
        "checksums": checksum_result,
        "archive": archive_result,
        "interpretation": "Passing validates the bundled research artifacts and consolidation boundary; it is not a deployment safety or legal-compliance certification.",
    }


def markdown(report: dict) -> str:
    legacy = report["legacy_v03"]
    lines = [
        "# SwarmGlue v0.10 consolidation validation",
        "",
        f"Overall: **{'PASS' if report['passed'] else 'FAIL'}**",
        "",
        f"- Version: {report['version']['observed']} ({report['version']['passed']})",
        f"- Source provenance: {report['provenance']['passed']}",
        f"- Canonical v0.9-derived gate: {report['canonical_v09_derived_gate']['passed']}",
        f"- Legacy v0.3 unit tests: {legacy['unit_tests']['passed']}",
        f"- Legacy v0.3 corpus validation: {legacy['corpus_validation']['passed']}",
        f"- Legacy v0.3 formal validation: {legacy['formal_validation']['passed']}",
        f"- Legacy v0.3 decision validation: {legacy['decision_validation']['passed']}",
        f"- Canonical/legacy namespace quarantine: {report['namespace_quarantine']['passed']}",
        f"- Manifest: {report['manifest']['passed'] if report['manifest']['checked'] else 'deferred'}",
        f"- Checksums: {report['checksums']['passed'] if report['checksums']['checked'] else 'deferred'}",
        f"- Archive: {report['archive']['passed'] if report['archive']['checked'] else 'not checked in this pass'}",
        "",
    ]
    if report["failures"]:
        lines += ["## Failures", ""] + [f"- {x}" for x in report["failures"]] + [""]
    lines += [report["interpretation"], ""]
    return "\n".join(lines)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--archive", type=Path)
    ap.add_argument("--json", type=Path)
    ap.add_argument("--markdown", type=Path)
    args = ap.parse_args()
    report = validate(args.archive)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if args.markdown:
        args.markdown.parent.mkdir(parents=True, exist_ok=True)
        args.markdown.write_text(markdown(report), encoding="utf-8")
    print(json.dumps({"passed": report["passed"], "failures": report["failures"]}))
    raise SystemExit(0 if report["passed"] else 1)


if __name__ == "__main__":
    main()
