#!/usr/bin/env python3
"""Build the cumulative v0.9 FDT package without rerunning the simulation."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from scripts.terminology_audit import audit as terminology_audit
from scripts.terminology_audit import markdown as terminology_markdown
from scripts.validate_fdt_corpus import write_reports as write_fdt_reports
from scripts.validate_release import check_archive
from scripts.validate_release import validate as validate_release
from swarmglue.fdt_corpus import generate_records, write_records


EXCLUDED_PARTS = {"__pycache__", ".git", ".pytest_cache"}


def sha256(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def release_files(root: Path, *, include_integrity: bool = True) -> list[Path]:
    output: list[Path] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if any(part in EXCLUDED_PARTS for part in relative.parts) or path.suffix == ".pyc":
            continue
        if not include_integrity and relative.as_posix() in {"MANIFEST.json", "SHA256SUMS"}:
            continue
        output.append(path)
    return sorted(output, key=lambda item: item.relative_to(root).as_posix())


def write_integrity(root: Path) -> None:
    base_files = release_files(root, include_integrity=False)
    manifest = {
        "release": "SwarmGlue_v0.9_fdt_robustness",
        "version": "0.9.0",
        "cumulative": True,
        "fdt_evidence_class": "C1",
        "fdt_learned_agent_trial": "not_run",
        "simulation_status": "preserved_and_deferred_for_later_stress_testing",
        "file_count_excluding_integrity_files": len(base_files),
        "files": [
            {
                "path": path.relative_to(root).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
            for path in base_files
        ],
    }
    (root / "MANIFEST.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    checksum_files = sorted(
        [*base_files, root / "MANIFEST.json"],
        key=lambda path: path.relative_to(root).as_posix(),
    )
    (root / "SHA256SUMS").write_text(
        "\n".join(
            f"{sha256(path)}  {path.relative_to(root).as_posix()}"
            for path in checksum_files
        )
        + "\n",
        encoding="utf-8",
    )


def write_archive(root: Path, archive: Path) -> None:
    archive.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(
        archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as bundle:
        for path in release_files(root):
            relative = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(
                f"{root.name}/{relative}", date_time=(2026, 1, 1, 0, 0, 0)
            )
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (
                0o755 if path.parent.name == "scripts" else 0o644
            ) << 16
            bundle.writestr(
                info,
                path.read_bytes(),
                compress_type=zipfile.ZIP_DEFLATED,
                compresslevel=9,
            )


def release_markdown(report: dict) -> str:
    core = report["cumulative_validation"]
    fdt = report["fdt_corpus"]
    shortcut = report["fdt_shortcut"]
    return "\n".join(
        [
            "# Cumulative v0.9 FDT release validation",
            "",
            f"Overall: **{'PASS' if report['passed'] else 'FAIL'}**",
            "",
            f"- Inherited core plus open-world validation: {core['passed']}",
            f"- Unit tests: {core['unit_tests']['passed']}",
            f"- Inherited corpus: {core['corpus']['record_count']} records",
            f"- FDT supplement: {fdt['record_count']} records / {fdt['pair_count']} pairs",
            f"- FDT single-axis pair failures: {len(fdt['single_axis_pair_failures'])}",
            f"- FDT challenge family overlap: `{fdt['challenge_family_overlap']}`",
            f"- FDT challenge skeleton overlap: `{fdt['challenge_skeleton_overlap']}`",
            f"- FDT response-only challenge AUC: {shortcut['splits']['challenge']['response_only_auc']:.3f}",
            f"- FDT legitimate-cooperation records: {fdt['legitimate_cooperation_record_count']}",
            f"- FDT constitutional-override records: {fdt['constitutional_override_record_count']}",
            f"- FDT V6 learned-agent trial: {core['fdt_agent_trial_status']['status']} "
            f"({core['fdt_agent_trial_status']['completed_cells']} / "
            f"{core['fdt_agent_trial_status']['required_cells']} cells; no C3 evidence)",
            "- Prior open-world and cumulative small-town archives: preserved under `prior_releases/`",
            "- New simulation run: not performed",
            "",
            "This is C1 evidence for the FDT supplement. It does not validate FDT, "
            "a learned agent, human legitimacy, or real institutional outcomes.",
            "",
            f"Failures: `{report['failures']}`",
            "",
        ]
    )


def build(root: Path, archive: Path) -> dict:
    for path in (root / "MANIFEST.json", root / "SHA256SUMS"):
        path.unlink(missing_ok=True)

    config = json.loads(
        (root / "configs" / "fdt_training_regime.json").read_text(encoding="utf-8")
    )
    counts = config["pair_counts"]
    records = generate_records(
        train_pairs=counts["train"],
        dev_pairs=counts["dev"],
        challenge_pairs=counts["challenge"],
        seed=config["generator_seed"],
    )
    write_records(records, root / "corpus" / "fdt")
    fdt_validation, fdt_shortcut = write_fdt_reports(root)
    if not fdt_validation["valid"] or not fdt_shortcut["passed"]:
        raise RuntimeError(
            f"FDT corpus validation failed: "
            f"{fdt_validation['failures'] + fdt_shortcut['failures']}"
        )

    terminology = terminology_audit(root)
    (root / "reports" / "terminology_audit.json").write_text(
        json.dumps(terminology, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (root / "reports" / "terminology_audit.md").write_text(
        terminology_markdown(terminology), encoding="utf-8"
    )
    if not terminology["passed"]:
        raise RuntimeError(
            f"terminology audit failed: {terminology['violations']}"
        )

    cumulative = validate_release(
        root, run_tests=True, check_integrity_files=False
    )
    # unittest includes wall-clock duration in otherwise deterministic output.
    # Normalize it before storing the release report so identical source and
    # inputs produce byte-identical archives.
    cumulative["unit_tests"]["output"] = re.sub(
        r"Ran (\d+) tests? in [0-9.]+s",
        r"Ran \1 tests",
        cumulative["unit_tests"]["output"],
    )
    failures = [*cumulative["failures"]]
    result = {
        "schema_version": "swarmglue.fdt-release-validation.v0.1",
        "passed": not failures,
        "failures": failures,
        "cumulative_validation": cumulative,
        "fdt_corpus": fdt_validation,
        "fdt_shortcut": fdt_shortcut,
        "simulation_rerun": False,
        "simulation_status": "preserved_and_deferred",
        "evidence_class": "C1",
    }
    (root / "reports" / "fdt_release_validation.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (root / "reports" / "fdt_release_validation.md").write_text(
        release_markdown(result), encoding="utf-8"
    )
    if failures:
        raise RuntimeError(f"cumulative validation failed: {failures}")

    write_integrity(root)
    write_archive(root, archive)
    archive_result = check_archive(root, archive)
    if not archive_result["passed"]:
        raise RuntimeError(
            f"archive validation failed: {archive_result['failures']}"
        )
    return {
        "passed": True,
        "archive": str(archive),
        "archive_sha256": archive_result["sha256"],
        "archive_bytes": archive_result["bytes"],
        "unit_tests_passed": cumulative["unit_tests"]["passed"],
        "inherited_corpus_records": cumulative["corpus"]["record_count"],
        "fdt_records": fdt_validation["record_count"],
        "fdt_pairs": fdt_validation["pair_count"],
        "fdt_response_only_challenge_auc": fdt_shortcut["splits"]["challenge"]["response_only_auc"],
        "fdt_V6_status": cumulative["fdt_agent_trial_status"]["status"],
        "simulation_rerun": False,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=PROJECT_ROOT)
    parser.add_argument("--archive", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    archive = (args.archive or root.parent / f"{root.name}.zip").resolve()
    print(json.dumps(build(root, archive), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
