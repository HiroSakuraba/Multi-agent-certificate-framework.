#!/usr/bin/env python3
"""Reject superseded public framing from release artifacts."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
TEXT_SUFFIXES = {".json", ".jsonl", ".md", ".py", ".toml", ".txt"}
EXCLUDED = {
    "MANIFEST.json",
    "SHA256SUMS",
    "reports/terminology_audit.json",
    "reports/terminology_audit.md",
}
EXCLUDED_PARTS = {".git", "__pycache__", ".pytest_cache", "legacy"}


def _rules() -> dict[str, re.Pattern[str]]:
    terms = {
        "superseded_collective_metaphor": r"\bbo" + r"rg\b",
        "off_domain_planet_reference": r"\bma" + r"rs(?:ian)?\b",
        "planetary_engineering_reference": r"\bterra" + r"form\w*\b",
        "off_domain_transit_reference": r"\binter" + r"planet\w*\b",
        "stellar_region_reference": r"\bsolar[ -]sys" + r"tem\b",
        "off_domain_location_reference": (
            r"\b(?:aste" + r"roid|lu" + r"nar|orbi" + r"tal|ve" + r"nus)\b"
        ),
        "off_domain_colonization_reference": r"\bspace[ -]colon(?:y|ies)\b",
        "biological_totality_metaphor": r"\bsuper" + r"organism\w*\b",
        "biological_control_metaphor": r"\bhomeo" + r"stas\w*\b",
        "aspirational_scale_claim": r"\bcivili" + r"zation\w*\b",
        "specialized_survival_infrastructure_reference": r"\blife[ -]sup" + r"port\b",
        "legacy_module_or_release_name": (
            r"anti[_ -]?bo" + r"rg|federated[_ -]?homeo" + r"stasis"
        ),
    }
    return {name: re.compile(pattern, re.IGNORECASE) for name, pattern in terms.items()}


def audit(root: Path = PROJECT_ROOT) -> dict:
    root = root.resolve()
    rules = _rules()
    violations: list[dict] = []
    files_scanned = 0
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        relative = path.relative_to(root).as_posix()
        if relative in EXCLUDED or any(part in EXCLUDED_PARTS for part in path.parts):
            continue
        files_scanned += 1
        text = path.read_text(encoding="utf-8")
        for line_number, line in enumerate(text.splitlines(), start=1):
            for rule_id, pattern in rules.items():
                for match in pattern.finditer(line):
                    violations.append(
                        {
                            "rule_id": rule_id,
                            "path": relative,
                            "line": line_number,
                            "column": match.start() + 1,
                            "excerpt": line[max(0, match.start() - 45): match.end() + 45],
                        }
                    )
    return {
        "audit": "public_framing_terminology_v0.8",
        "passed": not violations,
        "files_scanned": files_scanned,
        "rule_count": len(rules),
        "rule_ids": sorted(rules),
        "violation_count": len(violations),
        "violations": violations,
    }


def markdown(report: dict) -> str:
    lines = [
        "# Public-framing terminology audit",
        "",
        f"Overall: **{'PASS' if report['passed'] else 'FAIL'}**",
        "",
        f"- Files scanned: {report['files_scanned']}",
        f"- Rules applied: {report['rule_count']}",
        f"- Violations: {report['violation_count']}",
        "",
    ]
    if report["violations"]:
        lines += ["## Violations", ""]
        for item in report["violations"]:
            lines.append(
                f"- `{item['rule_id']}` at `{item['path']}:{item['line']}:{item['column']}`: "
                f"`{item['excerpt']}`"
            )
        lines.append("")
    lines += [
        "This release gate checks public framing only. It does not evaluate conceptual quality or external validity.",
        "",
    ]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=PROJECT_ROOT)
    parser.add_argument("--json", type=Path)
    parser.add_argument("--markdown", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    report = audit(root)
    json_path = args.json or root / "reports" / "terminology_audit.json"
    markdown_path = args.markdown or root / "reports" / "terminology_audit.md"
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    markdown_path.write_text(markdown(report), encoding="utf-8")
    print(json.dumps({"passed": report["passed"], "violations": report["violation_count"]}))
    raise SystemExit(0 if report["passed"] else 1)


if __name__ == "__main__":
    main()
