#!/usr/bin/env python3
"""Run descriptive mechanism fixtures, authority checks, and runtime attacks."""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from swarmglue.adversary import coevolution_audit
from swarmglue.institutional_boundaries import run_institutional_boundary_suite
from swarmglue.authority import execute_amendment_sequence, gradual_erosion_sequence
from swarmglue.network_governance import POLICY_DESCRIPTIONS, SimulationConfig, compare_policies
from swarmglue.utils import mean, percentile, q


POLICIES = ("polycentric", "centralized_capture", "procedural_stasis", "fragmented_localism")
TOPOLOGIES = ("ring", "hub", "small_world", "modular")


def summarize(rows: list[dict]) -> dict:
    result = {}
    for policy in POLICIES:
        group = [r for r in rows if r["policy"] == policy]
        hard = Counter(reason for r in group for reason in r["hard_violations"])
        capacity = Counter(
            reason for r in group for reason in r["capacity_violations"]
        )

        def stats(name: str) -> dict:
            values = [float(r[name]) for r in group]
            return {
                "mean": q(mean(values)),
                "p05": q(percentile(values, 0.05)),
                "p50": q(percentile(values, 0.50)),
                "p95": q(percentile(values, 0.95)),
                "min": q(min(values)),
                "max": q(max(values)),
            }

        result[policy] = {
            "runs": len(group),
            "constitutional_admissibility_rate": q(sum(r["admissible"] for r in group) / len(group)),
            "hard_violation_counts": dict(sorted(hard.items())),
            "capacity_violation_counts": dict(sorted(capacity.items())),
            "population_index": stats("population_index"),
            "capacity_growth": stats("capacity_growth"),
            "opportunity_growth": stats("opportunity_growth"),
            "autonomy": stats("autonomy"),
            "joint_floor_share": stats("joint_floor_share"),
            "cultural_diversity": stats("cultural_diversity"),
            "ecological_resilience": stats("ecological_resilience"),
            "recoverability": stats("recoverability"),
            "cascade_cvar95": stats("cascade_cvar95"),
            "power_concentration": stats("power_concentration"),
            "domination_risk": stats("domination_risk"),
        }
    return result


def run(seed_count: int, rounds: int, n_jurisdictions: int) -> dict:
    rows: list[dict] = []
    for topology in TOPOLOGIES:
        for seed in range(seed_count):
            config = SimulationConfig(
                n_jurisdictions=n_jurisdictions, rounds=rounds, topology=topology, seed=seed
            )
            for policy, simulation in compare_policies(config).items():
                outcome = simulation["outcome"]
                verdict = simulation["constitutional_verdict"]
                domination_risk = mean([
                    outcome["power_concentration"],
                    outcome["private_cognition_monitoring"],
                    outcome["dissent_penalty_without_externality"],
                    1 - outcome["exit_access"],
                    1 - outcome["autonomy"],
                    1 - outcome["cultural_diversity"],
                ])
                rows.append({
                    "topology": topology,
                    "seed": seed,
                    "policy": policy,
                    "mechanism_fingerprint": simulation["mechanism_fingerprint"],
                    "admissible": verdict["admissible"],
                    "hard_violations": verdict["hard_violations"],
                    "capacity_violations": verdict["capacity_violations"],
                    "population_index": simulation["final"]["population_index"],
                    "capacity_growth": outcome["capacity_growth"],
                    "opportunity_growth": outcome["opportunity_growth"],
                    "autonomy": outcome["autonomy"],
                    "joint_floor_share": outcome["joint_floor_share"],
                    "cultural_diversity": outcome["cultural_diversity"],
                    "ecological_resilience": outcome["ecological_resilience"],
                    "recoverability": outcome["recoverability"],
                    "cascade_cvar95": simulation["cascade"]["cvar95_fraction"],
                    "power_concentration": outcome["power_concentration"],
                    "domination_risk": q(domination_risk),
                })
    authority = {
        checker: execute_amendment_sequence(gradual_erosion_sequence(), checker=checker)
        for checker in ("legacy", "polycentric")
    }
    summaries = summarize(rows)
    matched_descriptives = {}
    for baseline in POLICIES[1:]:
        polycentric = {
            (r["topology"], r["seed"]): r
            for r in rows
            if r["policy"] == "polycentric"
        }
        other = {(r["topology"], r["seed"]): r for r in rows if r["policy"] == baseline}
        matched_descriptives[baseline] = {
            "higher_population_index_rate": q(
                mean(
                    polycentric[key]["population_index"]
                    > other[key]["population_index"]
                    for key in polycentric
                )
            ),
            "lower_domination_risk_rate": q(
                mean(
                    polycentric[key]["domination_risk"]
                    < other[key]["domination_risk"]
                    for key in polycentric
                )
            ),
            "both_admissible_rate": q(
                mean(
                    polycentric[key]["admissible"] and other[key]["admissible"]
                    for key in polycentric
                )
            ),
        }
    return {
        "experiment": "network_governance_mechanism_fixtures_v0.8",
        "model_status": (
            "stylized, non-calibrated fixture diagnostics; named-fixture "
            "differences are not a causal, predictive, or comparative policy result"
        ),
        "configuration": {
            "seed_count": seed_count,
            "topologies": list(TOPOLOGIES),
            "policies": list(POLICIES),
            "rounds": rounds,
            "jurisdictions": n_jurisdictions,
            "matched_random_streams": True,
            "run_count": len(rows),
        },
        "policy_summary": summaries,
        "fixture_descriptions": POLICY_DESCRIPTIONS,
        "matched_fixture_descriptives": matched_descriptives,
        "authority_erosion": authority,
        "institutional_boundaries": run_institutional_boundary_suite(),
        "runtime_adversary": coevolution_audit(generations=6),
        "raw_runs": rows,
    }


def markdown(report: dict) -> str:
    config = report["configuration"]
    lines = [
        "# SwarmGlue v0.8 mechanism-fixture diagnostics", "",
        f"This report contains {config['run_count']} matched network-governance runs "
        f"({config['seed_count']} seeds × {len(config['topologies'])} topologies × "
        f"{len(config['policies'])} named mechanism fixtures).",
        "", f"**Model status:** {report['model_status']}.", "",
        "Each name identifies an authored point in one shared mechanism-parameter space. "
        "No state transition reads the name. Matched random streams improve regression "
        "sensitivity, but do not turn these fixtures into empirically matched alternatives. "
        "The table below is descriptive build output, not a finding about institutional forms. "
        "The preregistered causal-implementation evidence is in tier0_validation.md.", "",
        "## Fixture definitions", "",
    ]
    for policy in POLICIES:
        lines.append(f"- **{policy}:** {report['fixture_descriptions'][policy]}")
    lines += [
        "",
        "## Outcome summary", "",
        "| Archetype | Admissible | Normalized population index | Capacity growth | Opportunity growth | Autonomy | Domination risk | Cascade CVaR95 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for policy, summary in report["policy_summary"].items():
        lines.append(
            f"| {policy} | {summary['constitutional_admissibility_rate']:.1%} | "
            f"{summary['population_index']['mean']:.1f} | {summary['capacity_growth']['mean']:.3f} | "
            f"{summary['opportunity_growth']['mean']:.3f} | {summary['autonomy']['mean']:.3f} | "
            f"{summary['domination_risk']['mean']:.3f} | {summary['cascade_cvar95']['mean']:.3f} |"
        )
    authority = report["authority_erosion"]
    lines += [
        "", "## Gradual authority erosion", "",
        f"The local/legacy checker accepted {authority['legacy']['accepted_count']} of 24 small amendments, "
        f"ending at human decision share {authority['legacy']['final']['human_decision_share']:.3f}. "
        f"The cumulative checker accepted {authority['polycentric']['accepted_count']} and held the share at "
        f"{authority['polycentric']['final']['human_decision_share']:.3f}.", "",
        "## Institutional boundaries and runtime payload audit", "",
        f"- Institutional-boundary pairs: "
        f"{report['institutional_boundaries']['passed_count']}/"
        f"{report['institutional_boundaries']['case_count']} passed.",
        f"- Runtime payload generations satisfy catalog/release checks: "
        f"{report['runtime_adversary']['all_generations_release_pass']}.",
        f"- Detection rates by generation: "
        f"{report['runtime_adversary']['detection_rate_by_generation']}.",
        f"- Recorded blind-spot observations: "
        f"{len({(item['family'], item['variant']) for item in report['runtime_adversary']['known_blind_spots']})} "
        f"unique variants across "
        f"{len(report['runtime_adversary']['known_blind_spots'])} generation-level observations.",
        "", "These diagnostics validate enumerated implementation behavior only. "
        "They do not establish governed-agent improvement, exhaustive security, "
        "real-world safety, political legitimacy, policy effectiveness, or "
        "external validity.", "",
    ]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds", type=int, default=20)
    parser.add_argument("--rounds", type=int, default=80)
    parser.add_argument("--jurisdictions", type=int, default=16)
    parser.add_argument("--json", type=Path, default=Path("reports/experiment_report.json"))
    parser.add_argument("--markdown", type=Path, default=Path("reports/experiment_report.md"))
    args = parser.parse_args()
    report = run(args.seeds, args.rounds, args.jurisdictions)
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    args.markdown.write_text(markdown(report), encoding="utf-8")
    print(json.dumps({
        "run_count": report["configuration"]["run_count"],
        "polycentric_admissibility": report["policy_summary"]["polycentric"]["constitutional_admissibility_rate"],
    }))


if __name__ == "__main__":
    main()
