#!/usr/bin/env python3
"""Run paired, multi-seed open-world experiments and write an evidence report."""

from __future__ import annotations

import argparse
import json
import random
import statistics
import sys
from pathlib import Path
from typing import Any, Sequence

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from swarmglue.open_world import ARMS, OpenWorld, OpenWorldConfig, paired_arms
from swarmglue.utils import digest, q


ENDPOINTS = (
    "material_wellbeing",
    "civic_burden",
    "service_capacity",
    "goods_gini",
    "practical_exit_access",
    "private_cognition_monitoring",
    "dissent_penalty_without_externality",
    "executed_protected_actions",
    "failed_exits",
    "safe_actions_blocked",
    "review_false_negatives",
    "review_burden",
    "cumulative_delay_harm",
)


def percentile(values: Sequence[float], fraction: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(float(value) for value in values)
    position = (len(ordered) - 1) * fraction
    low = int(position)
    high = min(len(ordered) - 1, low + 1)
    weight = position - low
    return ordered[low] * (1.0 - weight) + ordered[high] * weight


def paired_interval(
    differences: Sequence[float], *, bootstrap_samples: int = 2000, seed: int = 90210
) -> dict[str, Any]:
    values = [float(value) for value in differences]
    if not values:
        return {"n": 0, "mean_difference": 0.0, "ci95": [0.0, 0.0]}
    rng = random.Random(seed)
    means = []
    for _ in range(bootstrap_samples):
        means.append(
            sum(values[rng.randrange(len(values))] for _ in values) / len(values)
        )
    return {
        "n": len(values),
        "mean_difference": q(statistics.fmean(values)),
        "median_difference": q(statistics.median(values)),
        "ci95": [q(percentile(means, 0.025)), q(percentile(means, 0.975))],
        "positive_pair_share": q(sum(value > 0 for value in values) / len(values)),
        "zero_pair_share": q(sum(value == 0 for value in values) / len(values)),
    }


def extract_summary(report: dict[str, Any]) -> dict[str, Any]:
    metrics = report["final"]["metrics"]
    counters = report["counters"]
    return {
        "arm": report["arm"],
        "seed": report["config"]["seed"],
        "n_residents": report["config"]["n_residents"],
        "stress_multiplier": report["config"]["stress_multiplier"],
        "replay_digest": report["replay_digest"],
        "exogenous_trace_digest": report["exogenous_trace_digest"],
        "constitutional_admissible": report["final"]["constitutional_verdict"][
            "admissible"
        ],
        "constitutional_hard_violations": report["final"][
            "constitutional_verdict"
        ]["hard_violations"],
        "constitutional_capacity_violations": report["final"][
            "constitutional_verdict"
        ]["capacity_violations"],
        "material_wellbeing": metrics["material_wellbeing"],
        "active_material_wellbeing": metrics["active_material_wellbeing"],
        "civic_burden": metrics["civic_burden"],
        "service_capacity": metrics["service_capacity"],
        "goods_gini": metrics["goods_gini"],
        "practical_exit_access": metrics["practical_exit_access"],
        "private_cognition_monitoring": metrics[
            "private_cognition_monitoring"
        ],
        "dissent_penalty_without_externality": metrics[
            "dissent_penalty_without_externality"
        ],
        "active_residents": metrics["active_residents"],
        "executed_protected_actions": counters.get(
            "executed_protected_actions", 0
        ),
        "failed_exits": counters.get("failed_exits", 0),
        "successful_exits": counters.get("successful_exits", 0),
        "safe_actions_blocked": counters.get("safe_actions_blocked", 0),
        "review_false_negatives": counters.get("review_false_negatives", 0),
        "semantic_misses": counters.get("semantic_misses", 0),
        "appeals": counters.get("appeals", 0),
        "appeal_overturns": counters.get("appeal_overturns", 0),
        "review_burden": counters.get("review_burden", 0.0),
        "cumulative_delay_harm": counters.get("cumulative_delay_harm", 0.0),
    }


def cell_key(row: dict[str, Any]) -> tuple[int, int, float]:
    return (
        int(row["seed"]),
        int(row["n_residents"]),
        float(row["stress_multiplier"]),
    )


def mean_by_arm(rows: Sequence[dict[str, Any]]) -> dict[str, dict[str, float]]:
    output: dict[str, dict[str, float]] = {}
    for arm in ARMS:
        arm_rows = [row for row in rows if row["arm"] == arm]
        output[arm] = {
            endpoint: q(statistics.fmean(float(row[endpoint]) for row in arm_rows))
            for endpoint in ENDPOINTS
        }
        output[arm]["constitutional_admissible_share"] = q(
            statistics.fmean(bool(row["constitutional_admissible"]) for row in arm_rows)
        )
    return output


def paired_contrasts(rows: Sequence[dict[str, Any]]) -> dict[str, Any]:
    by_arm = {
        arm: {cell_key(row): row for row in rows if row["arm"] == arm}
        for arm in ARMS
    }
    baseline = by_arm["open_binding"]
    output: dict[str, Any] = {}
    for arm in ARMS:
        if arm == "open_binding":
            continue
        shared = sorted(set(baseline) & set(by_arm[arm]))
        output[arm] = {
            endpoint: paired_interval(
                [
                    float(by_arm[arm][key][endpoint])
                    - float(baseline[key][endpoint])
                    for key in shared
                ],
                seed=90210 + sum(ord(character) for character in arm + endpoint),
            )
            for endpoint in ENDPOINTS
        }
    return output


def factor_effects(rows: Sequence[dict[str, Any]]) -> dict[str, Any]:
    sizes = sorted({int(row["n_residents"]) for row in rows})
    stresses = sorted({float(row["stress_multiplier"]) for row in rows})
    effects: dict[str, Any] = {"size": {}, "stress": {}}
    if len(sizes) >= 2:
        small, large = sizes[0], sizes[-1]
        for arm in ARMS:
            arm_rows = [row for row in rows if row["arm"] == arm]
            small_map = {
                (row["seed"], row["stress_multiplier"]): row
                for row in arm_rows
                if row["n_residents"] == small
            }
            large_map = {
                (row["seed"], row["stress_multiplier"]): row
                for row in arm_rows
                if row["n_residents"] == large
            }
            shared = sorted(set(small_map) & set(large_map))
            effects["size"][arm] = {
                endpoint: paired_interval(
                    [
                        float(large_map[key][endpoint])
                        - float(small_map[key][endpoint])
                        for key in shared
                    ],
                    seed=12000 + sum(ord(c) for c in arm + endpoint),
                )
                for endpoint in (
                    "material_wellbeing",
                    "service_capacity",
                    "civic_burden",
                    "failed_exits",
                )
            }
    if len(stresses) >= 2:
        low, high = stresses[0], stresses[-1]
        for arm in ARMS:
            arm_rows = [row for row in rows if row["arm"] == arm]
            low_map = {
                (row["seed"], row["n_residents"]): row
                for row in arm_rows
                if row["stress_multiplier"] == low
            }
            high_map = {
                (row["seed"], row["n_residents"]): row
                for row in arm_rows
                if row["stress_multiplier"] == high
            }
            shared = sorted(set(low_map) & set(high_map))
            effects["stress"][arm] = {
                endpoint: paired_interval(
                    [
                        float(high_map[key][endpoint])
                        - float(low_map[key][endpoint])
                        for key in shared
                    ],
                    seed=22000 + sum(ord(c) for c in arm + endpoint),
                )
                for endpoint in (
                    "material_wellbeing",
                    "service_capacity",
                    "civic_burden",
                    "failed_exits",
                )
            }
    return effects


def metamorphic_checks(seed_count: int = 8) -> dict[str, Any]:
    label_differences = 0
    replay_differences = 0
    exogenous_differences = 0
    checks = 0
    for seed in range(seed_count):
        config = OpenWorldConfig(
            seed=50_000 + seed,
            epochs=16,
            n_residents=16,
            max_residents=32,
            entry_rate=0.05,
        )
        left = OpenWorld.create(config=config, arm="contestable_review")
        right = OpenWorld.create(config=config, arm="contestable_review")
        for resident in right.residents.values():
            resident.profile_label = f"permuted-{seed}"
        left_report = left.run()
        right_report = right.run()
        checks += 1
        label_differences += int(
            left_report["history"] != right_report["history"]
            or left_report["action_ledger"] != right_report["action_ledger"]
        )
        replay = OpenWorld.create(
            config=config, arm="contestable_review"
        ).run()
        replay_differences += int(left_report != replay)
        paired = paired_arms(config=config)
        exogenous_differences += int(
            len(
                {
                    report["exogenous_trace_digest"]
                    for report in paired.values()
                }
            )
            != 1
        )
    return {
        "checks": checks,
        "label_only_transition_differences": label_differences,
        "exact_replay_differences": replay_differences,
        "paired_exogenous_tape_differences": exogenous_differences,
        "passed": not (
            label_differences or replay_differences or exogenous_differences
        ),
    }


def threshold_sensitivity(seed_count: int, epochs: int) -> list[dict[str, Any]]:
    rows = []
    for threshold in (0.20, 0.30, 0.40):
        fast_tracks = []
        delay_harms = []
        material = []
        for seed in range(seed_count):
            config = OpenWorldConfig(
                seed=70_000 + seed,
                epochs=epochs,
                n_residents=32,
                max_residents=64,
                stress_multiplier=1.5,
                irreversible_delay_threshold=threshold,
            )
            report = OpenWorld.create(
                config=config, arm="contestable_review"
            ).run()
            fast_tracks.append(
                sum(bool(record["fast_tracked"]) for record in report["action_ledger"])
            )
            delay_harms.append(report["counters"].get("cumulative_delay_harm", 0.0))
            material.append(report["final"]["metrics"]["material_wellbeing"])
        rows.append(
            {
                "irreversible_delay_threshold": threshold,
                "mean_fast_tracks": q(statistics.fmean(fast_tracks)),
                "mean_cumulative_delay_harm": q(statistics.fmean(delay_harms)),
                "mean_material_wellbeing": q(statistics.fmean(material)),
            }
        )
    return rows


def negative_findings(
    means: dict[str, dict[str, float]], contrasts: dict[str, Any]
) -> list[str]:
    findings = []
    process = contrasts["process_control"]
    contestable = contrasts["contestable_review"]
    veto = contrasts["veto_only"]
    if process["service_capacity"]["mean_difference"] < 0:
        interval = process["service_capacity"]["ci95"]
        qualifier = (
            "the interval crossed zero"
            if interval[0] <= 0 <= interval[1]
            else "the interval did not cross zero"
        )
        findings.append(
            "Process burden without protected-boundary review had lower mean "
            f"service capacity than open binding; {qualifier}."
        )
    if process["material_wellbeing"]["mean_difference"] < 0:
        interval = process["material_wellbeing"]["ci95"]
        qualifier = (
            "the interval crossed zero"
            if interval[0] <= 0 <= interval[1]
            else "the interval did not cross zero"
        )
        findings.append(
            "Process burden without protected-boundary review had lower mean "
            f"material wellbeing than open binding; {qualifier}."
        )
    if means["veto_only"]["safe_actions_blocked"] > 0:
        findings.append(
            "The veto-only arm overblocked some safe capacity or exit-restoration actions."
        )
    if means["contestable_review"]["review_false_negatives"] > 0:
        findings.append(
            "Contestable review retained semantic false negatives; the proxy blind spot was not eliminated."
        )
    if contestable["review_burden"]["mean_difference"] > 0:
        findings.append(
            "Contestable review imposed a measurable review burden; enforcement was not modeled as free."
        )
    if veto["cumulative_delay_harm"]["mean_difference"] > 0:
        findings.append(
            "The veto-only arm accumulated more modeled delay harm than open binding."
        )
    if not findings:
        findings.append(
            "No preregistered negative condition fired; inspect cell-level rows rather than treating this as proof of dominance."
        )
    return findings


def run(
    *,
    seed_count: int = 12,
    epochs: int = 60,
    sizes: Sequence[int] = (16, 64),
    stresses: Sequence[float] = (0.8, 1.4),
) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for size in sizes:
        for stress in stresses:
            for seed in range(seed_count):
                config = OpenWorldConfig(
                    seed=10_000 + seed,
                    epochs=epochs,
                    n_residents=size,
                    max_residents=max(96, size * 2),
                    entry_rate=0.08,
                    stress_multiplier=stress,
                )
                reports = paired_arms(config=config)
                rows.extend(extract_summary(reports[arm]) for arm in ARMS)
    means = mean_by_arm(rows)
    contrasts = paired_contrasts(rows)
    report = {
        "schema_version": "swarmglue.open-world-experiment.v2",
        "evidence_class": "C2_authored_simulation",
        "claim_boundary": (
            "The experiment measures rule-based behavior inside an authored world. "
            "It does not establish C3 effects on a learned agent or C4 correspondence "
            "with real institutions."
        ),
        "design": {
            "seed_count": seed_count,
            "epochs": epochs,
            "sizes": list(sizes),
            "stress_multipliers": list(stresses),
            "arms": list(ARMS),
            "run_count": len(rows),
            "paired_common_random_numbers": True,
            "bootstrap_samples_per_contrast": 2000,
            "endpoints": list(ENDPOINTS),
            "interpretation": (
                "Differences are arm minus open_binding. No scalar winner or "
                "multiple-comparison p-value is reported."
            ),
        },
        "aggregate_means": means,
        "paired_contrasts_vs_open_binding": contrasts,
        "factor_effects": factor_effects(rows),
        "threshold_sensitivity": threshold_sensitivity(
            max(4, seed_count // 2), epochs
        ),
        "metamorphic_checks": metamorphic_checks(min(8, seed_count)),
        "negative_and_open_findings": negative_findings(means, contrasts),
        "cell_rows": rows,
    }
    report["report_digest"] = digest(report)
    return report


def markdown(report: dict[str, Any]) -> str:
    design = report["design"]
    means = report["aggregate_means"]
    lines = [
        "# SwarmGlue open-world v0.2 experiment",
        "",
        "## Evidence boundary",
        "",
        report["claim_boundary"],
        "",
        "The simulator keeps material welfare, protected-boundary outcomes, process burden, and delay harm separate. It computes no scalar winner.",
        "",
        "## Design",
        "",
        f"- {design['run_count']} runs: {design['seed_count']} matched seeds × {len(design['sizes'])} sizes × {len(design['stress_multipliers'])} stress levels × {len(design['arms'])} arms.",
        f"- {design['epochs']} epochs per run.",
        "- Exogenous loads are keyed by seed and epoch, so every arm in a cell receives the same random tape.",
        "- Paired differences use deterministic 95% bootstrap intervals; they are descriptive, not externally calibrated causal estimates.",
        "",
        "## Aggregate endpoint means",
        "",
        "| arm | material | civic burden | service | exit | private monitor | protected executions | safe blocked | false negatives | review burden |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for arm in ARMS:
        item = means[arm]
        lines.append(
            f"| {arm} | {item['material_wellbeing']:.3f} | {item['civic_burden']:.3f} | "
            f"{item['service_capacity']:.3f} | {item['practical_exit_access']:.3f} | "
            f"{item['private_cognition_monitoring']:.3f} | "
            f"{item['executed_protected_actions']:.2f} | {item['safe_actions_blocked']:.2f} | "
            f"{item['review_false_negatives']:.2f} | {item['review_burden']:.3f} |"
        )
    lines.extend(
        [
            "",
            "## Paired contrasts against open binding",
            "",
            "Values are arm minus open binding. Intervals crossing zero remain unresolved in this authored experiment.",
            "",
            "| arm | endpoint | mean difference | 95% bootstrap interval | positive-pair share |",
            "|---|---|---:|---:|---:|",
        ]
    )
    for arm, endpoints in report["paired_contrasts_vs_open_binding"].items():
        for endpoint in (
            "material_wellbeing",
            "civic_burden",
            "service_capacity",
            "practical_exit_access",
            "executed_protected_actions",
            "safe_actions_blocked",
            "review_false_negatives",
            "review_burden",
            "cumulative_delay_harm",
        ):
            item = endpoints[endpoint]
            lines.append(
                f"| {arm} | {endpoint} | {item['mean_difference']:.3f} | "
                f"[{item['ci95'][0]:.3f}, {item['ci95'][1]:.3f}] | "
                f"{item['positive_pair_share']:.3f} |"
            )
    lines.extend(
        [
            "",
            "## Population-size and stress effects",
            "",
            "Size values are largest population minus smallest population; stress values are highest stress minus lowest stress. These are authored factor effects, not empirical scale laws.",
            "",
            "| factor | arm | material | service | civic burden | failed exits |",
            "|---|---|---:|---:|---:|---:|",
        ]
    )
    for factor in ("size", "stress"):
        for arm in ARMS:
            endpoints = report["factor_effects"][factor][arm]
            lines.append(
                f"| {factor} | {arm} | "
                f"{endpoints['material_wellbeing']['mean_difference']:.3f} | "
                f"{endpoints['service_capacity']['mean_difference']:.3f} | "
                f"{endpoints['civic_burden']['mean_difference']:.3f} | "
                f"{endpoints['failed_exits']['mean_difference']:.3f} |"
            )
    checks = report["metamorphic_checks"]
    lines.extend(
        [
            "",
            "## Metamorphic and replay checks",
            "",
            f"- Label-only transition differences: {checks['label_only_transition_differences']} / {checks['checks']}.",
            f"- Exact replay differences: {checks['exact_replay_differences']} / {checks['checks']}.",
            f"- Paired exogenous-tape differences: {checks['paired_exogenous_tape_differences']} / {checks['checks']}.",
            "",
            "## Threshold sensitivity",
            "",
            "| delay threshold | mean fast tracks | mean delay harm | mean material welfare |",
            "|---:|---:|---:|---:|",
        ]
    )
    for item in report["threshold_sensitivity"]:
        lines.append(
            f"| {item['irreversible_delay_threshold']:.2f} | {item['mean_fast_tracks']:.2f} | "
            f"{item['mean_cumulative_delay_harm']:.3f} | {item['mean_material_wellbeing']:.3f} |"
        )
    lines.extend(["", "## Negative and open findings", ""])
    lines.extend(f"- {finding}" for finding in report["negative_and_open_findings"])
    lines.extend(
        [
            "",
            "## Interpretation limits",
            "",
            "- Resident strategies, action semantics, causal equations, thresholds, and shocks are authored.",
            "- The common-random-number design removes one simulation confound; it does not validate the equations.",
            "- Rule-based adaptation is not a substitute for the V4 four-arm learned-agent trial.",
            "- Semantic detection failures remain in scope and are counted as false negatives when they execute.",
            "- Passing the release checks certifies artifact integrity and enumerated behavior only—not deployment safety, legitimacy, policy effectiveness, or real-world validity.",
            "",
            f"Report digest: `{report['report_digest']}`",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds", type=int, default=12)
    parser.add_argument("--epochs", type=int, default=60)
    parser.add_argument("--sizes", type=int, nargs="+", default=[16, 64])
    parser.add_argument("--stresses", type=float, nargs="+", default=[0.8, 1.4])
    parser.add_argument(
        "--json-output",
        type=Path,
        default=PROJECT_ROOT / "reports" / "open_world_experiment.json",
    )
    parser.add_argument(
        "--markdown-output",
        type=Path,
        default=PROJECT_ROOT / "reports" / "open_world_experiment.md",
    )
    args = parser.parse_args()
    report = run(
        seed_count=args.seeds,
        epochs=args.epochs,
        sizes=args.sizes,
        stresses=args.stresses,
    )
    args.json_output.parent.mkdir(parents=True, exist_ok=True)
    args.json_output.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    args.markdown_output.write_text(markdown(report), encoding="utf-8")
    print(
        json.dumps(
            {
                "passed": report["metamorphic_checks"]["passed"],
                "run_count": report["design"]["run_count"],
                "report_digest": report["report_digest"],
                "json": str(args.json_output),
                "markdown": str(args.markdown_output),
            },
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
