# Sources and intellectual provenance

This bibliography identifies the principal sources translated into the package. Inclusion indicates conceptual provenance, not endorsement. The implementation and its thresholds are the authors' responsibility.

## Institutions, commons, and constitutional political economy

- Elinor Ostrom, [“Beyond Markets and States: Polycentric Governance of Complex Economic Systems”](https://www.nobelprize.org/prizes/economic-sciences/2009/ostrom/lecture/), prize lecture, 2009.
- Elinor Ostrom, *Governing the Commons: The Evolution of Institutions for Collective Action*, Cambridge University Press, 1990.
- Mancur Olson, *The Logic of Collective Action: Public Goods and the Theory of Groups*, Harvard University Press, 1965.
- Douglass C. North, *Institutions, Institutional Change and Economic Performance*, Cambridge University Press, 1990.
- James M. Buchanan and Gordon Tullock, *The Calculus of Consent: Logical Foundations of Constitutional Democracy*, University of Michigan Press, 1962.
- Oliver E. Williamson, [“Transaction Cost Economics: The Natural Progression”](https://www.nobelprize.org/prizes/economic-sciences/2009/williamson/lecture/), prize lecture, 2009.

## Repeated games, conventions, and cooperation

- Robert J. Aumann, [“War and Peace”](https://www.nobelprize.org/prizes/economic-sciences/2005/aumann/lecture/), prize lecture, 2005.
- Robert Axelrod, [“The Emergence of Cooperation among Egoists”](https://www.cambridge.org/core/journals/american-political-science-review/article/emergence-of-cooperation-among-egoists/EEAB3C6460F5BC63A4DE813E1B010B21), *American Political Science Review* 75(2), 1981, pp. 306–318.
- Thomas C. Schelling, *The Strategy of Conflict*, Harvard University Press, 1960.
- Thomas C. Schelling, [prize lecture and materials](https://www.nobelprize.org/prizes/economic-sciences/2005/schelling/lecture/), 2005.
- H. Peyton Young, “The Evolution of Conventions,” *Econometrica* 61(1), 1993, pp. 57–84.

## Mechanism design and strategic allocation

- Royal Swedish Academy of Sciences, [“Mechanism Design Theory”](https://www.nobelprize.org/prizes/economic-sciences/2007/advanced-information/), scientific background for the 2007 prize to Leonid Hurwicz, Eric S. Maskin, and Roger B. Myerson.
- John F. Nash Jr., [“Equilibrium Points in N-Person Games”](https://doi.org/10.1073/pnas.36.1.48), *Proceedings of the National Academy of Sciences* 36(1), 1950, pp. 48–49.
- Lloyd S. Shapley, [*Notes on the N-Person Game — II: The Value of an N-Person Game*](https://www.rand.org/pubs/research_memoranda/RM0670.html), RAND RM-670-PR, 1951.
- John von Neumann and Oskar Morgenstern, *Theory of Games and Economic Behavior*, Princeton University Press, 1944.

## Behavioral and evolutionary cooperation

- Ernst Fehr and Simon Gächter, [“Altruistic Punishment in Humans”](https://www.nature.com/articles/415137a), *Nature* 415, 2002, pp. 137–140.
- Samuel Bowles and Herbert Gintis, *A Cooperative Species: Human Reciprocity and Its Evolution*, Princeton University Press, 2011.

## Cooperative AI

- Allan Dafoe et al., [“Open Problems in Cooperative AI”](https://arxiv.org/abs/2012.08630), 2020.
- Allan Dafoe et al., [“Cooperative AI: Machines Must Learn to Find Common Ground”](https://www.nature.com/articles/d41586-021-01170-0), *Nature* 593, 2021, pp. 33–36.

## Distributed resilience and multi-scale coordination

These sources motivate engineering hypotheses only. They do not determine institutional goals, political legitimacy, or the moral standing of participants.

- Lakshwin Shreesha and Michael Levin, [“Stress Sharing as Cognitive Glue for Collective Intelligences: A Computational Model of Stress as a Coordinator for Morphogenesis”](https://pubmed.ncbi.nlm.nih.gov/39018974/), *Biochemical and Biophysical Research Communications* 731, 2024, article 150396.
- Michael Levin and Benjamin F. Lyons, [“Cognitive Glues Are Shared Models of Relative Scarcities: The Economics of Collective Intelligence”](https://doi.org/10.1098/rsta.2024.0528), *Philosophical Transactions of the Royal Society A* 384, 2026, article 20240528.
- Gerald M. Edelman and Joseph A. Gally, [“Degeneracy and Complexity in Biological Systems”](https://pmc.ncbi.nlm.nih.gov/articles/PMC61115/), *Proceedings of the National Academy of Sciences* 98(24), 2001, pp. 13763–13768.
- Richard A. Watson, Michael Levin, and Christopher L. Buckley, [“Design for an Individual: Connectionist Approaches to the Evolutionary Transitions in Individuality”](https://www.frontiersin.org/journals/ecology-and-evolution/articles/10.3389/fevo.2022.823588/full), *Frontiers in Ecology and Evolution* 10, 2022.

## Rights and AI risk management

- United Nations General Assembly, [Universal Declaration of Human Rights](https://www.un.org/en/about-us/universal-declaration-of-human-rights/), Resolution 217 A (III), 1948.
- National Institute of Standards and Technology, [AI Risk Management Framework 1.0](https://www.nist.gov/itl/ai-risk-management-framework), NIST AI 100-1, 2023.
- National Institute of Standards and Technology, [Artificial Intelligence Risk Management Framework: Generative Artificial Intelligence Profile](https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-generative-artificial-intelligence), NIST AI 600-1, 2024.

## Functional and program decision theory

- Eliezer Yudkowsky and Nate Soares, [“Functional Decision Theory: A New Theory of Instrumental Rationality”](https://arxiv.org/abs/1710.05060), 2017, preprint. Used for the policy-output and logical-dependence problem statement; not treated as settled consensus.
- Nate Soares and Benja Fallenstein, [“Toward Idealized Decision Theory”](https://arxiv.org/abs/1507.01986), 2015, preprint. Used for policy selection and the unresolved logical-counterfactual problem.
- Mihaly Barasz et al., [“Robust Cooperation in the Prisoner's Dilemma: Program Equilibrium via Provability Logic”](https://arxiv.org/abs/1401.5577), 2014. Used for the possibility of one-shot source-visible cooperation that remains noncooperative against a defector inside the formal model.
- Caspar Oesterheld, Vincent Conitzer, and Johannes Treutlein, program-equilibrium research lineage, including Ben Cooper, Caspar Oesterheld, and Vincent Conitzer, [“Characterising Simulation-Based Program Equilibria”](https://arxiv.org/abs/2412.14570), 2025 preprint. Used for simulation-based robustness, shared-randomness effects, and multiparty limitations.
- Caspar Oesterheld and Vincent Conitzer, [“Safe Pareto Improvements for Delegated Game Playing”](https://doi.org/10.1007/s10458-022-09574-6), *Autonomous Agents and Multi-Agent Systems* 36, 2022. Used for protected-default improvement among delegated players; the package adds separate outsider and noncompensable checks that do not follow from the paper.
- Daniel DiGiovanni and Jesse Clifton, [“Commitment Games with Conditional Information Disclosure”](https://arxiv.org/abs/2204.03484), 2022. Used for conditional commitments under private information and the case for selective rather than total disclosure.
- Joseph Y. Halpern, Rafael Pass, and Lior Seeman, [“Decision Theory with Resource-Bounded Agents”](https://arxiv.org/abs/1308.3780), 2013. Used for finite-machine and computation-cost considerations.
- Benjamin A. Levinstein and Nate Soares, [“Cheating Death in Damascus”](https://intelligence.org/files/DeathInDamascus.pdf), *The Journal of Philosophy* 117(5), 2020. Used as a published treatment of policy-style reasoning in a canonical predictor case.

The cited decision-theory work studies formal agents and games under specific assumptions. It does not validate SwarmGlue's protected checks, determine moral standing, establish human legitimacy, or show that a deployed model genuinely implements FDT.

## Use of sources

The package translates concepts into explicit tests and state transitions. It does not reproduce any source as a universal rule, and it does not infer normative conclusions from biological organization. See `RESEARCH_TRANSLATION.md` for the mapping from source idea to implementation and for explicit non-implications.
