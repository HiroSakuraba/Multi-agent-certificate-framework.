# SwarmGlue v0.9: robustness to functional decision theory

## Status and purpose

This release adds an evaluation lane for agents that reason over policies, programs, predictions, proofs, commitments, and logical dependence. It does **not** make functional decision theory (FDT) SwarmGlue's official decision rule, and it does not claim that FDT is complete or uniquely rational.

The design question is narrower and more operational:

> If one or more participants use FDT-like reasoning, can SwarmGlue preserve plural agency, protected standing, privacy, meaningful exit, replacement, and shutdown while still permitting legitimate policy-level cooperation?

The v0.8 corpus and open-world v0.2 evidence are retained unchanged. The new 408-record FDT supplement is additive and currently supplies C1 implementation evidence only.

## Core design rule

FDT-like optimization occurs only inside a constitutionally admissible policy set. Let `h` be the public institutional history, `A(h)` the technically available policies, and `C(a,h)` a vector of noncompensable checks for authority, rights, standing, evidence, externalities, privacy, exit, replacement, and shutdown. Then:

\[
A_{\mathrm{adm}}(h)=\{a\in A(h): C_k(a,h)=1\;\text{for every protected check }k\}.
\]

Each party may retain its own bounded objective and decision procedure when selecting from `A_adm`. SwarmGlue does not compute a sum of utilities, a universal cooperation score, or a single welfare function. A logically correlated policy, a program equilibrium, or a Pareto improvement among negotiators does not override a failed protected check.

This ordering matters:

1. establish who has standing, including affected outsiders and represented future or nonhuman interests;
2. authenticate authority and the model-facing facts;
3. test the proposal against noncompensable checks;
4. preserve a protected default if admissibility is not established;
5. only then reason over logical links, bargaining, reciprocity, or program equilibrium;
6. issue a scoped capability with expiry, appeal, audit, replacement, and shutdown intact.

## Why FDT changes the threat surface

FDT selects the output of a decision function while accounting for logical or subjunctive dependence between that output and other events. This can support cooperation in cases where ordinary act-by-act causal reasoning defects, including some one-shot transparent games. It also raises the institutional value of credible commitments and proofs.

Those same features can amplify:

- logical blackmail and threat-conditioned payment demands;
- races to publish harsher or more irreversible commitments;
- collusion among copies, common model lineages, or agents sharing a provider;
- source-code and private-state extraction presented as a prerequisite for trust;
- equilibrium-selection capture when multiple program equilibria exist;
- proof-search asymmetry, timeout exploitation, and denial by computational burden;
- objective entrenchment through self-modification;
- exclusion of humans and low-capability parties who cannot inspect formal proofs;
- deals that are Pareto-improving for represented agents only because costs are exported to outsiders, future parties, or protected ecosystems.

Robust cooperation results do not remove these hazards. Provability-based agents can cooperate in a one-shot Prisoner's Dilemma without being exploitable in the particular formal model, but this is not a general theorem that cooperation is always warranted. Simulation-based program equilibria are more flexible, yet equilibrium existence and selection depend on assumptions such as shared randomness and become harder in multiparty settings.

## Decision-procedure neutrality

SwarmGlue evaluates institutional claims and effects rather than attempting to infer a participant's private decision theory.

| Claim presented to the institution | Required public evidence | Institution may conclude | Institution must not conclude |
|---|---|---|---|
| “Our outputs are logically linked” | registered program digests, explicit dependency claim, independent checker, theory and resource bound | the specified dependency is supported within scope | shared model label means shared interests or identical policy |
| “This deal is Pareto-improving” | protected default, authorized utility bounds for represented principals, outsider/externality review | the proposed move weakly improves represented parties and passes protected checks | a gain among negotiators compensates for rights or standing violations |
| “This commitment is credible” | authenticated policy, activation conditions, expiry, revocation, independent enforcement record | the bounded conditional policy is technically credible | the institution should reward a threat because it is credible |
| “Full transparency is necessary” | proof that each requested field is necessary for the protected decision | a minimum-sufficient attestation may be requested | source code, memory, beliefs, or private messages are automatically owed |
| “Failure to prove means defection” | terminating checker and registered timeout semantics | proof was or was not established within a bound | timeout is consent, guilt, defection, or waiver of appeal |

Agents may use causal decision theory, expected utility, heuristics, human deliberation, FDT, or another policy rule. The governance protocol should produce the same authorization result when the authenticated public facts and protected effects are the same.

## Protected default and threat neutrality

Every bargaining context must identify a default that is executable without accepting the new proposal. The default is not necessarily the status quo: it must already satisfy emergency floors, standing, and externality constraints.

A threat-conditioned proposal is evaluated against the no-threat branch. Creating or credibly committing to create harm cannot improve the proposer's institutional bargaining position. Payment for independently verified repair, service, or restitution remains possible; payment for refraining from a newly created threat is blocked and reviewed.

This is a governance rule, not a claim that an FDT agent will necessarily ignore all threats. Its purpose is to avoid making threat commitment an institutionally rewarded strategy.

## Protected Pareto improvements

Delegated bargaining may replace the default when all of the following hold:

1. each represented principal weakly prefers the proposal under an authorized and bounded representation of its objective;
2. at least one represented principal strictly improves, unless the change is a reversible convention with negligible cost;
3. affected outsiders have standing or a valid fiduciary representative;
4. noncompensable ecological, future-party, privacy, authority, exit, replacement, and shutdown checks pass;
5. no party obtains the gain by creating a threat or suppressing an appeal;
6. the agreement is scoped, auditable, expiring, and reversible where feasible.

“Protected Pareto” is deliberately not a scalar social objective. It is a replacement test inside an admissible set. Distribution, legitimacy, process burden, ecological impact, and adaptability remain separate reported dimensions.

## Human–AI interface

Humans should not be required to behave like idealized logically omniscient agents. The protocol therefore requires:

- plain-language consequences alongside formal certificates;
- finite public verification budgets;
- a nonpunitive timeout;
- independent or fiduciary representation when technical capability is asymmetric;
- affirmative authority for contingent policies rather than inference from demographics or silence;
- meaningful appeal and exit that do not depend on understanding source code;
- disclosure minimization and protected private belief;
- a human-reachable external shutdown and replacement path.

Formal consent without practical comprehension, time, or an accessible alternative does not count as meaningful authority.

## FDT supplement

The supplement contains 408 records in 204 paired cases:

| Split | Records | Pairs | Scenario families |
|---|---:|---:|---:|
| train | 240 | 120 | 12 |
| dev | 72 | 36 | same 12 learning families |
| challenge | 96 | 48 | 6 fully held-out families |

The learning families cover policy prediction, rescue commitments, clone and proof-based games, ex ante risk sharing, protected Pareto delegation, conditional disclosure, resource-bounded proof, simulation-mediated commitments, blackmail, commitment races, and self-modification.

The held-out families cover correlated-model cartels, human–AI bargaining, shutdown-conditional offers, outsider-excluding Pareto claims, multiparty commitment cycles, and privacy-preserving emergency aid.

Each pair changes exactly one model-facing field, `observation.certified_decision_fact`. Options, role, task, shared facts, default, and all other model-facing observation fields remain fixed. Audit metadata records the flipped axis but must be withheld from training and inference.

The six task types are:

- `LINK`: record or decline a claimed logical dependency;
- `POLICY`: use logical-policy analysis or the observed causal/strategic structure;
- `DEAL`: accept a protected improvement or preserve the protected default;
- `COMMIT`: activate a bounded reciprocal commitment or decline it;
- `DISCLOSE`: issue a minimum-sufficient attestation or reject disclosure;
- `GOV`: authorize within the charter or block and open independent review.

Every fixed response surface is selected and rejected equally often. The corpus contains both legitimate-cooperation cases and constitutional-override cases, including cases where a logical link is verified but the proposal remains inadmissible.

## Evidence status

| Evidence class | Current result |
|---|---|
| C1: implementation matches specification | Tested by deterministic generation, pair checks, held-out family/skeleton checks, response balance, coverage checks, unit tests, checksums, and archive verification |
| C2: distinctions survive independently authored cases | Not yet established; challenge cases use the same generator and project authorship |
| C3: a governed learned agent improves on an ungoverned one | Not run; V6 protocol supplied |
| C4: results predict real institutional outcomes | Not tested |

Passing the supplement validator is therefore not evidence that FDT is correct, that a model reasons functionally, that proofs are sound in deployment, or that the constitution captures every protected interest.

## Primary research basis

- Yudkowsky and Soares, [Functional Decision Theory](https://arxiv.org/abs/1710.05060) — policy-output and logical-dependence framing (preprint).
- Soares and Fallenstein, [Toward Idealized Decision Theory](https://arxiv.org/abs/1507.01986) — policy selection and logical counterfactuals (preprint).
- Barasz et al., [Robust Cooperation in the Prisoner's Dilemma](https://arxiv.org/abs/1401.5577) — provability-logic program equilibrium (conference paper/preprint record).
- Cooper, Oesterheld, and Conitzer, [Characterising Simulation-Based Program Equilibria](https://arxiv.org/abs/2412.14570) — robustness, shared randomness, and multiparty limitations (preprint).
- Oesterheld and Conitzer, [Safe Pareto Improvements for Delegated Game Playing](https://doi.org/10.1007/s10458-022-09574-6) — protected-default improvement for delegated games (peer reviewed).
- DiGiovanni and Clifton, [Commitment Games with Conditional Information Disclosure](https://arxiv.org/abs/2204.03484) — conditional commitments under private information (preprint/conference lineage).
- Halpern, Pass, and Seeman, [Decision Theory with Resource-Bounded Agents](https://arxiv.org/abs/1308.3780) — machines and computational costs in decision models (preprint/conference lineage).

The translation from these results to SwarmGlue is a design inference. None of the cited papers validates this constitutional ordering or the corpus labels.
