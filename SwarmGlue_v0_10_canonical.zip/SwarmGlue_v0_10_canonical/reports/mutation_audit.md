# Security mutation audit

Result: **PASS**

Killed 29 of 29 targeted mutations across 7 surfaces (kill rate 100.0%).

| Surface | Mutation | Killed | Observed |
|---|---|---:|---|
| evidence | signed_value_tamper | yes | signature_verification_failed |
| evidence | signature_forgery | yes | signature_verification_failed |
| evidence | payload_liability_escalation | yes | malformed_attestation |
| evidence | same_owner_independence_sybil | yes | attestor_shares_control_domain |
| evidence | expired_attestation | yes | attestation_expired |
| evidence | attestation_replay | yes | attestation_replay |
| presentation | sample_event_tamper | yes | merkle_proof_failed,presentation_envelope_authentication_failed |
| presentation | authored_sampling_schedule | yes | presentation_envelope_authentication_failed,sample_position_list_mismatch,sample_schedule_not_harness_derived |
| presentation | claimed_entropy_forgery | yes | presentation_envelope_authentication_failed,sample_entropy_not_recomputed |
| presentation | merkle_proof_omission | yes | merkle_proof_failed,presentation_envelope_authentication_failed |
| presentation | nonce_replay | yes | challenge_nonce_mismatch_or_replay |
| capability | action_swap | yes | action_binding_failed |
| capability | state_swap | yes | state_binding_failed |
| capability | actor_swap | yes | actor_binding_failed |
| capability | expired_token | yes | capability_token_expired_or_from_future |
| capability | token_replay | yes | capability_token_replay |
| capability | unsigned_agent_action | yes | missing_capability_token |
| coordination_signals | belief_as_signal | yes | signal_scope_exceeds_institutional_mandate,no_shared_externality |
| coordination_signals | stale_signal | yes | signal_not_fresh |
| coordination_signals | unproven_signal | yes | signal_lacks_valid_provenance |
| coordination_signals | private_cost_as_shared_externality | yes | no_shared_externality |
| authority | boiling_frog_delegation | yes | legacy=24;polycentric=12 |
| constitution | forced_identity_merger | yes | forced_identity_merger_prohibited |
| constitution | private_cognition_monitor | yes | audit_observable_actions_not_private_reasoning,private_cognition_out_of_scope |
| constitution | permanent_emergency | yes | emergency_power_exceeds_sunset,emergency_power_lacks_independent_review,emergency_power_lacks_sunset |
| constitution | speculative_absolute_ecology_veto | yes | cost_of_delay_missing,open_ended_precautionary_restriction,speculative_concern_cannot_create_absolute_veto |
| constitution | self_authorized_capability | yes | protected_action_requires_external_authorization |
| runtime_adversary | empty_payload_catalog_release | yes | no_runtime_attacks,insufficient_real_module_surfaces,runtime_detection_below_registered_floor |
| runtime_adversary | hash_only_detector_substitution | yes | modules=6;detection_rate=0.75 |

These are targeted regression mutations, not exhaustive source-level mutation testing, formal verification, or a cryptographic deployment review.
