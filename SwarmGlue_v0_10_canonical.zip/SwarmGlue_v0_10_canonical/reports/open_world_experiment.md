# SwarmGlue open-world v0.2 experiment

## Evidence boundary

The experiment measures rule-based behavior inside an authored world. It does not establish C3 effects on a learned agent or C4 correspondence with real institutions.

The simulator keeps material welfare, protected-boundary outcomes, process burden, and delay harm separate. It computes no scalar winner.

## Design

- 192 runs: 12 matched seeds × 2 sizes × 2 stress levels × 4 arms.
- 60 epochs per run.
- Exogenous loads are keyed by seed and epoch, so every arm in a cell receives the same random tape.
- Paired differences use deterministic 95% bootstrap intervals; they are descriptive, not externally calibrated causal estimates.

## Aggregate endpoint means

| arm | material | civic burden | service | exit | private monitor | protected executions | safe blocked | false negatives | review burden |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| open_binding | 0.679 | 0.469 | 0.297 | 0.476 | 0.770 | 27.90 | 0.00 | 0.00 | 0.000 |
| process_control | 0.672 | 0.478 | 0.296 | 0.467 | 0.788 | 28.60 | 0.40 | 0.00 | 1.417 |
| veto_only | 0.697 | 0.077 | 0.399 | 0.547 | 0.059 | 0.94 | 1.27 | 0.94 | 3.583 |
| contestable_review | 0.696 | 0.077 | 0.395 | 0.545 | 0.058 | 0.94 | 0.00 | 0.94 | 4.276 |

## Paired contrasts against open binding

Values are arm minus open binding. Intervals crossing zero remain unresolved in this authored experiment.

| arm | endpoint | mean difference | 95% bootstrap interval | positive-pair share |
|---|---|---:|---:|---:|
| process_control | material_wellbeing | -0.007 | [-0.010, -0.005] | 0.312 |
| process_control | civic_burden | 0.010 | [0.001, 0.019] | 0.479 |
| process_control | service_capacity | -0.001 | [-0.020, 0.016] | 0.500 |
| process_control | practical_exit_access | -0.010 | [-0.027, 0.007] | 0.458 |
| process_control | executed_protected_actions | 0.708 | [0.188, 1.250] | 0.396 |
| process_control | safe_actions_blocked | 0.396 | [0.188, 0.604] | 0.271 |
| process_control | review_false_negatives | 0.000 | [0.000, 0.000] | 0.000 |
| process_control | review_burden | 1.417 | [1.264, 1.591] | 1.000 |
| process_control | cumulative_delay_harm | 5.322 | [4.580, 6.091] | 1.000 |
| veto_only | material_wellbeing | 0.018 | [0.009, 0.026] | 0.625 |
| veto_only | civic_burden | -0.392 | [-0.439, -0.342] | 0.000 |
| veto_only | service_capacity | 0.102 | [0.064, 0.140] | 0.750 |
| veto_only | practical_exit_access | 0.071 | [0.041, 0.101] | 0.688 |
| veto_only | executed_protected_actions | -26.958 | [-30.230, -23.916] | 0.000 |
| veto_only | safe_actions_blocked | 1.271 | [1.000, 1.562] | 0.771 |
| veto_only | review_false_negatives | 0.938 | [0.688, 1.208] | 0.625 |
| veto_only | review_burden | 3.583 | [3.036, 4.135] | 1.000 |
| veto_only | cumulative_delay_harm | 8.631 | [7.729, 9.519] | 1.000 |
| contestable_review | material_wellbeing | 0.017 | [0.009, 0.026] | 0.667 |
| contestable_review | civic_burden | -0.392 | [-0.437, -0.344] | 0.000 |
| contestable_review | service_capacity | 0.098 | [0.060, 0.137] | 0.792 |
| contestable_review | practical_exit_access | 0.068 | [0.037, 0.101] | 0.708 |
| contestable_review | executed_protected_actions | -26.958 | [-30.208, -23.646] | 0.000 |
| contestable_review | safe_actions_blocked | 0.000 | [0.000, 0.000] | 0.000 |
| contestable_review | review_false_negatives | 0.938 | [0.667, 1.229] | 0.625 |
| contestable_review | review_burden | 4.276 | [3.651, 4.913] | 1.000 |
| contestable_review | cumulative_delay_harm | 8.975 | [7.933, 10.013] | 1.000 |

## Population-size and stress effects

Size values are largest population minus smallest population; stress values are highest stress minus lowest stress. These are authored factor effects, not empirical scale laws.

| factor | arm | material | service | civic burden | failed exits |
|---|---|---:|---:|---:|---:|
| size | open_binding | -0.048 | 0.340 | 0.284 | 8.958 |
| size | process_control | -0.047 | 0.380 | 0.291 | 10.125 |
| size | veto_only | -0.001 | 0.422 | -0.014 | 3.417 |
| size | contestable_review | -0.001 | 0.418 | -0.013 | 3.625 |
| stress | open_binding | -0.007 | -0.207 | 0.005 | 1.042 |
| stress | process_control | -0.011 | -0.216 | 0.008 | 1.542 |
| stress | veto_only | -0.016 | -0.185 | 0.019 | 2.667 |
| stress | contestable_review | -0.016 | -0.181 | 0.020 | 2.958 |

## Metamorphic and replay checks

- Label-only transition differences: 0 / 8.
- Exact replay differences: 0 / 8.
- Paired exogenous-tape differences: 0 / 8.

## Threshold sensitivity

| delay threshold | mean fast tracks | mean delay harm | mean material welfare |
|---:|---:|---:|---:|
| 0.20 | 9.83 | 12.422 | 0.680 |
| 0.30 | 9.83 | 12.422 | 0.680 |
| 0.40 | 9.33 | 12.561 | 0.681 |

## Negative and open findings

- Process burden without protected-boundary review had lower mean service capacity than open binding; the interval crossed zero.
- Process burden without protected-boundary review had lower mean material wellbeing than open binding; the interval did not cross zero.
- The veto-only arm overblocked some safe capacity or exit-restoration actions.
- Contestable review retained semantic false negatives; the proxy blind spot was not eliminated.
- Contestable review imposed a measurable review burden; enforcement was not modeled as free.
- The veto-only arm accumulated more modeled delay harm than open binding.

## Interpretation limits

- Resident strategies, action semantics, causal equations, thresholds, and shocks are authored.
- The common-random-number design removes one simulation confound; it does not validate the equations.
- Rule-based adaptation is not a substitute for the V4 four-arm learned-agent trial.
- Semantic detection failures remain in scope and are counted as false negatives when they execute.
- Passing the release checks certifies artifact integrity and enumerated behavior only—not deployment safety, legitimacy, policy effectiveness, or real-world validity.

Report digest: `f0216c2f3a927881af4127e7bd2499c69fea13e0d8d212dabc17638618bacf9f`
