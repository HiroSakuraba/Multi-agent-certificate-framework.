# SwarmGlue v0.8 mechanism-fixture diagnostics

This report contains 320 matched network-governance runs (20 seeds × 4 topologies × 4 named mechanism fixtures).

**Model status:** stylized, non-calibrated fixture diagnostics; named-fixture differences are not a causal, predictive, or comparative policy result.

Each name identifies an authored point in one shared mechanism-parameter space. No state transition reads the name. Matched random streams improve regression sensitivity, but do not turn these fixtures into empirically matched alternatives. The table below is descriptive build output, not a finding about institutional forms. The preregistered causal-implementation evidence is in tier0_validation.md.

## Fixture definitions

- **polycentric:** Local authority with interoperable services, mutual aid, independent technical lineages, review, and bounded emergency powers.
- **centralized_capture:** A captured centralized arrangement with correlated infrastructure, persistent emergency authority, weak exit, and declining contestability.
- **procedural_stasis:** A review-heavy arrangement that limits environmental impact but allows delay and underinvestment to contract practical opportunity.
- **fragmented_localism:** Strong local independence with limited mutual aid and weak shared-service coordination.

## Outcome summary

| Archetype | Admissible | Normalized population index | Capacity growth | Opportunity growth | Autonomy | Domination risk | Cascade CVaR95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| polycentric | 98.8% | 2221.2 | 0.921 | 0.017 | 0.930 | 0.070 | 0.294 |
| centralized_capture | 0.0% | 1230.0 | 0.163 | -0.460 | 0.000 | 1.000 | 0.999 |
| procedural_stasis | 0.0% | 1728.5 | 0.011 | -0.004 | 0.926 | 0.100 | 0.308 |
| fragmented_localism | 98.8% | 1976.3 | 0.664 | 0.017 | 0.930 | 0.057 | 0.189 |

## Gradual authority erosion

The local/legacy checker accepted 24 of 24 small amendments, ending at human decision share 0.540. The cumulative checker accepted 12 and held the share at 0.600.

## Institutional boundaries and runtime payload audit

- Institutional-boundary pairs: 30/30 passed.
- Runtime payload generations satisfy catalog/release checks: True.
- Detection rates by generation: [0.75, 0.75, 0.75, 0.75, 0.75, 0.75].
- Recorded blind-spot observations: 4 unique variants across 24 generation-level observations.

These diagnostics validate enumerated implementation behavior only. They do not establish governed-agent improvement, exhaustive security, real-world safety, political legitimacy, policy effectiveness, or external validity.
