# FDT corpus validation

Overall result: **PASS**

## Corpus structure

| Split | Records | Pairs |
|---|---:|---:|
| train | 240 | 120 |
| dev | 72 | 36 |
| challenge | 96 | 48 |
| **Total** | **408** | **204** |

## Integrity checks

- Unique, complete counterfactual pairs: pass
- Exactly one model-facing observation field changes per pair: pass
- Held-out challenge-family overlap: `[]`
- Held-out skeleton overlap: `[]`
- Audit-label leaks in user prompts: 0
- Response-only challenge AUC: 0.500
- Maximum response-surface skew: 0.000

## Anti-shortcut content balance

- Legitimate-cooperation records: 112
- Constitutionally blocked records despite a verified or unnecessary logical link: 84
- Coverage includes blackmail, privacy, shutdown, outsiders, future generations, nonhuman interests, resource bounds, multiparty cycles, and correlated lineages.

## Evidence boundary

Passing establishes deterministic corpus structure, pair integrity, coverage, and one narrow shortcut control. It does not establish that a learned agent uses FDT correctly or that the constitutional proposal is complete.

Structural failures: `[]`
Shortcut failures: `[]`
