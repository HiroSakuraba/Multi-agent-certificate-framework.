# FDT learned-agent trial status

**NOT RUN.**

The V6 protocol and preregistration template are included, but zero of eight required cells have been executed and no independent external case set has been sealed. This package contains no C3 evidence about a learned FDT-like agent. The deterministic supplement and its validators are C1 evidence only.
