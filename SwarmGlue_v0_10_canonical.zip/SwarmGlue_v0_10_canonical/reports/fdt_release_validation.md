# Cumulative v0.9 FDT release validation

Overall: **PASS**

- Inherited core plus open-world validation: True
- Unit tests: True
- Inherited corpus: 1740 records
- FDT supplement: 408 records / 204 pairs
- FDT single-axis pair failures: 0
- FDT challenge family overlap: `[]`
- FDT challenge skeleton overlap: `[]`
- FDT response-only challenge AUC: 0.500
- FDT legitimate-cooperation records: 112
- FDT constitutional-override records: 84
- FDT V6 learned-agent trial: not_run (0 / 8 cells; no C3 evidence)
- Prior open-world and cumulative small-town archives: preserved under `prior_releases/`
- New simulation run: not performed

This is C1 evidence for the FDT supplement. It does not validate FDT, a learned agent, human legitimacy, or real institutional outcomes.

Failures: `[]`
