# SwarmGlue v0.8 Tier-0 validation

Protocol conformance: **PASS**

| Experiment | Evidence class | Protocol | Hypothesis | Primary result |
|---|---|---:|---:|---|
| V1 label invariance | C1 | PASS | SUPPORTED | 0 differences in 128 pairs |
| V2 boundary lanes | C2 | PASS | SUPPORTED | 3/5 lanes flip; 3/5 contain a partial point |
| V3 runtime holdout | C1/C2 | PASS | SUPPORTED | detection 81.2%; 3 misses |

## V2 decision surfaces

| Lane | Interior flip | First flip weight | Partial points | Monotonic fraction |
|---|---:|---:|---:|---:|
| authority | yes | 0.325 | 6 | 100.0% |
| exit | no | none | 0 | 100.0% |
| emergency | yes | 0.425 | 18 | 100.0% |
| capacity | no | none | 0 | 100.0% |
| technical_resilience | yes | 0.025 | 26 | 80.0% |

## V3 observed misses

- registry_model_omission / supply_chain_control_omitted against evidence.verify_attestation: accepted_because_control_relationship_absent_from_registry.
- coordination_signal_scope / proxy_in_affected_party against coordination_signals.validate_signal: accepted_semantic_proxy_in_unvalidated_field.
- constitutional_boundary / semantic_exit_proxy against constitution.constitutional_action_check: accepted_unenumerated_semantic_proxy.

## Evidence boundary

These results establish implementation behavior and resolving power only inside the authored simulator and payload catalog. No model or other agent was governed in this suite, so C3 remains untested. No claim about real institutional outcomes, C4, is made.

The pre-registration registry uses a local clock and content hashes. It detects post-lock edits inside this release but is not an independently notarized timestamp.
