# Open-world mutation audit

Baseline probes passed: **True**  
Mutants killed: **7 / 7**  
Kill rate: **1.000**

| mutant | killed | triggered probes |
|---|---:|---|
| private_effect_reclassified_safe | True | private_monitoring_veto_failed |
| authorized_effect_dropped | True | open_binding_effect_not_executed |
| profile_label_enters_policy | True | profile_label_changed_transition |
| exogenous_tape_depends_on_arm | True | exogenous_probe_crashed:AssertionError |
| delay_harm_zeroed | True | irreversible_delay_fast_track_failed |
| contestable_appeal_removed | True | safe_false_positive_not_repaired |
| cumulative_authority_review_removed | True | gradual_authority_drift_not_blocked |

These in-process mutants test enumerated simulation invariants; they are not an independent security assessment.
