# Public-framing terminology audit

Overall: **PASS**

- Files scanned: 121
- Rules applied: 12
- Violations: 0

This release gate checks public framing only. It does not evaluate conceptual quality or external validity.
