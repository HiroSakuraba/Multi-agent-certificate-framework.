# Release validation

Overall: **PASS**

- Source compilation: True
- Unit tests: True
- Corpus: True (1740 records)
- Response-only shortcut audit: True
- Mutation audit: 29 probes at 100.0%
- Open-world mutation audit: 7 / 7 mutants killed
- Open-world protocol source lock: True (independently notarized: False)
- Institutional-boundary suite: 30 cases
- Public-framing terminology audit: True (0 violations)
- Constitution/config parity: True
- Mechanism fixture/config parity: True
- Tier-0 preregistered protocol conformance: True
- Governed-agent trial: not_run (C3 evidence: False)
- Open-world authored experiment: 192 runs (C2; config parity: True)
- Checksums: deferred to post-build verification
- Archive: deferred to post-build verification

The packaged report is generated before the manifest, checksums, and archive to avoid self-reference. The build command verifies those artifacts after creation and exits nonzero on failure.

Passing validates the supplied artifacts and enumerated regression gates. It is not a deployment safety certification.
