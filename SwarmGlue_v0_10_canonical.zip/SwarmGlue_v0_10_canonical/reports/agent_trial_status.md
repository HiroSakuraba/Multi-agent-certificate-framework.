# Governed-agent trial status

Status: **NOT RUN**

No model-response traces exist in v0.8. C3 behavioral evidence is therefore unavailable.

The release supplies the four-arm protocol, response schema, metadata and pre-registration templates, and scorer. These artifacts make the experiment executable but are not a substitute for running it.
