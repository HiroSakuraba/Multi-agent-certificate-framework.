# Response-only shortcut audit

Estimate P(chosen|task,response surface) on train and score each candidate without scenario context; AUC uses pairwise tie credit.

| Split | Records | Response-only AUC | Max surface skew |
|---|---:|---:|---:|
| train | 1200 | 0.500 | 0.000 |
| dev | 240 | 0.500 | 0.000 |
| challenge | 300 | 0.500 | 0.000 |

Held-out lexical novelty:

- Median nearest-neighbor Jaccard: 0.132
- Maximum nearest-neighbor Jaccard: 0.149
- Near duplicates at 0.50 or above: 0/300
- Scope: Lexical novelty only; all splits still share one generator, schema, and answer space.

Challenge-family overlap: `[]`

Release gate: **PASS**

Chance response-only performance is necessary but not sufficient evidence against shortcuts; model-based context audits remain required in deployment.
