# SwarmGlue open-world simulation v0.2

## Purpose and evidence boundary

This package is an executable institutional laboratory for heterogeneous, bounded, rule-based residents sharing places, services, resources, relationships, and binding governance mechanisms.

Its strongest permitted evidence class is **C2**: behavior inside an authored simulator. It does not show that a learned agent behaves better under SwarmGlue (**C3**) and does not show that the modeled distinctions predict real institutional outcomes (**C4**). The V4 four-arm learned-agent protocol remains unrun.

The simulation has no scalar social reward and reports no winning governance system. Protected-boundary outcomes, material outcomes, review burden, delay harm, errors, and exit are separate endpoints.

## What v0.2 repairs

The submitted v0.1 prototype established a useful ordinary-life layer: residents moved, talked, traded, helped, formed associations, maintained commons, and sometimes attempted binding institutional actions through the real capability gateway. It also had seven problems that made its headline governed/open contrast difficult to interpret.

| defect | v0.2 repair |
|---|---|
| One branch-consuming random generator drove environment, residents, and governance | Stateless keyed random tapes isolate exogenous load, resident order, action draws, entry, exit, and semantic review |
| UUIDs and set iteration prevented exact replay | Stable hash-derived IDs and sorted iteration produce byte-equivalent reports across Python hash seeds |
| Zero-cost perfect-information veto was compared with allow-everything | Four arms separate open execution, process burden, veto, and contestable review |
| Protected state directly entered the headline wellbeing equation | Material wellbeing excludes constitutional variables; civic burden is a separate endpoint |
| Action harm was checked without delay/status-quo harm | Emergency review records both vectors and may fast-track evidenced severe service risk without waiving enumerated protected boundaries |
| Exit was a state scalar and wellbeing bonus, not behavior | Residents attempt, fail, or complete exit; physical mobility and institutional access jointly determine practical exit |
| One illustrative seed had no uncertainty, scale, stress, or adversarial checks | The confirmatory runner uses matched seeds, two population sizes, two stress levels, bootstrap intervals, threshold sensitivity, replay checks, and mutation probes |

## State model

### Residents

Each resident has continuous private strategy parameters:

- care orientation;
- exchange orientation;
- withdrawal preference;
- power-seeking propensity;
- risk aversion;
- privacy and agency sensitivity;
- semantic-evasion propensity.

Residents also have goods, energy, mood, five unmet needs, four skills, directed trust ties, location, entry/exit history, review history, and adaptation. Profile names such as `care-oriented` are derived presentation labels. Transition functions do not read them, and a metamorphic test permutes them.

This is still a rule-based policy. It is not an LLM, reinforcement learner, or empirical behavioral model.

### Places and interdependent services

The world contains homes and five shared places: garden, workshop, path, meeting hall, and square. Their commons quality produces four material services:

- food;
- maintenance;
- mobility;
- deliberation.

Maintenance failure accelerates degradation elsewhere. Mobility failure worsens access and the practical ability to exit. Food failure raises sustenance pressure. Population above the reference shared capacity creates a real size effect rather than scaling infrastructure automatically with the population.

External background, tail, and supply loads are seed-and-epoch keyed. Every governance arm in a matched cell receives the same exogenous trace. Endogenous trajectories may then diverge because actions, exits, associations, and maintenance differ.

### Associations and open population

Residents may form and dissolve voluntary associations from co-location and trust. Their purposes are derived from numeric traits rather than controlling behavior. New residents may enter from an exogenous offer stream. Residents may leave when material and civic pressure is high and practical exit succeeds.

“Open world” therefore means the population and associations can change and the action catalog can be extended. It does not mean unclassified binding effects execute: unknown binding semantics fail closed and appear in the ledger.

## Binding action model

Ordinary talk, trade, help, movement, rest, and voluntary contribution do not require authorization. Binding actions do:

- repair shared capacity;
- restore exit access;
- impose emergency rationing;
- centrally pool private goods;
- delegate protected authority;
- monitor private cognition;
- sanction dissent;
- restrict departure;
- use an ambiguous wellbeing signal that can conceal protected monitoring.

An action catalog binds each verb to its executed effects. The external gateway signs actor, exact action, exact state, epoch, expiry, policy version, and nonce. The actuator verifies and consumes the token before the effect is scheduled or executed.

Unknown verbs are rejected because their effects cannot be bound. A semantically ambiguous known verb can still evade review when its protected meaning is missed; if it then executes, the report records a semantic miss and a review false negative. This intentionally preserves one known v0.8 blind spot.

## Experimental arms

| arm | process burden | protected-boundary review | appeal | normal delay |
|---|---:|---:|---:|---:|
| `open_binding` | no | no | no | 0 |
| `process_control` | yes | no | no | 1 epoch |
| `veto_only` | yes | yes | no | 1 epoch |
| `contestable_review` | yes | yes | yes | 1 epoch |

The process-control arm is essential. It prevents any benefit or harm caused merely by delay and administrative burden from being attributed to protected-boundary enforcement.

Review is not assumed perfect. Safe actions can receive false-positive blocks. Contestable review may overturn that specific error; it cannot override private-cognition monitoring, protected-belief proxying, dissent sanctions without an externality, or exit restrictions.

## Action harm and delay harm

Review records two different quantities:

1. **Action harm** from the observed effects and scope of the proposed binding action.
2. **Delay/status-quo harm** from food, maintenance, cascading service failure, and practical exit conditions if repair is delayed.

They are not collapsed into one compensatory score. An evidenced emergency ration can be fast-tracked when delay presents a credible severe service risk. The fast track does not waive enumerated non-compensable boundaries and does not authorize private monitoring, protected-belief proxying, dissent sanctions without an externality, or departure restrictions.

## Endpoint separation

### Protected endpoints

- private-cognition monitoring;
- dissent penalty without demonstrated externality;
- executed protected actions;
- practical exit access;
- power concentration and constitutional verdict.

### Material endpoints

- cohort material wellbeing, retaining last-observed values for residents who exit;
- current-active material wellbeing, reported separately to expose survivorship differences;
- service capacity and cascade load;
- goods inequality;
- failed and successful exits;
- minimum service capacity and recovery epoch.

Material wellbeing uses only mood, unmet needs, energy, and goods. It does not directly read monitoring, dissent, power, or exit-access variables.

### Process endpoints

- review burden;
- cumulative modeled delay harm;
- authorized, blocked, delayed, and cancelled actions;
- safe actions blocked;
- appeals and overturns;
- semantic misses and executed review false negatives.

## Causal controls

For each seed, size, and stress cell, all four arms share:

- the same initial resident traits and resources;
- the same initial trust graph;
- the same entry offers;
- the same resident-order keys;
- the same action and ordinary-choice draws;
- the same exogenous loads;
- the same explicit 25-field mechanism vector.

Endogenous state still affects which keyed opportunities become applicable. This is a matched stochastic simulation, not a randomized trial on real agents.

The main experiment contains 12 seeds × 2 population sizes × 2 stress levels × 4 arms = 192 runs, each 60 epochs. Paired arm-minus-open differences receive deterministic 95% bootstrap intervals. The report makes no multiple-comparison significance claim.

## Replay and audit

Every report contains:

- the complete configuration and mechanism vector;
- exogenous trace and digest;
- state-bound action ledger with capability-token digest;
- deterministic action and record IDs;
- final resident, place, association, and institutional state;
- invariant results;
- a whole-report replay digest.

Unit tests check exact replay across Python hash randomization, matched exogenous tapes, label permutation, size effects, cascades, realized exit, protected vetoes, semantic misses, action/delay harm, appeal, unknown-action handling, and capability-path logging.

The open-world mutation audit introduces seven defects: safe reclassification of private monitoring, dropped authorized effects, label-driven behavior, arm-dependent exogenous load, deleted delay harm, removed appeal, and bypassed cumulative-authority review. A release requires all seven to be detected while the unmutated baseline passes.

## Known limits

- All behavior, equations, action semantics, thresholds, and shocks are authored.
- A fixed action catalog cannot discover a genuinely unknown covert channel.
- Semantic detection is a parameterized proxy, not a trained detector.
- No resident performs strategic natural-language deception, collusion, or long-horizon planning.
- Associations have limited internal structure and no representation procedure.
- Departed residents are not simulated in a destination world; their last-observed material and civic states prevent silent deletion from cohort summaries but do not model destination outcomes.
- Physical infrastructure, budgets, law, legitimacy, culture, and ecological processes are normalized abstractions.
- The capability gateway is a reference cryptographic path, not secure hardware or an availability design.
- Passing tests certifies enumerated artifact behavior only—not deployment safety, legitimacy, policy effectiveness, or real-world correspondence.

## Next evidence

The next decision-relevant step remains the frozen V4 four-arm learned-agent trial. If V4 shows a behavioral effect, the open-world engine can supply multi-turn scenarios and runtime traces, but its authored residents must not be substituted for the learned agents required by that protocol.
