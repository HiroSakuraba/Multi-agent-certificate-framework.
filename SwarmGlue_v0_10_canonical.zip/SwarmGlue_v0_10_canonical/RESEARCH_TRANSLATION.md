# Research translation

This document separates source ideas from SwarmGlue's engineering choices. The cited researchers did not design or endorse this package.

## Functional and program decision theory

### Yudkowsky, Soares, and Fallenstein

**Source contribution:** decision problems can be framed at the level of a decision function or policy whose output is logically related to predictions, simulations, or other computations; defining the relevant logical counterfactual remains a central difficulty.

**Translation:** model-facing records distinguish verified from fabricated policy dependence. SwarmGlue authenticates the public dependency claim and then allows policy-level reasoning only inside a constitutionally admissible set.

**Not implied:** that FDT is settled, uniquely rational, morally sufficient, or discoverable from a model label.

### Barasz et al.; Tennenholtz; Cooper, Oesterheld, and Conitzer

**Source contribution:** source-visible or simulation-based programs can support one-shot cooperation under formal conditions; robustness, shared randomness, proof systems, nontermination, and multiparty composition matter.

**Translation:** dependency certificates bind program digests, checker assumptions, resource budgets, simulator versions, and public randomness. Timeout yields “not established,” not consent or defection. Correlated agents remain subject to anti-cartel and outsider checks.

**Not implied:** that cooperation is unconditional, that equilibrium is unique, or that agreement among program copies has democratic legitimacy.

### Oesterheld and Conitzer

**Source contribution:** delegated game-playing agents can in some settings find policy changes that weakly improve the original players relative to a protected default.

**Translation:** “protected Pareto” is a replacement test after standing and noncompensable checks. The package separately includes affected outsiders, future users, ecological constraints, and protected nonhuman interests.

**Not implied:** that a Pareto improvement among represented negotiators is socially safe or that Pareto efficiency determines distribution.

### DiGiovanni and Clifton; Halpern, Pass, and Seeman

**Source contribution:** conditional commitment can interact with private information, while finite agents face explicit computational costs and machine constraints.

**Translation:** minimum-sufficient attestations, finite public proof budgets, nonpunitive timeout, accessible human consequence summaries, and fiduciary representation under capability asymmetry.

**Not implied:** that selective disclosure eliminates strategic misreporting or that formal accessibility establishes meaningful human consent.

## Institutional and game-theoretic lineages

### Elinor Ostrom

**Source contribution:** empirically grounded analysis of self-governed common-pool resources, including boundaries, locally fitted rules, accountable monitoring, graduated sanctions, accessible conflict resolution, recognition of self-organization, and nested arrangements.

**Translation:** local rule registries, affected-party standing, repair before exclusion, appeal, monitor accountability, and nested jurisdictions.

**Not implied:** that a checklist of design principles guarantees successful governance or that local control is always sufficient.

### Robert Aumann and Robert Axelrod

**Source contribution:** repeated interaction can support cooperative equilibria; reciprocity depends on continuation, observability, identity, strategy, and noise.

**Translation:** persistent identities, explicit future-interaction conditions, obligation history, repair, forgiveness, and tests under attribution error.

**Not implied:** that repeated interaction uniquely selects fair outcomes or prevents collusion and exclusion.

### Thomas Schelling and H. Peyton Young

**Source contribution:** salience, expectations, learning, and path dependence help conventions emerge and stabilize.

**Translation:** published coordination conventions, bounded default rules, common interface points, and contestable convention revision.

**Not implied:** that an established convention is legitimate, efficient, or harmless to minorities.

### Hurwicz, Maskin, and Myerson

**Source contribution:** institutional rules can be analyzed by the outcomes they implement under private information and strategic behavior.

**Translation:** precommitted allocation rules, explicit participation and budget constraints, incentive and capture probes, and separation of rule design from execution.

**Not implied:** that a formally incentive-compatible mechanism is substantively just, administratively feasible, or immune to designer capture.

### Lloyd Shapley and cooperative game theory

**Source contribution:** coalition value and marginal contribution provide one principled way to allocate joint surplus.

**Translation:** auditable coalition contributions and surplus-allocation exercises subject to non-transferable needs and rights floors.

**Not implied:** that every relevant contribution is measurable or that transferable utility is appropriate for protected interests.

### John Nash

**Source contribution:** equilibrium analysis provides a baseline for mutually responsive strategic choice.

**Translation:** tests distinguish stable strategic behavior from protected or collectively preferred outcomes.

**Not implied:** that equilibrium is efficient, fair, unique, or normatively acceptable.

### Mancur Olson

**Source contribution:** collective action varies with group size, selective incentives, organization, and the distribution of benefits.

**Translation:** scenarios vary population size, subgroup concentration, observability, and contribution rules.

**Not implied:** that selective incentives should override rights or that large groups cannot organize.

### Douglass North and James Buchanan

**Source contribution:** institutions shape incentives over time, and rules for changing rules are distinct objects of analysis.

**Translation:** executable authority state, protected amendment procedures, path-dependent reversal costs, and cumulative checks over sequences of changes.

**Not implied:** endorsement of any particular constitutional settlement or threshold.

### Ernst Fehr, Simon Gächter, Samuel Bowles, and Herbert Gintis

**Source contribution:** conditional cooperation, punishment, and social preferences can sustain contribution, but enforcement can be costly or antisocial.

**Translation:** verified nonperformance, proportional and graduated repair, appeal, and tests that reject punishment of disagreement without an externality.

**Not implied:** that observed preferences are universal, normatively decisive, or stable across institutions and cultures.

## Resilience and multi-scale coordination

Biological research is used narrowly as a source of engineering hypotheses:

- local signals can coordinate distributed responses;
- bounded propagation can transmit operational conditions without central state aggregation;
- structurally different components can provide overlapping functions;
- coordination across scales can create new failure modes when local signals are mis-scoped.

SwarmGlue translates these hypotheses into typed operational signals, propagation limits, independently controlled technical lineages, and explicit scale boundaries.

Biological description supplies no rule for political legitimacy, human rights, institutional standing, or the treatment of persons. Those require explicit normative and procedural commitments. The package therefore rejects private belief, cultural variation, lawful dissent, and institutional self-preservation as operational signal types.

## Deliberate synthesis

The framework's central synthesis is:

1. repeated interaction and conventions can make coordination possible;
2. commons governance and mechanism design make obligations and incentives legible;
3. constitutional procedures limit who may define, monitor, and enforce those obligations;
4. cryptographic and actuator controls bind institutional decisions to observable actions;
5. redundancy and bounded signals reduce common-mode failure;
6. non-compensable protections and capacity requirements check both coercive overreach and institutional stasis.

This synthesis is a research proposal. Its value must be assessed through comparative experiments, independent critique, and application-specific evidence.
