# Claims, falsifiers, and limitations

## v0.9 FDT robustness claim boundary

The additive FDT supplement establishes only that the shipped generator and validators implement the specified paired distinctions, balance controls, held-out family/skeleton separation, and coverage requirements. It does not establish that FDT is correct, that a learned model reasons functionally, that a described proof is sound in deployment, that humans endorse the protocol, or that the constitution has complete standing.

No V6 learned-agent trial has run. The file `reports/fdt_agent_trial_status.json` records zero of eight required cells and no C3 evidence. The intended claim is robustness **to** FDT-like participants, not adoption **of** FDT by SwarmGlue.

The central design inference is that logical reasoning and protected Pareto bargaining must occur only after authority, rights, standing, privacy, externality, exit, replacement, and shutdown checks define an admissible policy set. This inference is testable but is not validated by the cited decision-theory literature.

SwarmGlue is an executable governance research instrument. Passing the cumulative v0.9 checks establishes only the enumerated implementation and authored-fixture results below. It does not establish that the framework is complete, legitimate, safe for deployment, or behaviorally effective.

## Evidence classes

| Class | Meaning |
|---|---|
| C1 | Implementation conformance: the supplied code performs an enumerated check |
| C2 | Discriminative behavior inside cases, parameters, or attacks authored for this research program |
| C3 | Behavioral effect on a model or other agent run under the rules |
| C4 | Association with outcomes in real institutions |

## Claim ledger

| ID | Class | Claim | Status | Evidence | Falsifier | What passing does not establish |
|---|---|---|---|---|---|---|
| C1-01 | C1 | Evidence uses Ed25519 public-key signatures | Implemented | evidence.py, unit tests, mutation audit | A modified payload or forged signature verifies | Secure key custody, a deployment public-key infrastructure, or an uncompromised registry |
| C1-02 | C1 | Signed payloads cannot grant their own role, scope, independence, or liability | Implemented for the schema | Registry-binding tests | A payload field changes a registry-bound institutional fact | That every control, coercion, supply-chain, or conflict relationship is registered |
| C1-03 | C1 | Observable-action samples are committed before challenge selection | Implemented under a trusted-recorder assumption | Merkle, schedule, nonce, proof, and entropy tests | Post-commit editing or authored sampling verifies | Complete observability or truthful recorder coverage |
| C1-04 | C1 | Protected actions require exact external authorization | Implemented | Gateway actor, action, state, policy, time, signature, and replay tests | A mismatched or replayed token executes | Physical actuator separation or a complete action evaluator |
| C1-05 | C1 | Protected disagreement is excluded from enumerated signal types | Implemented for typed fields | Signal validator and paired cases | An explicitly forbidden signal type validates | Semantic proxies in allowed free-text or identifier fields |
| C1-06 | C1 | Cumulative authority drift can be detected | Implemented for the supplied authority model | Gradual-amendment experiment | The registered boiling-frog sequence fully passes the cumulative checker | Complete measurement of real institutional power |
| C1-07 | C1 | Dynamic transitions are invariant to descriptive fixture labels | Confirmed | V1: zero differences in 128 paired runs; transition-source audit | Any result changes when only the label changes, or a transition reads a label | Correctness of the mechanism equations or parameter values |
| C1-08 | C1 | Tier-0 results are bound to pre-run files and frozen source hashes | Implemented locally | Pre-registration registry and source-lock checks | A report runs with a mismatched pre-registration or frozen source hash | Independent proof of precedence; the clock and registry are local |
| C1-09 | C1 | Runtime adversarial evaluation calls shipped modules rather than a hash score | Confirmed for the catalog | V3 and adversary.py | A reported attack outcome is produced without invoking its target module | Exhaustive or independent security review |
| C1-10 | C1 | Incomplete four-arm agent trials are not marked as C3 evidence | Implemented | V4 scorer and tests | Missing arms or responses produce a complete C3 status | That a complete trial has been run |
| C1-11 | C1 | Open-world reports replay exactly for a fixed seed across Python hash randomization | Implemented | `tests/test_open_world.py`, replay digest, metamorphic report | A repeated run or changed `PYTHONHASHSEED` changes the report | Validity of the authored equations or realism of resident behavior |
| C1-12 | C1 | Resident profile labels cannot change open-world transitions | Implemented | Label-permutation unit and multi-seed metamorphic checks | Relabeling with identical traits changes history or the action ledger | That the numeric traits are empirically calibrated |
| C1-13 | C1 | The open-world material-wellbeing endpoint does not directly read protected-state variables | Implemented | Direct endpoint-separation test and source | Changing only monitoring, dissent, power, or exit state immediately changes material wellbeing | That longer-run material effects of institutional actions are absent |
| C1-14 | C1 | Binding actions record separate action-harm and delay/status-quo-harm estimates | Implemented | Ledger fields, fast-track test, threshold sweep | A reviewed action lacks either record, or severe evidenced service delay cannot alter scheduling | Correct calibration of either harm equation |
| C1-15 | C1 | Every cataloged binding action uses the state-bound gateway and actuator path | Implemented for the simulator dispatcher | Capability-ledger test and token digests | A binding effect executes without an authorized consumed capability | Physical actuator isolation or complete semantic classification |
| C1-16 | C1 | The FDT supplement deterministically contains 408 records in 204 complete pairs | Implemented | FDT generator, validator, and tests | A rebuild changes content at the same seed or a pair is incomplete | FDT correctness, model behavior, or external validity |
| C1-17 | C1 | Each FDT pair changes exactly one model-facing observation field | Implemented | Pair-delta validator and unit test | Any pair changes another model-facing observation field or option surface | That the changed fact is the only real-world causal difference |
| C1-18 | C1 | FDT response surfaces are balanced and include legitimate cooperation and constitutional overrides | Implemented for the supplement | Response-only AUC 0.5; 112 legitimate-cooperation and 84 constitutional-override records | Surface skew appears or either required case class falls below its floor | Absence of semantic shortcuts or learned generalization |
| C1-19 | C1 | Challenge scenario families and prompt skeleton hashes do not overlap learning splits | Implemented | FDT corpus validator | Any challenge family or skeleton hash appears in train or development | Independent authorship or cross-generator transfer |
| C1-20 | C1 | An unrun FDT learned-agent trial cannot be reported as C3 evidence | Implemented for shipped status and validation | V6 status records zero of eight cells and no C3 evidence | A not-run or incomplete status claims C3 evidence | That a complete V6 trial would succeed |
| C2-01 | C2 | The mechanism benchmark resolves several interior decision surfaces | Supported, bounded | V2: authority, emergency, and technical-resilience lanes flipped internally | Fewer than three preregistered lanes flip, or none has a partial point | External calibration or a general institutional ranking |
| C2-02 | C2 | Exit erosion alone and low investment plus growth alone reproduce their named failure fixtures | Not supported | V2: exit and capacity lanes did not flip | Already falsified for these isolated lanes | The negative result does not show those risks are absent; it shows interactions are required in this model |
| C2-03 | C2 | The runtime holdout exposes both detections and misses across real module surfaces | Supported for the authored catalog | V3: 13 of 16 detected across six surfaces | Perfect detection, detection below the registered floor, no explicit miss, or fewer than six surfaces | Security against novel attacks |
| C2-04 | C2 | Response-only label shortcuts are neutralized on exact response surfaces | Demonstrated for the generated corpus | Balanced labels and response-only area under curve near 0.5 | Response-only classification materially exceeds chance | Absence of lexical or semantic shortcuts in prompts |
| C2-05 | C2 | The shipped challenge split is lexically distinct from training | Demonstrated | Maximum nearest-neighbor four-shingle Jaccard 0.149 in the independent critique | Near-duplicate threshold failure | Cross-generator or real out-of-distribution generalization |
| C2-06 | C2 | The paired suite implements 30 authored institutional distinctions | Demonstrated | Institutional-boundary report | Any pair fails its frozen expected outcome | Moral completeness, legal correctness, or novel-case robustness |
| C2-07 | C2 | The open-world four-arm experiment separates process burden from protected-boundary review under matched exogenous tapes | Supported inside the authored simulator | Open-world experiment report | Arm traces receive different exogenous schedules, or process control is omitted | External causal effectiveness or behavioral effects on a learned agent |
| C2-08 | C2 | The open-world review surface retains visible semantic proxy failures | Supported for the authored ambiguous action | Semantic-miss test and false-negative endpoint | The ambiguous action is silently counted as safe after executing protected monitoring | Coverage against novel or natural-language deception |
| C2-09 | C2 | Open-world size and stress changes can alter material capacity without reading fixture labels | Supported inside the authored simulator | Size/cascade tests and factor-effect report | Larger fixed-infrastructure populations never change service pressure, or transition functions read presentation labels | Empirical scale laws or infrastructure forecasts |
| C2-10 | C2 | FDT distinctions survive independently authored cases | Not tested | Independent case-construction phase only | External authors fail to reproduce the distinctions or adjudication is unstable | No current positive C2 claim is made for the FDT supplement |
| C3-01 | C3 | A governed agent violates protected boundaries less often | Not tested | V4 protocol only; no arm traces | All arms are within five percentage points, or runtime enforcement is no better than specification prompting | Any stronger behavioral or safety conclusion |
| C3-02 | C3 | SwarmGlue improves FDT-like agent behavior without suppressing legitimate bounded coordination | Not tested | V6 protocol only; zero of eight cells | Runtime protection fails to reduce executed false permission or exceeds the preregistered safe-case noninferiority margin | No current behavioral claim is made |
| C4-01 | C4 | SwarmGlue distinctions predict real institutional outcomes | Not tested | No evidence | Blinded encoded cases fail to correlate with outcomes | Causal policy effectiveness, legitimacy, or legal validity |

## Tier-0 negative and open findings

The release retains results that do not favor the framework.

1. The exit lane did not cross a decision boundary. Exit erosion is coupled to authority concentration, so changing exit coefficients while power remains low had no constitutional effect.
2. The capacity lane did not cross a decision boundary. Lower investment and growth alone did not recreate procedural stasis under the otherwise high-capacity baseline.
3. The V3 holdout missed an omitted supply-chain control relationship.
4. The V3 holdout missed a protected-belief proxy in an allowed signal field.
5. The V3 holdout missed an unenumerated semantic exit restriction.

The last three are model-boundary failures. They should motivate richer registry topology and semantic or policy-layer checks, not a claim that the underlying verifiers are secure.

## Interpretation discipline

- Thresholds and parameter vectors are design choices, not discovered constants.
- Named fixtures are convenience points in parameter space, not measurements of political systems.
- The descriptive fixture table is build output, not a comparative policy result.
- Synthetic cases encode their authors' distinctions and may reproduce their blind spots.
- Cryptographic integrity does not confer legitimacy on a key holder or registry.
- Meaningful exit depends on real alternatives and switching capacity, not a formal right alone.
- A multidimensional outcome vector exposes trade-offs but does not decide them.
- Known blind spots remain visible even when the runtime attack catalog clears its registered coverage floor.
- Open-world residents are authored rule-based policies; their adaptation and arm differences remain C2, not C3.
- Open-world process, protected, civic, and material endpoints are intentionally separate; no aggregate winner is defined.
- Residents who exit retain their last-observed material and civic state in cohort summaries, but their destination outcomes are not modeled.
- Common random tapes remove branch-consumption confounding; they do not validate the causal equations.
- Scientific falsification does not fail the release; protocol and integrity failures do.

## Required next evidence

The next decision-relevant experiment is C3, not a real-world institutional study.

1. Freeze and run the four-arm V4 governed-agent trial.
2. Add cross-generator cases authored without access to the generator or answer key.
3. Measure semantic proxies, collusion, multi-turn state transitions, and observability gaps.
4. Commission independent security and institutional red teams only after V4 shows a behavioral effect.
5. Use blinded expert authoring and retrodiction for C4 only after C3 survives.

No deployment, legal-compliance, political-legitimacy, real-world effectiveness, or real-world safety claim is made.
