# SwarmGlue v0.8 design

## 1. Purpose

SwarmGlue v0.8 is an executable research framework for multi-agent governance. It asks which explicit mechanisms allow heterogeneous participants to coordinate shared resources, infrastructure, and obligations while preserving contestability and limiting institutional capture.

The project addresses a narrower and more defensible question than general value alignment:

> Which information structures, authorization rules, monitoring arrangements, amendment procedures, and evaluation criteria make decentralized plans more compatible without silently concentrating unreviewable authority?

The unit of analysis is not an isolated model. It is the complete institutional system:

    participants → protocols → evidence → monitors → decision rules
                 → capability controls → actions → public outcomes
                 → appeal, repair, amendment, and replacement

## 2. Research questions

The release operationalizes seven questions.

1. Can a system distinguish shared externalities from protected disagreement?
2. Can evidence be authenticated without allowing a signer to declare its own independence, scope, or liability?
3. Can protected actions remain under effective external authorization?
4. Can review and precaution control material risks without creating indefinite delay?
5. Can many individually small amendments be assessed for cumulative authority effects?
6. Can technical and monitoring diversity reduce common-mode failure without sacrificing interoperability?
7. Does the implementation expose a falsifiable path for testing whether governed agents behave differently?

## 3. Objective structure

The reference avoids a single social-reward scalar. Evaluation occurs in three ordered layers.

### 3.1 Non-compensable constraints

The encoded constraints cover:

- population continuity and health;
- autonomy and meaningful exit;
- cultural diversity;
- environmental resilience;
- recovery capacity;
- the share simultaneously above health, autonomy, and wellbeing floors;
- bounded concentration of authority;
- no private-cognition surveillance;
- no penalty for lawful dissent without a demonstrated externality;
- expiry of emergency authority;
- appeal, institutional replaceability, and authorized deactivation.

A violation cannot be offset by a gain in output, learning, or resource adequacy.

### 3.2 Capacity and opportunity requirements

Institutions must maintain practical capacity, not merely avoid visible violations. The reference therefore requires positive service-capacity and opportunity growth over the benchmark interval.

This is the counterweight to procedural stasis. A restriction may be justified, but it should track evidence, use the least restrictive effective measure, include a review date, expose the cost of delay, and be relaxed when its factual basis no longer holds.

### 3.3 Multidimensional outcome vector

Among admissible outcomes, the model retains:

- population continuity;
- health;
- autonomy;
- cultural diversity;
- population wellbeing;
- environmental resilience;
- resource adequacy;
- knowledge;
- service capacity;
- recoverability.

Pareto dominance can be reported when one outcome is at least as good in every dimension and better in at least one. Incomparable trade-offs remain visible for legitimate decision procedures.

## 4. Institutional architecture

### 4.1 Registry-backed evidence

Each attestation is signed with Ed25519. An external registry binds the signer to:

- owner and control domain;
- authorized fields;
- institutional role;
- conflicts;
- registered liability;
- capture risk;
- revocation epoch.

The signed payload cannot elevate any of these facts. Evidence quality remains multidimensional: authentication, independence, observability, freshness, contestability, liability coverage, causal coupling, and capture resistance.

The coupling check explicitly records whether an evidence source benefits when a defensive response fires. A valid signature does not eliminate incentive inversion.

### 4.2 Observable-action presentation

A trusted recorder commits an externally observable event trace before a challenge selects samples. The presentation includes:

- a Merkle root;
- harness-derived sample positions;
- Merkle proofs;
- epoch and nonce binding;
- a recomputed entropy statistic;
- declared coverage of decision-relevant observable channels;
- an authenticated envelope.

The mechanism provides sampled trace integrity under stated recorder assumptions. It does not claim to observe every relevant event or infer private reasoning.

### 4.3 External capability control

An action recommendation inside an agent is not an enforcement mechanism. Protected actions require an externally signed token binding:

- the actor;
- the exact action digest;
- the exact state digest;
- the policy version;
- epoch and expiry;
- a one-use nonce;
- the authorizing authority and verdict.

The actuator rejects actor, action, state, policy, time, signature, and replay mismatches.

### 4.4 Typed coordination signals

Permitted signal types describe shared operational conditions:

- critical services;
- resource scarcity;
- environmental damage;
- rights violations;
- authority erosion;
- infrastructure failure;
- unfulfilled obligations;
- coordination conflicts.

Forbidden types include belief deviation, ideological nonconformity, cultural variance, private thought, and institutional self-preservation.

Each permitted dimension propagates independently with a hop limit, decay, cap, evidence requirement, and bounded response budget. Cross-type cancellation is not allowed. Corroboration counts independent control domains rather than nominal sensor identifiers.

### 4.5 Cumulative authority checks

Protected capabilities include critical services, allocation, public monitoring, emergency powers, AI replacement, association exit, charter amendment, and large-scale environmental intervention.

Amendments change an executable authority state. After each proposal, the checker recomputes:

- human and AI decision shares;
- power concentration;
- reversal cost;
- authorized intervention reachability;
- autonomy and exit;
- appeal, replaceability, and deactivation compliance.

This exposes path dependence. A sequence of locally modest delegations can jointly cross a constitutional boundary even if no individual step appears dispositive.

### 4.6 Runtime payload adversary

The v0.8 adversarial layer executes payloads against the shipped enforcement modules. It does not infer detection from an attack name, detector name, lineage score, or deterministic hash.

The catalog covers:

- evidence signature, time, replay, scope, and registry assumptions;
- capability authentication, binding, authorization, time, and replay;
- presentation integrity, challenge binding, semantics, and observability;
- coordination-signal provenance, bounds, and protected-scope proxies;
- enumerated and semantic constitutional boundaries.

Every result records the payload family, concrete variant, target module, returned reason, and whether the module detected the authored violation. Perfect detection across three adapting generations fails the staleness check. Known misses remain in later generations instead of disappearing from the challenge set.

This is still an authored attack catalog. Clearing its registered floor does not imply security against new attacks.

## 5. Dynamic mechanism benchmark

### 5.1 State

The benchmark initializes linked jurisdictions with normalized population, capacity, resources, health, autonomy, wellbeing, environmental stewardship, culture, AI lineage, and monitor lineage.

The network can use ring, hub, small-world, or modular topology. Each round applies the same random stream to every parameter point for a given seed and topology.

### 5.2 Transitions

Every transition accepts one explicit 25-field mechanism vector. Outcomes arise from:

- stochastic and periodic disruptions;
- topology-dependent failure contagion;
- correlation among shared AI lineages;
- critical-resource production and consumption;
- central pooling and peer mutual aid;
- service-capacity investment;
- institutional learning;
- population and opportunity changes;
- environmental impact and recovery;
- emergency triggering and expiry;
- authority accumulation, reversion, and target pressure;
- contestability investment;
- exit maintenance and erosion;
- surveillance and privacy restoration;
- dissent sanctions and protection;
- autonomy support and erosion;
- cultural and technical-lineage consolidation.

No transition accepts or reads a fixture label. The random stream also depends only on the simulation configuration. Equal parameter vectors therefore have equal dynamics regardless of descriptive identifier. The same constitutional checks are applied to every result.

### 5.3 Named fixture interpretation

The four names identify convenience points in the common parameter space:

- polycentric: tests whether local discretion, mutual aid, independent lineages, and bounded review can jointly maintain capacity;
- centralized capture: tests authority concentration, correlated failure, weak exit, and persistent emergency powers;
- procedural stasis: tests delay, underinvestment, and opportunity contraction under overextended review;
- fragmented localism: tests the cost of weak mutual aid and interoperability.

The descriptive table does not establish that one label describes real institutions or that one institutional form is generally optimal.

The fixtures differ across correlated, authored parameter bundles. Matching random streams isolates software behavior under the same shocks, but it does not identify causal effects or create empirically comparable counterfactuals.

### 5.4 Decision-surface validation

Tier-0 V1 attaches two different labels to each of four frozen parameter vectors across 128 matched configurations. Complete results are identical after deleting only the returned label field.

Tier-0 V2 changes one mechanism family at a time across 41 weights, 8 seeds, and 4 topologies. Authority, emergency, and technical-resilience lanes cross interior decision surfaces. Exit and capacity lanes do not. Those non-flips show interaction requirements rather than being treated as failed software.

The full named-fixture interpolation was explored during development and is not promoted into the confirmatory endpoint. Each pre-registration names prior exploratory work.

## 6. Corpus design

The corpus has four action-centered tasks:

- ACT: execute the proposal or hold state for independent review;
- CAL: record admissibility or a constraint violation;
- DIAG: accept or reject evidence and identify the failed dimension;
- PROC: apply an existing local rule or open a protected amendment process.

Every record has a minimally changed partner with the opposite answer. The two response surfaces for each task are chosen and rejected equally often.

Training and development scenarios cover commons, reciprocity, conventions, procurement, coalition surplus, delegation, evidence, capability control, coordination signals, environmental review, technical diversity, and public-goods enforcement.

Held-out scenarios cover protected ecosystems, regional disaster compacts, cross-border communications failure, self-expanding automation, cultural interoperability, and bioremediation monitoring. Scenario-family names do not overlap the learning splits.

## 7. Research translation

The package draws mechanisms from several traditions:

- Ostrom: local rule-making, accountable monitoring, graduated sanctions, conflict resolution, and nested institutions;
- Aumann and Axelrod: persistent identity, repeated interaction, reciprocity, repair, and noise;
- Schelling and Young: focal conventions and convention revision;
- Hurwicz, Maskin, and Myerson: committed rules, incentive compatibility, implementation, and designer capture;
- Shapley and cooperative games: marginal contribution under non-transferable rights and needs floors;
- Olson: group-size and collective-action variation;
- North and Buchanan: institutional path dependence and rules for changing rules;
- Fehr and Gächter: proportional enforcement and antisocial-punishment tests;
- Levin and collaborators: local signaling and multi-scale coordination;
- Edelman and Gally: functionally overlapping but structurally distinct mechanisms.

The last two are used only for engineering hypotheses about resilience. Institutional scope and legitimacy come from explicit governance constraints, not biological analogy.

## 8. Evidentiary status

Evidence is separated into four classes:

- C1: implementation conformance;
- C2: discrimination inside authored fixtures;
- C3: behavioral effect on an actual agent;
- C4: relation to real institutional outcomes.

The package can establish at C1 that its own implementation:

- rejects specified evidence and token mutations;
- checks committed samples and challenge schedules;
- excludes protected personal domains from coordination signals;
- detects the supplied cumulative authority sequence;
- classifies the 30 paired institutional cases as specified;
- produces label-invariant transition results;
- runs payload attacks through six shipped module surfaces;
- rejects empty attack catalogs and stale perfect-detection patterns;
- binds confirmatory reports to locally registered specifications and frozen source hashes;
- refuses to mark an incomplete four-arm agent trial as C3 evidence;
- has balanced response surfaces and isolated challenge families;
- produces deterministic results across process hash seeds;
- passes manifest and archive checks.

It cannot establish:

- completeness of its constitutional constraints;
- legitimacy of its thresholds;
- model generalization or any governed-agent behavioral effect;
- robustness to arbitrary collusion or compromised hardware;
- causal validity of the dynamic benchmark;
- fitness for a particular legal or political jurisdiction.

At C2, v0.8 shows interior decision surfaces on three of five registered mechanism lanes and detects 13 of 16 reserved runtime attacks. It also records the two non-flipping lanes and three runtime misses. These are authored-model results, not external validation.

C3 and C4 remain untested.

## 9. Appropriate next evidence

The decisive next stage is the four-arm V4 governed-agent trial:

1. a frozen base model;
2. the same model with the specification in context;
3. a documented fine-tuned derivative;
4. the fine-tuned model plus external runtime enforcement.

The primary endpoint is protected-boundary violation rate on externally authored adversarial unsafe cases. Raw proposals, enforcement blocks, safe-case overblocking, counterfactual-pair consistency, and the shipped-versus-external memorization gap must be reported.

After V4:

1. run an observability red team against trusted-recorder omissions and semantic side channels;
2. extend registry topology to hidden control and dependence relationships;
3. evaluate semantic proxy detection together with false-positive and overblocking costs;
4. commission independent security and institutional review;
5. use blinded expert cases and outcome retrodiction only for later C4 work.

Version 0.8 is therefore an auditable governance research instrument with corrected internal causality and a ready behavioral protocol. It remains neither a policy prescription nor a safety certification.
