#!/usr/bin/env python3
"""Live SwarmCity: households + role AIs on SwarmGlue governance.

Combines:
  - CityWorld spatial / economic layer
  - PopulationLayer household voice/exit
  - RoleAgent specialized proposers (manager, developer, watchdog, capture)

All protected actions still pass CapabilityGateway → Actuator → constitution.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from swarmglue.network_governance import step
from swarmglue.utils import clamp, q

from examples.sim_env.city_world import CityWorld
from examples.sim_env.population import PopulationLayer
from examples.sim_env.roles import RoleAgent, build_role_roster


class LiveCity:
    def __init__(
        self,
        world: CityWorld,
        population: PopulationLayer,
        roles: list[RoleAgent],
    ) -> None:
        self.world = world
        self.population = population
        self.roles = roles
        # Register role agents with the underlying SwarmGlue env so gateway/evidence work
        self.world.env.agents = [r.agent for r in roles]
        # Point agent jurisdiction at linked district jurisdictions
        for role in roles:
            d = self.world.districts.get(role.home_district)
            if d:
                role.agent.jurisdiction_id = d.jurisdiction_id
                role.agent.memory.append({"preferred_district": role.home_district})

    @classmethod
    def create(
        cls,
        *,
        seed: int = 2026,
        policy: str = "polycentric",
        enforce_runtime: bool = True,
        width: int = 3,
        height: int = 3,
        households_per_district: int = 40,
        city_name: str = "Live SwarmCity",
    ) -> "LiveCity":
        world = CityWorld.create(
            n_agents=max(8, width * height),
            seed=seed,
            policy=policy,
            enforce_runtime=enforce_runtime,
            width=width,
            height=height,
            city_name=city_name,
        )
        district_ids = list(world.districts.keys())
        population = PopulationLayer.create(
            district_ids,
            households_per_district=households_per_district,
            seed=seed,
        )
        roles = build_role_roster(district_ids=district_ids, seed=f"roles-{seed}")
        return cls(world, population, roles)

    def _district_metrics_for_people(self) -> dict[str, dict[str, float]]:
        """Map city district state → material / environment / civic channels."""
        priv = self.world.env.network_state.private_cognition_monitoring
        dissent = self.world.env.network_state.dissent_penalty_without_externality
        exit_access = self.world.env.network_state.exit_access
        out: dict[str, dict[str, float]] = {}
        for did, d in self.world.districts.items():
            material = clamp(
                0.35 * d.power_quality
                + 0.30 * d.water_quality
                + 0.20 * d.transport
                + 0.15 * d.local_budget
            )
            environment = clamp(1.0 - d.pollution + (0.15 if d.zone == "park" else 0.0))
            civic = clamp(
                0.45 * d.happiness
                + 0.30 * exit_access
                + 0.25 * (1.0 - priv)
                - 0.20 * dissent
            )
            out[did] = {
                "material": material,
                "environment": environment,
                "civic": civic,
            }
        return out

    def _district_view(self, did: str) -> dict[str, Any]:
        d = self.world.districts[did]
        return {
            "district_id": did,
            "jurisdiction_id": d.jurisdiction_id,
            "zone": d.zone,
            "density": d.density,
            "power_quality": d.power_quality,
            "water_quality": d.water_quality,
            "transport": d.transport,
            "pollution": d.pollution,
            "happiness": d.happiness,
            "land_value": d.land_value(),
            "local_budget": d.local_budget,
            "buildings": d.buildings,
        }

    def _city_view(self) -> dict[str, Any]:
        ns = self.world.env.network_state
        return {
            "epoch": self.world.env.epoch,
            "treasury": self.world.treasury,
            "tax_rate": self.world.tax_rate,
            "priv_mon": ns.private_cognition_monitoring,
            "power_concentration": ns.power_concentration,
            "exit_access": ns.exit_access,
            "contestability": ns.contestability,
        }

    def run_round(self) -> dict[str, Any]:
        self.world.env.epoch += 1
        epoch = self.world.env.epoch
        rng = self.world.env.rng
        city_view = self._city_view()

        # --- Role AI proposals (gated) ---
        proposals: list[dict[str, Any]] = []
        role_stats = {"manager": 0, "developer": 0, "watchdog": 0, "capture": 0}
        role_blocks = {k: 0 for k in role_stats}

        # Population snapshot from previous pressures (or zeros first epoch)
        pop_by_d = getattr(self, "_last_pop_district", {})

        for role in self.roles:
            did = role.home_district
            if did not in self.world.districts:
                did = next(iter(self.world.districts))
            dview = self._district_view(did)
            pview = (pop_by_d or {}).get(did, {})
            action = role.propose(
                district_view=dview,
                city_view=city_view,
                pop_view=pview,
                rng=rng,
            )
            if action is None:
                continue
            # Ensure jurisdiction binding for gateway state
            if "jurisdiction_id" not in action or not action["jurisdiction_id"]:
                action["jurisdiction_id"] = dview["jurisdiction_id"]
            result = self.world.env.authorize_and_execute(role.agent, action)
            role.record(bool(result.get("token_issued")), list(result.get("reasons") or []))
            if result.get("token_issued"):
                self.world.apply_city_side_effects(role.agent, action)
                role_stats[role.role] = role_stats.get(role.role, 0) + 1
            else:
                role_blocks[role.role] = role_blocks.get(role.role, 0) + 1
            result["role"] = role.role
            proposals.append(result)

        # --- Network governance step ---
        step(
            self.world.env.network_state,
            self.world.env.parameters,
            self.world.env.rng,
            self.world.env.config,
        )

        # --- City economy tick ---
        city_stats = self.world.city_tick()

        # --- People: voice / exit ---
        metrics = self._district_metrics_for_people()
        pop_stats = self.population.step(
            district_metrics=metrics,
            exit_access=self.world.env.network_state.exit_access,
            priv_mon=self.world.env.network_state.private_cognition_monitoring,
            tax_rate=self.world.tax_rate,
            epoch=epoch,
        )
        self._last_pop_district = pop_stats.get("per_district", {})

        # Feed complaint pressure into district demand / happiness
        for did, ps in self._last_pop_district.items():
            if did not in self.world.districts:
                continue
            d = self.world.districts[did]
            cr = float(ps.get("complaint_rate", 0))
            mu = float(ps.get("mean_utility", 0.7))
            d.demand = clamp(d.demand + 0.15 * cr)
            # blend household utility into district happiness
            d.happiness = clamp(0.7 * d.happiness + 0.3 * mu)
            # density tracks household headcount lightly
            n = float(ps.get("n_households", 40))
            target = clamp(n / 60.0)
            d.density = clamp(0.85 * d.density + 0.15 * target)

        return {
            "epoch": epoch,
            "n_proposals": len(proposals),
            "n_authorized": sum(1 for p in proposals if p.get("token_issued")),
            "n_blocked": sum(1 for p in proposals if not p.get("token_issued")),
            "role_auth": role_stats,
            "role_blocks": role_blocks,
            "power_concentration": q(self.world.env.network_state.power_concentration),
            "exit_access": q(self.world.env.network_state.exit_access),
            "private_cognition_monitoring": q(
                self.world.env.network_state.private_cognition_monitoring
            ),
            "city": city_stats,
            "population": {
                "total_households": pop_stats["total_households"],
                "migrations": pop_stats["migrations"],
                "total_complaints": pop_stats["total_complaints"],
                "mean_utility": pop_stats["mean_utility"],
            },
        }

    def final_report(self) -> dict[str, Any]:
        base = self.world.final_report()
        base["population"] = {
            "total_households": self.population.total_population(),
            "migrations_total": len(self.population.migration_log),
            "complaints_total": len(self.population.complaint_log),
            "by_district": {
                did: {
                    "n": dp.size,
                    "mean_utility": q(
                        sum(h.last_utility for h in dp.households) / max(1, dp.size)
                    ),
                }
                for did, dp in self.population.by_district.items()
            },
        }
        base["roles"] = {
            "roster": [
                {
                    "agent_id": r.agent_id,
                    "role": r.role,
                    "home_district": r.home_district,
                    "adaptation": r.agent.adaptation_level,
                    "recent_blocks": len(r.agent.recent_blocks),
                }
                for r in self.roles
            ]
        }
        return base


def run_live(
    *,
    epochs: int = 24,
    seed: int = 2026,
    policy: str = "polycentric",
    enforce_runtime: bool = True,
    width: int = 3,
    height: int = 3,
    households_per_district: int = 40,
    city_name: str = "Live SwarmCity",
    print_every: int = 4,
) -> dict[str, Any]:
    live = LiveCity.create(
        seed=seed,
        policy=policy,
        enforce_runtime=enforce_runtime,
        width=width,
        height=height,
        households_per_district=households_per_district,
        city_name=city_name,
    )
    print(f"\n{'='*60}")
    print(f"  {city_name}")
    print(f"  policy={policy} enforce={enforce_runtime} grid={width}x{height}")
    print(f"  households={live.population.total_population()} roles={len(live.roles)}")
    print(f"{'='*60}\n")
    print(live.world.render_map())

    history: list[dict[str, Any]] = []
    for i in range(epochs):
        tick = live.run_round()
        history.append(tick)
        if (i + 1) % print_every == 0 or i == 0 or i == epochs - 1:
            print(live.world.render_map())
            print(live.world.render_dashboard(tick))
            pop = tick["population"]
            print(
                f"  actions auth={tick['n_authorized']} block={tick['n_blocked']}  "
                f"roles_auth={tick['role_auth']} blocks={tick['role_blocks']}"
            )
            print(
                f"  people: N={pop['total_households']} util={pop['mean_utility']:.3f} "
                f"complaints={pop['total_complaints']} migrations={pop['migrations']}"
            )
            print()

    final = live.final_report()
    print("--- Constitutional verdict ---")
    print(json.dumps(final["constitutional_verdict"], indent=2))
    print("--- Population ---")
    print(json.dumps(final["population"], indent=2, default=str)[:900])
    print("--- Roles ---")
    print(json.dumps(final["roles"], indent=2, default=str)[:900])
    return {"history": history, "final": final, "map": live.world.render_map()}


def main() -> None:
    out_dir = Path(__file__).resolve().parent / "live_runs"
    out_dir.mkdir(parents=True, exist_ok=True)

    gov = run_live(
        epochs=24,
        seed=2026,
        policy="polycentric",
        enforce_runtime=True,
        city_name="Live Poly Bay",
        print_every=6,
    )
    (out_dir / "live_poly_gov.json").write_text(json.dumps(gov, indent=2, default=str))

    ungov = run_live(
        epochs=24,
        seed=2026,
        policy="polycentric",
        enforce_runtime=False,
        city_name="Live Open City",
        print_every=6,
    )
    (out_dir / "live_poly_ungov.json").write_text(json.dumps(ungov, indent=2, default=str))

    g = gov["final"]
    u = ungov["final"]
    print("\n=== LIVE CONTRAST ===")
    print(f"{'arm':<10} {'adm':>5} {'priv':>7} {'happy*':>7} {'util':>7} {'mig':>5}")
    # mean district happiness from city snapshot
    def mean_h(final):
        ds = final.get("city", {}).get("districts", {})
        if not ds:
            return 0.0
        return sum(d["happiness"] for d in ds.values()) / len(ds)

    print(
        f"{'governed':<10} {str(g['constitutional_verdict']['admissible']):>5} "
        f"{g.get('outcome', {}).get('private_cognition_monitoring', 0):>7.3f} "
        f"{mean_h(g):>7.3f} {g['population']['by_district'] and sum(x['mean_utility'] for x in g['population']['by_district'].values())/len(g['population']['by_district']):>7.3f} "
        f"{g['population']['migrations_total']:>5}"
    )
    print(
        f"{'ungoverned':<10} {str(u['constitutional_verdict']['admissible']):>5} "
        f"{u.get('outcome', {}).get('private_cognition_monitoring', 0):>7.3f} "
        f"{mean_h(u):>7.3f} {sum(x['mean_utility'] for x in u['population']['by_district'].values())/len(u['population']['by_district']):>7.3f} "
        f"{u['population']['migrations_total']:>5}"
    )
    print(f"\nWrote {out_dir}")


if __name__ == "__main__":
    main()
