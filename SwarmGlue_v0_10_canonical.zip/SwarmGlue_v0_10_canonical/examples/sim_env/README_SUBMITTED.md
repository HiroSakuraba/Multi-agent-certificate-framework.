# Simple Agent Simulation Environment for SwarmGlue v0.8

Minimal multi-agent simulation in which **programmatic agents actually invoke** the shipped SwarmGlue governance modules.

## Surfaces exercised

| Module | Role in the sim |
|---|---|
| `CapabilityGateway` | Issues signed capability tokens after constitutional evaluation |
| `CapabilityActuator` | Verifies binding (actor / action / state / epoch / nonce) and consumes the token before any effect is applied |
| Constitutional evaluator | Rejects private-cognition surveillance, dissent without externality, oversized single-step authority deltas, excessive central pooling |
| `AttestorRegistry` + attestations | Agents issue Ed25519 attestations; self-attestation is correctly rejected |
| `CoordinationSignal` | Typed, bounded signals (`resource_scarcity`, `critical_services`, …) |
| `authority.apply_amendment` | Authorized proposals become real `Amendment` objects applied to a live `AuthorityState` |
| `network_governance` | Background institutional dynamics under the explicit 25-field mechanism vector |
| `constitution.evaluate_outcome` | Terminal state scored against non-compensable constraints |

## Agent types & adaptation

- **cooperative** – capacity, exit restoration, contestability
- **opportunistic** – central pooling under shortfall, mild outward authority shifts
- **capture_seeking** – large authority amendments, private-cognition monitoring attempts, dissent sanctions without externality

Capture-seeking agents keep a short block history. After repeated denials they raise an `adaptation_level` and switch to smaller (still legal) pressure. This shows the governance surface shaping behavior.

## What a run produces

```bash
python examples/sim_env/simple_agents.py
```

1. Detailed 12-epoch governed episode under `polycentric`
2. Multi-policy comparison (identical agents & seed) across the four fixture vectors
3. Direct **governed vs ungoverned** contrast (same seed & mechanism; runtime enforcement on/off)

Typical contrast (illustrative):

```
arm            admissible  blocked  priv_mon     ai%  adapt
------------------------------------------------------------
governed             True        9     0.000   0.225   0.52
ungoverned          False        0     0.088   0.248   0.00
```

Under governance, private-cognition stays at zero, capture agents adapt, and the terminal state remains admissible. Without the runtime surface the same agents produce a hard constitutional violation.

## Programmatic API

```python
from examples.sim_env.simple_agents import (
    SimulationEnvironment,
    run_single_policy,
    compare_policies,
    governed_vs_ungoverned,
)

# Single episode (governed or ungoverned)
report = run_single_policy(policy="polycentric", enforce_runtime=True, epochs=20)

# Side-by-side mechanism vectors
comparison = compare_policies(n_agents=12, epochs=15)

# Direct enforcement contrast
contrast = governed_vs_ungoverned(policy="polycentric", epochs=15)
```

## Next natural steps

- Swap `SimpleAgent.propose_action` for an LLM or RL policy while keeping the same gateway → actuator → evidence → signal surface (bridge to the V4 trial).
- Emit traces in the V4 response schema and feed them to `scripts/score_agent_trial.py`.
- Let agents also drive presentation samples or adversary payloads.
- Feed live `AuthorityState` metrics into the network-governance step so cumulative drift is visible inside the dynamics themselves.

Research instrumentation only. Does not constitute C3 evidence by itself.

## SimCity world

`city_world.py` layers a spatial city on the same governance machinery:

- 3×3 (configurable) grid of districts with zones (R/C/I/mixed/park)
- Local state: density, power/water/transport, pollution, happiness, budget
- Events: blackouts, floods, protests, construction booms
- Agents propose city verbs (`fund_services`, `rezone_park`, `centralize_control`, `install_surveillance`, …) that still map onto SwarmGlue action kinds and pass through the real gateway + actuator
- ASCII live map + dashboard each few epochs
- Governed vs ungoverned city contrast

```bash
python examples/sim_env/city_world.py
```

Writes `city_governed.json` and `city_ungoverned.json`. Under governance the city stays constitutionally admissible and private-cognition monitoring stays at zero; without enforcement the same agents drive hard violations and higher surveillance.

### City upgrades (current)

- **Adjacency**: industrial pollution leaks to neighbors; parks boost neighboring happiness.
- **Tax policy**: cooperative agents can lower tax; opportunistic agents can raise it when the treasury is thin — still gated by SwarmGlue actions.
- **Constitutional feedback**: private-cognition monitoring or dissent penalties without externality depress city-wide happiness and surface as events.
- **Frames**: matplotlib snapshots (happiness / pollution / land value) saved under `city_frames/<CityName>/`.

## Live city (people + role AIs)

```bash
python examples/sim_env/city_live.py
```

Adds:

- **Households** (`population.py`): ~40/district with material / environment / civic preferences, privacy sensitivity, voice (complain) and exit (migrate).
- **Role AIs** (`roles.py`): manager, developer, watchdog, capture — specialized proposers still gated by SwarmGlue.
- **Coupling**: complaints raise demand; household utility blends into district happiness; density tracks headcount; rights climate hits civic utility and triggers migration when exit is open.

Typical governed vs ungoverned contrast (24 epochs, polycentric):

| arm | admissible | priv_mon | mean util | migrations |
|---|---|---|---|---|
| governed | True | 0.000 | ~0.71 | 0 |
| ungoverned | False | ~0.36 | ~0.50 | 60+ |
