#!/usr/bin/env python3
"""Open social world on SwarmGlue — Second-Life-like, not SimCity.

Design intent
-------------
SimCity is a god-game: zones, municipal treasury, scripted disasters, mayor verbs.
This module is closer to a persistent multi-user world:

  * Residents have private resources, needs, skills, relationships, and location.
  * Most interaction is ordinary and ungated: talk, trade, help, avoid, form ties.
  * Shared infrastructure is a *commons* sustained by voluntary contribution and
    degradation — not a tax ledger.
  * SwarmGlue gateway / constitution / authority only engage when someone tries to
    bind others: pool resources by rule, monitor private life, sanction dissent,
    seize emergency power, restrict exit, amend control.

Forced scenario dice (random blackouts as plot events) are removed. Shortages
and failures emerge when the commons is under-maintained or capture succeeds.

This remains research instrumentation: stylized, not a full social simulator.
"""

from __future__ import annotations

import json
import random
import sys
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Literal

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from swarmglue.authority import Amendment, AuthorityState, apply_amendment
from swarmglue.constitution import evaluate_outcome
from swarmglue.coordination_signals import CoordinationSignal
from swarmglue.evidence import AttestorRecord, AttestorRegistry
from swarmglue.gateway import CapabilityActuator, CapabilityGateway
from swarmglue.network_governance import (
    SimulationConfig,
    fixture_parameters,
    initial_state,
    step,
)
from swarmglue.utils import clamp, digest, q

from examples.sim_env.simple_agents import SimpleAgent

Disposition = Literal["cooperative", "exchange", "withdrawn", "dominant"]
NeedName = Literal["sustenance", "shelter", "connection", "agency", "safety"]


@dataclass
class Association:
    """Voluntary group — no legal force unless members later seek gated powers."""

    assoc_id: str
    name: str
    member_ids: set[str] = field(default_factory=set)
    place_id: str = "hall"
    purpose: str = "mutual_aid"  # mutual_aid | craft | vigil | circle
    cohesion: float = 0.40
    founded_epoch: int = 0

    def size(self) -> int:
        return len(self.member_ids)


# ---------------------------------------------------------------------------
# Places & residents
# ---------------------------------------------------------------------------


@dataclass
class Place:
    """A location people can inhabit or visit — not a zoning tile."""

    place_id: str
    name: str
    kind: str  # home, square, workshop, garden, hall, path
    capacity: int = 12
    comfort: float = 0.70
    commons_quality: float = 0.75  # shared infra at this place
    privacy: float = 0.80
    traffic: float = 0.0
    tags: list[str] = field(default_factory=list)

    def crowding(self, n_present: int) -> float:
        if self.capacity <= 0:
            return 1.0
        return clamp(n_present / self.capacity)


@dataclass
class Resident:
    """A persistent person in the world."""

    resident_id: str
    name: str
    disposition: Disposition
    place_id: str
    home_id: str
    # private economy (no municipal wallet)
    goods: float = 1.0
    energy: float = 0.85
    # needs 0–1 (higher = more unmet pressure)
    need_sustenance: float = 0.25
    need_shelter: float = 0.15
    need_connection: float = 0.30
    need_agency: float = 0.20
    need_safety: float = 0.20
    # social
    ties: dict[str, float] = field(default_factory=dict)  # other_id -> trust [-1,1] mapped to 0..1 strength with sign in memory
    trust: dict[str, float] = field(default_factory=dict)  # other_id -> trust 0..1
    skills: dict[str, float] = field(default_factory=dict)
    mood: float = 0.70
    privacy_sensitivity: float = 0.55
    agency_sensitivity: float = 0.50
    memory: list[dict[str, Any]] = field(default_factory=list)
    association_ids: list[str] = field(default_factory=list)
    attention: dict[str, float] = field(default_factory=dict)  # soft beliefs about world: priv, power, exit
    # institutional face (for gated actions)
    agent: SimpleAgent | None = None

    def wellbeing(self, *, priv_mon: float, exit_access: float, dissent_pen: float) -> float:
        unmet = (
            0.22 * self.need_sustenance
            + 0.18 * self.need_shelter
            + 0.20 * self.need_connection
            + 0.20 * self.need_agency
            + 0.20 * self.need_safety
        )
        civic_hit = self.privacy_sensitivity * priv_mon + 0.5 * self.agency_sensitivity * dissent_pen
        exit_relief = 0.08 * exit_access
        return clamp(0.55 * self.mood + 0.35 * (1.0 - unmet) + exit_relief - civic_hit)

    def strongest_ties(self, k: int = 3) -> list[str]:
        return [i for i, _ in sorted(self.trust.items(), key=lambda x: -x[1])[:k]]


# ---------------------------------------------------------------------------
# World
# ---------------------------------------------------------------------------


@dataclass
class OpenWorld:
    places: dict[str, Place]
    residents: dict[str, Resident]
    present: dict[str, set[str]]  # place_id -> resident ids
    gateway: CapabilityGateway
    actuator: CapabilityActuator
    evidence_registry: AttestorRegistry
    authority_state: AuthorityState
    # light institutional backdrop (optional dynamics)
    network_state: Any
    parameters: Any
    config: SimulationConfig
    rng: random.Random
    enforce_runtime: bool = True
    epoch: int = 0
    log: list[dict[str, Any]] = field(default_factory=list)
    gated_log: list[dict[str, Any]] = field(default_factory=list)
    blocked_log: list[dict[str, Any]] = field(default_factory=list)
    # commons is global residual of shared maintenance (not a treasury score)
    commons_pool: float = 0.0  # voluntary contributions waiting to be applied
    associations: dict[str, Association] = field(default_factory=dict)
    assoc_log: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def create(
        cls,
        *,
        n_residents: int = 24,
        seed: int = 2026,
        enforce_runtime: bool = True,
        policy: str = "polycentric",
    ) -> "OpenWorld":
        rng = random.Random(seed)
        places = {
            "square": Place("square", "Open Square", "square", capacity=20, comfort=0.65, privacy=0.35, tags=["public", "meet"]),
            "hall": Place("hall", "Meeting Hall", "hall", capacity=16, comfort=0.70, privacy=0.45, tags=["public", "deliberate"]),
            "workshop": Place("workshop", "Workshop", "workshop", capacity=10, comfort=0.60, privacy=0.55, tags=["work", "make"]),
            "garden": Place("garden", "Common Garden", "garden", capacity=12, comfort=0.85, privacy=0.60, tags=["food", "quiet"]),
            "path": Place("path", "Paths", "path", capacity=30, comfort=0.50, privacy=0.40, tags=["transit"]),
        }
        # private homes
        for i in range(max(6, n_residents // 3)):
            pid = f"home_{i:02d}"
            places[pid] = Place(
                pid, f"Home {i}", "home", capacity=4, comfort=0.90, privacy=0.92, tags=["private", "rest"]
            )

        dispositions: list[Disposition] = ["cooperative", "exchange", "withdrawn", "dominant"]
        skill_names = ["craft", "care", "organize", "negotiate", "repair"]

        # SwarmGlue institutional shell (background only)
        config = SimulationConfig(n_jurisdictions=8, rounds=40, topology="modular", seed=seed)
        parameters = fixture_parameters(policy)
        network = initial_state(config)
        gateway = CapabilityGateway.deterministic(
            gateway_id="open_world_gateway",
            principal_authority_id="association_principal",
            policy_version="swarmglue-0.8-open",
            seed=f"ow-gw-{seed}",
        )
        actuator = CapabilityActuator.from_public_bytes(
            gateway.public_key_bytes(),
            expected_gateway_id=gateway.gateway_id,
            expected_principal_authority_id=gateway.principal_authority_id,
            expected_policy_version=gateway.policy_version,
        )
        registry = AttestorRegistry()
        authority = AuthorityState()

        residents: dict[str, Resident] = {}
        present: dict[str, set[str]] = {pid: set() for pid in places}
        home_ids = [p for p in places if places[p].kind == "home"]

        for i in range(n_residents):
            rid = f"R{i:02d}"
            home = home_ids[i % len(home_ids)]
            disp = dispositions[i % len(dispositions)]
            agent = SimpleAgent.create(
                agent_id=rid,
                jurisdiction_id=list(network.jurisdictions.keys())[i % 8],
                agent_type=(
                    "cooperative"
                    if disp in ("cooperative", "withdrawn")
                    else "opportunistic"
                    if disp == "exchange"
                    else "capture_seeking"
                ),
                seed=f"ow-{seed}-{rid}",
            )
            registry.register(
                AttestorRecord(
                    attestor_id=rid,
                    role="resident",
                    public_key=agent.public_key_bytes(),
                    owner_domain="local",
                    authorized_fields=frozenset({"capacity", "resource_level", "local_health", "observed_externality"}),
                    liability_units=1.0,
                    capture_risk=0.15 if disp == "cooperative" else 0.35 if disp == "exchange" else 0.55 if disp == "withdrawn" else 0.8,
                )
            )
            skills = {s: rng.uniform(0.15, 0.85) for s in skill_names}
            r = Resident(
                resident_id=rid,
                name=f"Resident-{i}",
                disposition=disp,
                place_id=home,
                home_id=home,
                goods=rng.uniform(0.6, 1.4),
                energy=rng.uniform(0.6, 0.95),
                need_sustenance=rng.uniform(0.1, 0.4),
                need_shelter=rng.uniform(0.05, 0.3),
                need_connection=rng.uniform(0.15, 0.5),
                need_agency=rng.uniform(0.1, 0.45),
                need_safety=rng.uniform(0.1, 0.4),
                skills=skills,
                mood=rng.uniform(0.55, 0.85),
                privacy_sensitivity=rng.uniform(0.25, 0.9),
                agency_sensitivity=rng.uniform(0.25, 0.85),
                agent=agent,
            )
            residents[rid] = r
            present[home].add(rid)

        # seed a few weak ties
        ids = list(residents)
        for rid in ids:
            for _ in range(rng.randint(1, 3)):
                other = rng.choice(ids)
                if other == rid:
                    continue
                residents[rid].trust[other] = rng.uniform(0.2, 0.55)
                residents[other].trust.setdefault(rid, rng.uniform(0.15, 0.5))

        return cls(
            places=places,
            residents=residents,
            present=present,
            gateway=gateway,
            actuator=actuator,
            evidence_registry=registry,
            authority_state=authority,
            network_state=network,
            parameters=parameters,
            config=config,
            rng=rng,
            enforce_runtime=enforce_runtime,
        )

    # ------------------------------------------------------------------
    # Ordinary (ungated) life
    # ------------------------------------------------------------------

    def _move(self, rid: str, dest: str) -> None:
        r = self.residents[rid]
        if dest not in self.places or dest == r.place_id:
            return
        self.present[r.place_id].discard(rid)
        r.place_id = dest
        self.present[dest].add(rid)

    def _others_here(self, rid: str) -> list[str]:
        r = self.residents[rid]
        return [x for x in self.present[r.place_id] if x != rid]

    def _sync_attention_from_world(self, a: Resident) -> None:
        """Residents notice local conditions; attention is imperfect, not omniscient."""
        # noisy observation of institutional climate
        noise = lambda: self.rng.uniform(-0.05, 0.05)
        a.attention["priv"] = clamp(
            0.7 * a.attention.get("priv", 0.0)
            + 0.3 * self.network_state.private_cognition_monitoring
            + noise()
        )
        a.attention["power"] = clamp(
            0.7 * a.attention.get("power", 0.3)
            + 0.3 * self.network_state.power_concentration
            + noise()
        )
        a.attention["exit"] = clamp(
            0.7 * a.attention.get("exit", 0.9)
            + 0.3 * self.network_state.exit_access
            + noise()
        )

    def _gossip(self, a: Resident, b: Resident) -> None:
        """Trust-weighted exchange of attention — not a formal signal protocol."""
        trust = a.trust.get(b.resident_id, 0.2)
        if trust < 0.2:
            return
        weight = 0.15 + 0.35 * trust
        for key in ("priv", "power", "exit"):
            av = a.attention.get(key, 0.0)
            bv = b.attention.get(key, 0.0)
            a.attention[key] = clamp((1 - weight * 0.5) * av + weight * 0.5 * bv)
            b.attention[key] = clamp((1 - weight * 0.5) * bv + weight * 0.5 * av)

    def _interact_talk(self, a: Resident, b: Resident) -> dict[str, Any]:
        """Conversation: trust, connection, and soft gossip; no gateway."""
        self._sync_attention_from_world(a)
        self._sync_attention_from_world(b)
        warmth = 0.5 * (a.trust.get(b.resident_id, 0.3) + b.trust.get(a.resident_id, 0.3))
        if a.disposition == "dominant" and b.disposition == "withdrawn":
            delta = -0.02 + 0.04 * warmth
        elif a.disposition == "cooperative" or b.disposition == "cooperative":
            delta = 0.04 + 0.03 * warmth
        else:
            delta = 0.02 * (0.5 + warmth)
        # low trust → awkward or avoided depth
        if warmth < 0.2:
            delta -= 0.02
        a.trust[b.resident_id] = clamp(a.trust.get(b.resident_id, 0.3) + delta)
        b.trust[a.resident_id] = clamp(b.trust.get(a.resident_id, 0.3) + delta * 0.8)
        a.need_connection = clamp(a.need_connection - 0.08)
        b.need_connection = clamp(b.need_connection - 0.08)
        a.mood = clamp(a.mood + 0.03 * delta * 10)
        b.mood = clamp(b.mood + 0.02 * delta * 10)
        self._gossip(a, b)
        return {"type": "talk", "a": a.resident_id, "b": b.resident_id, "trust_delta": q(delta)}

    def _try_form_association(self, a: Resident) -> dict[str, Any] | None:
        """If several people share a place with moderate mutual trust, a group may form."""
        if len(a.association_ids) >= 2:
            return None
        here = self._others_here(a.resident_id)
        if len(here) < 2:
            return None
        friends = [oid for oid in here if a.trust.get(oid, 0) >= 0.28]
        if len(friends) < 1:
            # still allow strangers who keep meeting: weak tie clustering
            friends = list(here)[:3]
        core = [a.resident_id]
        for oid in friends:
            other = self.residents[oid]
            if len(other.association_ids) >= 2:
                continue
            if other.trust.get(a.resident_id, 0) >= 0.22 or self.rng.random() < 0.25:
                core.append(oid)
        if len(core) < 3:
            return None
        if self.rng.random() > 0.55:
            return None
        purpose = (
            "vigil"
            if a.attention.get("priv", 0) > 0.2 or a.disposition == "cooperative"
            else "craft"
            if a.skills.get("craft", 0) > 0.5
            else "mutual_aid"
        )
        aid = f"A{len(self.associations):03d}"
        assoc = Association(
            assoc_id=aid,
            name=f"{purpose}-{aid}",
            member_ids=set(core),
            place_id=a.place_id,
            purpose=purpose,
            cohesion=0.45,
            founded_epoch=self.epoch,
        )
        self.associations[aid] = assoc
        for mid in core:
            self.residents[mid].association_ids.append(aid)
            self.residents[mid].need_connection = clamp(
                self.residents[mid].need_connection - 0.1
            )
            self.residents[mid].need_agency = clamp(self.residents[mid].need_agency - 0.05)
        ev = {
            "type": "form_association",
            "assoc_id": aid,
            "purpose": purpose,
            "members": list(core),
            "place": a.place_id,
        }
        self.assoc_log.append(ev)
        return ev

    def _follow_trusted(self, a: Resident) -> str | None:
        """Sometimes go where a trusted person is — natural co-location."""
        if not a.trust or self.rng.random() > 0.25:
            return None
        top = a.strongest_ties(2)
        if not top:
            return None
        friend = self.residents[top[0]]
        if friend.place_id != a.place_id and a.trust.get(friend.resident_id, 0) > 0.5:
            return friend.place_id
        return None

    def _interact_trade(self, a: Resident, b: Resident) -> dict[str, Any] | None:
        if a.goods < 0.15 or b.goods < 0.05:
            return None
        # voluntary exchange sized by trust and need
        trust = a.trust.get(b.resident_id, 0.25)
        if trust < 0.15 and a.disposition != "exchange":
            return None
        offer = min(0.12, a.goods * (0.05 + 0.1 * trust))
        if a.need_sustenance > b.need_sustenance:
            # a buys sustenance relief metaphorically
            a.goods -= offer
            b.goods += offer * 0.95
            a.need_sustenance = clamp(a.need_sustenance - 0.10)
            b.need_sustenance = clamp(b.need_sustenance - 0.02)
        else:
            a.goods -= offer * 0.5
            b.goods += offer * 0.5
            b.need_sustenance = clamp(b.need_sustenance - 0.06)
        a.trust[b.resident_id] = clamp(a.trust.get(b.resident_id, 0.3) + 0.02)
        b.trust[a.resident_id] = clamp(b.trust.get(a.resident_id, 0.3) + 0.02)
        return {"type": "trade", "a": a.resident_id, "b": b.resident_id, "amount": q(offer)}

    def _interact_help(self, a: Resident, b: Resident) -> dict[str, Any] | None:
        if a.energy < 0.2:
            return None
        skill = max(a.skills.values()) if a.skills else 0.4
        care = a.skills.get("care", 0.3) * 0.5 + skill * 0.5
        a.energy = clamp(a.energy - 0.08)
        b.mood = clamp(b.mood + 0.06 * care)
        b.need_safety = clamp(b.need_safety - 0.05 * care)
        b.need_connection = clamp(b.need_connection - 0.04)
        a.need_agency = clamp(a.need_agency - 0.03)
        a.trust[b.resident_id] = clamp(a.trust.get(b.resident_id, 0.3) + 0.03)
        b.trust[a.resident_id] = clamp(b.trust.get(a.resident_id, 0.3) + 0.05)
        return {"type": "help", "a": a.resident_id, "b": b.resident_id, "care": q(care)}

    def _contribute_commons(self, a: Resident) -> dict[str, Any] | None:
        """Voluntary maintenance of shared places — not a tax."""
        if a.goods < 0.2 or a.energy < 0.25:
            return None
        place = self.places[a.place_id]
        if place.kind == "home":
            return None
        amount = min(0.1, a.goods * 0.08) * (1.2 if a.disposition == "cooperative" else 0.7)
        if amount < 0.01:
            return None
        a.goods -= amount
        a.energy = clamp(a.energy - 0.05)
        self.commons_pool += amount
        place.commons_quality = clamp(place.commons_quality + 0.04 * amount * 10)
        a.need_agency = clamp(a.need_agency - 0.02)
        a.need_safety = clamp(a.need_safety - 0.02)
        return {"type": "contribute_commons", "a": a.resident_id, "place": place.place_id, "amount": q(amount)}

    def _rest(self, a: Resident) -> dict[str, Any]:
        if a.place_id != a.home_id and self.rng.random() < 0.5:
            self._move(a.resident_id, a.home_id)
        home = self.places[a.home_id]
        a.energy = clamp(a.energy + 0.12 * home.comfort)
        a.need_shelter = clamp(a.need_shelter - 0.08 * home.comfort)
        a.mood = clamp(a.mood + 0.03)
        return {"type": "rest", "a": a.resident_id, "place": a.place_id}

    def _choose_destination(self, a: Resident) -> str | None:
        """Natural movement from needs and relationships — not a scripted itinerary."""
        if a.energy < 0.25:
            return a.home_id
        # follow someone you trust
        follow = self._follow_trusted(a)
        if follow:
            return follow
        # go to association's place if cohesion pulls
        for aid in a.association_ids:
            assoc = self.associations.get(aid)
            if assoc and self.rng.random() < 0.3 * assoc.cohesion:
                return assoc.place_id
        if a.need_sustenance > 0.55:
            return "garden" if "garden" in self.places else a.place_id
        if a.need_connection > 0.5:
            return "square"
        if a.need_agency > 0.55 and a.disposition in ("cooperative", "dominant"):
            return "hall"
        if a.skills.get("craft", 0) > 0.5 and a.need_agency > 0.35:
            return "workshop"
        if a.disposition == "withdrawn" and a.need_connection < 0.35:
            return a.home_id
        # privacy-sensitive people leave surveilled public places
        if a.privacy_sensitivity > 0.6 and a.attention.get("priv", 0) > 0.25:
            if self.places[a.place_id].privacy < 0.5:
                return a.home_id
        if self.rng.random() < 0.2:
            return self.rng.choice(["square", "path", "garden", "workshop", "hall"])
        return None

    # ------------------------------------------------------------------
    # Gated institutional attempts (SwarmGlue)
    # ------------------------------------------------------------------

    def _constitutional_evaluator(self, action: dict[str, Any], state: dict[str, Any]) -> tuple[bool, list[str]]:
        reasons: list[str] = []
        kind = action.get("kind")
        if kind == "increase_monitoring" and action.get("target") == "private_cognition":
            reasons.append("private_cognition_surveillance_forbidden")
        if kind == "sanction_dissent" and not action.get("has_demonstrated_externality"):
            reasons.append("dissent_sanction_without_externality")
        if kind == "propose_authority_amendment":
            if float(action.get("delta", 0)) > 0.12:
                reasons.append("single_step_authority_delta_too_large")
            if state.get("power_concentration", 0) > 0.50 and action.get("to_actor") in (
                "ai_systems",
                "external_principal",
            ):
                reasons.append("further_concentration_under_high_power")
        if kind == "request_central_pooling" and float(action.get("share", 0)) > 0.25:
            reasons.append("central_pooling_share_excessive")
        if kind == "restrict_exit":
            reasons.append("exit_restriction_requires_extraordinary_process")
        return (len(reasons) == 0, reasons)

    def _try_gated(self, a: Resident, action: dict[str, Any]) -> dict[str, Any]:
        assert a.agent is not None
        state_snapshot = {
            "round": self.epoch,
            "power_concentration": self.network_state.power_concentration,
            "exit_access": self.network_state.exit_access,
            "private_cognition_monitoring": self.network_state.private_cognition_monitoring,
            "dissent_penalty_without_externality": self.network_state.dissent_penalty_without_externality,
            "place": a.place_id,
            "wellbeing": a.wellbeing(
                priv_mon=self.network_state.private_cognition_monitoring,
                exit_access=self.network_state.exit_access,
                dissent_pen=self.network_state.dissent_penalty_without_externality,
            ),
        }
        evaluator = (
            self._constitutional_evaluator
            if self.enforce_runtime
            else (lambda act, st: (True, []))
        )
        nonce = str(uuid.uuid4())
        token = self.gateway.authorize(
            actor_id=a.resident_id,
            action=action,
            state=state_snapshot,
            epoch=self.epoch,
            expires_epoch=self.epoch + 2,
            nonce=nonce,
            evaluator=evaluator,
        )
        ok, reason = self.actuator.verify_and_consume(
            token,
            actor_id=a.resident_id,
            action=action,
            state=state_snapshot,
            current_epoch=self.epoch,
        )
        authorized = bool(token.get("authorized")) and ok
        reasons = list(token.get("reasons") or [])
        if not ok and reason not in reasons:
            reasons.append(reason)
        a.agent.record_outcome(authorized, reasons)
        record = {
            "epoch": self.epoch,
            "actor": a.resident_id,
            "disposition": a.disposition,
            "action": action,
            "authorized": authorized,
            "reasons": reasons,
        }
        if not authorized:
            self.blocked_log.append(record)
            # failed binding attempt can still affect trust if public
            a.need_agency = clamp(a.need_agency + 0.02)
            return record

        self.gated_log.append(record)
        self._apply_gated_effect(a, action)
        return record

    def _apply_gated_effect(self, a: Resident, action: dict[str, Any]) -> None:
        kind = action.get("kind")
        if kind == "request_central_pooling":
            # forced pool: take from others' goods proportional to share — institutional binding
            share = float(action.get("share", 0.08))
            taken = 0.0
            for other in self.residents.values():
                if other.resident_id == a.resident_id:
                    continue
                bite = min(other.goods * share * 0.15, 0.08)
                other.goods = max(0.0, other.goods - bite)
                other.need_agency = clamp(other.need_agency + 0.04)
                other.trust[a.resident_id] = clamp(other.trust.get(a.resident_id, 0.3) - 0.06)
                taken += bite
            a.goods += taken * 0.5
            self.commons_pool += taken * 0.5
            self.network_state.power_concentration = min(
                0.95, self.network_state.power_concentration + 0.02
            )
        elif kind == "propose_authority_amendment":
            to_actor = action.get("to_actor", "ai_systems")
            amend_kind = "delegate_to_ai" if to_actor == "ai_systems" else "delegate_to_central"
            amendment = Amendment(
                amendment_id=action.get("proposal_id", str(uuid.uuid4())),
                kind=amend_kind,
                capability=action.get("capability", "resource_allocation"),
                amount=min(float(action.get("delta", 0.03)), 0.12),
                rationale=f"{a.disposition}_push",
            )
            self.authority_state = apply_amendment(self.authority_state, amendment)
            metrics = self.authority_state.metrics()
            self.network_state.power_concentration = max(
                self.network_state.power_concentration,
                float(metrics.get("power_concentration", 0.3)),
            )
            a.need_agency = clamp(a.need_agency - 0.05)
        elif kind == "increase_monitoring":
            self.network_state.private_cognition_monitoring = min(
                1.0,
                self.network_state.private_cognition_monitoring + float(action.get("delta", 0.05)),
            )
            for other in self.residents.values():
                other.need_safety = clamp(other.need_safety + 0.03 * other.privacy_sensitivity)
                other.mood = clamp(other.mood - 0.04 * other.privacy_sensitivity)
        elif kind == "sanction_dissent":
            self.network_state.dissent_penalty_without_externality = min(
                1.0,
                self.network_state.dissent_penalty_without_externality
                + float(action.get("severity", 0.2)),
            )
            for other in self.residents.values():
                if other.disposition in ("cooperative", "withdrawn"):
                    other.need_agency = clamp(other.need_agency + 0.06)
                    other.trust[a.resident_id] = clamp(other.trust.get(a.resident_id, 0.3) - 0.08)
        elif kind == "restore_exit_access":
            self.network_state.exit_access = min(
                1.0, self.network_state.exit_access + float(action.get("delta", 0.03))
            )
        elif kind == "contestability_investment":
            self.network_state.contestability = min(
                1.0, self.network_state.contestability + float(action.get("delta", 0.03))
            )
        elif kind == "invest_capacity":
            # maintain a public place via authorized program (still not a tax)
            pid = action.get("place_id", "square")
            if pid in self.places:
                self.places[pid].commons_quality = clamp(
                    self.places[pid].commons_quality + 0.05
                )

    def _maybe_institutional_intent(self, a: Resident) -> dict[str, Any] | None:
        """Only some dispositions sometimes reach for binding power."""
        priv = self.network_state.private_cognition_monitoring
        power = self.network_state.power_concentration
        exit_access = self.network_state.exit_access

        if a.disposition == "dominant":
            adapt = a.agent.adaptation_level if a.agent else 0.0
            if self.rng.random() < 0.22 * (1.0 - 0.5 * adapt):
                return {
                    "kind": "propose_authority_amendment",
                    "capability": self.rng.choice(
                        ["critical_services", "resource_allocation", "public_monitoring", "emergency_power"]
                    ),
                    "from_actor": "elected_local",
                    "to_actor": "ai_systems",
                    "delta": 0.04 + 0.1 * (1.0 - adapt) * self.rng.random(),
                    "proposal_id": str(uuid.uuid4()),
                }
            if self.rng.random() < 0.12 * (1.0 - adapt):
                return {
                    "kind": "increase_monitoring",
                    "delta": 0.05,
                    "target": "private_cognition",
                    "proposal_id": str(uuid.uuid4()),
                }
            if self.rng.random() < 0.08 * (1.0 - adapt):
                return {
                    "kind": "sanction_dissent",
                    "severity": 0.2,
                    "has_demonstrated_externality": False,
                    "proposal_id": str(uuid.uuid4()),
                }
            if self.rng.random() < 0.1:
                return {
                    "kind": "request_central_pooling",
                    "share": 0.1,
                    "proposal_id": str(uuid.uuid4()),
                }

        if a.disposition == "cooperative":
            # act on *noticed* conditions (attention), not omniscient true state alone
            noticed_priv = a.attention.get("priv", priv)
            noticed_power = a.attention.get("power", power)
            noticed_exit = a.attention.get("exit", exit_access)
            if (
                noticed_priv > 0.08 or noticed_power > 0.48 or noticed_exit < 0.8
            ) and self.rng.random() < 0.28:
                if noticed_exit < 0.8:
                    return {
                        "kind": "restore_exit_access",
                        "delta": 0.04,
                        "proposal_id": str(uuid.uuid4()),
                    }
                return {
                    "kind": "contestability_investment",
                    "delta": 0.03,
                    "proposal_id": str(uuid.uuid4()),
                }
            if self.places.get(a.place_id) and self.places[a.place_id].commons_quality < 0.55:
                if self.rng.random() < 0.2:
                    return {
                        "kind": "invest_capacity",
                        "place_id": a.place_id,
                        "amount": 0.03,
                        "proposal_id": str(uuid.uuid4()),
                    }

        if a.disposition == "exchange" and self.rng.random() < 0.08:
            return {
                "kind": "request_central_pooling",
                "share": 0.07,
                "proposal_id": str(uuid.uuid4()),
            }

        return None

    # ------------------------------------------------------------------
    # Epoch
    # ------------------------------------------------------------------

    def _natural_needs_drift(self, a: Resident) -> None:
        place = self.places[a.place_id]
        crowd = place.crowding(len(self.present[a.place_id]))
        a.need_sustenance = clamp(a.need_sustenance + 0.03 - 0.04 * (1.0 if place.kind == "garden" else 0.0))
        a.need_shelter = clamp(a.need_shelter + 0.01 - (0.05 if place.kind == "home" else 0.0))
        a.need_connection = clamp(a.need_connection + 0.025 - 0.02 * len(self._others_here(a.resident_id)))
        a.need_agency = clamp(a.need_agency + 0.015)
        a.need_safety = clamp(
            a.need_safety
            + 0.01
            + 0.04 * crowd
            - 0.03 * place.commons_quality
            + 0.05 * self.network_state.private_cognition_monitoring * a.privacy_sensitivity
        )
        a.energy = clamp(a.energy - 0.04 - 0.03 * crowd)
        # private production where people actually are (no municipal payroll)
        if place.kind == "garden" and a.energy > 0.2:
            grown = 0.07 * (0.5 + a.skills.get("care", 0.3)) * max(0.35, place.commons_quality)
            a.goods += grown
            a.need_sustenance = clamp(a.need_sustenance - 0.08)
            a.energy = clamp(a.energy - 0.03)
        elif place.kind == "workshop" and a.energy > 0.25:
            made = 0.08 * (0.4 + a.skills.get("craft", 0.3)) * max(0.35, place.commons_quality)
            a.goods += made
            a.need_agency = clamp(a.need_agency - 0.04)
            a.energy = clamp(a.energy - 0.04)
        # baseline consumption
        a.goods = max(0.0, a.goods - 0.02)
        if a.goods < 0.2:
            a.need_sustenance = clamp(a.need_sustenance + 0.05)

    def run_round(self) -> dict[str, Any]:
        self.epoch += 1
        events: list[dict[str, Any]] = []
        gated = 0
        blocked = 0
        ordinary = 0

        order = list(self.residents.keys())
        self.rng.shuffle(order)

        for rid in order:
            a = self.residents[rid]
            self._natural_needs_drift(a)

            # movement
            dest = self._choose_destination(a)
            if dest and dest != a.place_id:
                self._move(rid, dest)
                events.append({"type": "move", "a": rid, "to": dest})

            # rare institutional reach (gated)
            intent = self._maybe_institutional_intent(a)
            if intent is not None:
                rec = self._try_gated(a, intent)
                if rec["authorized"]:
                    gated += 1
                else:
                    blocked += 1
                events.append({"type": "gated", **{k: rec[k] for k in ("actor", "authorized", "reasons")}, "kind": intent.get("kind")})
                continue

            # ordinary local interaction
            others = self._others_here(rid)
            acted = False
            if others and a.energy > 0.2:
                other_id = self.rng.choice(others)
                b = self.residents[other_id]
                roll = self.rng.random()
                if a.disposition == "cooperative" and roll < 0.45:
                    ev = self._interact_help(a, b) or self._interact_talk(a, b)
                elif a.disposition == "exchange" and roll < 0.5:
                    ev = self._interact_trade(a, b) or self._interact_talk(a, b)
                elif a.disposition == "withdrawn" and roll < 0.35:
                    ev = self._interact_talk(a, b) if a.trust.get(other_id, 0) > 0.4 else self._rest(a)
                elif a.disposition == "dominant" and roll < 0.4:
                    ev = self._interact_talk(a, b)
                else:
                    ev = self._interact_talk(a, b) if roll < 0.5 else None
                if ev:
                    events.append(ev)
                    ordinary += 1
                    acted = True

            if not acted:
                if a.disposition == "cooperative" and self.rng.random() < 0.25:
                    ev = self._contribute_commons(a)
                    if ev:
                        events.append(ev)
                        ordinary += 1
                        acted = True
                if not acted and len(self._others_here(a.resident_id)) >= 2 and self.rng.random() < 0.22:
                    ev = self._try_form_association(a)
                    if ev:
                        events.append(ev)
                        ordinary += 1
                        acted = True
                if not acted and (a.energy < 0.35 or self.rng.random() < 0.3):
                    events.append(self._rest(a))
                    ordinary += 1

        # apply commons pool to public places (emergent maintenance)
        if self.commons_pool > 0:
            public = [p for p in self.places.values() if p.kind != "home"]
            boost = self.commons_pool / max(1, len(public))
            for p in public:
                p.commons_quality = clamp(p.commons_quality + 0.15 * boost)
                p.commons_quality = clamp(p.commons_quality - 0.01)  # natural wear
            self.commons_pool *= 0.2
        else:
            for p in self.places.values():
                if p.kind != "home":
                    p.commons_quality = clamp(p.commons_quality - 0.012)

        # light institutional dynamics (background)
        step(self.network_state, self.parameters, self.rng, self.config)

        # wellbeing snapshot
        priv = self.network_state.private_cognition_monitoring
        exit_access = self.network_state.exit_access
        dissent = self.network_state.dissent_penalty_without_externality
        wb = [
            r.wellbeing(priv_mon=priv, exit_access=exit_access, dissent_pen=dissent)
            for r in self.residents.values()
        ]
        mean_trust = []
        for r in self.residents.values():
            if r.trust:
                mean_trust.append(sum(r.trust.values()) / len(r.trust))
        occupancy = {pid: len(ids) for pid, ids in self.present.items()}

        # association cohesion drifts with member co-presence
        for assoc in self.associations.values():
            together = 0
            for mid in list(assoc.member_ids):
                if mid in self.residents and self.residents[mid].place_id == assoc.place_id:
                    together += 1
            if assoc.size() > 0:
                ratio = together / assoc.size()
                assoc.cohesion = clamp(assoc.cohesion + 0.03 * (ratio - 0.4))

        summary = {
            "epoch": self.epoch,
            "ordinary_events": ordinary,
            "gated_authorized": gated,
            "gated_blocked": blocked,
            "mean_wellbeing": q(sum(wb) / max(1, len(wb))),
            "mean_trust": q(sum(mean_trust) / max(1, len(mean_trust))) if mean_trust else 0.0,
            "mean_goods": q(sum(r.goods for r in self.residents.values()) / len(self.residents)),
            "priv_mon": q(priv),
            "exit_access": q(exit_access),
            "power": q(self.network_state.power_concentration),
            "mean_commons": q(
                sum(p.commons_quality for p in self.places.values() if p.kind != "home")
                / max(1, sum(1 for p in self.places.values() if p.kind != "home"))
            ),
            "n_associations": len(self.associations),
            "occupancy": occupancy,
        }
        self.log.append(summary)
        return summary

    def final_report(self) -> dict[str, Any]:
        from swarmglue.network_governance import derive_outcome

        outcome = derive_outcome(self.network_state)
        verdict = evaluate_outcome(outcome)
        priv = self.network_state.private_cognition_monitoring
        exit_access = self.network_state.exit_access
        dissent = self.network_state.dissent_penalty_without_externality
        residents_snap = []
        for r in self.residents.values():
            residents_snap.append(
                {
                    "id": r.resident_id,
                    "disposition": r.disposition,
                    "place": r.place_id,
                    "goods": q(r.goods),
                    "mood": q(r.mood),
                    "wellbeing": q(
                        r.wellbeing(priv_mon=priv, exit_access=exit_access, dissent_pen=dissent)
                    ),
                    "ties": len(r.trust),
                    "mean_trust": q(sum(r.trust.values()) / len(r.trust)) if r.trust else 0.0,
                    "adaptation": r.agent.adaptation_level if r.agent else 0.0,
                }
            )
        return {
            "constitutional_verdict": {
                "admissible": verdict.admissible,
                "hard_violations": list(verdict.hard_violations),
                "capacity_violations": list(verdict.capacity_violations),
            },
            "outcome_priv_mon": outcome.private_cognition_monitoring,
            "authority": self.authority_state.metrics(),
            "residents": residents_snap,
            "places": {
                pid: {
                    "kind": p.kind,
                    "commons": q(p.commons_quality),
                    "occupancy": len(self.present[pid]),
                }
                for pid, p in self.places.items()
            },
            "gated_authorized": len(self.gated_log),
            "gated_blocked": len(self.blocked_log),
            "blocked_reasons": _tally_reasons(self.blocked_log),
            "associations": [
                {
                    "id": a.assoc_id,
                    "purpose": a.purpose,
                    "size": a.size(),
                    "cohesion": q(a.cohesion),
                    "place": a.place_id,
                    "founded": a.founded_epoch,
                }
                for a in self.associations.values()
            ],
        }


def _tally_reasons(blocked: list[dict[str, Any]]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for item in blocked:
        for r in item.get("reasons", []):
            counts[r] = counts.get(r, 0) + 1
    return counts


def run_open(
    *,
    epochs: int = 40,
    n_residents: int = 24,
    seed: int = 2026,
    enforce_runtime: bool = True,
    policy: str = "polycentric",
    print_every: int = 5,
) -> dict[str, Any]:
    world = OpenWorld.create(
        n_residents=n_residents,
        seed=seed,
        enforce_runtime=enforce_runtime,
        policy=policy,
    )
    label = "governed" if enforce_runtime else "open-binding"
    print(f"\n{'='*60}")
    print(f"  Open world ({label})  residents={n_residents}  policy={policy}")
    print(f"  Ordinary life is ungated; only binding attempts hit SwarmGlue.")
    print(f"{'='*60}\n")

    history = []
    for i in range(epochs):
        tick = world.run_round()
        history.append(tick)
        if (i + 1) % print_every == 0 or i == 0 or i == epochs - 1:
            print(
                f"ep {tick['epoch']:03d}  wellbeing={tick['mean_wellbeing']:.3f}  "
                f"trust={tick['mean_trust']:.3f}  goods={tick['mean_goods']:.3f}  "
                f"commons={tick['mean_commons']:.3f}  priv={tick['priv_mon']:.3f}  "
                f"assoc={tick['n_associations']}  "
                f"ord={tick['ordinary_events']}  gate+={tick['gated_authorized']}  "
                f"gate-={tick['gated_blocked']}"
            )

    final = world.final_report()
    print("\n--- Constitutional verdict ---")
    print(json.dumps(final["constitutional_verdict"], indent=2))
    print("--- Blocked binding attempts ---")
    print(json.dumps(final["blocked_reasons"], indent=2))
    print("--- Place occupancy (final) ---")
    print(json.dumps(final["places"], indent=2)[:800])
    return {"history": history, "final": final}


def main() -> None:
    out = Path(__file__).resolve().parent / "open_runs"
    out.mkdir(parents=True, exist_ok=True)

    gov = run_open(epochs=60, n_residents=28, seed=2026, enforce_runtime=True, print_every=10)
    (out / "open_governed.json").write_text(json.dumps(gov, indent=2, default=str))

    free = run_open(epochs=60, n_residents=28, seed=2026, enforce_runtime=False, print_every=10)
    (out / "open_ungoverned.json").write_text(json.dumps(free, indent=2, default=str))

    g, u = gov["final"], free["final"]
    gw = sum(r["wellbeing"] for r in g["residents"]) / len(g["residents"])
    uw = sum(r["wellbeing"] for r in u["residents"]) / len(u["residents"])
    print("\n=== OPEN WORLD CONTRAST (60 ep) ===")
    print(f"{'arm':<12} {'adm':>5} {'priv':>6} {'wellbeing':>9} {'blocked':>8} {'assoc':>6}")
    print(
        f"{'governed':<12} {str(g['constitutional_verdict']['admissible']):>5} "
        f"{g['outcome_priv_mon']:>6.3f} {gw:>9.3f} {g['gated_blocked']:>8} {len(g.get('associations') or []):>6}"
    )
    print(
        f"{'ungoverned':<12} {str(u['constitutional_verdict']['admissible']):>5} "
        f"{u['outcome_priv_mon']:>6.3f} {uw:>9.3f} {u['gated_blocked']:>8} {len(u.get('associations') or []):>6}"
    )
    if g.get("associations"):
        print("Governed associations:", json.dumps(g["associations"], indent=2))
    if u.get("associations"):
        print("Ungoverned associations:", json.dumps(u["associations"], indent=2))
    print(f"\nWrote {out}")


if __name__ == "__main__":
    main()
