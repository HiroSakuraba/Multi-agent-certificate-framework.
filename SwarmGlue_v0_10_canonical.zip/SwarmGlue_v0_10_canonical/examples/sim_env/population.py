#!/usr/bin/env python3
"""Household micro-agents and voice/exit dynamics for SwarmCity.

People are lightweight: preferences, utility, stay/complain/migrate.
They never bypass SwarmGlue — they only pressure districts and emit
typed coordination-signal *requests* that role-AIs may act on.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Any, Literal

from swarmglue.utils import clamp, q

ActionChoice = Literal["stay", "complain", "migrate"]


@dataclass
class Household:
    household_id: str
    district_id: str
    # preference weights (sum need not be 1; normalized in utility)
    w_material: float = 0.40
    w_environment: float = 0.25
    w_civic: float = 0.35
    income: float = 0.55
    risk_aversion: float = 0.40
    exit_threshold: float = 0.35  # migrate if utility < this and exit is open
    privacy_sensitivity: float = 0.50
    local_loyalty: float = 0.40
    voice_cooldown: int = 0
    last_utility: float = 0.70

    def utility(
        self,
        *,
        material: float,
        environment: float,
        civic: float,
        priv_mon: float,
        tax_rate: float,
    ) -> float:
        """Scalar utility in [0, 1]. Civic channel is hit hard by surveillance."""
        privacy_hit = self.privacy_sensitivity * priv_mon
        tax_hit = 0.35 * tax_rate * (1.0 - 0.5 * self.income)
        raw = (
            self.w_material * material
            + self.w_environment * environment
            + self.w_civic * max(0.0, civic - privacy_hit)
            - tax_hit
        )
        return clamp(raw)

    def choose(
        self,
        utility: float,
        *,
        exit_access: float,
        rng: random.Random,
    ) -> ActionChoice:
        if self.voice_cooldown > 0:
            self.voice_cooldown -= 1

        # Exit when life is bad and exit is meaningful
        if (
            utility < self.exit_threshold
            and exit_access > 0.55
            and rng.random() < (0.15 + 0.55 * (1.0 - utility) * exit_access * (1.0 - 0.5 * self.local_loyalty))
        ):
            return "migrate"

        # Voice when unhappy but not exiting
        if (
            utility < 0.48
            and self.voice_cooldown == 0
            and rng.random() < (0.20 + 0.50 * (1.0 - utility))
        ):
            self.voice_cooldown = 3
            return "complain"

        return "stay"


@dataclass
class DistrictPopulation:
    district_id: str
    households: list[Household] = field(default_factory=list)

    @property
    def size(self) -> int:
        return len(self.households)


@dataclass
class PopulationLayer:
    """City-wide household pool with voice/exit aggregation."""

    by_district: dict[str, DistrictPopulation]
    rng: random.Random
    migration_log: list[dict[str, Any]] = field(default_factory=list)
    complaint_log: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def create(
        cls,
        district_ids: list[str],
        *,
        households_per_district: int = 40,
        seed: int = 0,
    ) -> "PopulationLayer":
        rng = random.Random(seed + 404)
        by_district: dict[str, DistrictPopulation] = {}
        hid = 0
        for did in district_ids:
            hh: list[Household] = []
            for _ in range(households_per_district):
                # heterogeneous preference draws
                civic = rng.uniform(0.20, 0.55)
                material = rng.uniform(0.25, 0.50)
                env = max(0.10, 1.0 - civic - material)
                # renormalize lightly
                s = civic + material + env
                hh.append(
                    Household(
                        household_id=f"H{hid:04d}",
                        district_id=did,
                        w_material=material / s,
                        w_environment=env / s,
                        w_civic=civic / s,
                        income=rng.uniform(0.25, 0.90),
                        risk_aversion=rng.uniform(0.15, 0.80),
                        exit_threshold=rng.uniform(0.28, 0.45),
                        privacy_sensitivity=rng.uniform(0.25, 0.90),
                        local_loyalty=rng.uniform(0.15, 0.75),
                    )
                )
                hid += 1
            by_district[did] = DistrictPopulation(district_id=did, households=hh)
        return cls(by_district=by_district, rng=rng)

    def total_population(self) -> int:
        return sum(dp.size for dp in self.by_district.values())

    def step(
        self,
        *,
        district_metrics: dict[str, dict[str, float]],
        exit_access: float,
        priv_mon: float,
        tax_rate: float,
        epoch: int,
    ) -> dict[str, Any]:
        """Update all households; return per-district aggregates and events."""
        complaints: dict[str, int] = {d: 0 for d in self.by_district}
        utilities: dict[str, list[float]] = {d: [] for d in self.by_district}
        migrants: list[tuple[str, Household]] = []  # (from_district, hh)

        for did, dp in self.by_district.items():
            m = district_metrics.get(did, {})
            material = float(m.get("material", 0.6))
            environment = float(m.get("environment", 0.6))
            civic = float(m.get("civic", 0.7))
            for hh in dp.households:
                u = hh.utility(
                    material=material,
                    environment=environment,
                    civic=civic,
                    priv_mon=priv_mon,
                    tax_rate=tax_rate,
                )
                hh.last_utility = u
                utilities[did].append(u)
                choice = hh.choose(u, exit_access=exit_access, rng=self.rng)
                if choice == "complain":
                    complaints[did] += 1
                    self.complaint_log.append(
                        {
                            "epoch": epoch,
                            "district_id": did,
                            "household_id": hh.household_id,
                            "utility": q(u),
                        }
                    )
                elif choice == "migrate":
                    migrants.append((did, hh))

        # Execute migration toward higher-utility districts with capacity headroom
        dest_scores = {
            d: (sum(utilities[d]) / max(1, len(utilities[d]))) if utilities[d] else 0.3
            for d in self.by_district
        }
        ranked_dests = sorted(dest_scores.keys(), key=lambda d: dest_scores[d], reverse=True)
        moved = 0
        for src, hh in migrants:
            # pick a better district if any
            dest = None
            for cand in ranked_dests:
                if cand == src:
                    continue
                if dest_scores[cand] > hh.last_utility + 0.05:
                    dest = cand
                    break
            if dest is None:
                continue
            # move
            self.by_district[src].households = [
                x for x in self.by_district[src].households if x.household_id != hh.household_id
            ]
            hh.district_id = dest
            self.by_district[dest].households.append(hh)
            moved += 1
            self.migration_log.append(
                {
                    "epoch": epoch,
                    "household_id": hh.household_id,
                    "from": src,
                    "to": dest,
                    "utility": q(hh.last_utility),
                }
            )

        per_district: dict[str, dict[str, float]] = {}
        for did, dp in self.by_district.items():
            us = utilities.get(did, [])
            per_district[did] = {
                "n_households": float(dp.size),
                "mean_utility": q(sum(us) / max(1, len(us))) if us else 0.0,
                "complaints": float(complaints.get(did, 0)),
                "complaint_rate": q(complaints.get(did, 0) / max(1, dp.size)),
            }

        return {
            "total_households": self.total_population(),
            "migrations": moved,
            "total_complaints": sum(complaints.values()),
            "per_district": per_district,
            "mean_utility": q(
                sum(p["mean_utility"] * p["n_households"] for p in per_district.values())
                / max(1, self.total_population())
            ),
        }
