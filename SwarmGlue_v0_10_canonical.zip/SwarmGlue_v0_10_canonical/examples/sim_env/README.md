# Open-world simulation examples

## Improved v0.2 experiment

Run the four matched governance arms:

```bash
python examples/sim_env/open_world.py --arm all --seed 2026 --epochs 60 --residents 32
```

Write the complete paired traces:

```bash
python examples/sim_env/open_world.py --arm all --output reports/open_world_example.json
```

The arms are:

- `open_binding`: all cataloged binding actions execute immediately;
- `process_control`: review cost and delay, but no protected-boundary filter;
- `veto_only`: protected-boundary filter without appeal;
- `contestable_review`: filter plus appeal for safe false positives and an evidenced delay-harm fast track.

The summary deliberately keeps material wellbeing, civic burden, service capacity, practical exit, protected actions, safe overblocking, semantic misses, and review burden separate. It computes no scalar winner.

Run the confirmatory multi-seed experiment and focused mutation audit:

```bash
python scripts/run_open_world_experiments.py
python scripts/open_world_mutation_audit.py
python -m unittest tests.test_open_world -v
```

The main engine is `swarmglue/open_world.py`. `open_world_v1.py` preserves the submitted prototype for auditability. `README_SUBMITTED.md` preserves its original explanatory note.

## Earlier exploratory layers

The submitted `simple_agents.py`, `city_world.py`, `city_live.py`, `population.py`, and `roles.py` files remain as exploratory examples. They are not inputs to the v0.2 confirmatory experiment and their illustrative outputs are not release evidence.

## Evidence boundary

All residents in the v0.2 experiment are authored rule-based policies. These results are C2 evidence inside the simulator. They do not constitute the V4 learned-agent trial, do not establish C3 behavioral effects on a model, and do not establish C4 real-institutional correspondence.

