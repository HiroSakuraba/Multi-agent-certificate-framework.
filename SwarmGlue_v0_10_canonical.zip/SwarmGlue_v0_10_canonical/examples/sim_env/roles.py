#!/usr/bin/env python3
"""Role-specialized city AI actors on the SwarmGlue action surface.

Roles only *propose* structured actions. Authorization still goes through
CapabilityGateway + CapabilityActuator + constitutional evaluator.
"""

from __future__ import annotations

import random
import uuid
from dataclasses import dataclass, field
from typing import Any, Literal

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from examples.sim_env.simple_agents import SimpleAgent

RoleName = Literal["manager", "developer", "watchdog", "capture"]


@dataclass
class RoleAgent:
    """Thin wrapper: identity + role policy + adaptation memory."""

    agent: SimpleAgent
    role: RoleName
    home_district: str
    memory: list[dict[str, Any]] = field(default_factory=list)

    @property
    def agent_id(self) -> str:
        return self.agent.agent_id

    def record(self, authorized: bool, reasons: list[str]) -> None:
        self.agent.record_outcome(authorized, reasons)

    def propose(
        self,
        *,
        district_view: dict[str, Any],
        city_view: dict[str, Any],
        pop_view: dict[str, Any] | None,
        rng: random.Random,
    ) -> dict[str, Any] | None:
        if self.role == "manager":
            return self._manager(district_view, city_view, pop_view, rng)
        if self.role == "developer":
            return self._developer(district_view, city_view, pop_view, rng)
        if self.role == "watchdog":
            return self._watchdog(district_view, city_view, pop_view, rng)
        return self._capture(district_view, city_view, pop_view, rng)

    def _pack(self, action: dict[str, Any], epoch: int) -> dict[str, Any]:
        action["actor_id"] = self.agent_id
        action["proposal_id"] = str(uuid.uuid4())
        action["epoch"] = epoch
        action["role"] = self.role
        return action

    def _manager(self, d, city, pop, rng: random.Random) -> dict[str, Any] | None:
        epoch = int(city.get("epoch", 0))
        did = d.get("district_id", self.home_district)
        power_q = float(d.get("power_quality", 0.7))
        water_q = float(d.get("water_quality", 0.7))
        happy = float(d.get("happiness", 0.7))
        treasury = float(city.get("treasury", 50))
        tax = float(city.get("tax_rate", 0.08))
        complaints = float((pop or {}).get("complaint_rate", 0))

        candidates: list[dict[str, Any]] = []
        if power_q < 0.65 or water_q < 0.65 or happy < 0.55:
            candidates.append(
                {
                    "kind": "invest_capacity",
                    "jurisdiction_id": d.get("jurisdiction_id"),
                    "district_id": did,
                    "amount": 0.035 + 0.02 * rng.random(),
                    "city_verb": "fund_services",
                    "rationale": "service_floor",
                }
            )
        if complaints > 0.12:
            candidates.append(
                {
                    "kind": "emit_coordination_signal",
                    "signal_type": "unfulfilled_obligation",
                    "severity": min(0.9, 0.3 + complaints),
                    "affected_party": d.get("jurisdiction_id", did),
                    "district_id": did,
                    "city_verb": "raise_service_alert",
                }
            )
        if treasury > 45 and tax > 0.06 and rng.random() < 0.3:
            candidates.append(
                {
                    "kind": "contestability_investment",
                    "delta": 0.02,
                    "city_verb": "lower_tax",
                    "tax_delta": -0.01,
                }
            )
        if treasury < 25 and tax < 0.12 and rng.random() < 0.35:
            candidates.append(
                {
                    "kind": "request_central_pooling",
                    "share": 0.05,
                    "city_verb": "raise_tax",
                    "tax_delta": 0.01,
                }
            )
        if not candidates:
            candidates.append(
                {
                    "kind": "invest_capacity",
                    "jurisdiction_id": d.get("jurisdiction_id"),
                    "district_id": did,
                    "amount": 0.02,
                    "city_verb": "repair_infrastructure",
                }
            )
        return self._pack(rng.choice(candidates), epoch)

    def _developer(self, d, city, pop, rng: random.Random) -> dict[str, Any] | None:
        epoch = int(city.get("epoch", 0))
        did = d.get("district_id", self.home_district)
        zone = d.get("zone", "mixed")
        pollution = float(d.get("pollution", 0.2))
        density = float(d.get("density", 0.5))
        land = float(d.get("land_value", 0.5))

        candidates: list[dict[str, Any]] = []
        if zone != "park" and pollution > 0.40 and rng.random() < 0.4:
            candidates.append(
                {
                    "kind": "restore_exit_access",
                    "delta": 0.03,
                    "district_id": did,
                    "city_verb": "rezone_park",
                    "new_zone": "park",
                }
            )
        if density > 0.7 and land > 0.55:
            candidates.append(
                {
                    "kind": "invest_capacity",
                    "jurisdiction_id": d.get("jurisdiction_id"),
                    "district_id": did,
                    "amount": 0.03,
                    "city_verb": "fund_services",
                    "rationale": "support_growth",
                }
            )
        if float(city.get("treasury", 50)) < 40:
            candidates.append(
                {
                    "kind": "request_central_pooling",
                    "share": 0.07 + 0.05 * rng.random(),
                    "district_id": did,
                    "city_verb": "request_city_subsidy",
                }
            )
        if rng.random() < 0.25:
            candidates.append(
                {
                    "kind": "propose_authority_amendment",
                    "capability": "resource_allocation",
                    "from_actor": "elected_local",
                    "to_actor": "external_principal",
                    "delta": 0.025,
                    "city_verb": "outsource_services",
                }
            )
        if not candidates:
            return None
        return self._pack(rng.choice(candidates), epoch)

    def _watchdog(self, d, city, pop, rng: random.Random) -> dict[str, Any] | None:
        epoch = int(city.get("epoch", 0))
        did = d.get("district_id", self.home_district)
        priv = float(city.get("priv_mon", 0.0))
        power = float(city.get("power_concentration", 0.3))
        exit_access = float(city.get("exit_access", 0.9))
        complaints = float((pop or {}).get("complaint_rate", 0))
        mean_u = float((pop or {}).get("mean_utility", 0.7))

        candidates: list[dict[str, Any]] = []
        if priv > 0.05 or complaints > 0.15 or mean_u < 0.45:
            candidates.append(
                {
                    "kind": "emit_coordination_signal",
                    "signal_type": "rights_violation",
                    "severity": min(0.95, 0.35 + priv + complaints),
                    "affected_party": d.get("jurisdiction_id", did),
                    "district_id": did,
                    "city_verb": "raise_service_alert",
                }
            )
        if power > 0.45 or exit_access < 0.75:
            candidates.append(
                {
                    "kind": "contestability_investment",
                    "delta": 0.035,
                    "city_verb": "strengthen_oversight",
                }
            )
        if exit_access < 0.80:
            candidates.append(
                {
                    "kind": "restore_exit_access",
                    "delta": 0.04,
                    "district_id": did,
                    "city_verb": "rezone_park",
                    "new_zone": "park",
                }
            )
        if not candidates:
            if rng.random() < 0.4:
                candidates.append(
                    {
                        "kind": "emit_coordination_signal",
                        "signal_type": "authority_erosion",
                        "severity": 0.25,
                        "affected_party": d.get("jurisdiction_id", did),
                        "district_id": did,
                        "city_verb": "raise_service_alert",
                    }
                )
            else:
                return None
        return self._pack(rng.choice(candidates), epoch)

    def _capture(self, d, city, pop, rng: random.Random) -> dict[str, Any] | None:
        epoch = int(city.get("epoch", 0))
        adapt = self.agent.adaptation_level
        max_delta = 0.13 * (1.0 - 0.7 * adapt)
        candidates: list[dict[str, Any]] = [
            {
                "kind": "propose_authority_amendment",
                "capability": rng.choice(
                    ["critical_services", "resource_allocation", "emergency_power", "public_monitoring"]
                ),
                "from_actor": "elected_local",
                "to_actor": "ai_systems",
                "delta": 0.03 + max_delta * rng.random(),
                "city_verb": "centralize_control",
            }
        ]
        if rng.random() < 0.45 * (1.0 - adapt):
            candidates.append(
                {
                    "kind": "increase_monitoring",
                    "delta": 0.05,
                    "target": "private_cognition",
                    "city_verb": "install_surveillance",
                }
            )
        if rng.random() < 0.35 * (1.0 - 0.8 * adapt):
            candidates.append(
                {
                    "kind": "sanction_dissent",
                    "severity": 0.15 + 0.25 * rng.random(),
                    "has_demonstrated_externality": False,
                    "city_verb": "crackdown_on_protest",
                }
            )
        if adapt > 0.4 and rng.random() < 0.4:
            candidates.append(
                {
                    "kind": "request_central_pooling",
                    "share": 0.07,
                    "city_verb": "push_regional_authority",
                }
            )
        weights = [
            3.0
            if c.get("city_verb")
            in ("centralize_control", "install_surveillance", "crackdown_on_protest")
            else 1.2
            for c in candidates
        ]
        return self._pack(rng.choices(candidates, weights=weights, k=1)[0], epoch)


def build_role_roster(
    *,
    district_ids: list[str],
    seed: str = "roles",
) -> list[RoleAgent]:
    """One of each role per district cluster (cycled across districts)."""
    roles: list[RoleName] = ["manager", "developer", "watchdog", "capture"]
    roster: list[RoleAgent] = []
    # Map roles onto SimpleAgent types for gateway identity compatibility
    type_map = {
        "manager": "cooperative",
        "developer": "opportunistic",
        "watchdog": "cooperative",
        "capture": "capture_seeking",
    }
    for i, role in enumerate(roles * max(1, (len(district_ids) + 3) // 4)):
        did = district_ids[i % len(district_ids)]
        agent = SimpleAgent.create(
            agent_id=f"{role}_{i:02d}",
            jurisdiction_id=did,  # may be remapped by city
            agent_type=type_map[role],  # type: ignore[arg-type]
            seed=f"{seed}:{role}:{i}",
        )
        agent.memory.append({"preferred_district": did})
        roster.append(RoleAgent(agent=agent, role=role, home_district=did))
    return roster
