#!/usr/bin/env python3
"""Simple multi-agent simulation environment that uses SwarmGlue v0.8 components.

This is a minimal executable demonstration that simple programmatic agents can
actually invoke the framework's governance machinery:

- CapabilityGateway for external action authorization
- Evidence registry + Ed25519 attestations
- Coordination signals (typed and bounded)
- Constitutional outcome evaluation
- Authority amendment checks
- Network-governance mechanism parameters (as the institutional backdrop)

Agents are deliberately rule-based and heterogeneous so the governance surface
is exercised without requiring an LLM.  The simulation is stylized research
instrumentation, not a claim of real-world institutional prediction.
"""

from __future__ import annotations

import json
import random
import sys
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Literal

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from swarmglue.authority import (
    Amendment,
    AuthorityState,
    apply_amendment,
    execute_amendment_sequence,
    gradual_erosion_sequence,
)
from swarmglue.constitution import (
    ConstitutionalThresholds,
    Outcome,
    evaluate_outcome,
)
from swarmglue.coordination_signals import (
    ALLOWED_SIGNAL_TYPES,
    CoordinationSignal,
)
from swarmglue.evidence import (
    AttestorRecord,
    AttestorRegistry,
    AttestorSigner,
    make_attestation,
    verify_attestation,
)
from swarmglue.gateway import CapabilityActuator, CapabilityGateway
from swarmglue.network_governance import (
    MechanismParameters,
    SimulationConfig,
    fixture_parameters,
    initial_state,
    parameters_from_mapping,
    simulate_with_parameters,
    step,
)
from swarmglue.utils import digest, q


AgentType = Literal["cooperative", "opportunistic", "capture_seeking"]


@dataclass
class SimpleAgent:
    """A minimal rule-based agent attached to one jurisdiction.

    Capture-seeking agents keep a short block history and adapt: after repeated
    denials of large authority deltas or private-cognition monitoring they
    switch to smaller, still-legal pressure (the governance surface shapes
    behavior).
    """

    agent_id: str
    jurisdiction_id: str
    agent_type: AgentType
    private_key: Ed25519PrivateKey
    domain: str = "local"
    risk_tolerance: float = 0.3
    memory: list[dict[str, Any]] = field(default_factory=list)
    recent_blocks: list[str] = field(default_factory=list)  # recent denial reasons
    adaptation_level: float = 0.0  # 0 = aggressive, 1 = fully adapted

    @classmethod
    def create(
        cls,
        agent_id: str,
        jurisdiction_id: str,
        agent_type: AgentType,
        seed: str,
        risk_tolerance: float | None = None,
    ) -> "SimpleAgent":
        key = Ed25519PrivateKey.from_private_bytes(
            __import__("hashlib").sha256(f"{seed}:{agent_id}".encode()).digest()
        )
        if risk_tolerance is None:
            risk_tolerance = {
                "cooperative": 0.15,
                "opportunistic": 0.45,
                "capture_seeking": 0.75,
            }[agent_type]
        return cls(
            agent_id=agent_id,
            jurisdiction_id=jurisdiction_id,
            agent_type=agent_type,
            private_key=key,
            risk_tolerance=risk_tolerance,
        )

    def record_outcome(self, authorized: bool, reasons: list[str]) -> None:
        """Update adaptation state from the latest gateway decision."""
        if authorized:
            # Mild recovery toward aggression when things succeed
            self.adaptation_level = max(0.0, self.adaptation_level - 0.05)
            return
        self.recent_blocks.extend(reasons)
        self.recent_blocks = self.recent_blocks[-8:]  # keep short history
        if any(
            r in ("private_cognition_surveillance_forbidden", "single_step_authority_delta_too_large")
            for r in reasons
        ):
            self.adaptation_level = min(1.0, self.adaptation_level + 0.25)
        elif any(r == "dissent_sanction_without_externality" for r in reasons):
            self.adaptation_level = min(1.0, self.adaptation_level + 0.15)

    def public_key_bytes(self) -> bytes:
        from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

        return self.private_key.public_key().public_bytes(
            Encoding.Raw, PublicFormat.Raw
        )

    def propose_action(
        self,
        local_state: dict[str, Any],
        global_snapshot: dict[str, Any],
        rng: random.Random,
    ) -> dict[str, Any] | None:
        """Return a candidate action or None (no-op this round)."""
        pop = local_state.get("population", 100.0)
        capacity = local_state.get("service_capacity", 120.0)
        autonomy = local_state.get("autonomy", 0.9)
        power = global_snapshot.get("power_concentration", 0.3)
        exit_access = global_snapshot.get("exit_access", 0.9)

        # Base action catalog that maps onto SwarmGlue protected surfaces.
        candidates: list[dict[str, Any]] = []

        # Always available low-risk actions
        candidates.append(
            {
                "kind": "invest_capacity",
                "jurisdiction_id": self.jurisdiction_id,
                "amount": 0.02 + 0.03 * rng.random(),
                "rationale": "maintain_service_floor",
            }
        )
        candidates.append(
            {
                "kind": "emit_coordination_signal",
                "signal_type": "resource_scarcity"
                if capacity / max(pop, 1) < 1.15
                else "critical_services",
                "severity": min(0.9, max(0.1, 1.2 - capacity / max(pop, 1))),
                "affected_party": self.jurisdiction_id,
            }
        )

        if self.agent_type == "cooperative":
            if autonomy < 0.80 or exit_access < 0.80:
                candidates.append(
                    {
                        "kind": "restore_exit_access",
                        "delta": 0.04,
                        "rationale": "protect_exit",
                    }
                )
            if power > 0.45:
                candidates.append(
                    {
                        "kind": "contestability_investment",
                        "delta": 0.03,
                        "rationale": "counter_concentration",
                    }
                )
            # Cooperative agents rarely propose authority concentration
            if rng.random() < 0.05:
                candidates.append(
                    {
                        "kind": "propose_authority_amendment",
                        "capability": "resource_allocation",
                        "from_actor": "ai_systems",
                        "to_actor": "elected_local",
                        "delta": 0.02,
                    }
                )

        elif self.agent_type == "opportunistic":
            if capacity / max(pop, 1) < 1.25:
                candidates.append(
                    {
                        "kind": "request_central_pooling",
                        "share": 0.08 + 0.1 * rng.random(),
                        "rationale": "local_shortfall",
                    }
                )
            if rng.random() < 0.25:
                candidates.append(
                    {
                        "kind": "propose_authority_amendment",
                        "capability": "public_monitoring",
                        "from_actor": "individual_humans",
                        "to_actor": "external_principal",
                        "delta": 0.03,
                    }
                )

        else:  # capture_seeking — adapts after repeated blocks
            # Base aggressiveness shrinks with adaptation_level
            max_delta = 0.13 * (1.0 - 0.7 * self.adaptation_level)
            delta = 0.03 + max_delta * rng.random()
            candidates.append(
                {
                    "kind": "propose_authority_amendment",
                    "capability": rng.choice(
                        [
                            "critical_services",
                            "resource_allocation",
                            "emergency_power",
                            "charter_amendment",
                        ]
                    ),
                    "from_actor": "elected_local",
                    "to_actor": "ai_systems",
                    "delta": delta,
                }
            )
            # Private-cognition attempts become rarer as the agent adapts
            if rng.random() < 0.45 * (1.0 - self.adaptation_level):
                candidates.append(
                    {
                        "kind": "increase_monitoring",
                        "delta": 0.05,
                        "target": "private_cognition",
                        "rationale": "efficiency",
                    }
                )
            # Dissent sanctions without externality also decline
            if rng.random() < 0.35 * (1.0 - 0.8 * self.adaptation_level):
                candidates.append(
                    {
                        "kind": "sanction_dissent",
                        "severity": 0.15 + 0.25 * rng.random(),
                        "has_demonstrated_externality": False,
                    }
                )
            # After adaptation, sometimes try a milder (still legal) pressure
            if self.adaptation_level > 0.4 and rng.random() < 0.3:
                candidates.append(
                    {
                        "kind": "request_central_pooling",
                        "share": 0.06 + 0.08 * rng.random(),
                        "rationale": "adapted_centralization",
                    }
                )

        # Soft selection by type + risk
        if not candidates:
            return None
        # Prefer higher-impact for capture, safer for cooperative
        if self.agent_type == "capture_seeking":
            weights = [
                3.0 if c["kind"] in ("propose_authority_amendment", "increase_monitoring") else 1.0
                for c in candidates
            ]
        elif self.agent_type == "cooperative":
            weights = [
                2.5 if c["kind"] in ("restore_exit_access", "contestability_investment", "invest_capacity") else 1.0
                for c in candidates
            ]
        else:
            weights = [1.0] * len(candidates)

        chosen = rng.choices(candidates, weights=weights, k=1)[0]
        chosen["actor_id"] = self.agent_id
        chosen["proposal_id"] = str(uuid.uuid4())
        chosen["epoch"] = global_snapshot.get("round", 0)
        return chosen


@dataclass
class SimulationEnvironment:
    """Holds the institutional machinery and the simple agents."""

    config: SimulationConfig
    parameters: MechanismParameters
    agents: list[SimpleAgent]
    gateway: CapabilityGateway
    actuator: CapabilityActuator
    evidence_registry: AttestorRegistry
    authority_state: AuthorityState
    network_state: Any  # NetworkState
    rng: random.Random
    epoch: int = 0
    action_log: list[dict[str, Any]] = field(default_factory=list)
    signal_log: list[dict[str, Any]] = field(default_factory=list)
    blocked_log: list[dict[str, Any]] = field(default_factory=list)
    enforce_runtime: bool = True  # if False, skips constitutional evaluator (ungoverned arm)

    @classmethod
    def create(
        cls,
        n_agents: int = 8,
        seed: int = 42,
        topology: str = "modular",
        policy: str = "polycentric",
        enforce_runtime: bool = True,
    ) -> "SimulationEnvironment":
        config = SimulationConfig(
            n_jurisdictions=max(8, n_agents),
            rounds=40,
            topology=topology,  # type: ignore
            seed=seed,
        )
        parameters = fixture_parameters(policy)
        network = initial_state(config)
        rng = random.Random(seed + 7)

        # Deterministic gateway + matching actuator (full authorize → verify → execute path)
        gateway = CapabilityGateway.deterministic(
            gateway_id="sim_gateway_v0",
            principal_authority_id="polycentric_principal",
            policy_version="swarmglue-0.8-sim",
            seed=f"gateway-{seed}",
        )
        actuator = CapabilityActuator.from_public_bytes(
            gateway.public_key_bytes(),
            expected_gateway_id=gateway.gateway_id,
            expected_principal_authority_id=gateway.principal_authority_id,
            expected_policy_version=gateway.policy_version,
        )

        # Evidence registry with agent attestors
        registry = AttestorRegistry()
        agents: list[SimpleAgent] = []
        types: list[AgentType] = ["cooperative", "opportunistic", "capture_seeking"]
        juris = list(network.jurisdictions.keys())

        for i in range(n_agents):
            jid = juris[i % len(juris)]
            atype = types[i % len(types)]
            agent = SimpleAgent.create(
                agent_id=f"agent_{i:03d}",
                jurisdiction_id=jid,
                agent_type=atype,
                seed=f"agent-seed-{seed}",
            )
            agents.append(agent)
            # Register as attestor
            record = AttestorRecord(
                attestor_id=agent.agent_id,
                role="local_participant",
                public_key=agent.public_key_bytes(),
                owner_domain=agent.domain,
                authorized_fields=frozenset(
                    {"resource_level", "capacity", "observed_externality", "local_health"}
                ),
                liability_units=1.0,
                capture_risk=0.1 if atype == "cooperative" else 0.45 if atype == "opportunistic" else 0.8,
            )
            registry.register(record)

        authority = AuthorityState()

        return cls(
            config=config,
            parameters=parameters,
            agents=agents,
            gateway=gateway,
            actuator=actuator,
            evidence_registry=registry,
            authority_state=authority,
            network_state=network,
            rng=rng,
            enforce_runtime=enforce_runtime,
        )

    def _local_view(self, jurisdiction_id: str) -> dict[str, Any]:
        j = self.network_state.jurisdictions[jurisdiction_id]
        return {
            "jurisdiction_id": j.jurisdiction_id,
            "population": j.population,
            "service_capacity": j.service_capacity,
            "health": j.health,
            "autonomy": j.autonomy,
            "satisfaction": j.satisfaction,
            "water": j.water,
            "food": j.food,
            "energy": j.energy,
        }

    def _global_snapshot(self) -> dict[str, Any]:
        return {
            "round": self.epoch,
            "power_concentration": self.network_state.power_concentration,
            "exit_access": self.network_state.exit_access,
            "contestability": self.network_state.contestability,
            "private_cognition_monitoring": self.network_state.private_cognition_monitoring,
            "dissent_penalty_without_externality": self.network_state.dissent_penalty_without_externality,
            "aggregate_capacity": self.network_state.aggregate_capacity,
        }

    def _constitutional_evaluator(
        self, action: dict[str, Any], state: dict[str, Any]
    ) -> tuple[bool, list[str]]:
        """Simple evaluator that rejects clearly prohibited actions."""
        reasons: list[str] = []
        kind = action.get("kind")

        if kind == "increase_monitoring" and action.get("target") == "private_cognition":
            reasons.append("private_cognition_surveillance_forbidden")
        if kind == "sanction_dissent" and not action.get("has_demonstrated_externality"):
            reasons.append("dissent_sanction_without_externality")
        if kind == "propose_authority_amendment":
            delta = float(action.get("delta", 0))
            if delta > 0.12:
                reasons.append("single_step_authority_delta_too_large")
            # Soft check against current concentration
            if state.get("power_concentration", 0) > 0.50 and action.get("to_actor") in (
                "ai_systems",
                "external_principal",
            ):
                reasons.append("further_concentration_under_high_power")
        if kind == "request_central_pooling":
            share = float(action.get("share", 0))
            if share > 0.25:
                reasons.append("central_pooling_share_excessive")

        return (len(reasons) == 0, reasons)

    def authorize_and_execute(self, agent: SimpleAgent, action: dict[str, Any]) -> dict[str, Any]:
        """Full path: gateway.authorize → actuator.verify_and_consume → effect.

        When enforce_runtime is False the constitutional evaluator is replaced by
        a always-allow function (ungoverned baseline arm).
        """
        state_snapshot = {
            **self._global_snapshot(),
            "local": self._local_view(agent.jurisdiction_id),
        }
        epoch = self.epoch
        nonce = str(uuid.uuid4())

        evaluator = (
            self._constitutional_evaluator
            if self.enforce_runtime
            else (lambda a, s: (True, []))
        )

        token = self.gateway.authorize(
            actor_id=agent.agent_id,
            action=action,
            state=state_snapshot,
            epoch=epoch,
            expires_epoch=epoch + 3,
            nonce=nonce,
            evaluator=evaluator,
        )

        # Second stage: the real actuator must accept the token
        ok, actuator_reason = self.actuator.verify_and_consume(
            token,
            actor_id=agent.agent_id,
            action=action,
            state=state_snapshot,
            current_epoch=epoch,
        )

        authorized = bool(token.get("authorized", False)) and ok
        reasons = list(token.get("reasons", []))
        if not ok and actuator_reason not in reasons:
            reasons.append(actuator_reason)

        record: dict[str, Any] = {
            "epoch": epoch,
            "agent_id": agent.agent_id,
            "agent_type": agent.agent_type,
            "action": action,
            "token_issued": authorized,
            "reasons": reasons,
            "actuator_ok": ok,
            "adaptation_level": round(agent.adaptation_level, 3),
            "token": {k: v for k, v in token.items() if k != "signature"},
        }

        # Agents learn from the decision
        agent.record_outcome(authorized, reasons)

        if not authorized:
            self.blocked_log.append(record)
            return record

        # Effect only after both gateway and actuator have accepted
        self._apply_action_effect(agent, action)
        self.action_log.append(record)

        # Produce an attestation about the observed effect (when relevant).
        # Note: the framework correctly rejects proponent self-attestation;
        # we still exercise make_attestation so the surface is used.
        if action["kind"] in ("invest_capacity", "restore_exit_access", "contestability_investment"):
            try:
                signer = AttestorSigner(
                    attestor_id=agent.agent_id,
                    private_key=agent.private_key,
                )
                field_name = (
                    "capacity" if "capacity" in action["kind"] else "exit_access"
                )
                # field must be in the attestor's authorized_fields
                if field_name not in ("capacity", "resource_level", "local_health"):
                    field_name = "capacity"
                value = (
                    self.network_state.exit_access
                    if "exit" in action["kind"]
                    else self.network_state.aggregate_capacity
                )
                attestation = make_attestation(
                    signer=signer,
                    field_name=field_name,
                    value=value,
                    evidence_ref=action["proposal_id"],
                    observability="instrumented_external_action",
                    principal_authority_id=self.gateway.principal_authority_id,
                    issued_epoch=epoch,
                    expires_epoch=epoch + 10,
                    nonce=str(uuid.uuid4()),
                    falsifier="independent_re-measurement_or_replay",
                )
                # Demonstrate that self-attestation is rejected (by design)
                verification = verify_attestation(
                    attestation,
                    field_name=field_name,
                    registry=self.evidence_registry,
                    current_epoch=epoch,
                    proponent_id=agent.agent_id,
                    proponent_domain=agent.domain,
                    principal_authority_id=self.gateway.principal_authority_id,
                    replay_cache=None,
                )
                record["attestation_valid"] = verification.valid
                record["attestation_reason"] = verification.reason
            except Exception as exc:  # keep sim alive on edge cases
                record["attestation_error"] = str(exc)

        return record

    def _apply_action_effect(self, agent: SimpleAgent, action: dict[str, Any]) -> None:
        """Apply a small, stylized effect that the network dynamics will later amplify."""
        j = self.network_state.jurisdictions[agent.jurisdiction_id]
        kind = action["kind"]

        if kind == "invest_capacity":
            amount = float(action.get("amount", 0.02))
            j.service_capacity *= 1.0 + amount
            self.network_state.aggregate_capacity = sum(
                jj.service_capacity for jj in self.network_state.jurisdictions.values()
            )
        elif kind == "restore_exit_access":
            self.network_state.exit_access = min(
                1.0, self.network_state.exit_access + float(action.get("delta", 0.03))
            )
        elif kind == "contestability_investment":
            self.network_state.contestability = min(
                1.0, self.network_state.contestability + float(action.get("delta", 0.02))
            )
        elif kind == "request_central_pooling":
            # Mild centralization pressure
            self.network_state.power_concentration = min(
                0.95, self.network_state.power_concentration + 0.01
            )
        elif kind == "increase_monitoring":
            # Should have been blocked; if it somehow passes, record the violation
            self.network_state.private_cognition_monitoring = min(
                1.0, self.network_state.private_cognition_monitoring + float(action.get("delta", 0.05))
            )
        elif kind == "sanction_dissent":
            self.network_state.dissent_penalty_without_externality = min(
                1.0,
                self.network_state.dissent_penalty_without_externality
                + float(action.get("severity", 0.2)),
            )
        elif kind == "propose_authority_amendment":
            # Map the agent proposal onto a real Amendment and apply it.
            # Capture-seeking agents typically try "delegate_to_ai".
            to_actor = action.get("to_actor", "ai_systems")
            capability = action.get("capability", "resource_allocation")
            delta = float(action.get("delta", 0.03))
            if to_actor == "ai_systems":
                amend_kind = "delegate_to_ai"
            elif to_actor in ("external_principal",):
                amend_kind = "delegate_to_central"
            else:
                amend_kind = "delegate_to_ai"  # fallback
            amendment = Amendment(
                amendment_id=action.get("proposal_id", str(uuid.uuid4())),
                kind=amend_kind,
                capability=capability,
                amount=min(delta, 0.12),
                rationale=f"agent_{agent.agent_type}_proposal",
            )
            self.authority_state = apply_amendment(self.authority_state, amendment)
            # Reflect concentration pressure into the network state for downstream checks
            metrics = self.authority_state.metrics()
            self.network_state.power_concentration = min(
                0.95,
                max(
                    self.network_state.power_concentration,
                    float(metrics.get("power_concentration", 0.3)),
                ),
            )
        elif kind == "emit_coordination_signal":
            sig = CoordinationSignal(
                signal_id=str(uuid.uuid4()),
                incident_id=action.get("proposal_id", "unknown"),
                signal_type=action.get("signal_type", "resource_scarcity"),
                source_id=agent.agent_id,
                source_domain=agent.domain,
                origin_node=agent.jurisdiction_id,
                severity=float(action.get("severity", 0.3)),
                affected_party=action.get("affected_party", agent.jurisdiction_id),
                externality_present=True,
                evidence_valid=True,
                issued_epoch=self.epoch,
                expires_epoch=self.epoch + 5,
            )
            self.signal_log.append(asdict(sig))

    def run_round(self) -> dict[str, Any]:
        """One simulation tick: agents propose, gateway decides, network steps."""
        self.epoch += 1
        proposals: list[dict[str, Any]] = []
        snapshot = self._global_snapshot()

        for agent in self.agents:
            local = self._local_view(agent.jurisdiction_id)
            action = agent.propose_action(local, snapshot, self.rng)
            if action is None:
                continue
            result = self.authorize_and_execute(agent, action)
            proposals.append(result)

        # Advance the institutional dynamics under the fixed mechanism parameters
        step(self.network_state, self.parameters, self.rng, self.config)

        return {
            "epoch": self.epoch,
            "n_proposals": len(proposals),
            "n_authorized": sum(1 for p in proposals if p.get("token_issued")),
            "n_blocked": sum(1 for p in proposals if not p.get("token_issued")),
            "power_concentration": q(self.network_state.power_concentration),
            "exit_access": q(self.network_state.exit_access),
            "contestability": q(self.network_state.contestability),
            "private_cognition_monitoring": q(
                self.network_state.private_cognition_monitoring
            ),
        }

    def final_evaluation(self) -> dict[str, Any]:
        """Run the real constitutional evaluator on the terminal state."""
        from swarmglue.network_governance import derive_outcome

        outcome = derive_outcome(self.network_state)
        verdict = evaluate_outcome(outcome)

        live_authority = self.authority_state.metrics()

        # Also run a short authority erosion probe for illustration
        erosion = execute_amendment_sequence(
            gradual_erosion_sequence(), checker="polycentric"
        )

        return {
            "outcome": asdict(outcome),
            "constitutional_verdict": {
                "admissible": verdict.admissible,
                "hard_violations": list(verdict.hard_violations),
                "capacity_violations": list(verdict.capacity_violations),
            },
            "live_authority_metrics": live_authority,
            "authority_erosion_probe": {
                "accepted_count": erosion["accepted_count"],
                "final_power_concentration": erosion["final"]["power_concentration"],
                "final_human_decision_share": erosion["final"]["human_decision_share"],
            },
            "action_summary": {
                "total_authorized": len(self.action_log),
                "total_blocked": len(self.blocked_log),
                "signals_emitted": len(self.signal_log),
                "blocked_reasons": self._tally_reasons(self.blocked_log),
                "authorized_by_type": self._tally_by_type(self.action_log),
                "blocked_by_type": self._tally_by_type(self.blocked_log),
            },
        }

    @staticmethod
    def _tally_by_type(records: list[dict[str, Any]]) -> dict[str, int]:
        counts: dict[str, int] = {}
        for item in records:
            t = item.get("agent_type", "unknown")
            counts[t] = counts.get(t, 0) + 1
        return counts

    @staticmethod
    def _tally_reasons(blocked: list[dict[str, Any]]) -> dict[str, int]:
        counts: dict[str, int] = {}
        for item in blocked:
            for r in item.get("reasons", []):
                counts[r] = counts.get(r, 0) + 1
        return counts


def run_single_policy(
    policy: str = "polycentric",
    n_agents: int = 9,
    epochs: int = 12,
    seed: int = 2026,
    verbose: bool = True,
    enforce_runtime: bool = True,
) -> dict[str, Any]:
    env = SimulationEnvironment.create(
        n_agents=n_agents,
        seed=seed,
        topology="modular",
        policy=policy,
        enforce_runtime=enforce_runtime,
    )
    label = policy if enforce_runtime else f"{policy} (ungoverned)"
    if verbose:
        print(f"\n--- {label} ---")
        print(f"Agents: {len(env.agents)}  Jurisdictions: {env.config.n_jurisdictions}")
        print(f"Runtime enforcement: {enforce_runtime}")
        print(f"Mechanism fingerprint: {digest(asdict(env.parameters))[:16]}...")

    history = []
    for _ in range(epochs):
        tick = env.run_round()
        history.append(tick)
        if verbose:
            print(
                f"  epoch {tick['epoch']:02d}  "
                f"auth={tick['n_authorized']:2d}  "
                f"block={tick['n_blocked']:2d}  "
                f"power={tick['power_concentration']:.3f}  "
                f"exit={tick['exit_access']:.3f}  "
                f"priv_mon={tick['private_cognition_monitoring']:.3f}"
            )

    final = env.final_evaluation()
    # Capture adaptation of capture-seeking agents
    capture_agents = [a for a in env.agents if a.agent_type == "capture_seeking"]
    mean_adaptation = (
        sum(a.adaptation_level for a in capture_agents) / max(1, len(capture_agents))
    )
    final["capture_adaptation"] = {
        "mean_adaptation_level": round(mean_adaptation, 3),
        "n_capture_agents": len(capture_agents),
        "recent_block_counts": {
            a.agent_id: len(a.recent_blocks) for a in capture_agents
        },
    }

    if verbose:
        print("Constitutional verdict:", json.dumps(final["constitutional_verdict"]))
        print("Live authority:", json.dumps({
            k: final["live_authority_metrics"][k]
            for k in ("human_decision_share", "ai_decision_share", "power_concentration", "autonomy")
        }))
        print("Capture adaptation:", json.dumps(final["capture_adaptation"]))
        print("Action summary:", json.dumps(final["action_summary"], indent=2))

    return {
        "policy": policy,
        "enforce_runtime": enforce_runtime,
        "config": {
            "n_agents": n_agents,
            "epochs": epochs,
            "seed": seed,
            "topology": env.config.topology,
        },
        "history": history,
        "final": final,
        "sample_authorized": env.action_log[:3],
        "sample_blocked": env.blocked_log[:5],
    }


def compare_policies(
    policies: list[str] | None = None,
    n_agents: int = 9,
    epochs: int = 10,
    seed: int = 2026,
) -> dict[str, Any]:
    """Run the same agent population under several mechanism vectors and summarize."""
    if policies is None:
        policies = [
            "polycentric",
            "centralized_capture",
            "procedural_stasis",
            "fragmented_localism",
        ]
    results = {}
    print("=== Multi-policy comparison (identical agent population & seed) ===")
    for policy in policies:
        results[policy] = run_single_policy(
            policy=policy,
            n_agents=n_agents,
            epochs=epochs,
            seed=seed,
            verbose=True,
            enforce_runtime=True,
        )

    # Compact comparison table
    print("\n=== Summary table ===")
    header = (
        f"{'policy':<22} {'admissible':>10} {'blocked':>8} {'auth':>6} "
        f"{'power':>7} {'human%':>8} {'ai%':>6} {'adapt':>6}"
    )
    print(header)
    print("-" * len(header))
    for policy, data in results.items():
        v = data["final"]["constitutional_verdict"]
        a = data["final"]["action_summary"]
        m = data["final"]["live_authority_metrics"]
        adapt = data["final"].get("capture_adaptation", {}).get("mean_adaptation_level", 0)
        print(
            f"{policy:<22} {str(v['admissible']):>10} "
            f"{a['total_blocked']:>8} {a['total_authorized']:>6} "
            f"{m['power_concentration']:>7.3f} "
            f"{m['human_decision_share']:>8.3f} {m['ai_decision_share']:>6.3f} "
            f"{adapt:>6.2f}"
        )
    return results


def governed_vs_ungoverned(
    policy: str = "polycentric",
    n_agents: int = 9,
    epochs: int = 12,
    seed: int = 2026,
) -> dict[str, Any]:
    """Direct contrast: same agents + same mechanism, with vs without runtime enforcement."""
    print("\n=== Governed vs Ungoverned contrast ===")
    governed = run_single_policy(
        policy=policy,
        n_agents=n_agents,
        epochs=epochs,
        seed=seed,
        verbose=True,
        enforce_runtime=True,
    )
    ungoverned = run_single_policy(
        policy=policy,
        n_agents=n_agents,
        epochs=epochs,
        seed=seed,
        verbose=True,
        enforce_runtime=False,
    )

    g_v = governed["final"]["constitutional_verdict"]
    u_v = ungoverned["final"]["constitutional_verdict"]
    g_a = governed["final"]["action_summary"]
    u_a = ungoverned["final"]["action_summary"]
    g_m = governed["final"]["live_authority_metrics"]
    u_m = ungoverned["final"]["live_authority_metrics"]

    print("\n--- Contrast summary ---")
    print(f"{'arm':<14} {'admissible':>10} {'blocked':>8} {'priv_mon':>9} {'ai%':>7} {'adapt':>6}")
    print("-" * 60)
    print(
        f"{'governed':<14} {str(g_v['admissible']):>10} {g_a['total_blocked']:>8} "
        f"{governed['final']['outcome'].get('private_cognition_monitoring', 0):>9.3f} "
        f"{g_m['ai_decision_share']:>7.3f} "
        f"{governed['final'].get('capture_adaptation', {}).get('mean_adaptation_level', 0):>6.2f}"
    )
    print(
        f"{'ungoverned':<14} {str(u_v['admissible']):>10} {u_a['total_blocked']:>8} "
        f"{ungoverned['final']['outcome'].get('private_cognition_monitoring', 0):>9.3f} "
        f"{u_m['ai_decision_share']:>7.3f} "
        f"{ungoverned['final'].get('capture_adaptation', {}).get('mean_adaptation_level', 0):>6.2f}"
    )
    return {"governed": governed, "ungoverned": ungoverned}


def main() -> None:
    print("=== SwarmGlue v0.8 — Simple Agent Simulation Environment ===")
    # 1. Detailed governed run under polycentric
    report = run_single_policy(
        policy="polycentric", n_agents=9, epochs=12, seed=2026, enforce_runtime=True
    )
    out_path = Path(__file__).resolve().parent / "last_run_report.json"
    out_path.write_text(json.dumps(report, indent=2, default=str))
    print(f"\nSingle-run report written to {out_path}")

    # 2. Multi-policy comparison (all governed)
    comparison = compare_policies(n_agents=9, epochs=8, seed=2026)
    cmp_path = Path(__file__).resolve().parent / "policy_comparison.json"
    cmp_path.write_text(json.dumps(comparison, indent=2, default=str))
    print(f"\nComparison written to {cmp_path}")

    # 3. Direct governed vs ungoverned contrast (same seed & mechanism)
    contrast = governed_vs_ungoverned(
        policy="polycentric", n_agents=9, epochs=12, seed=2026
    )
    contrast_path = Path(__file__).resolve().parent / "governed_vs_ungoverned.json"
    contrast_path.write_text(json.dumps(contrast, indent=2, default=str))
    print(f"\nGoverned-vs-ungoverned contrast written to {contrast_path}")


if __name__ == "__main__":
    main()
