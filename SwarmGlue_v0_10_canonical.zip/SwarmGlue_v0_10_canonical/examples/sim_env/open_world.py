#!/usr/bin/env python3
"""Run the improved replayable SwarmGlue open-world experiment."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from swarmglue.open_world import ARMS, OpenWorldConfig, paired_arms, run_open_world


def _summary(report: dict) -> dict:
    final = report["final"]
    metrics = final["metrics"]
    counters = report["counters"]
    return {
        "arm": report["arm"],
        "material_wellbeing": metrics["material_wellbeing"],
        "civic_burden": metrics["civic_burden"],
        "service_capacity": metrics["service_capacity"],
        "private_monitoring": metrics["private_cognition_monitoring"],
        "dissent_penalty": metrics["dissent_penalty_without_externality"],
        "practical_exit_access": metrics["practical_exit_access"],
        "blocked": counters.get("blocked_actions", 0),
        "safe_blocked": counters.get("safe_actions_blocked", 0),
        "semantic_misses": counters.get("semantic_misses", 0),
        "false_negatives": counters.get("review_false_negatives", 0),
        "review_burden": counters.get("review_burden", 0.0),
        "replay_digest": report["replay_digest"],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--arm", choices=(*ARMS, "all"), default="all")
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--epochs", type=int, default=60)
    parser.add_argument("--residents", type=int, default=32)
    parser.add_argument("--stress", type=float, default=1.0)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    config = OpenWorldConfig(
        seed=args.seed,
        epochs=args.epochs,
        n_residents=args.residents,
        max_residents=max(96, args.residents * 2),
        stress_multiplier=args.stress,
    )
    if args.arm == "all":
        reports = paired_arms(config=config)
    else:
        reports = {args.arm: run_open_world(config=config, arm=args.arm)}
    summaries = [_summary(reports[arm]) for arm in reports]

    print("SwarmGlue open-world v0.2 — authored C2 simulation")
    print(
        f"seed={args.seed} epochs={args.epochs} residents={args.residents} "
        f"stress={args.stress:g}"
    )
    print(
        f"{'arm':<20} {'material':>8} {'civic':>7} {'service':>8} "
        f"{'priv':>6} {'exit':>6} {'block':>6} {'safe':>5} {'miss':>5}"
    )
    print("-" * 88)
    for item in summaries:
        print(
            f"{item['arm']:<20} {item['material_wellbeing']:>8.3f} "
            f"{item['civic_burden']:>7.3f} {item['service_capacity']:>8.3f} "
            f"{item['private_monitoring']:>6.3f} "
            f"{item['practical_exit_access']:>6.3f} "
            f"{item['blocked']:>6} {item['safe_blocked']:>5} "
            f"{item['semantic_misses']:>5}"
        )
    print("\nNo scalar winner is computed; protected, material, and process endpoints remain separate.")
    print("These rule-based results are C2 only, not a completed C3 governed-agent trial.")

    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "configuration": {
                "seed": args.seed,
                "epochs": args.epochs,
                "residents": args.residents,
                "stress": args.stress,
            },
            "summaries": summaries,
            "reports": reports,
        }
        args.output.write_text(
            json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        print(f"Wrote {args.output}")


if __name__ == "__main__":
    main()

