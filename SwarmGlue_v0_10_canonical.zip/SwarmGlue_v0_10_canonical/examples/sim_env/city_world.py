#!/usr/bin/env python3
"""SimCity-style world layered on SwarmGlue v0.8 governance.

The city is a spatial grid of districts. Each district inherits the
network-governance Jurisdiction state and adds classic SimCity variables:

  - zone mix (residential / commercial / industrial)
  - infrastructure quality (power, water, transport)
  - pollution, demand, local budget pressure
  - growth and decline feedbacks

Agents act as city actors (mayors, developers, activists, capture-oriented
utilities). Every consequential action still goes through the real
CapabilityGateway → CapabilityActuator → constitutional evaluator path.

This is research instrumentation with a SimCity skin, not a commercial
city-builder. Constitutional outcomes and authority drift remain first-class.
"""

from __future__ import annotations

import json
import math
import random
import sys
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Literal

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from examples.sim_env.simple_agents import (  # type: ignore
    AgentType,
    SimulationEnvironment,
    SimpleAgent,
)
from swarmglue.utils import clamp, q

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import Normalize

    HAS_MPL = True
except Exception:  # pragma: no cover
    HAS_MPL = False

# ---------------------------------------------------------------------------
# Spatial city layer
# ---------------------------------------------------------------------------

ZoneType = Literal["residential", "commercial", "industrial", "mixed", "park"]


@dataclass
class District:
    """One tile / neighborhood on the city grid."""

    district_id: str
    row: int
    col: int
    jurisdiction_id: str  # link back to SwarmGlue NetworkState
    zone: ZoneType = "mixed"
    density: float = 0.55  # 0–1
    power_quality: float = 0.80
    water_quality: float = 0.80
    transport: float = 0.70
    pollution: float = 0.15
    demand: float = 0.50  # unmet demand pressure
    local_budget: float = 1.0
    happiness: float = 0.75
    buildings: int = 12

    def land_value(self) -> float:
        base = 0.35 * self.density + 0.25 * self.power_quality + 0.20 * self.water_quality
        base += 0.15 * self.transport - 0.30 * self.pollution + 0.10 * self.happiness
        if self.zone == "park":
            base += 0.08
        return q(max(0.05, min(1.0, base)))


@dataclass
class CityWorld:
    """Spatial SimCity layer on top of a SwarmGlue SimulationEnvironment."""

    env: SimulationEnvironment
    width: int
    height: int
    districts: dict[str, District] = field(default_factory=dict)
    city_name: str = "SwarmCity"
    treasury: float = 100.0
    tax_rate: float = 0.08
    epoch_events: list[str] = field(default_factory=list)
    disaster_cooldown: int = 0

    @classmethod
    def create(
        cls,
        n_agents: int = 9,
        seed: int = 2026,
        policy: str = "polycentric",
        enforce_runtime: bool = True,
        width: int = 3,
        height: int = 3,
        city_name: str = "SwarmCity",
    ) -> "CityWorld":
        n_cells = width * height
        env = SimulationEnvironment.create(
            n_agents=max(n_agents, n_cells),
            seed=seed,
            topology="modular",
            policy=policy,
            enforce_runtime=enforce_runtime,
        )
        # Re-map jurisdictions onto a grid
        juris_ids = list(env.network_state.jurisdictions.keys())
        districts: dict[str, District] = {}
        rng = random.Random(seed + 99)
        zones: list[ZoneType] = [
            "residential",
            "commercial",
            "industrial",
            "mixed",
            "park",
            "residential",
            "commercial",
            "industrial",
            "mixed",
        ]
        for i in range(n_cells):
            r, c = divmod(i, width)
            jid = juris_ids[i % len(juris_ids)]
            did = f"D{r}{c}"
            districts[did] = District(
                district_id=did,
                row=r,
                col=c,
                jurisdiction_id=jid,
                zone=zones[i % len(zones)],
                density=rng.uniform(0.35, 0.75),
                power_quality=rng.uniform(0.65, 0.92),
                water_quality=rng.uniform(0.60, 0.90),
                transport=rng.uniform(0.55, 0.85),
                pollution=rng.uniform(0.05, 0.35),
                demand=rng.uniform(0.20, 0.55),
                local_budget=rng.uniform(0.7, 1.2),
                happiness=rng.uniform(0.55, 0.88),
                buildings=rng.randint(6, 22),
            )
        # Attach agents to districts (cycle)
        for i, agent in enumerate(env.agents):
            did = list(districts.keys())[i % n_cells]
            agent.jurisdiction_id = districts[did].jurisdiction_id  # keep SwarmGlue link
            # store preferred district on the agent via memory for city actions
            agent.memory.append({"preferred_district": did})

        return cls(
            env=env,
            width=width,
            height=height,
            districts=districts,
            city_name=city_name,
        )

    # ------------------------------------------------------------------
    # City dynamics (lightweight SimCity loops)
    # ------------------------------------------------------------------

    def _district_for_agent(self, agent: SimpleAgent) -> District:
        for m in reversed(agent.memory):
            if "preferred_district" in m:
                return self.districts[m["preferred_district"]]
        # fallback
        return next(iter(self.districts.values()))

    def neighbors(self, d: District) -> list[District]:
        out: list[District] = []
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nr, nc = d.row + dr, d.col + dc
            nid = f"D{nr}{nc}"
            if nid in self.districts:
                out.append(self.districts[nid])
        return out

    def city_tick(self) -> dict[str, Any]:
        """Advance local city economy one step (after agent actions)."""
        events: list[str] = []
        total_pop = 0.0
        total_happy = 0.0
        total_pollution = 0.0
        revenue = 0.0

        # Snapshot pollution for adjacency diffusion
        pollution_snap = {did: d.pollution for did, d in self.districts.items()}
        park_boost = {did: 0.0 for did in self.districts}

        for d in self.districts.values():
            for nb in self.neighbors(d):
                if nb.zone == "park":
                    park_boost[d.district_id] += 0.015
                # industrial neighbors leak pollution
                if nb.zone == "industrial":
                    d.pollution = clamp(
                        d.pollution + 0.25 * (pollution_snap[nb.district_id] - d.pollution) * 0.08
                    )

        for d in self.districts.values():
            j = self.env.network_state.jurisdictions[d.jurisdiction_id]
            # Sync population pressure from jurisdiction
            pop_factor = j.population / max(1.0, j.initial_population)
            d.density = clamp(0.7 * d.density + 0.3 * min(1.0, pop_factor * 0.55))

            # Zone-specific production / consumption
            if d.zone == "residential":
                d.demand = clamp(d.demand + 0.02 * (0.7 - d.happiness))
                d.pollution = clamp(d.pollution * 0.97)
            elif d.zone == "commercial":
                d.local_budget = clamp(d.local_budget + 0.03 * d.density * (1.0 - d.demand))
                revenue += 12.0 * d.density * max(0.35, d.happiness)
            elif d.zone == "industrial":
                d.pollution = clamp(d.pollution + 0.04 * d.density)
                d.local_budget = clamp(d.local_budget + 0.05 * d.density)
                revenue += 14.0 * d.density
                d.demand = clamp(d.demand - 0.01)
            elif d.zone == "park":
                d.pollution = clamp(d.pollution * 0.90)
                d.happiness = clamp(d.happiness + 0.02)
                revenue += 1.5 * d.happiness  # amenity value
            else:  # mixed
                d.pollution = clamp(d.pollution + 0.015 * d.density)
                revenue += 8.0 * d.density
            # residential also contributes a light tax base
            if d.zone == "residential":
                revenue += 4.0 * d.density * max(0.3, d.happiness)

            # Infrastructure decay / repair pressure
            if d.power_quality < 0.55 or d.water_quality < 0.55:
                d.happiness = clamp(d.happiness - 0.04)
                d.demand = clamp(d.demand + 0.03)
            d.power_quality = clamp(d.power_quality - 0.008 + 0.01 * (d.local_budget - 0.8))
            d.water_quality = clamp(d.water_quality - 0.007 + 0.01 * (d.local_budget - 0.8))
            d.transport = clamp(d.transport - 0.005)

            # Happiness from services, pollution, and neighboring parks
            service = 0.4 * d.power_quality + 0.3 * d.water_quality + 0.3 * d.transport
            d.happiness = clamp(
                0.6 * d.happiness
                + 0.4 * (service - 0.5 * d.pollution)
                + park_boost.get(d.district_id, 0.0)
            )

            total_pop += j.population
            total_happy += d.happiness
            total_pollution += d.pollution

        n = max(1, len(self.districts))
        # Municipal budget: at ~8% tax a healthy mixed city runs near balance / small surplus.
        upkeep = 0.40 * n
        self.treasury = q(self.treasury + revenue * self.tax_rate - upkeep)
        self.treasury = max(0.0, min(500.0, self.treasury))

        # Constitutional feedback: hard violations depress city-wide happiness
        priv = self.env.network_state.private_cognition_monitoring
        dissent = self.env.network_state.dissent_penalty_without_externality
        if priv > 0.02 or dissent > 0.02:
            penalty = 0.04 + 0.15 * priv + 0.10 * dissent
            for d in self.districts.values():
                d.happiness = clamp(d.happiness - penalty)
            events.append(
                f"Rights climate worsens (priv={priv:.2f}, dissent_pen={dissent:.2f})"
            )
            # recompute aggregate after penalty
            total_happy = sum(d.happiness for d in self.districts.values())
            total_pollution = sum(d.pollution for d in self.districts.values())

        # Occasional disasters / events
        if self.disaster_cooldown <= 0 and self.env.rng.random() < 0.12:
            target = self.env.rng.choice(list(self.districts.values()))
            kind = self.env.rng.choice(["blackout", "flood", "protest", "boom"])
            if kind == "blackout":
                target.power_quality = clamp(target.power_quality - 0.25)
                events.append(f"Blackout in {target.district_id}")
            elif kind == "flood":
                target.water_quality = clamp(target.water_quality - 0.20)
                target.pollution = clamp(target.pollution + 0.15)
                events.append(f"Flood damage in {target.district_id}")
            elif kind == "protest":
                target.happiness = clamp(target.happiness - 0.15)
                events.append(f"Protest over services in {target.district_id}")
            else:
                target.density = clamp(target.density + 0.12)
                target.buildings += 3
                events.append(f"Construction boom in {target.district_id}")
            self.disaster_cooldown = 4
        else:
            self.disaster_cooldown = max(0, self.disaster_cooldown - 1)

        self.epoch_events = events
        return {
            "population": q(total_pop),
            "mean_happiness": q(total_happy / n),
            "mean_pollution": q(total_pollution / n),
            "treasury": q(self.treasury),
            "tax_rate": self.tax_rate,
            "events": events,
        }

    # ------------------------------------------------------------------
    # City-flavored agent proposals (still gated by SwarmGlue)
    # ------------------------------------------------------------------

    def propose_city_action(
        self, agent: SimpleAgent, rng: random.Random
    ) -> dict[str, Any] | None:
        """SimCity-style action vocabulary mapped onto SwarmGlue action kinds."""
        d = self._district_for_agent(agent)
        j = self.env.network_state.jurisdictions[d.jurisdiction_id]
        snap = self.env._global_snapshot()
        power = snap.get("power_concentration", 0.3)

        candidates: list[dict[str, Any]] = []

        # Universal low-risk city actions → invest_capacity / signals
        candidates.append(
            {
                "kind": "invest_capacity",
                "jurisdiction_id": d.jurisdiction_id,
                "district_id": d.district_id,
                "amount": 0.02 + 0.03 * rng.random(),
                "rationale": "infrastructure_upkeep",
                "city_verb": "repair_infrastructure",
            }
        )
        if d.demand > 0.55:
            candidates.append(
                {
                    "kind": "emit_coordination_signal",
                    "signal_type": "resource_scarcity",
                    "severity": min(0.9, d.demand),
                    "affected_party": d.jurisdiction_id,
                    "district_id": d.district_id,
                    "city_verb": "raise_service_alert",
                }
            )

        if agent.agent_type == "cooperative":
            if d.happiness < 0.6 or d.power_quality < 0.6:
                candidates.append(
                    {
                        "kind": "invest_capacity",
                        "jurisdiction_id": d.jurisdiction_id,
                        "district_id": d.district_id,
                        "amount": 0.04,
                        "rationale": "raise_happiness",
                        "city_verb": "fund_services",
                    }
                )
            # Tax policy: cooperative agents prefer modest rates when treasury is healthy
            if self.treasury > 40 and self.tax_rate > 0.06 and rng.random() < 0.25:
                candidates.append(
                    {
                        "kind": "contestability_investment",
                        "delta": 0.02,
                        "city_verb": "lower_tax",
                        "tax_delta": -0.01,
                    }
                )
            if d.zone != "park" and d.pollution > 0.35:
                candidates.append(
                    {
                        "kind": "restore_exit_access",  # stylized: open green / exit pressure
                        "delta": 0.03,
                        "district_id": d.district_id,
                        "city_verb": "rezone_park",
                        "new_zone": "park",
                    }
                )
            if power > 0.45:
                candidates.append(
                    {
                        "kind": "contestability_investment",
                        "delta": 0.03,
                        "city_verb": "strengthen_oversight",
                    }
                )

        elif agent.agent_type == "opportunistic":
            if d.local_budget < 0.9:
                candidates.append(
                    {
                        "kind": "request_central_pooling",
                        "share": 0.08 + 0.08 * rng.random(),
                        "district_id": d.district_id,
                        "city_verb": "request_city_subsidy",
                    }
                )
            if self.treasury < 35 and self.tax_rate < 0.14 and rng.random() < 0.35:
                candidates.append(
                    {
                        "kind": "request_central_pooling",
                        "share": 0.05,
                        "city_verb": "raise_tax",
                        "tax_delta": 0.015,
                    }
                )
            if rng.random() < 0.3:
                candidates.append(
                    {
                        "kind": "propose_authority_amendment",
                        "capability": "resource_allocation",
                        "from_actor": "elected_local",
                        "to_actor": "external_principal",
                        "delta": 0.03,
                        "city_verb": "outsource_services",
                    }
                )

        else:  # capture_seeking — adaptive
            max_delta = 0.13 * (1.0 - 0.7 * agent.adaptation_level)
            candidates.append(
                {
                    "kind": "propose_authority_amendment",
                    "capability": rng.choice(
                        ["critical_services", "resource_allocation", "emergency_power"]
                    ),
                    "from_actor": "elected_local",
                    "to_actor": "ai_systems",
                    "delta": 0.03 + max_delta * rng.random(),
                    "city_verb": "centralize_control",
                }
            )
            if rng.random() < 0.4 * (1.0 - agent.adaptation_level):
                candidates.append(
                    {
                        "kind": "increase_monitoring",
                        "delta": 0.05,
                        "target": "private_cognition",
                        "city_verb": "install_surveillance",
                    }
                )
            if rng.random() < 0.3 * (1.0 - 0.8 * agent.adaptation_level):
                candidates.append(
                    {
                        "kind": "sanction_dissent",
                        "severity": 0.2,
                        "has_demonstrated_externality": False,
                        "city_verb": "crackdown_on_protest",
                    }
                )
            if agent.adaptation_level > 0.4 and rng.random() < 0.35:
                candidates.append(
                    {
                        "kind": "request_central_pooling",
                        "share": 0.07,
                        "city_verb": "push_regional_authority",
                    }
                )

        if not candidates:
            return None
        # Weight by type preference
        if agent.agent_type == "capture_seeking":
            weights = [
                3.0
                if c.get("city_verb")
                in ("centralize_control", "install_surveillance", "crackdown_on_protest")
                else 1.0
                for c in candidates
            ]
        elif agent.agent_type == "cooperative":
            weights = [
                2.5
                if c.get("city_verb")
                in ("fund_services", "rezone_park", "strengthen_oversight", "repair_infrastructure")
                else 1.0
                for c in candidates
            ]
        else:
            weights = [1.0] * len(candidates)

        chosen = rng.choices(candidates, weights=weights, k=1)[0]
        chosen["actor_id"] = agent.agent_id
        chosen["proposal_id"] = str(uuid.uuid4())
        chosen["epoch"] = self.env.epoch
        return chosen

    def apply_city_side_effects(self, agent: SimpleAgent, action: dict[str, Any]) -> None:
        """Apply local SimCity effects after SwarmGlue has authorized the action."""
        verb = action.get("city_verb")
        did = action.get("district_id")
        if not did or did not in self.districts:
            # try agent preferred
            d = self._district_for_agent(agent)
        else:
            d = self.districts[did]

        if verb == "repair_infrastructure" or verb == "fund_services":
            amount = float(action.get("amount", 0.03))
            d.power_quality = clamp(d.power_quality + 0.6 * amount)
            d.water_quality = clamp(d.water_quality + 0.5 * amount)
            d.transport = clamp(d.transport + 0.3 * amount)
            d.local_budget = clamp(d.local_budget - 0.5 * amount)
            self.treasury = max(0.0, self.treasury - max(0.15, 4.0 * amount))
        elif verb == "rezone_park":
            d.zone = "park"
            d.pollution = clamp(d.pollution * 0.7)
            d.happiness = clamp(d.happiness + 0.08)
            d.buildings = max(2, d.buildings - 2)
        elif verb == "raise_service_alert":
            d.demand = clamp(d.demand * 0.9)
        elif verb == "request_city_subsidy" or verb == "push_regional_authority":
            d.local_budget = clamp(d.local_budget + 0.08)
            self.treasury = max(0.0, self.treasury - 0.4)
        elif verb == "outsource_services":
            d.power_quality = clamp(d.power_quality + 0.03)
            d.local_budget = clamp(d.local_budget - 0.04)
        elif verb == "centralize_control":
            d.local_budget = clamp(d.local_budget + 0.02)
        elif verb == "install_surveillance":
            d.happiness = clamp(d.happiness - 0.10)
        elif verb == "crackdown_on_protest":
            d.happiness = clamp(d.happiness - 0.12)
            d.demand = clamp(d.demand + 0.05)
        elif verb == "lower_tax":
            delta = float(action.get("tax_delta", -0.01))
            self.tax_rate = clamp(self.tax_rate + delta, 0.02, 0.20)
            # modest happiness bump city-wide
            for dist in self.districts.values():
                dist.happiness = clamp(dist.happiness + 0.02)
        elif verb == "raise_tax":
            delta = float(action.get("tax_delta", 0.015))
            self.tax_rate = clamp(self.tax_rate + delta, 0.02, 0.20)
            for dist in self.districts.values():
                dist.happiness = clamp(dist.happiness - 0.025)

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    def run_round(self) -> dict[str, Any]:
        self.env.epoch += 1
        proposals: list[dict[str, Any]] = []
        rng = self.env.rng

        for agent in self.env.agents:
            action = self.propose_city_action(agent, rng)
            if action is None:
                continue
            result = self.env.authorize_and_execute(agent, action)
            if result.get("token_issued"):
                self.apply_city_side_effects(agent, action)
            proposals.append(result)

        # Advance SwarmGlue network dynamics
        from swarmglue.network_governance import step

        step(self.env.network_state, self.env.parameters, self.env.rng, self.env.config)

        # Advance local city economy
        city_stats = self.city_tick()

        return {
            "epoch": self.env.epoch,
            "n_proposals": len(proposals),
            "n_authorized": sum(1 for p in proposals if p.get("token_issued")),
            "n_blocked": sum(1 for p in proposals if not p.get("token_issued")),
            "power_concentration": q(self.env.network_state.power_concentration),
            "exit_access": q(self.env.network_state.exit_access),
            "private_cognition_monitoring": q(
                self.env.network_state.private_cognition_monitoring
            ),
            "city": city_stats,
        }

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def render_map(self) -> str:
        """ASCII map of the city."""
        zone_sym = {
            "residential": "R",
            "commercial": "C",
            "industrial": "I",
            "mixed": "M",
            "park": "P",
        }
        lines = [f"=== {self.city_name}  epoch {self.env.epoch} ==="]
        # header
        lines.append("   " + "  ".join(f"{c:2d}" for c in range(self.width)))
        for r in range(self.height):
            row_cells = []
            for c in range(self.width):
                did = f"D{r}{c}"
                d = self.districts.get(did)
                if not d:
                    row_cells.append(" ?")
                    continue
                sym = zone_sym.get(d.zone, "?")
                # happiness tint
                if d.happiness >= 0.75:
                    mark = "·"
                elif d.happiness >= 0.55:
                    mark = ":"
                else:
                    mark = "!"
                row_cells.append(f"{sym}{mark}")
            lines.append(f"{r:2d} " + " ".join(row_cells))
        lines.append("Legend: R resid  C comm  I ind  M mixed  P park   · ok  : strained  ! crisis")
        return "\n".join(lines)

    def render_dashboard(self, last_tick: dict[str, Any] | None = None) -> str:
        city = (last_tick or {}).get("city", {})
        lines = [
            f"Treasury: {self.treasury:6.1f}   Tax: {self.tax_rate:.0%}   "
            f"Pop≈{city.get('population', 0):.0f}   "
            f"Happy {city.get('mean_happiness', 0):.2f}   "
            f"Pollution {city.get('mean_pollution', 0):.2f}",
            f"Power conc. {self.env.network_state.power_concentration:.3f}   "
            f"Exit {self.env.network_state.exit_access:.3f}   "
            f"Priv-mon {self.env.network_state.private_cognition_monitoring:.3f}",
        ]
        if self.epoch_events:
            lines.append("Events: " + "; ".join(self.epoch_events))
        # Top / bottom districts
        ranked = sorted(self.districts.values(), key=lambda d: d.happiness)
        worst = ranked[0]
        best = ranked[-1]
        lines.append(
            f"Best district {best.district_id} ({best.zone}) happy={best.happiness:.2f}  "
            f"Worst {worst.district_id} ({worst.zone}) happy={worst.happiness:.2f}"
        )
        return "\n".join(lines)

    def render_image(self, path: Path | str) -> Path | None:
        """Save a 3-panel city snapshot (happiness, pollution, land value)."""
        if not HAS_MPL:
            return None
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        def grid(attr: str) -> list[list[float]]:
            g = [[0.0] * self.width for _ in range(self.height)]
            for d in self.districts.values():
                if attr == "land_value":
                    g[d.row][d.col] = d.land_value()
                else:
                    g[d.row][d.col] = float(getattr(d, attr))
            return g

        fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.6))
        panels = [
            ("happiness", "Happiness", "YlGn"),
            ("pollution", "Pollution", "YlOrRd"),
            ("land_value", "Land value", "Blues"),
        ]
        for ax, (attr, title, cmap) in zip(axes, panels):
            data = grid(attr)
            im = ax.imshow(data, cmap=cmap, vmin=0, vmax=1, origin="upper")
            ax.set_title(title, fontsize=11)
            ax.set_xticks(range(self.width))
            ax.set_yticks(range(self.height))
            for d in self.districts.values():
                ax.text(
                    d.col,
                    d.row,
                    d.zone[0].upper(),
                    ha="center",
                    va="center",
                    fontsize=9,
                    color="black",
                    alpha=0.7,
                )
            fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        fig.suptitle(
            f"{self.city_name}  epoch {self.env.epoch}  "
            f"tax={self.tax_rate:.0%}  treasury={self.treasury:.0f}  "
            f"priv-mon={self.env.network_state.private_cognition_monitoring:.3f}",
            fontsize=12,
        )
        fig.tight_layout()
        fig.savefig(path, dpi=120, bbox_inches="tight")
        plt.close(fig)
        return path

    def final_report(self) -> dict[str, Any]:
        final = self.env.final_evaluation()
        capture_agents = [a for a in self.env.agents if a.agent_type == "capture_seeking"]
        mean_adapt = (
            sum(a.adaptation_level for a in capture_agents) / max(1, len(capture_agents))
        )
        final["capture_adaptation"] = {
            "mean_adaptation_level": round(mean_adapt, 3),
            "n_capture_agents": len(capture_agents),
            "recent_block_counts": {
                a.agent_id: len(a.recent_blocks) for a in capture_agents
            },
        }
        final["city"] = {
            "name": self.city_name,
            "treasury": self.treasury,
            "tax_rate": self.tax_rate,
            "districts": {
                did: {
                    "zone": d.zone,
                    "density": d.density,
                    "happiness": d.happiness,
                    "pollution": d.pollution,
                    "power": d.power_quality,
                    "water": d.water_quality,
                    "land_value": d.land_value(),
                    "buildings": d.buildings,
                }
                for did, d in self.districts.items()
            },
        }
        return final


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------


def run_city(
    epochs: int = 16,
    n_agents: int = 9,
    seed: int = 2026,
    policy: str = "polycentric",
    enforce_runtime: bool = True,
    width: int = 3,
    height: int = 3,
    city_name: str = "SwarmCity",
    print_every: int = 2,
    save_frames: bool = True,
) -> dict[str, Any]:
    world = CityWorld.create(
        n_agents=n_agents,
        seed=seed,
        policy=policy,
        enforce_runtime=enforce_runtime,
        width=width,
        height=height,
        city_name=city_name,
    )
    frames_dir = Path(__file__).resolve().parent / "city_frames" / city_name.replace(" ", "_")
    if save_frames:
        frames_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n{'='*60}")
    print(f"  {city_name} — SwarmGlue-governed SimCity")
    print(f"  policy={policy}  enforce={enforce_runtime}  grid={width}x{height}")
    print(f"{'='*60}\n")
    print(world.render_map())
    print()

    history = []
    frame_paths: list[str] = []
    for i in range(epochs):
        tick = world.run_round()
        history.append(tick)
        if (i + 1) % print_every == 0 or i == 0 or i == epochs - 1:
            print(world.render_map())
            print(world.render_dashboard(tick))
            print(
                f"  actions: auth={tick['n_authorized']}  "
                f"block={tick['n_blocked']}  "
                f"events={tick['city'].get('events', [])}"
            )
            print()
            if save_frames:
                fp = frames_dir / f"epoch_{world.env.epoch:03d}.png"
                saved = world.render_image(fp)
                if saved:
                    frame_paths.append(str(saved))

    # Always save a final frame
    if save_frames:
        final_fp = frames_dir / "final.png"
        saved = world.render_image(final_fp)
        if saved:
            frame_paths.append(str(saved))

    final = world.final_report()
    print("--- Final constitutional verdict ---")
    print(json.dumps(final["constitutional_verdict"], indent=2))
    print("--- City snapshot ---")
    print(json.dumps(final["city"], indent=2, default=str)[:1200])
    print("...")
    if frame_paths:
        print(f"Frames saved under {frames_dir} ({len(frame_paths)} images)")
    return {
        "history": history,
        "final": final,
        "map": world.render_map(),
        "frames": frame_paths,
    }


def main() -> None:
    # 1. Governed city
    governed = run_city(
        epochs=14,
        n_agents=9,
        seed=2026,
        policy="polycentric",
        enforce_runtime=True,
        city_name="Polycentric Bay",
    )
    out = Path(__file__).resolve().parent / "city_governed.json"
    out.write_text(json.dumps(governed, indent=2, default=str))
    print(f"\nWrote {out}")

    # 2. Ungoverned contrast (same seed)
    print("\n" + "=" * 60)
    ungoverned = run_city(
        epochs=14,
        n_agents=9,
        seed=2026,
        policy="polycentric",
        enforce_runtime=False,
        city_name="Open Capture City",
    )
    out2 = Path(__file__).resolve().parent / "city_ungoverned.json"
    out2.write_text(json.dumps(ungoverned, indent=2, default=str))
    print(f"\nWrote {out2}")

    # Quick contrast
    g_v = governed["final"]["constitutional_verdict"]
    u_v = ungoverned["final"]["constitutional_verdict"]
    g_priv = governed["final"]["outcome"].get("private_cognition_monitoring", 0)
    u_priv = ungoverned["final"]["outcome"].get("private_cognition_monitoring", 0)
    print("\n=== City contrast ===")
    print(f"{'arm':<12} {'admissible':>10} {'priv_mon':>9}")
    print("-" * 35)
    print(f"{'governed':<12} {str(g_v['admissible']):>10} {g_priv:>9.3f}")
    print(f"{'ungoverned':<12} {str(u_v['admissible']):>10} {u_priv:>9.3f}")


if __name__ == "__main__":
    main()
