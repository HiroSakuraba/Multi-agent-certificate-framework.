#!/usr/bin/env python3
"""Small executable tour of the v0.8 distinctions."""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from swarmglue.institutional_boundaries import run_institutional_boundary_suite
from swarmglue.authority import execute_amendment_sequence, gradual_erosion_sequence
from swarmglue.network_governance import SimulationConfig, compare_policies


def main() -> None:
    policies = compare_policies(SimulationConfig(seed=4, topology="modular"))
    output = {
        "institutional_boundaries": {
            key: value for key, value in run_institutional_boundary_suite().items() if key != "cases"
        },
        "authority": {
            checker: execute_amendment_sequence(gradual_erosion_sequence(), checker=checker)
            for checker in ("legacy", "polycentric")
        },
        "network_governance": {
            policy: {
                "admissible": result["constitutional_verdict"]["admissible"],
                "hard_violations": result["constitutional_verdict"]["hard_violations"],
                "capacity_violations": result["constitutional_verdict"]["capacity_violations"],
                "population_index": result["final"]["population_index"],
                "capacity_growth": result["outcome"]["capacity_growth"],
                "autonomy": result["outcome"]["autonomy"],
                "domination_risk_inputs": {
                    "power_concentration": result["outcome"]["power_concentration"],
                    "private_cognition_monitoring": result["outcome"]["private_cognition_monitoring"],
                    "exit_access": result["outcome"]["exit_access"],
                },
            }
            for policy, result in policies.items()
        },
    }
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
