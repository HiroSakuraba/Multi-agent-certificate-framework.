import os
import inspect
import subprocess
import sys
import unittest

import swarmglue.network_governance as ng
from swarmglue.network_governance import (
    POLICY,
    SimulationConfig,
    compare_policies,
    fixture_parameters,
    interpolate_parameters,
    simulate,
    simulate_with_parameters,
)


class NetworkGovernanceBenchmarkTests(unittest.TestCase):
    def test_same_seed_is_reproducible(self):
        config = SimulationConfig(seed=7, topology="modular", rounds=30)
        self.assertEqual(simulate(config, "polycentric"), simulate(config, "polycentric"))

    def test_seed_is_reproducible_across_python_hash_randomization(self):
        code = (
            "import json; from swarmglue.network_governance import SimulationConfig,simulate; "
            "print(json.dumps(simulate(SimulationConfig(seed=7,topology='modular',rounds=30),'polycentric'),sort_keys=True))"
        )
        outputs = []
        for hash_seed in ("1", "987654"):
            env = dict(os.environ)
            env["PYTHONHASHSEED"] = hash_seed
            outputs.append(subprocess.check_output([sys.executable, "-c", code], env=env, text=True))
        self.assertEqual(outputs[0], outputs[1])

    def test_policy_outcomes_are_derived_not_authored_curves(self):
        short = simulate(SimulationConfig(seed=3, rounds=20), "polycentric")
        long = simulate(SimulationConfig(seed=3, rounds=80), "polycentric")
        self.assertNotEqual(
            short["final"]["population_index"], long["final"]["population_index"]
        )
        self.assertEqual(len(short["history"]), 20)
        self.assertEqual(len(long["history"]), 80)

    def test_transition_code_cannot_read_fixture_label(self):
        transition_functions = (
            ng._failure_cascade,
            ng._mutual_aid,
            ng._governance_transition,
            ng.step,
        )
        for function in transition_functions:
            source = inspect.getsource(function)
            self.assertNotIn("policy", source.lower(), function.__name__)
            for label in POLICY:
                self.assertNotIn(label, source, function.__name__)

    def test_equal_parameters_are_label_invariant(self):
        config = SimulationConfig(seed=13, topology="small_world", rounds=35)
        parameters = fixture_parameters("polycentric")
        left = simulate_with_parameters(config, parameters, fixture_id="label-a")
        right = simulate_with_parameters(config, parameters, fixture_id="label-b")
        self.assertNotEqual(left["policy"], right["policy"])
        left.pop("policy")
        right.pop("policy")
        self.assertEqual(left, right)

    def test_complete_parameter_vector_is_interpolated(self):
        midpoint = interpolate_parameters(
            POLICY["polycentric"], POLICY["centralized_capture"], 0.5
        )
        for name, left in POLICY["polycentric"].items():
            right = POLICY["centralized_capture"][name]
            self.assertAlmostEqual(getattr(midpoint, name), (left + right) / 2)

    def test_polycentric_archetype_avoids_capture_and_stasis_failures(self):
        admissible = {p: 0 for p in ("polycentric", "centralized_capture", "procedural_stasis", "fragmented_localism")}
        population_index = {p: [] for p in admissible}
        for topology in ("ring", "hub", "small_world", "modular"):
            for seed in range(5):
                for policy, result in compare_policies(
                    SimulationConfig(seed=seed, topology=topology)
                ).items():
                    admissible[policy] += int(result["constitutional_verdict"]["admissible"])
                    population_index[policy].append(
                        result["final"]["population_index"]
                    )
        self.assertGreaterEqual(admissible["polycentric"], 19)
        self.assertEqual(admissible["centralized_capture"], 0)
        self.assertEqual(admissible["procedural_stasis"], 0)
        self.assertGreater(
            sum(population_index["polycentric"])
            / len(population_index["polycentric"]),
            sum(population_index["fragmented_localism"])
            / len(population_index["fragmented_localism"]),
        )


if __name__ == "__main__":
    unittest.main()
