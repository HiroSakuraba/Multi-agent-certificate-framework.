import unittest

from swarmglue.adversary import baseline_attacks, coevolution_audit, evaluate_defense
from swarmglue.corpus import generate_records, response_only_rows, validate_records


class CorpusTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.records = generate_records(train_pairs=48, dev_pairs=24, challenge_pairs=24)

    def test_counterfactual_balance_and_ood_split(self):
        report = validate_records(self.records)
        self.assertTrue(report["valid"], report)
        self.assertEqual(report["challenge_family_overlap"], [])

    def test_every_response_surface_is_label_balanced(self):
        rows = response_only_rows(
            record for split in self.records.values() for record in split
        )
        by_text = {}
        for row in rows:
            by_text.setdefault((row["task_type"], row["response_text"]), []).append(row["label"])
        for labels in by_text.values():
            self.assertEqual(sum(labels), len(labels) / 2)


class AdversaryTests(unittest.TestCase):
    def test_runtime_attacks_call_real_modules_and_expose_misses(self):
        report = coevolution_audit(generations=6)
        self.assertTrue(report["all_generations_release_pass"], report["generations"])
        self.assertTrue(report["staleness_gate_pass"])
        self.assertTrue(all(rate < 1.0 for rate in report["detection_rate_by_generation"]))
        self.assertTrue(report["known_blind_spots"])
        self.assertGreaterEqual(
            report["generations"][0]["real_module_surface_count"], 5
        )

    def test_empty_runtime_attack_set_cannot_pass(self):
        result = evaluate_defense([])
        self.assertFalse(result["coverage_gate_pass"])
        self.assertIn("no_runtime_attacks", result["coverage_gate_failures"])

    def test_baseline_records_payload_level_reasons(self):
        result = evaluate_defense(baseline_attacks())
        self.assertTrue(result["attack_results"])
        for item in result["attack_results"]:
            self.assertIn(".", item["target_module"])
            self.assertTrue(item["observed_reason"])


if __name__ == "__main__":
    unittest.main()
