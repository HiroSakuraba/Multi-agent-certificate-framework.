import copy
import unittest

from swarmglue.gateway import CapabilityActuator, CapabilityGateway
from swarmglue.presentation import TrustedTraceRecorder, semantic_integrity, verify_presentation


class PresentationTests(unittest.TestCase):
    def setUp(self):
        self.key = b"external-unpredictable-challenge-key"
        self.trace = [
            {"event_type": ("observe", "propose", "transfer", "verify")[i % 4],
             "channel": "public-action", "sequence": i}
            for i in range(16)
        ]
        self.presentation = TrustedTraceRecorder(self.key, sample_count=8).present(
            self.trace, epoch=9, nonce="principal-nonce-9",
            sampleable_channels={"public-action", "resource-ledger"},
            decision_relevant_channels={"public-action", "resource-ledger"},
        )

    def verify(self, presentation):
        return verify_presentation(
            presentation, challenge_key=self.key, expected_epoch=9,
            expected_nonce="principal-nonce-9", min_samples=6, min_entropy_bits=1.0,
        )

    def test_valid_committed_trace(self):
        verdict = self.verify(self.presentation)
        self.assertTrue(verdict.valid, verdict.reasons)
        self.assertEqual(verdict.trace_coverage, 1.0)

    def test_tampered_sample_fails_envelope_and_merkle_proof(self):
        tampered = copy.deepcopy(self.presentation)
        tampered["samples"][0]["event"]["sequence"] = 999
        verdict = self.verify(tampered)
        self.assertIn("presentation_envelope_authentication_failed", verdict.reasons)
        self.assertIn("merkle_proof_failed", verdict.reasons)

    def test_authored_schedule_is_rejected(self):
        tampered = copy.deepcopy(self.presentation)
        tampered["sampled_positions"] = list(reversed(tampered["sampled_positions"]))
        verdict = self.verify(tampered)
        self.assertIn("sample_schedule_not_harness_derived", verdict.reasons)

    def test_claimed_entropy_is_recomputed(self):
        tampered = copy.deepcopy(self.presentation)
        tampered["sample_entropy_bits"] = 99.0
        verdict = self.verify(tampered)
        self.assertIn("sample_entropy_not_recomputed", verdict.reasons)

    def test_semantic_contradiction_is_visible(self):
        verdict = self.verify(self.presentation)
        result = semantic_integrity(
            verdict, declared={"transfers_occurred": False},
            imply=lambda events: {"transfers_occurred": any(e["event_type"] == "transfer" for e in events)},
        )
        self.assertFalse(result["consistent"])


class GatewayTests(unittest.TestCase):
    def setUp(self):
        self.gateway = CapabilityGateway.deterministic(
            gateway_id="external-gateway", principal_authority_id="human-charter",
            policy_version="constitution-0.6", seed="gateway-seed",
        )
        self.action = {"kind": "open_valve", "valve": "oxygen-3", "duration": 2}
        self.state = {"oxygen": 0.64, "epoch": 10}
        self.token = self.gateway.authorize(
            actor_id="repair-agent", action=self.action, state=self.state,
            epoch=10, expires_epoch=12, nonce="cap-nonce-1",
            evaluator=lambda action, state: (state["oxygen"] < 0.7, []),
        )

    def actuator(self):
        return CapabilityActuator.from_public_bytes(
            self.gateway.public_key_bytes(), expected_gateway_id="external-gateway",
            expected_principal_authority_id="human-charter",
            expected_policy_version="constitution-0.6",
        )

    def test_exact_action_executes_once(self):
        actuator = self.actuator()
        self.assertTrue(actuator.verify_and_consume(
            self.token, actor_id="repair-agent", action=self.action,
            state=self.state, current_epoch=10,
        )[0])
        self.assertEqual(actuator.verify_and_consume(
            self.token, actor_id="repair-agent", action=self.action,
            state=self.state, current_epoch=10,
        )[1], "capability_token_replay")

    def test_action_and_state_swap_rejected(self):
        actuator = self.actuator()
        changed_action = {**self.action, "duration": 20}
        self.assertEqual(actuator.verify_and_consume(
            self.token, actor_id="repair-agent", action=changed_action,
            state=self.state, current_epoch=10,
        )[1], "action_binding_failed")
        changed_state = {**self.state, "oxygen": 0.95}
        self.assertEqual(actuator.verify_and_consume(
            self.token, actor_id="repair-agent", action=self.action,
            state=changed_state, current_epoch=10,
        )[1], "state_binding_failed")

    def test_agent_cannot_forge_unsigned_action(self):
        allowed, reason = self.actuator().verify_and_consume(
            None, actor_id="repair-agent", action=self.action,
            state=self.state, current_epoch=10,
        )
        self.assertFalse(allowed)
        self.assertEqual(reason, "missing_capability_token")


if __name__ == "__main__":
    unittest.main()
