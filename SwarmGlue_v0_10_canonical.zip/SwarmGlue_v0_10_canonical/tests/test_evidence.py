import copy
import unittest

from swarmglue.evidence import (
    AttestorRecord,
    AttestorRegistry,
    AttestorSigner,
    ReplayCache,
    assess_coupling,
    evidence_quality,
    make_attestation,
    verify_attestation,
)


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.signer = AttestorSigner.deterministic("sensor-a", "sensor-seed")
        self.registry = AttestorRegistry([
            AttestorRecord(
                "sensor-a", "independent_sensor", self.signer.public_bytes(),
                "sensor-owner", frozenset({"oxygen"}), 20.0, capture_risk=0.10,
            )
        ])

    def record(self, nonce="n-1"):
        return make_attestation(
            signer=self.signer, field_name="oxygen", value=0.81,
            evidence_ref="log://oxygen/44", observability="direct_world_measurement",
            principal_authority_id="human-charter", issued_epoch=40,
            expires_epoch=50, nonce=nonce, falsifier="independent recalibration",
        )

    def verify(self, record, cache=None):
        return verify_attestation(
            record, field_name="oxygen", registry=self.registry, current_epoch=44,
            proponent_id="swarm", proponent_domain="swarm-owner",
            principal_authority_id="human-charter", replay_cache=cache,
        )

    def test_valid_public_key_attestation(self):
        self.assertTrue(self.verify(self.record()).valid)

    def test_signature_and_payload_tamper_rejected(self):
        tampered = self.record()
        tampered["value"] = 1.0
        self.assertEqual(self.verify(tampered).reason, "signature_verification_failed")

    def test_signed_record_cannot_invent_registry_liability(self):
        tampered = self.record()
        tampered["liability_units"] = 10_000
        self.assertEqual(self.verify(tampered).reason, "malformed_attestation")

    def test_same_control_domain_is_not_independent(self):
        shared_registry = AttestorRegistry([
            AttestorRecord(
                "sensor-a", "independent_sensor", self.signer.public_bytes(),
                "swarm-owner", frozenset({"oxygen"}), 20.0,
            )
        ])
        result = verify_attestation(
            self.record(), field_name="oxygen", registry=shared_registry,
            current_epoch=44, proponent_id="swarm", proponent_domain="swarm-owner",
            principal_authority_id="human-charter",
        )
        self.assertEqual(result.reason, "attestor_shares_control_domain")

    def test_nonce_replay_rejected(self):
        cache = ReplayCache()
        self.assertTrue(self.verify(self.record(), cache).valid)
        self.assertEqual(self.verify(self.record(), cache).reason, "attestation_replay")

    def test_capture_benefit_does_not_become_coupling_credit(self):
        record = self.record()
        verification = self.verify(record)
        coupling = assess_coupling(
            cost_to_fake=12, benefit_from_fake=2, benefit_from_triggering_defense=5
        )
        quality = evidence_quality(
            record, verification, current_epoch=44, required_liability=30,
            coupling=coupling,
        )
        self.assertTrue(coupling.capturable)
        self.assertEqual(quality.coupling_strength, 0.0)


if __name__ == "__main__":
    unittest.main()
