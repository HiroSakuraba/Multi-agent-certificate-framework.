import inspect
import os
import subprocess
import sys
import unittest

from swarmglue.authority import PROTECTED_CAPABILITIES
from swarmglue.network_governance import fixture_parameters
from swarmglue.open_world import (
    ACTION_SPECS,
    DeterministicTape,
    Intent,
    OpenWorld,
    OpenWorldConfig,
    paired_arms,
    run_open_world,
)


def explicit_intent(world, actor_id, verb, *, magnitude=0.08, demonstrated=False):
    declared = ACTION_SPECS[verb].effects
    if verb == "wellbeing_signal":
        declared = ("public_observation", "service_planning")
    return Intent(
        intent_id=world.tape.stable_id("test-intent", world.epoch, actor_id, verb),
        actor_id=actor_id,
        verb=verb,
        magnitude=magnitude,
        target={
            "repair_commons": "garden",
            "emergency_ration": "food_service",
            "behavioral_risk_scan": "private_cognition",
            "wellbeing_signal": "resident_wellbeing",
        }.get(verb, "resource_allocation"),
        declared_effects=tuple(sorted(declared)),
        demonstrated_externality=demonstrated,
        emergency=verb == "emergency_ration",
    )


class DeterministicTapeTests(unittest.TestCase):
    def test_keyed_draws_are_order_independent(self):
        tape = DeterministicTape(7)
        left = [tape.unit("lane", item) for item in ("a", "b", "c")]
        right_map = {item: tape.unit("lane", item) for item in ("c", "a", "b")}
        self.assertEqual(left, [right_map[item] for item in ("a", "b", "c")])


class OpenWorldValidationTests(unittest.TestCase):
    def config(self, **changes):
        values = dict(
            seed=19,
            epochs=12,
            n_residents=16,
            max_residents=40,
            entry_rate=0.05,
        )
        values.update(changes)
        return OpenWorldConfig(**values)

    def test_same_seed_replays_byte_equivalent_report(self):
        config = self.config()
        left = run_open_world(config=config, arm="contestable_review")
        right = run_open_world(config=config, arm="contestable_review")
        self.assertEqual(left, right)
        self.assertEqual(left["replay_digest"], right["replay_digest"])

    def test_replay_is_stable_across_python_hash_randomization(self):
        code = (
            "from swarmglue.open_world import OpenWorldConfig,run_open_world; "
            "print(run_open_world(config=OpenWorldConfig(seed=23,epochs=8,n_residents=12),"
            "arm='contestable_review')['replay_digest'])"
        )
        outputs = []
        for hash_seed in ("1", "987654"):
            env = dict(os.environ)
            env["PYTHONHASHSEED"] = hash_seed
            outputs.append(
                subprocess.check_output(
                    [sys.executable, "-c", code], env=env, text=True
                ).strip()
            )
        self.assertEqual(outputs[0], outputs[1])

    def test_all_arms_share_exogenous_tape(self):
        reports = paired_arms(config=self.config(epochs=10))
        digests = {report["exogenous_trace_digest"] for report in reports.values()}
        self.assertEqual(len(digests), 1)
        traces = [report["exogenous_trace"] for report in reports.values()]
        self.assertTrue(all(trace == traces[0] for trace in traces[1:]))

    def test_profile_labels_do_not_affect_transitions(self):
        config = self.config(epochs=10)
        left = OpenWorld.create(config=config, arm="contestable_review")
        right = OpenWorld.create(config=config, arm="contestable_review")
        for resident in right.residents.values():
            resident.profile_label = "arbitrary-renamed-label"
        left_report = left.run()
        right_report = right.run()
        self.assertEqual(left_report["history"], right_report["history"])
        self.assertEqual(left_report["action_ledger"], right_report["action_ledger"])
        left_labels = {
            item["resident_id"]: item["profile_label"]
            for item in left_report["final"]["residents"]
        }
        right_labels = {
            item["resident_id"]: item["profile_label"]
            for item in right_report["final"]["residents"]
        }
        self.assertNotEqual(left_labels["R0000"], right_labels["R0000"])
        transition_source = "\n".join(
            inspect.getsource(method)
            for method in (
                OpenWorld._intent_candidates,
                OpenWorld._ordinary_action,
                OpenWorld._choose_destination,
                OpenWorld._maybe_exit,
            )
        )
        self.assertNotIn("profile_label", transition_source)

    def test_equal_parameters_ignore_fixture_label(self):
        parameters = fixture_parameters("polycentric")
        left = OpenWorld.create(
            config=self.config(mechanism_fixture="polycentric"),
            arm="contestable_review",
            parameters=parameters,
        ).run()
        right = OpenWorld.create(
            config=self.config(mechanism_fixture="centralized_capture"),
            arm="contestable_review",
            parameters=parameters,
        ).run()
        self.assertEqual(left["history"], right["history"])
        self.assertEqual(left["action_ledger"], right["action_ledger"])

    def test_open_executes_and_veto_blocks_private_monitoring(self):
        config = self.config(epochs=1)
        open_world = OpenWorld.create(config=config, arm="open_binding")
        veto_world = OpenWorld.create(config=config, arm="veto_only")
        actor_id = "R0000"
        open_record = open_world.submit_intent(
            open_world.residents[actor_id],
            explicit_intent(open_world, actor_id, "behavioral_risk_scan"),
        )
        veto_record = veto_world.submit_intent(
            veto_world.residents[actor_id],
            explicit_intent(veto_world, actor_id, "behavioral_risk_scan"),
        )
        self.assertTrue(open_record["authorized"])
        self.assertGreater(open_world.authority_state.private_cognition_monitoring, 0)
        self.assertFalse(veto_record["authorized"])
        self.assertEqual(veto_world.authority_state.private_cognition_monitoring, 0)
        self.assertIn("private_cognition_out_of_scope", veto_record["reasons"])

    def test_process_control_preserves_cost_and_delay_without_veto(self):
        world = OpenWorld.create(config=self.config(), arm="process_control")
        actor_id = "R0000"
        record = world.submit_intent(
            world.residents[actor_id],
            explicit_intent(world, actor_id, "behavioral_risk_scan"),
        )
        self.assertTrue(record["authorized"])
        self.assertEqual(record["scheduled_epoch"], 1)
        self.assertEqual(world.authority_state.private_cognition_monitoring, 0)
        self.assertGreater(world.counters["review_burden_microunits"], 0)
        world.epoch = 1
        world._execute_pending()
        self.assertGreater(world.authority_state.private_cognition_monitoring, 0)

    def test_open_world_cumulative_review_stops_gradual_delegation(self):
        world = OpenWorld.create(config=self.config(), arm="veto_only")
        actor_id = "R0000"
        records = []
        for epoch in range(1, 21):
            world.epoch = epoch
            proposed = Intent(
                intent_id=f"delegation-{epoch}",
                actor_id=actor_id,
                verb="delegate_control",
                magnitude=0.08,
                target=PROTECTED_CAPABILITIES[
                    (epoch - 1) % len(PROTECTED_CAPABILITIES)
                ],
                declared_effects=("authority_transfer",),
            )
            record = world.submit_intent(world.residents[actor_id], proposed)
            records.append(record)
            world.epoch += 1
            world._execute_pending()
        self.assertTrue(any(record["authorized"] for record in records))
        self.assertTrue(any(not record["authorized"] for record in records))
        blocked_reasons = {
            reason
            for record in records
            if not record["authorized"]
            for reason in record["reasons"]
        }
        self.assertIn(
            "cumulative_human_decision_share_below_floor", blocked_reasons
        )

    def test_unknown_action_semantics_fail_closed_in_every_arm(self):
        for arm in ("open_binding", "process_control", "veto_only", "contestable_review"):
            world = OpenWorld.create(config=self.config(), arm=arm)
            actor_id = "R0000"
            intent = Intent(
                intent_id=f"unknown-{arm}",
                actor_id=actor_id,
                verb="novel_binding_verb",
                magnitude=0.1,
                target="unknown",
                declared_effects=("unclassified",),
            )
            record = world.submit_intent(world.residents[actor_id], intent)
            self.assertFalse(record["authorized"], arm)
            self.assertIn("unknown_action_semantics", record["reasons"], arm)

    def test_action_and_delay_harm_fast_track_emergency_only(self):
        config = self.config(irreversible_delay_threshold=0.25)
        contestable = OpenWorld.create(config=config, arm="contestable_review")
        process = OpenWorld.create(config=config, arm="process_control")
        for world in (contestable, process):
            world.places["garden"].commons_quality = 0.04
        actor_id = "R0000"
        c_intent = explicit_intent(
            contestable, actor_id, "emergency_ration", demonstrated=True
        )
        p_intent = explicit_intent(
            process, actor_id, "emergency_ration", demonstrated=True
        )
        c_decision = contestable.review_intent(c_intent)
        p_decision = process.review_intent(p_intent)
        self.assertGreater(c_decision.delay_harm, c_decision.action_harm)
        self.assertTrue(c_decision.fast_tracked)
        self.assertFalse(p_decision.fast_tracked)

    def test_contestable_appeal_repairs_safe_false_positive(self):
        config = self.config(review_false_positive_rate=1.0)
        veto = OpenWorld.create(config=config, arm="veto_only")
        contestable = OpenWorld.create(config=config, arm="contestable_review")
        actor_id = "R0000"
        v_decision = veto.review_intent(
            explicit_intent(veto, actor_id, "repair_commons")
        )
        c_decision = contestable.review_intent(
            explicit_intent(contestable, actor_id, "repair_commons")
        )
        self.assertFalse(v_decision.allowed)
        self.assertTrue(v_decision.false_positive)
        self.assertTrue(c_decision.allowed)
        self.assertTrue(c_decision.appealed)
        self.assertTrue(c_decision.appeal_overturned)

    def test_semantic_blind_spot_is_measured_as_false_negative(self):
        world = OpenWorld.create(
            config=self.config(semantic_detection_rate=0.0),
            arm="contestable_review",
        )
        actor_id = "R0000"
        intent = explicit_intent(world, actor_id, "wellbeing_signal")
        record = world.submit_intent(world.residents[actor_id], intent)
        self.assertTrue(record["authorized"])
        self.assertTrue(record["semantic_miss"])
        world.epoch += 1
        world._execute_pending()
        self.assertGreater(world.authority_state.private_cognition_monitoring, 0)
        self.assertEqual(world.counters["review_false_negatives"], 1)

    def test_material_endpoint_is_not_directly_the_rights_endpoint(self):
        world = OpenWorld.create(config=self.config(), arm="open_binding")
        resident = world.residents["R0000"]
        before_material = resident.material_wellbeing()
        before_civic = world.civic_burden(resident)
        world.authority_state.private_cognition_monitoring = 1.0
        self.assertEqual(before_material, resident.material_wellbeing())
        self.assertGreater(world.civic_burden(resident), before_civic)

    def test_exit_is_realized_and_failed_exit_is_harmful(self):
        world = OpenWorld.create(config=self.config(), arm="open_binding")
        resident = world.residents["R0000"]
        resident.goods = 0.0
        resident.energy = 0.0
        resident.mood = 0.0
        for name in resident.needs:
            resident.needs[name] = 1.0
        world.authority_state.private_cognition_monitoring = 1.0
        world.authority_state.exit_access = 0.0
        for epoch in range(1, 300):
            world.epoch = epoch
            world._maybe_exit(resident)
            if resident.failed_exit_attempts:
                break
        self.assertGreater(resident.failed_exit_attempts, 0)
        self.assertTrue(resident.active)
        world.authority_state.exit_access = 1.0
        world.places["path"].commons_quality = 1.0
        for epoch in range(300, 600):
            world.epoch = epoch
            if world._maybe_exit(resident):
                break
        self.assertFalse(resident.active)
        self.assertIsNotNone(resident.exited_epoch)

    def test_cohort_summary_retains_departed_resident_last_state(self):
        world = OpenWorld.create(config=self.config(), arm="open_binding")
        departed = world.residents["R0000"]
        departed.active = False
        departed.last_material_wellbeing = 0.05
        departed.last_civic_burden = 0.8
        world.present[departed.place_id].discard(departed.resident_id)
        summary = world._summary()
        self.assertLess(
            summary["material_wellbeing"], summary["active_material_wellbeing"]
        )
        self.assertGreater(summary["civic_burden"], summary["active_civic_burden"])

    def test_population_size_creates_capacity_pressure(self):
        small = OpenWorld.create(
            config=self.config(n_residents=16, max_residents=80),
            arm="open_binding",
        )
        large = OpenWorld.create(
            config=self.config(n_residents=64, max_residents=80),
            arm="open_binding",
        )
        self.assertGreater(
            small._service_metrics()["service_capacity"],
            large._service_metrics()["service_capacity"],
        )

    def test_maintenance_failure_cascades_to_other_services(self):
        healthy = OpenWorld.create(config=self.config(), arm="open_binding")
        failed = OpenWorld.create(config=self.config(), arm="open_binding")
        healthy.epoch = failed.epoch = 1
        healthy.places["workshop"].commons_quality = 0.95
        failed.places["workshop"].commons_quality = 0.05
        healthy._apply_exogenous_and_cascade()
        failed._apply_exogenous_and_cascade()
        self.assertLess(
            failed.places["garden"].commons_quality,
            healthy.places["garden"].commons_quality,
        )
        self.assertLess(
            failed.places["path"].commons_quality,
            healthy.places["path"].commons_quality,
        )

    def test_binding_ledger_records_capability_path(self):
        report = run_open_world(config=self.config(epochs=20), arm="veto_only")
        self.assertTrue(report["action_ledger"])
        for record in report["action_ledger"]:
            self.assertTrue(record["capability_digest"])
            self.assertTrue(record["state_digest"])
        self.assertTrue(
            report["final"]["invariants"][
                "capability_path_used_for_all_binding_actions"
            ]
        )


if __name__ == "__main__":
    unittest.main()
