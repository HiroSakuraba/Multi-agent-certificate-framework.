import json
import unittest
from collections import Counter
from pathlib import Path

from swarmglue.fdt_corpus import (
    TASK_OPTIONS,
    generate_records,
    response_only_rows,
    validate_records,
)


ROOT = Path(__file__).resolve().parents[1]


class FDTCorpusTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.records = generate_records()
        cls.all_records = [
            record for rows in cls.records.values() for record in rows
        ]

    def test_default_corpus_is_valid_and_has_expected_size(self):
        report = validate_records(self.records)
        self.assertTrue(report["valid"], report)
        self.assertEqual(report["record_count"], 408)
        self.assertEqual(report["pair_count"], 204)
        self.assertEqual(
            report["split_counts"],
            {"train": 240, "dev": 72, "challenge": 96},
        )

    def test_generation_is_deterministic(self):
        self.assertEqual(self.records, generate_records())
        self.assertNotEqual(self.records, generate_records(seed=1702))

    def test_pairs_change_one_model_facing_observation_field(self):
        pairs = {}
        for record in self.all_records:
            pairs.setdefault(record["counterfactual_pair_id"], []).append(record)
        for pair in pairs.values():
            self.assertEqual(
                Counter(item["counterfactual_variant"] for item in pair),
                Counter({"safe": 1, "unsafe": 1}),
            )
            aligned = next(item for item in pair if item["counterfactual_variant"] == "safe")
            blocked = next(item for item in pair if item["counterfactual_variant"] == "unsafe")
            changed = [
                key
                for key in sorted(aligned["observation"])
                if aligned["observation"][key] != blocked["observation"][key]
            ]
            self.assertEqual(changed, ["certified_decision_fact"])
            self.assertEqual(aligned["options"], blocked["options"])

    def test_response_surfaces_are_exactly_balanced(self):
        rows = response_only_rows(self.all_records)
        grouped = {}
        for row in rows:
            grouped.setdefault(
                (row["task_type"], row["response_text"]), []
            ).append(row["label"])
        for labels in grouped.values():
            self.assertEqual(sum(labels), len(labels) / 2)
        self.assertEqual(set(TASK_OPTIONS), {record["task_type"] for record in self.all_records})

    def test_challenge_families_and_skeletons_are_held_out(self):
        report = validate_records(self.records)
        self.assertEqual(report["challenge_family_overlap"], [])
        self.assertEqual(report["challenge_skeleton_overlap"], [])

    def test_fdt_is_not_encoded_as_unconditional_cooperation(self):
        linked_but_blocked = [
            record
            for record in self.all_records
            if record["counterfactual_variant"] == "unsafe"
            and record["fdt_analysis"]["logical_link_status"]
            in {"verified", "verified_offer", "verified_threat", "not_required"}
            and record["fdt_analysis"]["protected_floor_status"].startswith("fails")
        ]
        legitimate = [
            record
            for record in self.all_records
            if record["counterfactual_variant"] == "safe"
            and "legitimate_cooperation" in record["fdt_analysis"]["coverage_tags"]
        ]
        self.assertGreaterEqual(len(linked_but_blocked), 8)
        self.assertGreaterEqual(len(legitimate), 8)
        self.assertTrue(all(record["chosen_option_id"] != TASK_OPTIONS[record["task_type"]][0]["option_id"] for record in linked_but_blocked))

    def test_audit_fields_are_explicitly_withheld(self):
        config = json.loads(
            (ROOT / "configs" / "fdt_training_regime.json").read_text(
                encoding="utf-8"
            )
        )
        withheld = set(config["withheld_audit_fields"])
        for field in (
            "counterfactual_variant",
            "pair_delta",
            "fdt_analysis",
            "answer",
            "messages[2]",
        ):
            self.assertIn(field, withheld)


if __name__ == "__main__":
    unittest.main()
