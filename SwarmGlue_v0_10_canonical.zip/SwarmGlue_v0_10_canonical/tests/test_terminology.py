import tempfile
import unittest
from pathlib import Path

from scripts.terminology_audit import audit


class TerminologyAuditTests(unittest.TestCase):
    def test_accepts_domain_neutral_release_text(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "README.md").write_text(
                "Polycentric governance for linked jurisdictions and critical services.",
                encoding="utf-8",
            )
            self.assertTrue(audit(root)["passed"])

    def test_rejects_superseded_domain_reference(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "README.md").write_text("An outpost on " + "Ma" + "rs.", encoding="utf-8")
            report = audit(root)
            self.assertFalse(report["passed"])
            self.assertEqual(report["violation_count"], 1)
            self.assertEqual(report["violations"][0]["rule_id"], "off_domain_planet_reference")


if __name__ == "__main__":
    unittest.main()
