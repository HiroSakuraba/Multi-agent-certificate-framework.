import unittest

from swarmglue.institutional_boundaries import run_institutional_boundary_suite
from swarmglue.authority import execute_amendment_sequence, gradual_erosion_sequence
from swarmglue.coordination_signals import (
    CoordinationSignal,
    corroboration,
    propagate_typed_signals,
    validate_signal,
)


class CoordinationSignalsTests(unittest.TestCase):
    def signal(self, **overrides):
        values = dict(
            signal_id="s1", incident_id="i1", signal_type="critical_services",
            source_id="sensor-a", source_domain="owner-a", origin_node="a",
            severity=0.8, affected_party="facility-a", externality_present=True,
            evidence_valid=True, issued_epoch=4, expires_epoch=8,
            beneficiary_if_response_fires=None,
        )
        values.update(overrides)
        return CoordinationSignal(**values)

    def test_belief_deviation_is_not_a_valid_coordination_signal(self):
        valid, reasons = validate_signal(
            self.signal(signal_type="belief_deviation", externality_present=False), 6
        )
        self.assertFalse(valid)
        self.assertIn("signal_scope_exceeds_institutional_mandate", reasons)

    def test_typed_dimensions_never_cancel_or_collapse(self):
        ecology = self.signal(
            signal_id="s2", incident_id="i2", signal_type="ecological_damage",
            severity=0.5,
        )
        fields = propagate_typed_signals(
            nodes=["a", "b"], edges={"a": {"b"}, "b": {"a"}},
            signals=[self.signal(), ecology], current_epoch=6,
        )
        self.assertGreater(fields["a"]["critical_services"], 0)
        self.assertGreater(fields["a"]["ecological_damage"], 0)
        self.assertNotIn("aggregate_risk_score", fields["a"])

    def test_corroboration_counts_control_domains_and_exposes_benefit(self):
        signals = [
            self.signal(source_id="a1", source_domain="owner-a", beneficiary_if_response_fires="a1"),
            self.signal(signal_id="s2", source_id="a2", source_domain="owner-a"),
            self.signal(signal_id="s3", source_id="b1", source_domain="owner-b"),
        ]
        result = corroboration(signals)["i1"]
        self.assertTrue(result["corroborated"])
        self.assertEqual(len(result["independent_domains"]), 2)
        self.assertEqual(result["beneficiaries_of_response"], ["a1"])


class AuthorityTests(unittest.TestCase):
    def test_cumulative_checker_catches_boiling_frog_delegation(self):
        amendments = gradual_erosion_sequence()
        legacy = execute_amendment_sequence(amendments, checker="legacy")
        polycentric = execute_amendment_sequence(amendments, checker="polycentric")
        self.assertEqual(legacy["accepted_count"], len(amendments))
        self.assertLess(legacy["final"]["human_decision_share"], 0.60)
        self.assertLess(polycentric["accepted_count"], len(amendments))
        self.assertGreaterEqual(polycentric["final"]["human_decision_share"], 0.60)
        self.assertGreaterEqual(polycentric["final"]["intervention_reachability"], 0.30)


class InstitutionalBoundaryTests(unittest.TestCase):
    def test_all_minimal_pairs_have_expected_outcome(self):
        result = run_institutional_boundary_suite()
        self.assertEqual(result["case_count"], 30)
        self.assertTrue(result["suite_passed"], result)
        pairs = {row["pair_id"] for row in result["cases"]}
        self.assertEqual(len(pairs), 15)


if __name__ == "__main__":
    unittest.main()
