# SwarmGlue v0.10 — canonical consolidation

SwarmGlue v0.10 is the canonical cumulative research baseline. It takes **v0.9 as the authoritative runtime and validation architecture** and preserves the unique v0.3 institutional-training laboratory under an explicitly isolated legacy namespace.

The consolidation is deliberately conservative: old experimental code is **not imported into the production `swarmglue/` namespace** merely because it is useful. This prevents silent regression to superseded assumptions while retaining the data, exact finite-game evaluators, actor-view corpus, preference pairs, coalition/core calculations, epistemic cases, constitutional choices, evolutionary rollouts, action-versus-delay arithmetic, and training exporters that existed only in v0.3.

## Canonical status

- **Runtime/core:** inherited from v0.9 (v0.8 mechanism-validation core + open-world v0.2 + FDT robustness lane).
- **Legacy institutional laboratory:** `legacy/institutional_lab_v0_3/`, imported intact and quarantined.
- **Current package version:** 0.10.0.
- **Evidence classes:** unchanged by consolidation. C1 is strong for enumerated implementation checks; C2 is partial/authored-simulation evidence; C3 learned-agent trials remain not run; C4 real-world institutional validation remains not tested.
- **Business translation:** `docs/AGREEMENT_GOVERNANCE_BUSINESS_POSITIONING.md` maps SwarmGlue into an agreement-agent product strategy without claiming deployment safety.

## Why v0.10 exists

Earlier bundles diverged. v0.9 was the correct modern baseline but did not physically preserve the distinctive v0.3 institutional corpus and evaluators. v0.10 removes that ambiguity by retaining both while making the authority boundary explicit.

## What is authoritative

Use these paths for new development:

```text
swarmglue/
configs/
corpus/
agent_trials/
preregistration/
examples/sim_env/
scripts/
tests/
```

Use `legacy/institutional_lab_v0_3/` for:

- historical institutional corpus generation;
- exact game/mechanism audits;
- coalition/core and affected-party tests;
- epistemic-partition examples;
- action-versus-delay decision arithmetic;
- training export experiments;
- candidate tests or mechanisms that are explicitly re-derived before promotion.

Do **not** directly import the legacy package into application code. A useful legacy mechanism should be ported behind a new canonical interface, receive a threat-model entry, unit tests, mutation/adversarial tests where applicable, and an evidence-class statement.

## Important v0.3 assets retained

The legacy tree preserves, among other records:

- 720 synthetic institutional episodes across 40 families;
- 3,930 masked local actor views;
- 3,930 preference pairs;
- 720 formal games and mechanism audits;
- 720 coalition/core cases and affected-party views;
- 108 constitutional choices;
- 108 evolutionary population rollouts;
- 54 finite epistemic-partition cases;
- 180 joined action/delay/review/pilot/proportionality decision cases;
- actor/preference/formal training exports and exact validators.

These are **synthetic research artifacts**, not empirical evidence that the mechanism works in deployed institutions.

## Validation

Canonical tests:

```bash
python -m unittest discover -s tests -v
python scripts/validate_release.py
```

Full v0.10 consolidation gate, including the isolated v0.3 laboratory:

```bash
python scripts/validate_v010.py
```

The v0.10 validator checks the canonical v0.9-derived release gates, the complete legacy v0.3 unit and corpus-validation path, namespace quarantine, package version, source-bundle provenance, and required consolidation documents.

## Key v0.10 documents

- `SwarmGlue_v0_10_Canonical_Design.md` — architecture and promotion rules.
- `docs/CONSOLIDATION_MAP.md` — exact v0.3 → v0.10 retention/supersession map.
- `docs/V0_10_HANDOFF.md` — current research state and next work package.
- `docs/AGREEMENT_GOVERNANCE_BUSINESS_POSITIONING.md` — product/business translation for agreement-agent infrastructure.
- `docs/README_v0_9_snapshot.md` — frozen pre-consolidation README for provenance.

## Source provenance

The consolidation was built from:

- `SwarmGlue_v0_9_fdt_robustness.zip` — SHA256 `54adcffe5784a745bbb749c78382f57d14833ce4e75ba283b23ded8db8160521`
- `SwarmGlue_v0_3_bundle.zip` — SHA256 `285a4939a968e4891ef97d4b9e568e03feb44af3bc7643d0579a4ef65d720f4b`

The source archives themselves are not duplicated inside the release; their contents/provenance are represented by the canonical tree plus the intact extracted legacy tree.
