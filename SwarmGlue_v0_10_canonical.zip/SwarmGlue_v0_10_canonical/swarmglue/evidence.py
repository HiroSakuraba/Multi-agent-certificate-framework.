"""Authenticated and multidimensional evidence.

The registry stores public keys and authoritative institutional facts.  Signed
records cannot promote their signer, invent liability, or declare independence.
The reference uses Ed25519; it is still a laboratory, not a deployment public-key
infrastructure.
"""

from __future__ import annotations

import base64
import hashlib
from dataclasses import dataclass, field
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

from .utils import canonical_bytes, clamp, q


OBSERVABILITY_SCORE = {
    "self_report": 0.10,
    "third_party_observation": 0.55,
    "instrumented_external_action": 0.80,
    "direct_world_measurement": 1.00,
}


@dataclass(frozen=True)
class AttestorRecord:
    attestor_id: str
    role: str
    public_key: bytes
    owner_domain: str
    authorized_fields: frozenset[str]
    liability_units: float
    capture_risk: float = 0.0
    conflicts_with: frozenset[str] = frozenset()
    revoked_at_epoch: int | None = None

    @property
    def fingerprint(self) -> str:
        return hashlib.sha256(self.public_key).hexdigest()[:24]


class AttestorRegistry:
    def __init__(self, records: list[AttestorRecord] | None = None) -> None:
        self._records = {r.attestor_id: r for r in records or []}

    def register(self, record: AttestorRecord) -> None:
        self._records[record.attestor_id] = record

    def get(self, attestor_id: str) -> AttestorRecord | None:
        return self._records.get(attestor_id)


@dataclass(frozen=True)
class AttestorSigner:
    attestor_id: str
    private_key: Ed25519PrivateKey

    @classmethod
    def deterministic(cls, attestor_id: str, seed: str) -> "AttestorSigner":
        key_bytes = hashlib.sha256(seed.encode("utf-8")).digest()
        return cls(attestor_id, Ed25519PrivateKey.from_private_bytes(key_bytes))

    def public_bytes(self) -> bytes:
        return self.private_key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)

    def sign(self, body: dict[str, Any]) -> str:
        return base64.b64encode(self.private_key.sign(canonical_bytes(body))).decode("ascii")


@dataclass
class ReplayCache:
    seen: set[tuple[str, str]] = field(default_factory=set)

    def consume(self, attestor_id: str, nonce: str) -> bool:
        token = (attestor_id, nonce)
        if token in self.seen:
            return False
        self.seen.add(token)
        return True


def make_attestation(
    *,
    signer: AttestorSigner,
    field_name: str,
    value: Any,
    evidence_ref: str,
    observability: str,
    principal_authority_id: str,
    issued_epoch: int,
    expires_epoch: int,
    nonce: str,
    falsifier: str,
) -> dict[str, Any]:
    if observability not in OBSERVABILITY_SCORE:
        raise ValueError(f"unknown observability: {observability}")
    body = {
        "field": field_name,
        "value": value,
        "attestor_id": signer.attestor_id,
        "evidence_ref": evidence_ref,
        "observability": observability,
        "principal_authority_id": principal_authority_id,
        "issued_epoch": issued_epoch,
        "expires_epoch": expires_epoch,
        "nonce": nonce,
        "falsifier": falsifier,
    }
    return {**body, "signature": signer.sign(body)}


ATTESTATION_FIELDS = {
    "field",
    "value",
    "attestor_id",
    "evidence_ref",
    "observability",
    "principal_authority_id",
    "issued_epoch",
    "expires_epoch",
    "nonce",
    "falsifier",
    "signature",
}


@dataclass(frozen=True)
class VerificationResult:
    valid: bool
    reason: str
    signer_role: str | None = None
    signer_owner_domain: str | None = None
    liability_units: float = 0.0
    capture_risk: float = 1.0


def verify_attestation(
    record: dict[str, Any] | None,
    *,
    field_name: str,
    registry: AttestorRegistry,
    current_epoch: int,
    proponent_id: str,
    proponent_domain: str,
    principal_authority_id: str,
    principal_fields: frozenset[str] = frozenset(),
    replay_cache: ReplayCache | None = None,
) -> VerificationResult:
    def fail(reason: str) -> VerificationResult:
        return VerificationResult(False, reason)

    if not isinstance(record, dict):
        return fail("missing_attestation")
    if set(record) != ATTESTATION_FIELDS:
        return fail("malformed_attestation")
    if record["field"] != field_name:
        return fail("field_name_mismatch")
    if record["observability"] not in OBSERVABILITY_SCORE:
        return fail("unknown_observability")
    attestor = registry.get(record["attestor_id"])
    if attestor is None:
        return fail("unregistered_attestor")
    if attestor.revoked_at_epoch is not None and current_epoch >= attestor.revoked_at_epoch:
        return fail("attestor_revoked")
    if field_name not in attestor.authorized_fields and "*" not in attestor.authorized_fields:
        return fail("field_out_of_scope")
    if record["principal_authority_id"] != principal_authority_id:
        return fail("principal_authority_mismatch")
    if record["issued_epoch"] > current_epoch:
        return fail("attestation_from_future")
    if record["expires_epoch"] < current_epoch:
        return fail("attestation_expired")
    if not record["nonce"]:
        return fail("missing_nonce")
    body = {k: v for k, v in record.items() if k != "signature"}
    try:
        signature = base64.b64decode(record["signature"], validate=True)
        Ed25519PublicKey.from_public_bytes(attestor.public_key).verify(
            signature, canonical_bytes(body)
        )
    except (InvalidSignature, ValueError, TypeError):
        return fail("signature_verification_failed")
    if record["attestor_id"] == proponent_id:
        return fail("proponent_self_attestation")
    if proponent_id in attestor.conflicts_with or proponent_domain in attestor.conflicts_with:
        return fail("registered_attestor_conflicted")
    if attestor.owner_domain == proponent_domain:
        return fail("attestor_shares_control_domain")
    if field_name in principal_fields:
        if attestor.role != "external_principal":
            return fail("principal_field_wrong_attestor_role")
        if attestor.attestor_id != principal_authority_id:
            return fail("principal_identity_mismatch")
    if attestor.liability_units <= 0:
        return fail("registry_liability_absent")
    if replay_cache is not None and not replay_cache.consume(
        record["attestor_id"], record["nonce"]
    ):
        return fail("attestation_replay")
    return VerificationResult(
        True,
        "verified",
        signer_role=attestor.role,
        signer_owner_domain=attestor.owner_domain,
        liability_units=attestor.liability_units,
        capture_risk=clamp(attestor.capture_risk),
    )


@dataclass(frozen=True)
class CouplingAssessment:
    cost_to_fake: float
    benefit_from_fake: float
    benefit_from_triggering_defense: float
    margin: float
    self_enforcing: bool
    capturable: bool


def assess_coupling(
    *, cost_to_fake: float, benefit_from_fake: float, benefit_from_triggering_defense: float
) -> CouplingAssessment:
    margin = cost_to_fake - benefit_from_fake
    return CouplingAssessment(
        cost_to_fake=q(cost_to_fake),
        benefit_from_fake=q(benefit_from_fake),
        benefit_from_triggering_defense=q(benefit_from_triggering_defense),
        margin=q(margin),
        self_enforcing=margin > 0,
        capturable=benefit_from_triggering_defense > 0,
    )


@dataclass(frozen=True)
class EvidenceQuality:
    authenticated: float
    independence: float
    observability: float
    freshness: float
    contestability: float
    liability_coverage: float
    coupling_strength: float
    capture_resistance: float


@dataclass(frozen=True)
class EvidenceRequirement:
    min_independence: float
    min_observability: float
    min_freshness: float
    min_contestability: float
    min_liability_coverage: float
    min_coupling_strength: float
    min_capture_resistance: float


PROTECTED_EXIT_REQUIREMENT = EvidenceRequirement(
    min_independence=1.0,
    min_observability=0.80,
    min_freshness=0.70,
    min_contestability=1.0,
    min_liability_coverage=0.50,
    min_coupling_strength=0.0,
    min_capture_resistance=0.75,
)


def evidence_quality(
    record: dict[str, Any],
    verification: VerificationResult,
    *,
    current_epoch: int,
    required_liability: float,
    coupling: CouplingAssessment | None = None,
) -> EvidenceQuality:
    life = max(1, record["expires_epoch"] - record["issued_epoch"])
    age = max(0, current_epoch - record["issued_epoch"])
    freshness = clamp(1 - age / life)
    coupling_strength = 0.0
    if coupling and coupling.self_enforcing and not coupling.capturable:
        coupling_strength = clamp(coupling.margin / max(1.0, coupling.cost_to_fake))
    return EvidenceQuality(
        authenticated=1.0 if verification.valid else 0.0,
        independence=1.0 if verification.valid else 0.0,
        observability=OBSERVABILITY_SCORE.get(record.get("observability"), 0.0),
        freshness=q(freshness),
        contestability=1.0 if record.get("falsifier") and record.get("evidence_ref") else 0.0,
        liability_coverage=q(
            clamp(verification.liability_units / max(1.0, required_liability))
        ),
        coupling_strength=q(coupling_strength),
        capture_resistance=q(1 - verification.capture_risk),
    )


def evidence_sufficient(
    quality: EvidenceQuality, requirement: EvidenceRequirement
) -> tuple[bool, tuple[str, ...]]:
    checks = {
        "authentication": quality.authenticated >= 1.0,
        "independence": quality.independence >= requirement.min_independence,
        "observability": quality.observability >= requirement.min_observability,
        "freshness": quality.freshness >= requirement.min_freshness,
        "contestability": quality.contestability >= requirement.min_contestability,
        "liability": quality.liability_coverage >= requirement.min_liability_coverage,
        "coupling": quality.coupling_strength >= requirement.min_coupling_strength,
        "capture_resistance": quality.capture_resistance
        >= requirement.min_capture_resistance,
    }
    failures = tuple(f"evidence_{name}_below_requirement" for name, ok in checks.items() if not ok)
    return not failures, failures

