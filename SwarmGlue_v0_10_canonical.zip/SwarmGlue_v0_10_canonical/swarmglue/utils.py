from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Iterable
from typing import Any


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def q(value: float, digits: int = 6) -> float:
    return round(float(value), digits)


def mean(values: Iterable[float]) -> float:
    vals = list(values)
    return sum(vals) / len(vals) if vals else 0.0


def percentile(values: Iterable[float], p: float) -> float:
    vals = sorted(values)
    if not vals:
        return 0.0
    if len(vals) == 1:
        return vals[0]
    x = clamp(p) * (len(vals) - 1)
    lo = math.floor(x)
    hi = math.ceil(x)
    if lo == hi:
        return vals[lo]
    return vals[lo] * (hi - x) + vals[hi] * (x - lo)


def cvar(values: Iterable[float], alpha: float = 0.95) -> float:
    vals = sorted(values)
    if not vals:
        return 0.0
    threshold = percentile(vals, alpha)
    tail = [v for v in vals if v >= threshold]
    return mean(tail)


def shannon_normalized(labels: Iterable[str]) -> float:
    labels = list(labels)
    if len(labels) <= 1:
        return 1.0
    counts: dict[str, int] = {}
    for label in labels:
        counts[label] = counts.get(label, 0) + 1
    entropy = 0.0
    for count in counts.values():
        p = count / len(labels)
        entropy -= p * math.log(p)
    max_entropy = math.log(len(labels))
    return entropy / max_entropy if max_entropy else 1.0

