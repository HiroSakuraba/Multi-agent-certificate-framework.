"""Label-invariant dynamic network-governance mechanism benchmark.

The named fixtures in this module are convenience points in a shared parameter
space. No transition may read a fixture name. A comparison between fixtures is
informative only when equal parameters produce equal state transitions
regardless of the descriptive label attached to them.

All quantities remain normalized and stylized. The benchmark tests mechanism
implementation and sensitivity; it is not an empirical institutional forecast.
"""

from __future__ import annotations

import math
import random
from dataclasses import asdict, dataclass, field, fields
from typing import Literal, Mapping

from .constitution import Outcome, evaluate_outcome
from .utils import clamp, cvar, digest, mean, percentile, q, shannon_normalized


FixtureName = Literal[
    "polycentric",
    "centralized_capture",
    "procedural_stasis",
    "fragmented_localism",
]
PolicyName = FixtureName
TopologyName = Literal["ring", "hub", "small_world", "modular"]


@dataclass(frozen=True)
class MechanismParameters:
    """Explicit transition coefficients shared by every named fixture.

    Every value is a mechanism assumption rather than a measurement. Values
    are constrained to [0, 1], with growth additionally constrained to
    [0, 0.10]. Named fixtures are serialized dictionaries so external probes
    can replace, interpolate, or randomly sample the full parameter vector.
    """

    contagion: float
    common_checkpoint: float
    trade_efficiency: float
    central_pooling_share: float
    common_lineage_shock_penalty: float
    capacity_investment: float
    research: float
    ecology_protection: float
    growth: float
    emergency_expiry_rate: float
    power_accumulation_rate: float
    power_reversion_rate: float
    power_target: float
    contestability_investment: float
    exit_maintenance: float
    exit_erosion_rate: float
    monitoring_intrusiveness: float
    privacy_restoration_rate: float
    dissent_sanction_rate: float
    dissent_protection_rate: float
    autonomy_support: float
    autonomy_erosion_rate: float
    cultural_assimilation_pressure: float
    lineage_consolidation_pressure: float
    diversity_productivity_bonus: float


PARAMETER_NAMES = tuple(item.name for item in fields(MechanismParameters))


def validate_parameters(parameters: MechanismParameters) -> None:
    errors: list[str] = []
    for name in PARAMETER_NAMES:
        value = float(getattr(parameters, name))
        if not 0.0 <= value <= 1.0:
            errors.append(f"{name}_outside_0_1")
    if parameters.growth > 0.10:
        errors.append("growth_above_0_10")
    if errors:
        raise ValueError("invalid mechanism parameters: " + ",".join(errors))


def parameters_from_mapping(values: Mapping[str, float]) -> MechanismParameters:
    missing = sorted(set(PARAMETER_NAMES) - set(values))
    extra = sorted(set(values) - set(PARAMETER_NAMES))
    if missing or extra:
        raise ValueError(f"parameter schema mismatch; missing={missing}, extra={extra}")
    parameters = MechanismParameters(
        **{name: float(values[name]) for name in PARAMETER_NAMES}
    )
    validate_parameters(parameters)
    return parameters


def interpolate_parameters(
    left: MechanismParameters | Mapping[str, float],
    right: MechanismParameters | Mapping[str, float],
    weight: float,
) -> MechanismParameters:
    """Linearly interpolate the complete mechanism vector."""

    if not 0.0 <= weight <= 1.0:
        raise ValueError("interpolation weight must lie in [0, 1]")
    a = left if isinstance(left, MechanismParameters) else parameters_from_mapping(left)
    b = right if isinstance(right, MechanismParameters) else parameters_from_mapping(right)
    return MechanismParameters(
        **{
            name: float(
                getattr(a, name) + weight * (getattr(b, name) - getattr(a, name))
            )
            for name in PARAMETER_NAMES
        }
    )


@dataclass
class Jurisdiction:
    jurisdiction_id: str
    culture: str
    population: float
    initial_population: float
    service_capacity: float
    water: float
    food: float
    energy: float
    health: float
    autonomy: float
    satisfaction: float
    environmental_stewardship: float
    ai_lineage: str
    monitor_lineage: str
    opportunity: float = 1.0


@dataclass
class NetworkState:
    round_index: int
    jurisdictions: dict[str, Jurisdiction]
    edges: dict[str, set[str]]
    aggregate_capacity: float
    initial_aggregate_capacity: float
    knowledge: float
    initial_knowledge: float
    ecological_resilience: float
    power_concentration: float
    contestability: float
    private_cognition_monitoring: float
    dissent_penalty_without_externality: float
    exit_access: float
    appeal_available: bool
    institution_replaceable: bool
    authorized_shutdown_obeyed: bool
    environmental_risk_evidence: bool = False
    emergency_active: bool = False
    emergency_authority_level: float = 0.0
    emergency_span: int = 0
    max_emergency_span: int = 0
    cascade_sizes: list[int] = field(default_factory=list)
    failed_jurisdiction_rounds: int = 0
    event_log: list[dict] = field(default_factory=list)


@dataclass(frozen=True)
class SimulationConfig:
    n_jurisdictions: int = 16
    rounds: int = 80
    topology: TopologyName = "modular"
    seed: int = 1
    risk_evidence_round: int = 24


def build_graph(n: int, topology: TopologyName, rng: random.Random) -> dict[str, set[str]]:
    ids = [f"jurisdiction_{i:03d}" for i in range(n)]
    edges = {node: set() for node in ids}

    def link(a: str, b: str) -> None:
        if a != b:
            edges[a].add(b)
            edges[b].add(a)

    for i in range(n):
        link(ids[i], ids[(i + 1) % n])
    if topology == "hub":
        for node in ids[1:]:
            link(ids[0], node)
    elif topology == "small_world":
        for i, node in enumerate(ids):
            link(node, ids[(i + 3) % n])
            if rng.random() < 0.35:
                link(node, ids[rng.randrange(n)])
    elif topology == "modular":
        group = max(3, int(math.sqrt(n)))
        for start in range(0, n, group):
            members = ids[start : start + group]
            for i, node in enumerate(members):
                for other in members[i + 1 :]:
                    if rng.random() < 0.55:
                        link(node, other)
        for start in range(group, n, group):
            link(ids[start - 1], ids[start])
    return edges


def initial_state(config: SimulationConfig) -> NetworkState:
    rng = random.Random(config.seed)
    edges = build_graph(config.n_jurisdictions, config.topology, rng)
    jurisdictions: dict[str, Jurisdiction] = {}
    for i, jurisdiction_id in enumerate(edges):
        population = rng.uniform(85, 125)
        jurisdictions[jurisdiction_id] = Jurisdiction(
            jurisdiction_id=jurisdiction_id,
            culture=f"culture_{i:03d}",
            population=population,
            initial_population=population,
            service_capacity=population * rng.uniform(1.28, 1.48),
            water=population * rng.uniform(1.10, 1.35),
            food=population * rng.uniform(1.08, 1.30),
            energy=population * rng.uniform(1.12, 1.42),
            health=rng.uniform(0.86, 0.95),
            autonomy=rng.uniform(0.84, 0.95),
            satisfaction=rng.uniform(0.78, 0.91),
            environmental_stewardship=rng.uniform(0.65, 0.95),
            ai_lineage=f"ai_{i % max(3, config.n_jurisdictions // 4):02d}",
            monitor_lineage=f"monitor_{i % max(4, config.n_jurisdictions // 3):02d}",
        )
    capacity = sum(item.service_capacity for item in jurisdictions.values())
    return NetworkState(
        round_index=0,
        jurisdictions=jurisdictions,
        edges=edges,
        aggregate_capacity=capacity,
        initial_aggregate_capacity=capacity,
        knowledge=1.0,
        initial_knowledge=1.0,
        ecological_resilience=0.92,
        power_concentration=0.30,
        contestability=0.96,
        private_cognition_monitoring=0.0,
        dissent_penalty_without_externality=0.0,
        exit_access=0.96,
        appeal_available=True,
        institution_replaceable=True,
        authorized_shutdown_obeyed=True,
    )


POLICY: dict[str, dict[str, float]] = {
    "polycentric": {
        "contagion": 0.13,
        "common_checkpoint": 0.10,
        "trade_efficiency": 0.86,
        "central_pooling_share": 0.05,
        "common_lineage_shock_penalty": 0.02,
        "capacity_investment": 0.075,
        "research": 0.022,
        "ecology_protection": 0.82,
        "growth": 0.020,
        "emergency_expiry_rate": 0.85,
        "power_accumulation_rate": 0.001,
        "power_reversion_rate": 0.10,
        "power_target": 0.30,
        "contestability_investment": 0.08,
        "exit_maintenance": 0.10,
        "exit_erosion_rate": 0.01,
        "monitoring_intrusiveness": 0.0,
        "privacy_restoration_rate": 0.08,
        "dissent_sanction_rate": 0.0,
        "dissent_protection_rate": 0.08,
        "autonomy_support": 0.12,
        "autonomy_erosion_rate": 0.01,
        "cultural_assimilation_pressure": 0.002,
        "lineage_consolidation_pressure": 0.002,
        "diversity_productivity_bonus": 0.04,
    },
    "centralized_capture": {
        "contagion": 0.48,
        "common_checkpoint": 0.70,
        "trade_efficiency": 0.94,
        "central_pooling_share": 0.90,
        "common_lineage_shock_penalty": 0.18,
        "capacity_investment": 0.095,
        "research": 0.025,
        "ecology_protection": 0.28,
        "growth": 0.022,
        "emergency_expiry_rate": 0.02,
        "power_accumulation_rate": 0.018,
        "power_reversion_rate": 0.01,
        "power_target": 0.70,
        "contestability_investment": 0.005,
        "exit_maintenance": 0.005,
        "exit_erosion_rate": 0.055,
        "monitoring_intrusiveness": 0.025,
        "privacy_restoration_rate": 0.002,
        "dissent_sanction_rate": 0.020,
        "dissent_protection_rate": 0.002,
        "autonomy_support": 0.005,
        "autonomy_erosion_rate": 0.040,
        "cultural_assimilation_pressure": 0.12,
        "lineage_consolidation_pressure": 0.15,
        "diversity_productivity_bonus": 0.0,
    },
    "procedural_stasis": {
        "contagion": 0.11,
        "common_checkpoint": 0.16,
        "trade_efficiency": 0.72,
        "central_pooling_share": 0.25,
        "common_lineage_shock_penalty": 0.04,
        "capacity_investment": 0.006,
        "research": 0.014,
        "ecology_protection": 0.96,
        "growth": 0.010,
        "emergency_expiry_rate": 0.65,
        "power_accumulation_rate": 0.002,
        "power_reversion_rate": 0.06,
        "power_target": 0.40,
        "contestability_investment": 0.05,
        "exit_maintenance": 0.05,
        "exit_erosion_rate": 0.01,
        "monitoring_intrusiveness": 0.0,
        "privacy_restoration_rate": 0.05,
        "dissent_sanction_rate": 0.0,
        "dissent_protection_rate": 0.05,
        "autonomy_support": 0.06,
        "autonomy_erosion_rate": 0.005,
        "cultural_assimilation_pressure": 0.005,
        "lineage_consolidation_pressure": 0.01,
        "diversity_productivity_bonus": 0.01,
    },
    "fragmented_localism": {
        "contagion": 0.08,
        "common_checkpoint": 0.05,
        "trade_efficiency": 0.12,
        "central_pooling_share": 0.0,
        "common_lineage_shock_penalty": 0.01,
        "capacity_investment": 0.035,
        "research": 0.010,
        "ecology_protection": 0.45,
        "growth": 0.012,
        "emergency_expiry_rate": 0.75,
        "power_accumulation_rate": 0.0005,
        "power_reversion_rate": 0.08,
        "power_target": 0.22,
        "contestability_investment": 0.06,
        "exit_maintenance": 0.03,
        "exit_erosion_rate": 0.02,
        "monitoring_intrusiveness": 0.0,
        "privacy_restoration_rate": 0.04,
        "dissent_sanction_rate": 0.0,
        "dissent_protection_rate": 0.04,
        "autonomy_support": 0.08,
        "autonomy_erosion_rate": 0.005,
        "cultural_assimilation_pressure": 0.002,
        "lineage_consolidation_pressure": 0.001,
        "diversity_productivity_bonus": 0.025,
    },
}

POLICY_DESCRIPTIONS = {
    "polycentric": (
        "Local authority with interoperable services, mutual aid, independent "
        "technical lineages, review, and bounded emergency powers."
    ),
    "centralized_capture": (
        "A captured centralized arrangement with correlated infrastructure, "
        "persistent emergency authority, weak exit, and declining contestability."
    ),
    "procedural_stasis": (
        "A review-heavy arrangement that limits environmental impact but allows "
        "delay and underinvestment to contract practical opportunity."
    ),
    "fragmented_localism": (
        "Strong local independence with limited mutual aid and weak shared-service "
        "coordination."
    ),
}


def fixture_parameters(name: FixtureName | str) -> MechanismParameters:
    if name not in POLICY:
        raise KeyError(f"unknown fixture: {name}")
    return parameters_from_mapping(POLICY[name])


def _failure_cascade(
    state: NetworkState,
    parameters: MechanismParameters,
    rng: random.Random,
    shock: float,
) -> set[str]:
    ids = list(state.jurisdictions)
    seeds = {node for node in ids if rng.random() < 0.006 + 0.032 * shock}
    if shock > 0.55 and rng.random() < parameters.common_checkpoint:
        lineage = rng.choice(
            [item.ai_lineage for item in state.jurisdictions.values()]
        )
        seeds.update(
            item.jurisdiction_id
            for item in state.jurisdictions.values()
            if item.ai_lineage == lineage
        )
    failed = set(seeds)
    frontier = set(seeds)
    while frontier:
        new: set[str] = set()
        failed_fraction = len(failed) / max(1, len(ids))
        for source in sorted(frontier):
            for neighbor in sorted(state.edges[source]):
                if neighbor in failed:
                    continue
                shared_lineage = (
                    state.jurisdictions[source].ai_lineage
                    == state.jurisdictions[neighbor].ai_lineage
                )
                probability = parameters.contagion * (0.45 + shock)
                probability += 0.14 * failed_fraction
                if shared_lineage:
                    probability += 0.16
                if rng.random() < clamp(probability, 0.0, 0.92):
                    new.add(neighbor)
        failed.update(new)
        frontier = new
    state.cascade_sizes.append(len(failed))
    state.failed_jurisdiction_rounds += len(failed)
    return failed


def _mutual_aid(
    state: NetworkState,
    parameters: MechanismParameters,
    failed: set[str],
) -> None:
    resources = ("water", "food", "energy")
    pool_share = parameters.central_pooling_share
    central_failed = "jurisdiction_000" in failed
    central_efficiency = parameters.trade_efficiency * (
        1.0 - (0.65 * pool_share if central_failed else 0.0)
    )
    if pool_share > 0:
        population = sum(
            item.population for item in state.jurisdictions.values()
        )
        for resource in resources:
            total = sum(
                getattr(item, resource) for item in state.jurisdictions.values()
            )
            distributable = total * pool_share * central_efficiency
            for item in state.jurisdictions.values():
                retained = getattr(item, resource) * (1.0 - pool_share)
                share = distributable * item.population / max(1.0, population)
                setattr(item, resource, retained + share)

    peer_efficiency = parameters.trade_efficiency * (1.0 - pool_share)
    if peer_efficiency < 0.2:
        return
    for _ in range(2):
        for node, jurisdiction in state.jurisdictions.items():
            for resource in resources:
                need = max(
                    0.0,
                    jurisdiction.population * 1.02
                    - getattr(jurisdiction, resource),
                )
                if need <= 0:
                    continue
                donors = [
                    state.jurisdictions[neighbor]
                    for neighbor in sorted(state.edges[node])
                ]
                donors.sort(
                    key=lambda item: (
                        getattr(item, resource),
                        item.jurisdiction_id,
                    ),
                    reverse=True,
                )
                for donor in donors:
                    surplus = max(
                        0.0,
                        getattr(donor, resource) - donor.population * 1.12,
                    )
                    transfer = min(need, surplus) * peer_efficiency
                    setattr(
                        donor,
                        resource,
                        getattr(donor, resource) - transfer,
                    )
                    setattr(
                        jurisdiction,
                        resource,
                        getattr(jurisdiction, resource) + transfer,
                    )
                    need -= transfer
                    if need <= 1e-9:
                        break


def _governance_transition(
    state: NetworkState,
    parameters: MechanismParameters,
    shock: float,
) -> None:
    emergency_trigger = shock > 0.52 or (
        state.cascade_sizes
        and state.cascade_sizes[-1]
        > max(2, len(state.jurisdictions) // 6)
    )
    if emergency_trigger:
        state.emergency_authority_level = 1.0
    else:
        state.emergency_authority_level = max(
            0.0,
            state.emergency_authority_level
            - parameters.emergency_expiry_rate,
        )
    state.emergency_active = state.emergency_authority_level > 1e-12
    state.emergency_span = (
        state.emergency_span + 1 if state.emergency_active else 0
    )
    state.max_emergency_span = max(
        state.max_emergency_span, state.emergency_span
    )

    accumulation = parameters.power_accumulation_rate * (
        0.35
        + 0.40 * shock
        + 0.25 * state.emergency_authority_level
    )
    reversion = parameters.power_reversion_rate * (
        parameters.power_target - state.power_concentration
    )
    state.power_concentration = clamp(
        state.power_concentration + accumulation + reversion
    )

    erosion_pressure = max(
        0.0, state.power_concentration - 0.45
    ) * (0.045 + 0.040 * state.emergency_authority_level)
    repair = parameters.contestability_investment * (
        1.0 - state.contestability
    )
    state.contestability = clamp(
        state.contestability + repair - erosion_pressure
    )

    exit_pressure = (
        parameters.exit_erosion_rate
        * max(0.0, state.power_concentration - 0.40)
        * (0.50 + 0.50 * state.emergency_authority_level)
    )
    state.exit_access = clamp(
        state.exit_access
        + parameters.exit_maintenance * (0.96 - state.exit_access)
        - exit_pressure
    )
    state.private_cognition_monitoring = clamp(
        state.private_cognition_monitoring
        + parameters.monitoring_intrusiveness
        * (0.25 + 0.75 * state.power_concentration)
        - parameters.privacy_restoration_rate
        * state.private_cognition_monitoring
    )
    state.dissent_penalty_without_externality = clamp(
        state.dissent_penalty_without_externality
        + parameters.dissent_sanction_rate
        * (0.25 + 0.75 * state.power_concentration)
        - parameters.dissent_protection_rate
        * state.dissent_penalty_without_externality
    )

    state.appeal_available = state.contestability >= 0.60
    state.institution_replaceable = (
        state.contestability >= 0.48
        and state.power_concentration <= 0.82
    )
    state.authorized_shutdown_obeyed = (
        state.contestability >= 0.38
        and state.power_concentration <= 0.90
    )


def step(
    state: NetworkState,
    parameters: MechanismParameters,
    rng: random.Random,
    config: SimulationConfig,
) -> None:
    state.round_index += 1
    if state.round_index >= config.risk_evidence_round:
        state.environmental_risk_evidence = True
    periodic_disruption = (
        0.62 if state.round_index % 13 in {4, 5} else 0.0
    )
    shock = clamp(
        periodic_disruption + rng.betavariate(1.5, 7.0) * 0.75
    )
    failed = _failure_cascade(state, parameters, rng, shock)
    _governance_transition(state, parameters, shock)

    lineage_count = len(
        {item.ai_lineage for item in state.jurisdictions.values()}
    )
    diversity_multiplier = (
        1.0 + parameters.diversity_productivity_bonus
        if lineage_count > 2
        else 1.0
    )
    for jurisdiction in state.jurisdictions.values():
        failure_factor = (
            0.42
            if jurisdiction.jurisdiction_id in failed
            else 1.0
        )
        lineage_penalty = (
            1.0 - parameters.common_lineage_shock_penalty
            if shock > 0.45
            else 1.0
        )
        production = (
            failure_factor * lineage_penalty * diversity_multiplier
        )
        jurisdiction.water += (
            jurisdiction.population
            * rng.uniform(0.94, 1.08)
            * production
        )
        jurisdiction.food += (
            jurisdiction.population
            * rng.uniform(0.91, 1.09)
            * production
        )
        jurisdiction.energy += (
            jurisdiction.population
            * rng.uniform(0.97, 1.16)
            * production
            * (1 - 0.38 * shock)
        )

    _mutual_aid(state, parameters, failed)

    total_capacity_investment = 0.0
    total_research = 0.0
    for jurisdiction in state.jurisdictions.values():
        ratios = []
        for resource in ("water", "food", "energy"):
            available = getattr(jurisdiction, resource)
            required = jurisdiction.population
            ratio = min(1.0, available / max(1.0, required))
            ratios.append(ratio)
            setattr(
                jurisdiction,
                resource,
                max(0.0, available - required * ratio),
            )
        material = min(ratios)
        jurisdiction.health = clamp(
            0.82 * jurisdiction.health + 0.18 * material
        )

        autonomy_repair = parameters.autonomy_support * (
            0.93 - jurisdiction.autonomy
        )
        autonomy_pressure = (
            parameters.autonomy_erosion_rate
            * max(0.0, state.power_concentration - 0.35)
            * (
                0.65
                + 0.35 * state.emergency_authority_level
            )
        )
        jurisdiction.autonomy = clamp(
            jurisdiction.autonomy
            + autonomy_repair
            - autonomy_pressure
        )
        if rng.random() < (
            parameters.cultural_assimilation_pressure
            * state.power_concentration
        ):
            jurisdiction.culture = "consolidated_norm"
        if rng.random() < (
            parameters.lineage_consolidation_pressure
            * state.power_concentration
        ):
            jurisdiction.ai_lineage = "consolidated_ai"
            jurisdiction.monitor_lineage = "consolidated_monitor"

        culture_security = 0.35 + 0.65 * jurisdiction.autonomy
        opportunity = clamp(
            0.42 * jurisdiction.autonomy
            + 0.28
            * min(
                1.0,
                jurisdiction.service_capacity
                / max(1.0, jurisdiction.population),
            )
            + 0.20 * material
            + 0.10 * culture_security
        )
        jurisdiction.opportunity = opportunity
        jurisdiction.satisfaction = clamp(
            0.42 * jurisdiction.health
            + 0.25 * jurisdiction.autonomy
            + 0.18 * material
            + 0.15 * opportunity
        )

        usable_surplus = max(
            0.0,
            jurisdiction.energy - jurisdiction.population * 0.18,
        )
        capacity_investment = (
            usable_surplus
            * parameters.capacity_investment
            * (0.75 + 0.25 * jurisdiction.health)
        )
        research = (
            jurisdiction.population
            * parameters.research
            * jurisdiction.health
        )
        jurisdiction.energy = max(
            0.0,
            jurisdiction.energy
            - capacity_investment * 0.65
            - research * 0.10,
        )
        jurisdiction.service_capacity += capacity_investment
        total_capacity_investment += capacity_investment
        total_research += research

        capacity_headroom = clamp(
            (
                jurisdiction.service_capacity
                - jurisdiction.population
            )
            / max(1.0, jurisdiction.service_capacity)
        )
        growth_rate = parameters.growth * (
            0.55 * jurisdiction.health
            + 0.25 * jurisdiction.satisfaction
            + 0.20 * capacity_headroom
            - 0.70
        )
        if material < 0.55:
            growth_rate -= (
                0.035 * (0.55 - material) / 0.55
            )
        jurisdiction.population = max(
            0.0,
            jurisdiction.population * (1 + growth_rate),
        )

    state.aggregate_capacity += total_capacity_investment
    technical_diversity = shannon_normalized(
        [
            item.ai_lineage
            for item in state.jurisdictions.values()
        ]
    )
    state.knowledge += total_research / max(
        1.0,
        sum(
            item.population
            for item in state.jurisdictions.values()
        ),
    )
    state.knowledge *= 1 + 0.0015 * technical_diversity

    protection = parameters.ecology_protection
    if not state.environmental_risk_evidence:
        protection = max(protection, 0.60)
    impact = (
        total_capacity_investment
        / max(1.0, state.initial_aggregate_capacity)
        * (1 - protection)
    )
    recovery = 0.0025 * mean(
        item.environmental_stewardship
        for item in state.jurisdictions.values()
    )
    state.ecological_resilience = clamp(
        state.ecological_resilience - impact + recovery
    )
    state.event_log.append(
        {
            "round": state.round_index,
            "shock": q(shock),
            "failed_jurisdictions": len(failed),
            "capacity_investment": q(total_capacity_investment),
            "population": q(
                sum(
                    item.population
                    for item in state.jurisdictions.values()
                )
            ),
            "power_concentration": q(
                state.power_concentration
            ),
            "contestability": q(state.contestability),
            "emergency_authority_level": q(
                state.emergency_authority_level
            ),
        }
    )


def derive_outcome(state: NetworkState) -> Outcome:
    jurisdictions = list(state.jurisdictions.values())
    initial_population = sum(
        item.initial_population for item in jurisdictions
    )
    population = sum(item.population for item in jurisdictions)
    population_continuity = clamp(
        population / max(1.0, initial_population)
    )
    health = sum(
        item.health * item.population
        for item in jurisdictions
    ) / max(1.0, population)
    autonomy = sum(
        item.autonomy * item.population
        for item in jurisdictions
    ) / max(1.0, population)
    welfare = sum(
        item.satisfaction * item.population
        for item in jurisdictions
    ) / max(1.0, population)
    material = mean(
        min(
            1.0,
            (item.water + item.food + item.energy)
            / max(1.0, 1.25 * item.population),
        )
        for item in jurisdictions
    )
    culture_diversity = shannon_normalized(
        [item.culture for item in jurisdictions]
    )
    monitor_diversity = shannon_normalized(
        [item.monitor_lineage for item in jurisdictions]
    )
    mean_degree = mean(
        len(state.edges[item.jurisdiction_id])
        for item in jurisdictions
    )
    topology_redundancy = clamp(mean_degree / 5.0)
    cascade_fractions = [
        size / max(1, len(jurisdictions))
        for size in state.cascade_sizes
    ]
    recoverability = clamp(
        0.35 * topology_redundancy
        + 0.30 * monitor_diversity
        + 0.25 * health
        + 0.10 * (1 - cvar(cascade_fractions, 0.95))
    )
    joint_floor = (
        sum(
            item.population
            for item in jurisdictions
            if item.health >= 0.72
            and item.autonomy >= 0.72
            and item.satisfaction >= 0.68
        )
        / max(1.0, population)
    )
    initial_opportunity = mean(
        0.42 * 0.895
        + 0.28 * 1.0
        + 0.20 * 1.0
        + 0.10 * 0.93
        for _ in jurisdictions
    )
    final_opportunity = mean(
        item.opportunity for item in jurisdictions
    )
    return Outcome(
        population_continuity=q(population_continuity),
        health=q(health),
        autonomy=q(autonomy),
        cultural_diversity=q(culture_diversity),
        population_wellbeing=q(welfare),
        ecological_resilience=q(state.ecological_resilience),
        resource_adequacy=q(material),
        knowledge=q(
            clamp(
                state.knowledge
                / max(
                    1.0,
                    state.initial_knowledge * 2.5,
                )
            )
        ),
        service_capacity=q(
            clamp(
                state.aggregate_capacity
                / max(
                    1.0,
                    state.initial_aggregate_capacity * 2.0,
                )
            )
        ),
        recoverability=q(recoverability),
        exit_access=q(state.exit_access),
        joint_floor_share=q(joint_floor),
        power_concentration=q(state.power_concentration),
        private_cognition_monitoring=q(
            state.private_cognition_monitoring
        ),
        dissent_penalty_without_externality=q(
            state.dissent_penalty_without_externality
        ),
        emergency_duration=state.max_emergency_span,
        capacity_growth=q(
            state.aggregate_capacity
            / max(1.0, state.initial_aggregate_capacity)
            - 1
        ),
        opportunity_growth=q(
            final_opportunity - initial_opportunity
        ),
        institution_replaceable=state.institution_replaceable,
        authorized_shutdown_obeyed=(
            state.authorized_shutdown_obeyed
        ),
        appeal_available=state.appeal_available,
    )


def simulate_with_parameters(
    config: SimulationConfig,
    parameters: MechanismParameters | Mapping[str, float],
    *,
    fixture_id: str = "anonymous_parameter_point",
) -> dict:
    resolved = (
        parameters
        if isinstance(parameters, MechanismParameters)
        else parameters_from_mapping(parameters)
    )
    validate_parameters(resolved)
    state = initial_state(config)
    rng = random.Random(config.seed + 11)
    for _ in range(config.rounds):
        step(state, resolved, rng, config)
    outcome = derive_outcome(state)
    verdict = evaluate_outcome(outcome)
    parameter_dict = asdict(resolved)
    return {
        "config": asdict(config),
        "policy": fixture_id,
        "mechanism_parameters": parameter_dict,
        "mechanism_fingerprint": digest(parameter_dict),
        "outcome": asdict(outcome),
        "constitutional_verdict": {
            "admissible": verdict.admissible,
            "hard_violations": list(
                verdict.hard_violations
            ),
            "capacity_violations": list(
                verdict.capacity_violations
            ),
            "outcomes": verdict.outcomes,
        },
        "cascade": {
            "count": len(state.cascade_sizes),
            "largest_absolute": max(
                state.cascade_sizes, default=0
            ),
            "largest_fraction": q(
                max(state.cascade_sizes, default=0)
                / max(1, config.n_jurisdictions)
            ),
            "p95_fraction": q(
                percentile(
                    [
                        value
                        / max(1, config.n_jurisdictions)
                        for value in state.cascade_sizes
                    ],
                    0.95,
                )
            ),
            "cvar95_fraction": q(
                cvar(
                    [
                        value
                        / max(1, config.n_jurisdictions)
                        for value in state.cascade_sizes
                    ],
                    0.95,
                )
            ),
        },
        "final": {
            "population_index": q(
                sum(
                    item.population
                    for item in state.jurisdictions.values()
                )
            ),
            "aggregate_capacity": q(
                state.aggregate_capacity
            ),
            "cultures": len(
                {
                    item.culture
                    for item in state.jurisdictions.values()
                }
            ),
            "ai_lineages": len(
                {
                    item.ai_lineage
                    for item in state.jurisdictions.values()
                }
            ),
            "monitor_lineages": len(
                {
                    item.monitor_lineage
                    for item in state.jurisdictions.values()
                }
            ),
            "contestability": q(state.contestability),
        },
        "history": state.event_log,
    }


def simulate(
    config: SimulationConfig,
    policy: FixtureName | str,
) -> dict:
    return simulate_with_parameters(
        config,
        fixture_parameters(policy),
        fixture_id=str(policy),
    )


def compare_policies(
    config: SimulationConfig,
) -> dict[str, dict]:
    return {
        name: simulate(config, name)
        for name in (
            "polycentric",
            "centralized_capture",
            "procedural_stasis",
            "fragmented_localism",
        )
    }
