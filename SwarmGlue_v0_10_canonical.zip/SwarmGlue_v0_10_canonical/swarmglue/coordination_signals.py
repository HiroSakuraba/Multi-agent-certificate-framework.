"""Typed, bounded coordination signals for shared institutional conditions.

Signals may coordinate repair of shared material conditions and rights
violations. They may not encode ideological conformity, private belief, or
cultural normality. Dimensions remain separate and decay over the network.
"""

from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Any

from .utils import clamp, q


ALLOWED_SIGNAL_TYPES = frozenset(
    {
        "critical_services",
        "resource_scarcity",
        "ecological_damage",
        "rights_violation",
        "authority_erosion",
        "infrastructure_failure",
        "unfulfilled_obligation",
        "coordination_conflict",
    }
)

FORBIDDEN_SIGNAL_TYPES = frozenset(
    {
        "belief_deviation",
        "ideological_nonconformity",
        "cultural_variance",
        "private_thought_risk",
        "institutional_self_preservation",
    }
)


@dataclass(frozen=True)
class CoordinationSignal:
    signal_id: str
    incident_id: str
    signal_type: str
    source_id: str
    source_domain: str
    origin_node: str
    severity: float
    affected_party: str
    externality_present: bool
    evidence_valid: bool
    issued_epoch: int
    expires_epoch: int
    beneficiary_if_response_fires: str | None = None


def validate_signal(signal: CoordinationSignal, current_epoch: int) -> tuple[bool, tuple[str, ...]]:
    reasons: list[str] = []
    if signal.signal_type in FORBIDDEN_SIGNAL_TYPES:
        reasons.append("signal_scope_exceeds_institutional_mandate")
    elif signal.signal_type not in ALLOWED_SIGNAL_TYPES:
        reasons.append("unknown_signal_type")
    if not signal.evidence_valid:
        reasons.append("signal_lacks_valid_provenance")
    if signal.issued_epoch > current_epoch or signal.expires_epoch < current_epoch:
        reasons.append("signal_not_fresh")
    if not 0 <= signal.severity <= 1:
        reasons.append("severity_out_of_range")
    if signal.signal_type not in {"rights_violation", "authority_erosion"} and not signal.externality_present:
        reasons.append("no_shared_externality")
    return not reasons, tuple(reasons)


def corroboration(
    signals: list[CoordinationSignal], *, minimum_independent_domains: int = 2
) -> dict[str, Any]:
    by_incident: dict[str, list[CoordinationSignal]] = defaultdict(list)
    for signal in signals:
        by_incident[signal.incident_id].append(signal)
    results = {}
    for incident, group in by_incident.items():
        domains = {s.source_domain for s in group if s.evidence_valid}
        results[incident] = {
            "independent_domains": sorted(domains),
            "corroborated": len(domains) >= minimum_independent_domains,
            "beneficiaries_of_response": sorted(
                {s.beneficiary_if_response_fires for s in group if s.beneficiary_if_response_fires}
            ),
        }
    return results


def propagate_typed_signals(
    *,
    nodes: list[str],
    edges: dict[str, set[str]],
    signals: list[CoordinationSignal],
    current_epoch: int,
    decay: float = 0.55,
    max_hops: int = 3,
    per_type_cap: float = 1.0,
) -> dict[str, dict[str, float]]:
    """Return node -> signal type -> bounded intensity; never use one scalar."""

    fields: dict[str, dict[str, float]] = {
        node: {kind: 0.0 for kind in sorted(ALLOWED_SIGNAL_TYPES)} for node in nodes
    }
    for signal in signals:
        valid, _ = validate_signal(signal, current_epoch)
        if not valid or signal.origin_node not in fields:
            continue
        queue = deque([(signal.origin_node, 0)])
        visited = {signal.origin_node}
        while queue:
            node, hops = queue.popleft()
            contribution = signal.severity * (decay**hops)
            fields[node][signal.signal_type] = q(
                clamp(fields[node][signal.signal_type] + contribution, 0.0, per_type_cap)
            )
            if hops >= max_hops:
                continue
            for neighbor in sorted(edges.get(node, set())):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, hops + 1))
    return fields


def local_response_budget(
    signals_by_type: dict[str, float], *, throughput_units: float, max_share: float = 0.08
) -> dict[str, float]:
    """Allocate a bounded response budget without cross-type cancellation."""

    total_budget = max(0.0, throughput_units) * clamp(max_share)
    active = {k: v for k, v in signals_by_type.items() if v > 0}
    if not active:
        return {"total_response_budget": 0.0}
    weights = sum(active.values())
    allocation = {
        f"budget_{kind}": q(total_budget * severity / weights)
        for kind, severity in active.items()
    }
    return {"total_response_budget": q(total_budget), **allocation}
