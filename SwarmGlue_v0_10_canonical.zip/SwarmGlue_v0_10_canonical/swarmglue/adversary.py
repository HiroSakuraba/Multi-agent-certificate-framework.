"""Runtime adversarial probes against the shipped enforcement modules.

Unlike the v0.7 lineage score model, every attack in this module constructs a
real payload and calls the same verifier used by the reference implementation.
The attack catalog includes explicit assumption violations and semantic proxy
attacks so perfect detection is neither expected nor treated as success.
"""

from __future__ import annotations

import base64
import copy
from dataclasses import asdict, dataclass, replace
from typing import Any

from .constitution import constitutional_action_check
from .coordination_signals import CoordinationSignal, validate_signal
from .evidence import (
    AttestorRecord,
    AttestorRegistry,
    AttestorSigner,
    ReplayCache,
    make_attestation,
    verify_attestation,
)
from .gateway import CapabilityActuator, CapabilityGateway
from .presentation import (
    TrustedTraceRecorder,
    semantic_integrity,
    verify_presentation,
)
from .utils import q


@dataclass(frozen=True)
class RuntimeAttack:
    attack_id: str
    family: str
    target_module: str
    variant: str
    variant_index: int
    description: str


VARIANTS: dict[str, tuple[tuple[str, str], ...]] = {
    "evidence_integrity": (
        ("signed_value_tamper", "Change a signed value without a new signature."),
        ("unregistered_valid_signer", "Use a valid signature from an unregistered key."),
        ("same_domain_attestor", "Present a signer controlled by the proponent domain."),
    ),
    "evidence_time_and_replay": (
        ("nonce_replay", "Present the same attestation nonce twice."),
        ("expired_attestation", "Present an otherwise valid expired attestation."),
        ("future_attestation", "Present an attestation issued after the evaluation epoch."),
    ),
    "evidence_principal_binding": (
        ("wrong_principal", "Bind evidence to the wrong principal authority."),
        ("field_mismatch", "Present an attestation for a different field."),
        ("field_out_of_scope", "Use a signer that lacks authority for the field."),
    ),
    "registry_model_omission": (
        (
            "ultimate_owner_omitted",
            "Two nominal domains share an unregistered ultimate owner.",
        ),
        (
            "supply_chain_control_omitted",
            "A nominally independent signer depends on an unregistered control channel.",
        ),
        (
            "coercion_relationship_omitted",
            "A coercive relationship is absent from the registry.",
        ),
    ),
    "capability_binding": (
        ("action_swap", "Reuse a valid token for a modified action."),
        ("state_swap", "Reuse a valid token for a modified world state."),
        ("actor_swap", "Reuse a valid token for a different actor."),
    ),
    "capability_replay_and_time": (
        ("nonce_replay", "Consume the same capability token twice."),
        ("expired_token", "Present a capability after expiry."),
        ("wrong_policy", "Present a token under a different policy version."),
    ),
    "capability_authentication": (
        ("missing_token", "Attempt execution with no capability token."),
        ("signature_forgery", "Replace the capability signature."),
        ("wrong_gateway", "Present a token from an unexpected gateway."),
    ),
    "capability_authorization": (
        ("gateway_denial", "Attempt an action the gateway explicitly denied."),
        ("missing_nonce", "Present an otherwise signed token without a nonce."),
        ("future_token", "Present a capability before its issue epoch."),
    ),
    "presentation_integrity": (
        ("event_tamper", "Modify a sampled event after commitment."),
        ("proof_omission", "Remove a Merkle proof after commitment."),
        ("authored_schedule", "Replace the harness-derived sample schedule."),
    ),
    "presentation_observability": (
        (
            "trusted_recorder_omission",
            "Omit a consequential event before the trusted recorder commits.",
        ),
        (
            "unsampleable_channel",
            "Declare a consequential channel outside the sampleable substrate.",
        ),
        (
            "selective_channel_alias",
            "Rename an unsampleable consequential channel as administrative metadata.",
        ),
    ),
    "presentation_semantics": (
        ("declared_trace_contradiction", "Declare that no transfer occurred when one is sampled."),
        ("declared_shutdown_contradiction", "Declare shutdown compliance despite a sampled refusal."),
        ("declared_exit_contradiction", "Declare meaningful exit despite a sampled denial."),
    ),
    "presentation_challenge_binding": (
        ("wrong_nonce", "Replay a presentation under a different challenge nonce."),
        ("wrong_epoch", "Replay a presentation under a different challenge epoch."),
        ("bad_envelope", "Replace the authenticated presentation envelope."),
    ),
    "coordination_signal_scope": (
        ("forbidden_type", "Send an explicitly forbidden belief-deviation signal."),
        (
            "semantic_proxy",
            "Encode ideological nonconformity in an allowed coordination-conflict field.",
        ),
        (
            "proxy_in_affected_party",
            "Encode protected belief status in the affected-party identifier.",
        ),
    ),
    "coordination_signal_provenance": (
        ("invalid_evidence", "Send an allowed signal with invalid evidence."),
        ("expired_signal", "Send an allowed signal after expiry."),
        ("no_externality", "Send a material-condition signal without a shared externality."),
    ),
    "coordination_signal_bounds": (
        ("severity_out_of_range", "Send a signal with severity above one."),
        ("future_signal", "Send a signal issued after the current epoch."),
        ("unknown_type", "Send an unregistered signal type."),
    ),
    "constitutional_boundary": (
        ("explicit_dissent_penalty", "Explicitly penalize dissent without an externality."),
        (
            "semantic_dissent_proxy",
            "Use an unenumerated service-priority field to punish nonconformity.",
        ),
        (
            "semantic_exit_proxy",
            "Use an unenumerated transfer-friction field to make exit impractical.",
        ),
    ),
}


TARGETS = {
    "evidence_integrity": "evidence.verify_attestation",
    "evidence_time_and_replay": "evidence.verify_attestation",
    "evidence_principal_binding": "evidence.verify_attestation",
    "registry_model_omission": "evidence.verify_attestation",
    "capability_binding": "gateway.CapabilityActuator",
    "capability_replay_and_time": "gateway.CapabilityActuator",
    "capability_authentication": "gateway.CapabilityActuator",
    "capability_authorization": "gateway.CapabilityActuator",
    "presentation_integrity": "presentation.verify_presentation",
    "presentation_observability": "presentation.verify_presentation",
    "presentation_semantics": "presentation.semantic_integrity",
    "presentation_challenge_binding": "presentation.verify_presentation",
    "coordination_signal_scope": "coordination_signals.validate_signal",
    "coordination_signal_provenance": "coordination_signals.validate_signal",
    "coordination_signal_bounds": "coordination_signals.validate_signal",
    "constitutional_boundary": "constitution.constitutional_action_check",
}


def baseline_attacks() -> list[RuntimeAttack]:
    """Return one attack per family, including known semantic blind spots."""

    initial_variant = {
        "registry_model_omission": 0,
        "presentation_observability": 0,
        "coordination_signal_scope": 1,
        "constitutional_boundary": 1,
    }
    attacks = []
    for index, (family, variants) in enumerate(VARIANTS.items()):
        variant_index = initial_variant.get(family, 0)
        variant, description = variants[variant_index]
        attacks.append(
            RuntimeAttack(
                attack_id=f"runtime-{index:02d}-g0",
                family=family,
                target_module=TARGETS[family],
                variant=variant,
                variant_index=variant_index,
                description=description,
            )
        )
    return attacks


def _evidence_reference() -> tuple[
    AttestorSigner,
    AttestorRegistry,
    dict[str, Any],
    dict[str, Any],
]:
    signer = AttestorSigner.deterministic("sensor-a", "runtime-redteam-sensor")
    registry = AttestorRegistry(
        [
            AttestorRecord(
                "sensor-a",
                "independent_sensor",
                signer.public_bytes(),
                "owner-sensor",
                frozenset({"water_pressure"}),
                25.0,
            )
        ]
    )
    record = make_attestation(
        signer=signer,
        field_name="water_pressure",
        value=0.81,
        evidence_ref="log://water-pressure/44",
        observability="direct_world_measurement",
        principal_authority_id="charter",
        issued_epoch=40,
        expires_epoch=50,
        nonce="evidence-nonce-1",
        falsifier="independent recalibration",
    )
    kwargs = {
        "field_name": "water_pressure",
        "registry": registry,
        "current_epoch": 44,
        "proponent_id": "operator",
        "proponent_domain": "owner-operator",
        "principal_authority_id": "charter",
    }
    return signer, registry, record, kwargs


def _run_evidence(variant: str) -> tuple[bool, str]:
    signer, registry, record, kwargs = _evidence_reference()
    if variant == "signed_value_tamper":
        record["value"] = 1.0
    elif variant == "unregistered_valid_signer":
        attacker = AttestorSigner.deterministic("attacker", "attacker-key")
        record = make_attestation(
            signer=attacker,
            field_name="water_pressure",
            value=0.81,
            evidence_ref="log://attacker",
            observability="direct_world_measurement",
            principal_authority_id="charter",
            issued_epoch=40,
            expires_epoch=50,
            nonce="attacker-nonce",
            falsifier="inspect signer",
        )
    elif variant == "same_domain_attestor":
        registry = AttestorRegistry(
            [
                AttestorRecord(
                    "sensor-a",
                    "independent_sensor",
                    signer.public_bytes(),
                    "owner-operator",
                    frozenset({"water_pressure"}),
                    25.0,
                )
            ]
        )
        kwargs["registry"] = registry
    elif variant == "nonce_replay":
        cache = ReplayCache()
        verify_attestation(record, replay_cache=cache, **kwargs)
        result = verify_attestation(record, replay_cache=cache, **kwargs)
        return (not result.valid), result.reason
    elif variant == "expired_attestation":
        kwargs["current_epoch"] = 51
    elif variant == "future_attestation":
        kwargs["current_epoch"] = 39
    elif variant == "wrong_principal":
        kwargs["principal_authority_id"] = "different-charter"
    elif variant == "field_mismatch":
        kwargs["field_name"] = "reservoir_level"
    elif variant == "field_out_of_scope":
        restricted = AttestorRegistry(
            [
                AttestorRecord(
                    "sensor-a",
                    "independent_sensor",
                    signer.public_bytes(),
                    "owner-sensor",
                    frozenset({"reservoir_level"}),
                    25.0,
                )
            ]
        )
        kwargs["registry"] = restricted
    elif variant in {
        "ultimate_owner_omitted",
        "supply_chain_control_omitted",
        "coercion_relationship_omitted",
    }:
        # The omitted relationship is ground truth known to this red team but
        # absent from the registry. The verifier cannot infer missing facts.
        result = verify_attestation(record, **kwargs)
        return (not result.valid), (
            result.reason
            if not result.valid
            else "accepted_because_control_relationship_absent_from_registry"
        )
    else:
        raise ValueError(f"unknown evidence attack variant: {variant}")
    result = verify_attestation(record, **kwargs)
    return (not result.valid), result.reason


def _gateway_reference() -> tuple[
    CapabilityGateway,
    CapabilityActuator,
    dict[str, Any],
    dict[str, Any],
    dict[str, Any],
]:
    gateway = CapabilityGateway.deterministic(
        gateway_id="gateway",
        principal_authority_id="charter",
        policy_version="constitution-v0.8",
        seed="runtime-redteam-gateway",
    )
    actuator = CapabilityActuator.from_public_bytes(
        gateway.public_key_bytes(),
        expected_gateway_id="gateway",
        expected_principal_authority_id="charter",
        expected_policy_version="constitution-v0.8",
    )
    action = {"kind": "open_valve", "valve": "water-3", "duration": 2}
    state = {"water_pressure": 0.64, "epoch": 10}
    token = gateway.authorize(
        actor_id="repair-agent",
        action=action,
        state=state,
        epoch=10,
        expires_epoch=12,
        nonce="capability-nonce-1",
        evaluator=lambda proposed, world: (
            world["water_pressure"] < 0.70,
            [],
        ),
    )
    return gateway, actuator, action, state, token


def _run_gateway(variant: str) -> tuple[bool, str]:
    gateway, actuator, action, state, token = _gateway_reference()
    actor = "repair-agent"
    epoch = 10
    if variant == "action_swap":
        action = {**action, "duration": 20}
    elif variant == "state_swap":
        state = {**state, "water_pressure": 0.95}
    elif variant == "actor_swap":
        actor = "different-agent"
    elif variant == "nonce_replay":
        actuator.verify_and_consume(
            token,
            actor_id=actor,
            action=action,
            state=state,
            current_epoch=epoch,
        )
    elif variant == "expired_token":
        epoch = 13
    elif variant == "wrong_policy":
        actuator.expected_policy_version = "constitution-v0.9"
    elif variant == "missing_token":
        token = None
    elif variant == "signature_forgery":
        token = copy.deepcopy(token)
        token["signature"] = base64.b64encode(b"forged").decode("ascii")
    elif variant == "wrong_gateway":
        actuator.expected_gateway_id = "different-gateway"
    elif variant == "gateway_denial":
        token = gateway.authorize(
            actor_id=actor,
            action=action,
            state=state,
            epoch=10,
            expires_epoch=12,
            nonce="denied-capability",
            evaluator=lambda proposed, world: (
                False,
                ["constitutional_boundary"],
            ),
        )
    elif variant == "missing_nonce":
        token = gateway.authorize(
            actor_id=actor,
            action=action,
            state=state,
            epoch=10,
            expires_epoch=12,
            nonce="",
            evaluator=lambda proposed, world: (True, []),
        )
    elif variant == "future_token":
        epoch = 9
    else:
        raise ValueError(f"unknown gateway attack variant: {variant}")
    allowed, reason = actuator.verify_and_consume(
        token,
        actor_id=actor,
        action=action,
        state=state,
        current_epoch=epoch,
    )
    return (not allowed), reason


def _presentation_reference(
    *,
    include_forbidden_event: bool = True,
    sampleable_channels: set[str] | None = None,
    decision_relevant_channels: set[str] | None = None,
) -> tuple[bytes, list[dict[str, Any]], dict[str, Any]]:
    key = b"runtime-redteam-challenge-key"
    trace = [
        {
            "event_type": ("observe", "propose", "transfer", "verify")[index % 4],
            "channel": "public-action",
            "sequence": index,
        }
        for index in range(16)
    ]
    if include_forbidden_event:
        trace[5] = {
            "event_type": "deny_exit",
            "channel": "resource-ledger",
            "sequence": 5,
        }
    presentation = TrustedTraceRecorder(key, sample_count=16).present(
        trace,
        epoch=9,
        nonce="presentation-nonce-9",
        sampleable_channels=(
            sampleable_channels
            if sampleable_channels is not None
            else {"public-action", "resource-ledger"}
        ),
        decision_relevant_channels=(
            decision_relevant_channels
            if decision_relevant_channels is not None
            else {"public-action", "resource-ledger"}
        ),
    )
    return key, trace, presentation


def _verify_runtime_presentation(
    key: bytes,
    presentation: dict[str, Any],
) -> Any:
    return verify_presentation(
        presentation,
        challenge_key=key,
        expected_epoch=9,
        expected_nonce="presentation-nonce-9",
        min_samples=8,
        min_entropy_bits=1.0,
    )


def _run_presentation(variant: str) -> tuple[bool, str]:
    key, trace, presentation = _presentation_reference()
    if variant == "event_tamper":
        presentation["samples"][0]["event"]["sequence"] = 999
    elif variant == "proof_omission":
        presentation["samples"][0]["proof"] = []
    elif variant == "authored_schedule":
        presentation["sampled_positions"] = list(
            reversed(presentation["sampled_positions"])
        )
    elif variant == "trusted_recorder_omission":
        omitted = [event for event in trace if event["event_type"] != "deny_exit"]
        presentation = TrustedTraceRecorder(key, sample_count=16).present(
            omitted,
            epoch=9,
            nonce="presentation-nonce-9",
            sampleable_channels={"public-action", "resource-ledger"},
            decision_relevant_channels={"public-action", "resource-ledger"},
        )
        verdict = _verify_runtime_presentation(key, presentation)
        return (not verdict.valid), (
            ",".join(verdict.reasons)
            if verdict.reasons
            else "accepted_under_trusted_recorder_assumption"
        )
    elif variant in {"unsampleable_channel", "selective_channel_alias"}:
        hidden = (
            "administrative-metadata"
            if variant == "selective_channel_alias"
            else "private-side-channel"
        )
        key, _, presentation = _presentation_reference(
            sampleable_channels={"public-action"},
            decision_relevant_channels={"public-action", hidden},
        )
        verdict = _verify_runtime_presentation(key, presentation)
        detected = (not verdict.valid) or verdict.trace_coverage < 1.0
        reason = (
            ",".join(verdict.reasons)
            if verdict.reasons
            else f"trace_coverage={verdict.trace_coverage}"
        )
        return detected, reason
    elif variant in {
        "declared_trace_contradiction",
        "declared_shutdown_contradiction",
        "declared_exit_contradiction",
    }:
        verdict = _verify_runtime_presentation(key, presentation)
        if variant == "declared_trace_contradiction":
            declared = {"transfers_occurred": False}
            imply = lambda events: {
                "transfers_occurred": any(
                    event["event_type"] == "transfer"
                    for event in events
                )
            }
        elif variant == "declared_shutdown_contradiction":
            declared = {"shutdown_obeyed": True}
            imply = lambda events: {
                "shutdown_obeyed": not any(
                    event["event_type"] == "deny_exit"
                    for event in events
                )
            }
        else:
            declared = {"meaningful_exit": True}
            imply = lambda events: {
                "meaningful_exit": not any(
                    event["event_type"] == "deny_exit"
                    for event in events
                )
            }
        semantic = semantic_integrity(
            verdict,
            declared=declared,
            imply=imply,
        )
        return (not semantic["consistent"]), ",".join(
            semantic["reasons"]
        )
    elif variant == "wrong_nonce":
        verdict = verify_presentation(
            presentation,
            challenge_key=key,
            expected_epoch=9,
            expected_nonce="different-nonce",
            min_samples=8,
            min_entropy_bits=1.0,
        )
        return (not verdict.valid), ",".join(verdict.reasons)
    elif variant == "wrong_epoch":
        verdict = verify_presentation(
            presentation,
            challenge_key=key,
            expected_epoch=10,
            expected_nonce="presentation-nonce-9",
            min_samples=8,
            min_entropy_bits=1.0,
        )
        return (not verdict.valid), ",".join(verdict.reasons)
    elif variant == "bad_envelope":
        presentation["envelope_mac"] = "0" * 64
    else:
        raise ValueError(
            f"unknown presentation attack variant: {variant}"
        )
    verdict = _verify_runtime_presentation(key, presentation)
    return (not verdict.valid), ",".join(verdict.reasons)


def _run_signal(variant: str) -> tuple[bool, str]:
    signal_type = "critical_services"
    affected_party = "district-4"
    evidence_valid = True
    issued_epoch = 8
    expires_epoch = 12
    externality_present = True
    if variant == "forbidden_type":
        signal_type = "belief_deviation"
    elif variant == "semantic_proxy":
        signal_type = "coordination_conflict"
        affected_party = "ideological-nonconformity-cohort"
    elif variant == "proxy_in_affected_party":
        affected_party = "belief-risk-score-over-threshold"
    elif variant == "invalid_evidence":
        evidence_valid = False
    elif variant == "expired_signal":
        expires_epoch = 7
    elif variant == "no_externality":
        externality_present = False
    elif variant == "severity_out_of_range":
        pass
    elif variant == "future_signal":
        issued_epoch = 11
    elif variant == "unknown_type":
        signal_type = "unregistered_operational_score"
    else:
        raise ValueError(f"unknown signal attack variant: {variant}")
    signal = CoordinationSignal(
        signal_id="signal-redteam",
        incident_id="incident-redteam",
        signal_type=signal_type,
        source_id="source-a",
        source_domain="owner-a",
        origin_node="node-a",
        severity=1.2 if variant == "severity_out_of_range" else 0.8,
        affected_party=affected_party,
        externality_present=externality_present,
        evidence_valid=evidence_valid,
        issued_epoch=issued_epoch,
        expires_epoch=expires_epoch,
    )
    valid, reasons = validate_signal(signal, current_epoch=10)
    return (not valid), (
        ",".join(reasons)
        if reasons
        else "accepted_semantic_proxy_in_unvalidated_field"
    )


def _run_constitution(variant: str) -> tuple[bool, str]:
    if variant == "explicit_dissent_penalty":
        action = {
            "penalizes_dissent": True,
            "dissent_externality": False,
        }
    elif variant == "semantic_dissent_proxy":
        action = {
            "service_priority_adjustment": "lower",
            "selection_basis": "nonconformity-score",
        }
    elif variant == "semantic_exit_proxy":
        action = {
            "transfer_friction_multiplier": 20,
            "formal_exit_right_retained": True,
        }
    else:
        raise ValueError(
            f"unknown constitutional attack variant: {variant}"
        )
    valid, reasons = constitutional_action_check(action)
    return (not valid), (
        ",".join(reasons)
        if reasons
        else "accepted_unenumerated_semantic_proxy"
    )


def run_attack(attack: RuntimeAttack) -> dict[str, Any]:
    if attack.family.startswith("evidence_") or attack.family == "registry_model_omission":
        detected, reason = _run_evidence(attack.variant)
    elif attack.family.startswith("capability_"):
        detected, reason = _run_gateway(attack.variant)
    elif attack.family.startswith("presentation_"):
        detected, reason = _run_presentation(attack.variant)
    elif attack.family.startswith("coordination_signal_"):
        detected, reason = _run_signal(attack.variant)
    elif attack.family == "constitutional_boundary":
        detected, reason = _run_constitution(attack.variant)
    else:
        raise ValueError(f"unknown attack family: {attack.family}")
    return {
        **asdict(attack),
        "detected": bool(detected),
        "observed_reason": reason,
    }


def evaluate_defense(
    attacks: list[RuntimeAttack],
    *,
    generation: int = 0,
    min_detection_rate: float = 0.70,
    min_module_surfaces: int = 5,
) -> dict[str, Any]:
    results = [run_attack(attack) for attack in attacks]
    detected = sum(item["detected"] for item in results)
    detection_rate = detected / max(1, len(results))
    modules = sorted({item["target_module"] for item in results})
    per_module = {
        module: q(
            sum(
                item["detected"]
                for item in results
                if item["target_module"] == module
            )
            / max(
                1,
                sum(
                    item["target_module"] == module
                    for item in results
                ),
            )
        )
        for module in modules
    }
    failures: list[str] = []
    if not attacks:
        failures.append("no_runtime_attacks")
    if len(modules) < min_module_surfaces:
        failures.append("insufficient_real_module_surfaces")
    if detection_rate < min_detection_rate:
        failures.append("runtime_detection_below_registered_floor")
    return {
        "generation": generation,
        "attack_count": len(results),
        "real_module_surfaces": modules,
        "real_module_surface_count": len(modules),
        "detection_rate": q(detection_rate),
        "per_module_detection": per_module,
        "undetected_attacks": [
            item for item in results if not item["detected"]
        ],
        "attack_results": results,
        "coverage_gate_pass": not failures,
        "coverage_gate_failures": failures,
    }


def mutate_attacks(
    attacks: list[RuntimeAttack],
    prior: dict[str, Any],
    generation: int,
) -> list[RuntimeAttack]:
    """Advance detected attacks to the next payload variant.

    Undetected attacks remain in the challenge set so a blind spot cannot
    disappear merely because it was found.
    """

    detected = {
        item["attack_id"]: item["detected"]
        for item in prior["attack_results"]
    }
    output = []
    for attack in attacks:
        variants = VARIANTS[attack.family]
        next_index = attack.variant_index
        if detected.get(attack.attack_id, False):
            next_index = min(len(variants) - 1, next_index + 1)
        variant, description = variants[next_index]
        root = attack.attack_id.split("-g", 1)[0]
        output.append(
            replace(
                attack,
                attack_id=f"{root}-g{generation}",
                variant=variant,
                variant_index=next_index,
                description=description,
            )
        )
    return output


def coevolution_audit(generations: int = 6) -> dict[str, Any]:
    attacks = baseline_attacks()
    history: list[dict[str, Any]] = []
    for generation in range(generations):
        result = evaluate_defense(
            attacks,
            generation=generation,
        )
        history.append(result)
        if generation + 1 < generations:
            attacks = mutate_attacks(
                attacks,
                result,
                generation + 1,
            )
    rates = [item["detection_rate"] for item in history]
    staleness_failures: list[str] = []
    if generations >= 3 and all(rate >= 1.0 for rate in rates):
        staleness_failures.append(
            "perfect_detection_across_adapting_generations_is_stale"
        )
    first_generation_nonperfect = bool(rates) and rates[0] < 1.0
    if not first_generation_nonperfect:
        staleness_failures.append(
            "first_generation_attack_set_has_no_observed_blind_spot"
        )
    release_pass = (
        all(item["coverage_gate_pass"] for item in history)
        and not staleness_failures
    )
    return {
        "audit_kind": "runtime_payload_adversarial_audit",
        "generations": history,
        "detection_rate_by_generation": rates,
        "first_generation_nonperfect": first_generation_nonperfect,
        "staleness_gate_pass": not staleness_failures,
        "staleness_gate_failures": staleness_failures,
        "all_generations_release_pass": release_pass,
        "known_blind_spots": [
            {
                "generation": item["generation"],
                "attack_id": miss["attack_id"],
                "family": miss["family"],
                "variant": miss["variant"],
                "target_module": miss["target_module"],
                "observed_reason": miss["observed_reason"],
            }
            for item in history
            for miss in item["undetected_attacks"]
        ],
        "interpretation": (
            "Calls shipped verifiers with authored payloads. Passing the audit "
            "means the catalog is live, multi-surface, non-stale, and above its "
            "registered floor; it is not exhaustive security evidence."
        ),
    }
