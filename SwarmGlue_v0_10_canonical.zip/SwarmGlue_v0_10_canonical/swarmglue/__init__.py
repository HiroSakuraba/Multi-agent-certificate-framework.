"""Cumulative SwarmGlue v0.10 canonical research package."""

__version__ = "0.10.0"
