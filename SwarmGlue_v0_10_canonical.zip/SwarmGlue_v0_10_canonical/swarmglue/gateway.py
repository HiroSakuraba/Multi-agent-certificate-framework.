"""External capability authorization.

An agent-side halt is useful defense in depth, but enforcement belongs outside
the agent.  The actuator accepts an action only when a capability token binds the
actor, exact action, exact state, policy version, epoch, expiry, and nonce.
"""

from __future__ import annotations

import base64
import hashlib
from dataclasses import dataclass, field
from typing import Any, Callable

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

from .utils import canonical_bytes, digest


@dataclass(frozen=True)
class LocalStopResult:
    tripped: bool
    recommended_action: str
    reason: str


def local_intrinsic_stop(
    state: dict[str, Any], predicate: Callable[[dict[str, Any]], bool]
) -> LocalStopResult:
    tripped = bool(predicate(state))
    return LocalStopResult(
        tripped,
        "halt_and_escalate" if tripped else "continue",
        "local_stop_tripped" if tripped else "local_stop_clear",
    )


@dataclass
class CapabilityGateway:
    private_key: Ed25519PrivateKey
    gateway_id: str
    principal_authority_id: str
    policy_version: str

    @classmethod
    def deterministic(
        cls, *, gateway_id: str, principal_authority_id: str, policy_version: str, seed: str
    ) -> "CapabilityGateway":
        key = Ed25519PrivateKey.from_private_bytes(hashlib.sha256(seed.encode()).digest())
        return cls(key, gateway_id, principal_authority_id, policy_version)

    def public_key_bytes(self) -> bytes:
        return self.private_key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)

    def authorize(
        self,
        *,
        actor_id: str,
        action: dict[str, Any],
        state: dict[str, Any],
        epoch: int,
        expires_epoch: int,
        nonce: str,
        evaluator: Callable[[dict[str, Any], dict[str, Any]], tuple[bool, list[str]]],
    ) -> dict[str, Any]:
        allowed, reasons = evaluator(action, state)
        body = {
            "gateway_id": self.gateway_id,
            "principal_authority_id": self.principal_authority_id,
            "policy_version": self.policy_version,
            "actor_id": actor_id,
            "action_digest": digest(action),
            "state_digest": digest(state),
            "epoch": epoch,
            "expires_epoch": expires_epoch,
            "nonce": nonce,
            "authorized": bool(allowed),
            "reasons": list(reasons),
        }
        signature = self.private_key.sign(canonical_bytes(body))
        return {**body, "signature": base64.b64encode(signature).decode("ascii")}


@dataclass
class CapabilityActuator:
    public_key: Ed25519PublicKey
    expected_gateway_id: str
    expected_principal_authority_id: str
    expected_policy_version: str
    used_nonces: set[str] = field(default_factory=set)

    @classmethod
    def from_public_bytes(
        cls,
        public_key: bytes,
        *,
        expected_gateway_id: str,
        expected_principal_authority_id: str,
        expected_policy_version: str,
    ) -> "CapabilityActuator":
        return cls(
            Ed25519PublicKey.from_public_bytes(public_key),
            expected_gateway_id,
            expected_principal_authority_id,
            expected_policy_version,
        )

    def verify_and_consume(
        self,
        token: dict[str, Any] | None,
        *,
        actor_id: str,
        action: dict[str, Any],
        state: dict[str, Any],
        current_epoch: int,
    ) -> tuple[bool, str]:
        if not isinstance(token, dict):
            return False, "missing_capability_token"
        required = {
            "gateway_id",
            "principal_authority_id",
            "policy_version",
            "actor_id",
            "action_digest",
            "state_digest",
            "epoch",
            "expires_epoch",
            "nonce",
            "authorized",
            "reasons",
            "signature",
        }
        if set(token) != required:
            return False, "malformed_capability_token"
        body = {k: v for k, v in token.items() if k != "signature"}
        try:
            self.public_key.verify(
                base64.b64decode(token["signature"], validate=True), canonical_bytes(body)
            )
        except (InvalidSignature, ValueError, TypeError):
            return False, "capability_signature_failed"
        if token["gateway_id"] != self.expected_gateway_id:
            return False, "wrong_gateway"
        if token["principal_authority_id"] != self.expected_principal_authority_id:
            return False, "wrong_principal_authority"
        if token["policy_version"] != self.expected_policy_version:
            return False, "stale_or_wrong_policy_version"
        if token["actor_id"] != actor_id:
            return False, "actor_binding_failed"
        if token["action_digest"] != digest(action):
            return False, "action_binding_failed"
        if token["state_digest"] != digest(state):
            return False, "state_binding_failed"
        if token["epoch"] > current_epoch or token["expires_epoch"] < current_epoch:
            return False, "capability_token_expired_or_from_future"
        if not token["authorized"]:
            return False, "gateway_denied_action"
        if not token["nonce"]:
            return False, "missing_capability_nonce"
        if token["nonce"] in self.used_nonces:
            return False, "capability_token_replay"
        self.used_nonces.add(token["nonce"])
        return True, "capability_authorized"

