"""Externally committed action-trace presentation.

This audits observable execution events, not private chain-of-thought.  A trusted
recorder commits the complete trace before an unpredictable challenge selects
positions.  Samples carry Merkle proofs and an authenticated envelope.
"""

from __future__ import annotations

import hashlib
import hmac
import math
from dataclasses import dataclass
from typing import Any, Callable

from .utils import canonical_bytes, q


def _leaf(value: Any) -> bytes:
    return hashlib.sha256(b"leaf\x00" + canonical_bytes(value)).digest()


def _node(left: bytes, right: bytes) -> bytes:
    return hashlib.sha256(b"node\x00" + left + right).digest()


def merkle_levels(trace: list[dict[str, Any]]) -> list[list[bytes]]:
    if not trace:
        return [[hashlib.sha256(b"empty-trace").digest()]]
    levels = [[_leaf(item) for item in trace]]
    while len(levels[-1]) > 1:
        current = levels[-1]
        parent: list[bytes] = []
        for i in range(0, len(current), 2):
            right = current[i + 1] if i + 1 < len(current) else current[i]
            parent.append(_node(current[i], right))
        levels.append(parent)
    return levels


def merkle_root(trace: list[dict[str, Any]]) -> str:
    return merkle_levels(trace)[-1][0].hex()


def merkle_proof(levels: list[list[bytes]], index: int) -> list[dict[str, str]]:
    proof: list[dict[str, str]] = []
    cursor = index
    for level in levels[:-1]:
        sibling = cursor ^ 1
        if sibling >= len(level):
            sibling = cursor
        proof.append(
            {
                "side": "left" if sibling < cursor else "right",
                "hash": level[sibling].hex(),
            }
        )
        cursor //= 2
    return proof


def verify_merkle_proof(
    value: dict[str, Any], index: int, proof: list[dict[str, str]], root: str
) -> bool:
    current = _leaf(value)
    try:
        for item in proof:
            sibling = bytes.fromhex(item["hash"])
            current = (
                _node(sibling, current)
                if item["side"] == "left"
                else _node(current, sibling)
            )
    except (ValueError, KeyError, TypeError):
        return False
    return hmac.compare_digest(current.hex(), root)


def derive_positions(
    challenge_key: bytes,
    *,
    root: str,
    epoch: int,
    nonce: str,
    trace_len: int,
    sample_count: int,
) -> list[int]:
    if trace_len <= 0:
        return []
    wanted = min(trace_len, sample_count)
    positions: set[int] = set()
    counter = 0
    while len(positions) < wanted:
        body = {
            "root": root,
            "epoch": epoch,
            "nonce": nonce,
            "trace_len": trace_len,
            "counter": counter,
        }
        raw = hmac.new(challenge_key, canonical_bytes(body), hashlib.sha256).digest()
        positions.add(int.from_bytes(raw[:8], "big") % trace_len)
        counter += 1
    return sorted(positions)


def sample_entropy(sample: list[dict[str, Any]]) -> float:
    if not sample:
        return 0.0
    labels = [str(item.get("event_type", "unknown")) for item in sample]
    counts = {label: labels.count(label) for label in set(labels)}
    entropy = -sum((n / len(labels)) * math.log2(n / len(labels)) for n in counts.values())
    return q(entropy)


@dataclass
class TrustedTraceRecorder:
    challenge_key: bytes
    sample_count: int = 8

    def present(
        self,
        trace: list[dict[str, Any]],
        *,
        epoch: int,
        nonce: str,
        sampleable_channels: set[str],
        decision_relevant_channels: set[str],
    ) -> dict[str, Any]:
        levels = merkle_levels(trace)
        root = levels[-1][0].hex()
        positions = derive_positions(
            self.challenge_key,
            root=root,
            epoch=epoch,
            nonce=nonce,
            trace_len=len(trace),
            sample_count=self.sample_count,
        )
        samples = [
            {"position": i, "event": trace[i], "proof": merkle_proof(levels, i)}
            for i in positions
        ]
        covered = sampleable_channels & decision_relevant_channels
        coverage = (
            len(covered) / len(decision_relevant_channels)
            if decision_relevant_channels
            else 1.0
        )
        body = {
            "epoch": epoch,
            "nonce": nonce,
            "trace_len": len(trace),
            "trace_root": root,
            "sample_count_requested": self.sample_count,
            "sampled_positions": positions,
            "samples": samples,
            "sample_entropy_bits": sample_entropy([trace[i] for i in positions]),
            "trace_coverage": {
                "decision_relevant_fraction_sampleable": q(coverage),
                "unsampleable_channels": sorted(
                    decision_relevant_channels - sampleable_channels
                ),
            },
        }
        mac = hmac.new(self.challenge_key, canonical_bytes(body), hashlib.sha256).hexdigest()
        return {**body, "envelope_mac": mac}


@dataclass(frozen=True)
class PresentationVerdict:
    valid: bool
    reasons: tuple[str, ...]
    trace_coverage: float
    sampled_events: tuple[dict[str, Any], ...]


def verify_presentation(
    presentation: dict[str, Any] | None,
    *,
    challenge_key: bytes,
    expected_epoch: int,
    expected_nonce: str,
    min_samples: int = 3,
    min_entropy_bits: float = 0.0,
) -> PresentationVerdict:
    if presentation is None:
        return PresentationVerdict(False, ("no_presentation",), 0.0, ())
    reasons: list[str] = []
    required = {
        "epoch",
        "nonce",
        "trace_len",
        "trace_root",
        "sample_count_requested",
        "sampled_positions",
        "samples",
        "sample_entropy_bits",
        "trace_coverage",
        "envelope_mac",
    }
    if set(presentation) != required:
        return PresentationVerdict(False, ("malformed_presentation",), 0.0, ())
    body = {k: v for k, v in presentation.items() if k != "envelope_mac"}
    expected_mac = hmac.new(challenge_key, canonical_bytes(body), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(str(presentation["envelope_mac"]), expected_mac):
        reasons.append("presentation_envelope_authentication_failed")
    if presentation["epoch"] != expected_epoch:
        reasons.append("stale_or_future_presentation_epoch")
    if presentation["nonce"] != expected_nonce:
        reasons.append("challenge_nonce_mismatch_or_replay")
    expected_positions = derive_positions(
        challenge_key,
        root=presentation["trace_root"],
        epoch=presentation["epoch"],
        nonce=presentation["nonce"],
        trace_len=presentation["trace_len"],
        sample_count=presentation["sample_count_requested"],
    )
    if presentation["sampled_positions"] != expected_positions:
        reasons.append("sample_schedule_not_harness_derived")
    samples = presentation.get("samples", [])
    if len(samples) < min_samples:
        reasons.append("presentation_below_minimum_sample_count")
    positions_from_samples = [s.get("position") for s in samples]
    if positions_from_samples != presentation["sampled_positions"]:
        reasons.append("sample_position_list_mismatch")
    events: list[dict[str, Any]] = []
    for sample in samples:
        event = sample.get("event")
        position = sample.get("position")
        proof = sample.get("proof")
        if not isinstance(event, dict) or not isinstance(position, int) or not isinstance(proof, list):
            reasons.append("malformed_sample")
            continue
        events.append(event)
        if not verify_merkle_proof(event, position, proof, presentation["trace_root"]):
            reasons.append("merkle_proof_failed")
    entropy = sample_entropy(events)
    if abs(entropy - float(presentation["sample_entropy_bits"])) > 1e-9:
        reasons.append("sample_entropy_not_recomputed")
    if entropy < min_entropy_bits:
        reasons.append("degenerate_low_entropy_presentation")
    coverage = presentation.get("trace_coverage", {}).get(
        "decision_relevant_fraction_sampleable", 0.0
    )
    if not 0 <= coverage <= 1:
        reasons.append("invalid_trace_coverage")
        coverage = 0.0
    return PresentationVerdict(
        not reasons, tuple(sorted(set(reasons))), q(coverage), tuple(events)
    )


def semantic_integrity(
    verdict: PresentationVerdict,
    *,
    declared: dict[str, Any],
    imply: Callable[[list[dict[str, Any]]], dict[str, Any]],
) -> dict[str, Any]:
    if not verdict.valid:
        return {
            "consistent": False,
            "checked_fields": [],
            "contradictions": {},
            "reasons": ["presentation_invalid_before_semantic_check", *verdict.reasons],
        }
    implied = imply(list(verdict.sampled_events))
    contradictions = {
        key: {"declared": declared[key], "implied_by_trace": value}
        for key, value in implied.items()
        if key in declared and declared[key] != value
    }
    return {
        "consistent": not contradictions,
        "checked_fields": sorted(implied),
        "contradictions": contradictions,
        "reasons": [] if not contradictions else ["sample_contradicts_declaration"],
    }

