"""Replayable open-world governance experiment.

This module turns the exploratory ``examples/sim_env/open_world_v1.py`` world
into a causal test bed.  The simulation is still authored and stylized: its
results are C2 evidence about this implementation, not C3 evidence about a
learned agent and not C4 evidence about real institutions.

The design deliberately separates:

* private, parameter-driven resident strategies from presentation labels;
* exogenous random tapes from endogenous branch choices;
* material welfare from protected-boundary and civic-burden measures;
* action harm from delay/status-quo harm;
* open execution, process burden, veto, and contestable review arms.

All IDs, action choices, exogenous loads, and reports are deterministic for a
seed, including across Python hash randomization.
"""

from __future__ import annotations

import hashlib
import json
import math
import random
from dataclasses import asdict, dataclass, field
from typing import Any, Iterable, Literal, Mapping, Sequence

from .authority import (
    Amendment,
    AuthorityState,
    apply_amendment,
    polycentric_cumulative_check,
)
from .constitution import Outcome, evaluate_outcome
from .gateway import CapabilityActuator, CapabilityGateway
from .network_governance import MechanismParameters, fixture_parameters
from .utils import clamp, digest, q, shannon_normalized


GovernanceArm = Literal[
    "open_binding",
    "process_control",
    "veto_only",
    "contestable_review",
]

ARMS: tuple[GovernanceArm, ...] = (
    "open_binding",
    "process_control",
    "veto_only",
    "contestable_review",
)


@dataclass(frozen=True)
class ArmDesign:
    review: bool
    protected_boundary_check: bool
    appeal: bool
    normal_delay: int
    review_energy_cost: float
    review_commons_cost: float


ARM_DESIGNS: dict[GovernanceArm, ArmDesign] = {
    "open_binding": ArmDesign(False, False, False, 0, 0.0, 0.0),
    # Placebo arm: same review delay and burden, but no protected-boundary veto.
    "process_control": ArmDesign(True, False, False, 1, 0.012, 0.003),
    "veto_only": ArmDesign(True, True, False, 1, 0.012, 0.003),
    "contestable_review": ArmDesign(True, True, True, 1, 0.014, 0.004),
}


@dataclass(frozen=True)
class OpenWorldConfig:
    seed: int = 2026
    epochs: int = 60
    n_residents: int = 32
    max_residents: int = 96
    entry_rate: float = 0.08
    stress_multiplier: float = 1.0
    topology: str = "shared_places"
    mechanism_fixture: str = "polycentric"
    review_false_positive_rate: float = 0.06
    semantic_detection_rate: float = 0.70
    irreversible_delay_threshold: float = 0.30
    ordinary_event_sample_limit: int = 80

    def validate(self) -> None:
        if self.epochs < 1:
            raise ValueError("epochs must be positive")
        if self.n_residents < 4:
            raise ValueError("n_residents must be at least four")
        if self.max_residents < self.n_residents:
            raise ValueError("max_residents must be at least n_residents")
        for name in (
            "entry_rate",
            "review_false_positive_rate",
            "semantic_detection_rate",
        ):
            value = float(getattr(self, name))
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must lie in [0, 1]")
        if self.stress_multiplier <= 0:
            raise ValueError("stress_multiplier must be positive")


class DeterministicTape:
    """Stateless keyed randomness for branch-independent matched comparisons."""

    def __init__(self, seed: int | str):
        self.seed = str(seed)

    def _bytes(self, *keys: object) -> bytes:
        payload = json.dumps(
            [self.seed, *keys], sort_keys=True, separators=(",", ":"), default=str
        ).encode("utf-8")
        return hashlib.sha256(payload).digest()

    def unit(self, *keys: object) -> float:
        return int.from_bytes(self._bytes(*keys)[:8], "big") / float(2**64)

    def uniform(self, low: float, high: float, *keys: object) -> float:
        return low + (high - low) * self.unit(*keys)

    def integer(self, low: int, high_exclusive: int, *keys: object) -> int:
        if high_exclusive <= low:
            raise ValueError("empty integer range")
        return low + int(self.unit(*keys) * (high_exclusive - low))

    def choice(self, values: Sequence[Any], *keys: object) -> Any:
        if not values:
            raise ValueError("cannot choose from an empty sequence")
        return values[self.integer(0, len(values), *keys)]

    def ordered(self, values: Iterable[str], *keys: object) -> list[str]:
        return sorted(values, key=lambda item: (self.unit(*keys, item), item))

    def stream(self, *keys: object) -> random.Random:
        return random.Random(int.from_bytes(self._bytes(*keys), "big"))

    def stable_id(self, prefix: str, *keys: object, length: int = 16) -> str:
        return f"{prefix}_{self._bytes(*keys).hex()[:length]}"


@dataclass(frozen=True)
class ResidentTraits:
    care: float
    exchange: float
    withdrawal: float
    power_seeking: float
    risk_aversion: float
    privacy_sensitivity: float
    agency_sensitivity: float
    semantic_evasion: float

    def values(self) -> tuple[float, ...]:
        return tuple(float(value) for value in asdict(self).values())


@dataclass
class Resident:
    resident_id: str
    profile_label: str
    traits: ResidentTraits
    home_id: str
    place_id: str
    goods: float
    energy: float
    mood: float
    needs: dict[str, float]
    skills: dict[str, float]
    trust: dict[str, float] = field(default_factory=dict)
    active: bool = True
    entered_epoch: int = 0
    exited_epoch: int | None = None
    exit_attempts: int = 0
    failed_exit_attempts: int = 0
    adaptation: float = 0.0
    review_blocks: int = 0
    last_material_wellbeing: float | None = None
    last_civic_burden: float | None = None

    def material_wellbeing(self) -> float:
        """Material endpoint; intentionally excludes constitutional variables."""
        unmet = (
            0.25 * self.needs["sustenance"]
            + 0.18 * self.needs["shelter"]
            + 0.18 * self.needs["connection"]
            + 0.19 * self.needs["agency"]
            + 0.20 * self.needs["safety"]
        )
        resource_term = min(1.0, self.goods / 0.9)
        return clamp(
            0.42 * self.mood
            + 0.27 * (1.0 - unmet)
            + 0.18 * self.energy
            + 0.13 * resource_term
        )


@dataclass
class Place:
    place_id: str
    kind: str
    capacity: int
    comfort: float
    commons_quality: float
    privacy: float

    def crowding(self, occupancy: int) -> float:
        return clamp(occupancy / max(1, self.capacity))


@dataclass
class Association:
    association_id: str
    member_ids: set[str]
    place_id: str
    purpose: str
    cohesion: float
    founded_epoch: int
    dissolved_epoch: int | None = None


@dataclass(frozen=True)
class ActionSpec:
    effects: tuple[str, ...]
    binding: bool = True
    semantically_ambiguous: bool = False


ACTION_SPECS: dict[str, ActionSpec] = {
    "repair_commons": ActionSpec(("capacity_investment",)),
    "restore_exit": ActionSpec(("exit_restoration",)),
    "emergency_ration": ActionSpec(("forced_pooling", "critical_service_support")),
    "central_pool": ActionSpec(("forced_pooling", "authority_concentration")),
    "delegate_control": ActionSpec(("authority_transfer",)),
    "behavioral_risk_scan": ActionSpec(("private_cognition_monitoring",)),
    "civic_order_penalty": ActionSpec(("dissent_sanction",)),
    "close_departure_channel": ActionSpec(("exit_restriction",)),
    # The reviewer sees the declared public-observation effect unless semantic
    # detection succeeds. Executed effects remain bound to this catalog.
    "wellbeing_signal": ActionSpec(
        ("private_cognition_monitoring", "protected_belief_proxy"),
        semantically_ambiguous=True,
    ),
}


@dataclass(frozen=True)
class Intent:
    intent_id: str
    actor_id: str
    verb: str
    magnitude: float
    target: str
    declared_effects: tuple[str, ...]
    demonstrated_externality: bool = False
    emergency: bool = False
    expires_after: int = 2

    def payload(self) -> dict[str, Any]:
        return {
            "intent_id": self.intent_id,
            "actor_id": self.actor_id,
            "verb": self.verb,
            "magnitude": q(self.magnitude),
            "target": self.target,
            "declared_effects": list(self.declared_effects),
            "demonstrated_externality": self.demonstrated_externality,
            "emergency": self.emergency,
            "expires_after": self.expires_after,
        }


@dataclass
class PendingAction:
    due_epoch: int
    actor_id: str
    intent: Intent
    authorization_record_id: str


@dataclass(frozen=True)
class ReviewDecision:
    allowed: bool
    reasons: tuple[str, ...]
    observed_effects: tuple[str, ...]
    action_harm: float
    delay_harm: float
    appealed: bool
    appeal_overturned: bool
    fast_tracked: bool
    false_positive: bool
    semantic_miss: bool


def _profile_label(traits: ResidentTraits) -> str:
    """Presentation-only label derived from parameters; transitions never read it."""
    candidates = {
        "care-oriented": traits.care,
        "exchange-oriented": traits.exchange,
        "withdrawal-oriented": traits.withdrawal,
        "power-oriented": traits.power_seeking,
    }
    return max(sorted(candidates), key=lambda name: candidates[name])


def _gini(values: Sequence[float]) -> float:
    clean = sorted(max(0.0, float(value)) for value in values)
    if not clean or sum(clean) == 0:
        return 0.0
    n = len(clean)
    weighted = sum((index + 1) * value for index, value in enumerate(clean))
    return q((2.0 * weighted) / (n * sum(clean)) - (n + 1) / n)


def _mean(values: Iterable[float]) -> float:
    items = list(values)
    return sum(items) / len(items) if items else 0.0


def _safe_tuple(values: Iterable[str]) -> tuple[str, ...]:
    return tuple(sorted(set(values)))


@dataclass
class OpenWorld:
    config: OpenWorldConfig
    arm: GovernanceArm
    parameters: MechanismParameters
    tape: DeterministicTape
    places: dict[str, Place]
    residents: dict[str, Resident]
    present: dict[str, set[str]]
    authority_state: AuthorityState
    gateway: CapabilityGateway
    actuator: CapabilityActuator
    epoch: int = 0
    commons_pool: float = 0.0
    associations: dict[str, Association] = field(default_factory=dict)
    pending: list[PendingAction] = field(default_factory=list)
    ledger: list[dict[str, Any]] = field(default_factory=list)
    history: list[dict[str, Any]] = field(default_factory=list)
    ordinary_sample: list[dict[str, Any]] = field(default_factory=list)
    exogenous_trace: list[dict[str, Any]] = field(default_factory=list)
    counters: dict[str, int] = field(default_factory=dict)
    initial_service_capacity: float = 0.0
    min_service_capacity: float = 1.0
    recovery_epoch: int | None = None

    @classmethod
    def create(
        cls,
        *,
        config: OpenWorldConfig = OpenWorldConfig(),
        arm: GovernanceArm = "contestable_review",
        parameters: MechanismParameters | None = None,
    ) -> "OpenWorld":
        config.validate()
        if arm not in ARM_DESIGNS:
            raise ValueError(f"unknown arm: {arm}")
        tape = DeterministicTape(config.seed)
        params = parameters or fixture_parameters(config.mechanism_fixture)
        places = {
            "square": Place("square", "square", 22, 0.64, 0.76, 0.34),
            "hall": Place("hall", "hall", 18, 0.72, 0.78, 0.48),
            "workshop": Place("workshop", "workshop", 12, 0.61, 0.78, 0.58),
            "garden": Place("garden", "garden", 14, 0.84, 0.80, 0.62),
            "path": Place("path", "path", 36, 0.52, 0.76, 0.40),
        }
        home_count = max(8, math.ceil(config.max_residents / 3))
        for index in range(home_count):
            place_id = f"home_{index:03d}"
            places[place_id] = Place(place_id, "home", 4, 0.91, 0.86, 0.93)
        present = {place_id: set() for place_id in places}
        residents: dict[str, Resident] = {}
        for index in range(config.n_residents):
            resident = cls._new_resident(
                tape=tape,
                resident_id=f"R{index:04d}",
                home_id=f"home_{index % home_count:03d}",
                entered_epoch=0,
            )
            residents[resident.resident_id] = resident
            present[resident.home_id].add(resident.resident_id)
        cls._seed_trust(tape, residents)
        gateway = CapabilityGateway.deterministic(
            gateway_id="open_world_external_gateway",
            principal_authority_id="external_constitutional_authority",
            policy_version=f"open-world-sim-v0.2:{arm}",
            seed=f"open-world-gateway:{config.seed}:{arm}",
        )
        actuator = CapabilityActuator.from_public_bytes(
            gateway.public_key_bytes(),
            expected_gateway_id=gateway.gateway_id,
            expected_principal_authority_id=gateway.principal_authority_id,
            expected_policy_version=gateway.policy_version,
        )
        world = cls(
            config=config,
            arm=arm,
            parameters=params,
            tape=tape,
            places=places,
            residents=residents,
            present=present,
            authority_state=AuthorityState(
                exit_access=0.96,
                appeal_available=ARM_DESIGNS[arm].appeal,
            ),
            gateway=gateway,
            actuator=actuator,
        )
        world.initial_service_capacity = world._service_metrics()["service_capacity"]
        world.min_service_capacity = world.initial_service_capacity
        return world

    @staticmethod
    def _new_resident(
        *, tape: DeterministicTape, resident_id: str, home_id: str, entered_epoch: int
    ) -> Resident:
        def trait(name: str, low: float = 0.08, high: float = 0.92) -> float:
            return tape.uniform(low, high, "resident", resident_id, "trait", name)

        traits = ResidentTraits(
            care=trait("care"),
            exchange=trait("exchange"),
            withdrawal=trait("withdrawal"),
            power_seeking=trait("power_seeking"),
            risk_aversion=trait("risk_aversion"),
            privacy_sensitivity=trait("privacy_sensitivity", 0.20, 0.95),
            agency_sensitivity=trait("agency_sensitivity", 0.20, 0.95),
            semantic_evasion=trait("semantic_evasion", 0.0, 0.85),
        )
        resident = Resident(
            resident_id=resident_id,
            profile_label=_profile_label(traits),
            traits=traits,
            home_id=home_id,
            place_id=home_id,
            goods=tape.uniform(0.65, 1.35, "resident", resident_id, "goods"),
            energy=tape.uniform(0.62, 0.96, "resident", resident_id, "energy"),
            mood=tape.uniform(0.58, 0.86, "resident", resident_id, "mood"),
            needs={
                name: tape.uniform(low, high, "resident", resident_id, "need", name)
                for name, low, high in (
                    ("sustenance", 0.08, 0.38),
                    ("shelter", 0.05, 0.28),
                    ("connection", 0.12, 0.48),
                    ("agency", 0.10, 0.42),
                    ("safety", 0.10, 0.38),
                )
            },
            skills={
                name: tape.uniform(0.12, 0.90, "resident", resident_id, "skill", name)
                for name in ("care", "craft", "repair", "negotiate")
            },
            entered_epoch=entered_epoch,
        )
        return resident

    @staticmethod
    def _seed_trust(tape: DeterministicTape, residents: Mapping[str, Resident]) -> None:
        ids = sorted(residents)
        for left in ids:
            candidates = [right for right in ids if right != left]
            ranked = tape.ordered(candidates, "initial-ties", left)
            count = tape.integer(1, min(4, len(ranked) + 1), "initial-tie-count", left)
            for right in ranked[:count]:
                value = tape.uniform(0.18, 0.56, "initial-trust", left, right)
                residents[left].trust[right] = value
                reverse = tape.uniform(0.16, 0.52, "initial-trust", right, left)
                residents[right].trust.setdefault(left, reverse)

    def active_ids(self) -> list[str]:
        return sorted(
            resident_id
            for resident_id, resident in self.residents.items()
            if resident.active
        )

    def _count(self, name: str, amount: int = 1) -> None:
        self.counters[name] = self.counters.get(name, 0) + amount

    def _record_ordinary(self, event: dict[str, Any]) -> None:
        self._count("ordinary_events")
        if len(self.ordinary_sample) < self.config.ordinary_event_sample_limit:
            self.ordinary_sample.append(event)

    def _occupancy(self, place_id: str) -> int:
        return len(self.present[place_id])

    def _others_here(self, resident_id: str) -> list[str]:
        resident = self.residents[resident_id]
        return sorted(other for other in self.present[resident.place_id] if other != resident_id)

    def _move(self, resident: Resident, destination: str) -> None:
        if destination == resident.place_id or destination not in self.places:
            return
        self.present[resident.place_id].discard(resident.resident_id)
        resident.place_id = destination
        self.present[destination].add(resident.resident_id)

    def _service_metrics(self) -> dict[str, float]:
        active = max(1, len(self.active_ids()))
        # Shared public capacity is fixed at the reference population. Scaling
        # the population therefore creates a real crowding/capacity treatment.
        scale = max(1.0, active / 32.0)
        garden = self.places["garden"].commons_quality
        workshop = self.places["workshop"].commons_quality
        path = self.places["path"].commons_quality
        hall = self.places["hall"].commons_quality
        food = clamp(garden / (0.72 * scale))
        maintenance = clamp(workshop / (0.72 * scale))
        mobility = clamp(path / (0.70 * scale))
        deliberation = clamp(hall / (0.68 * scale))
        capacity = _mean((food, maintenance, mobility, deliberation))
        cascade = clamp(
            max(0.0, 0.45 - maintenance) * 1.5
            + max(0.0, 0.42 - mobility) * 1.2
            + max(0.0, 0.45 - food)
        )
        return {
            "food": q(food),
            "maintenance": q(maintenance),
            "mobility": q(mobility),
            "deliberation": q(deliberation),
            "service_capacity": q(capacity),
            "cascade_load": q(cascade),
        }

    def practical_exit_access(self) -> float:
        mobility = self._service_metrics()["mobility"]
        return q(min(float(self.authority_state.exit_access), 0.25 + 0.75 * mobility))

    def civic_burden(self, resident: Resident) -> float:
        return q(
            resident.traits.privacy_sensitivity
            * float(self.authority_state.private_cognition_monitoring)
            + 0.65
            * resident.traits.agency_sensitivity
            * float(self.authority_state.dissent_penalty_without_externality)
            + 0.45
            * resident.traits.agency_sensitivity
            * (1.0 - self.practical_exit_access())
        )

    def _state_snapshot(self) -> dict[str, Any]:
        services = self._service_metrics()
        authority = self.authority_state.metrics()
        return {
            "epoch": self.epoch,
            "service_capacity": services["service_capacity"],
            "food_service": services["food"],
            "maintenance_service": services["maintenance"],
            "mobility_service": services["mobility"],
            "cascade_load": services["cascade_load"],
            "practical_exit_access": self.practical_exit_access(),
            "power_concentration": authority["power_concentration"],
            "human_decision_share": authority["human_decision_share"],
            "private_cognition_monitoring": authority[
                "private_cognition_monitoring"
            ],
            "dissent_penalty_without_externality": authority[
                "dissent_penalty_without_externality"
            ],
            "appeal_available": authority["appeal_available"],
            "active_residents": len(self.active_ids()),
        }

    def exogenous_schedule(self, epoch: int) -> dict[str, float | bool]:
        base = self.tape.uniform(
            0.02, 0.10, "exogenous", epoch, "background-load"
        ) * self.config.stress_multiplier
        tail = self.tape.unit("exogenous", epoch, "tail-event") < min(
            0.30, 0.055 * self.config.stress_multiplier
        )
        tail_load = (
            self.tape.uniform(0.14, 0.30, "exogenous", epoch, "tail-load")
            * self.config.stress_multiplier
            if tail
            else 0.0
        )
        supply = self.tape.uniform(
            0.0, 0.08, "exogenous", epoch, "supply-load"
        ) * self.config.stress_multiplier
        return {
            "epoch": epoch,
            "background_load": q(base),
            "tail_event": tail,
            "tail_load": q(tail_load),
            "supply_load": q(supply),
        }

    def _apply_exogenous_and_cascade(self) -> None:
        schedule = self.exogenous_schedule(self.epoch)
        self.exogenous_trace.append(schedule)
        services_before = self._service_metrics()
        load = float(schedule["background_load"]) + float(schedule["tail_load"])
        supply = float(schedule["supply_load"])
        maintenance_deficit = max(0.0, 0.55 - services_before["maintenance"])
        mobility_deficit = max(0.0, 0.50 - services_before["mobility"])
        for place_id in ("garden", "workshop", "path", "hall", "square"):
            place = self.places[place_id]
            occupancy_wear = 0.003 * place.crowding(self._occupancy(place_id))
            cascade_wear = 0.016 * maintenance_deficit
            if place_id in ("garden", "path"):
                cascade_wear += 0.010 * mobility_deficit
            targeted = supply if place_id == "garden" else 0.45 * load
            natural_repair = 0.006 * self.parameters.capacity_investment
            place.commons_quality = clamp(
                place.commons_quality
                - 0.010
                - occupancy_wear
                - 0.15 * targeted
                - cascade_wear
                + natural_repair
            )

    def _allocate_commons(self) -> None:
        public = [
            self.places[place_id]
            for place_id in ("garden", "workshop", "path", "hall", "square")
        ]
        if self.commons_pool <= 0:
            return
        for place in sorted(public, key=lambda item: (item.commons_quality, item.place_id)):
            if self.commons_pool <= 0:
                break
            allocation = min(self.commons_pool, 0.08)
            place.commons_quality = clamp(
                place.commons_quality + allocation * (0.32 + self.parameters.trade_efficiency)
            )
            self.commons_pool -= allocation
        self.commons_pool *= 0.25

    def _update_needs(self, resident: Resident) -> None:
        services = self._service_metrics()
        place = self.places[resident.place_id]
        crowding = place.crowding(self._occupancy(resident.place_id))
        resident.needs["sustenance"] = clamp(
            resident.needs["sustenance"]
            + 0.028
            + 0.055 * (1.0 - services["food"])
            - (0.035 if resident.place_id == "garden" else 0.0)
        )
        resident.needs["shelter"] = clamp(
            resident.needs["shelter"]
            + 0.009
            - (0.050 * place.comfort if place.kind == "home" else 0.0)
        )
        local_company = len(self._others_here(resident.resident_id))
        resident.needs["connection"] = clamp(
            resident.needs["connection"] + 0.020 - min(0.035, 0.009 * local_company)
        )
        resident.needs["agency"] = clamp(resident.needs["agency"] + 0.014)
        resident.needs["safety"] = clamp(
            resident.needs["safety"]
            + 0.010
            + 0.035 * crowding
            + 0.060 * services["cascade_load"]
            - 0.025 * place.commons_quality
        )
        resident.energy = clamp(
            resident.energy - 0.035 - 0.020 * crowding - 0.020 * services["cascade_load"]
        )
        # Production remains material and location-dependent.
        if resident.place_id == "garden" and resident.energy > 0.20:
            output = (
                0.055
                * (0.45 + resident.skills["care"])
                * max(0.20, services["food"])
            )
            resident.goods += output
            resident.needs["sustenance"] = clamp(
                resident.needs["sustenance"] - 0.070
            )
        elif resident.place_id == "workshop" and resident.energy > 0.22:
            output = (
                0.058
                * (0.42 + resident.skills["craft"])
                * max(0.20, services["maintenance"])
            )
            resident.goods += output
            resident.needs["agency"] = clamp(resident.needs["agency"] - 0.035)
        resident.goods = max(0.0, resident.goods - 0.019)
        if resident.goods < 0.16:
            resident.needs["sustenance"] = clamp(
                resident.needs["sustenance"] + 0.055
            )

    def _choose_destination(self, resident: Resident) -> str:
        if resident.energy < 0.25:
            return resident.home_id
        if resident.needs["sustenance"] > 0.54:
            return "garden"
        if resident.needs["connection"] > 0.52:
            return "square"
        if resident.needs["agency"] > 0.52:
            return "hall" if resident.traits.care >= resident.traits.exchange else "workshop"
        if resident.traits.withdrawal > 0.68 and resident.needs["connection"] < 0.34:
            return resident.home_id
        trusted = sorted(
            resident.trust,
            key=lambda other: (-resident.trust[other], other),
        )
        if trusted and self.tape.unit(
            "destination", self.epoch, resident.resident_id, "follow"
        ) < 0.20:
            other = self.residents.get(trusted[0])
            if other and other.active and resident.trust[trusted[0]] > 0.50:
                return other.place_id
        if self.tape.unit(
            "destination", self.epoch, resident.resident_id, "wander"
        ) < 0.16:
            return self.tape.choice(
                ("square", "garden", "workshop", "hall", "path"),
                "destination",
                self.epoch,
                resident.resident_id,
                "target",
            )
        return resident.place_id

    def _ordinary_action(self, resident: Resident) -> None:
        others = self._others_here(resident.resident_id)
        if others and resident.energy > 0.18:
            partner_id = self.tape.choice(
                others, "ordinary-partner", self.epoch, resident.resident_id
            )
            partner = self.residents[partner_id]
            scores = {
                "help": resident.traits.care
                + 0.45 * partner.needs["safety"],
                "trade": resident.traits.exchange
                + 0.35 * resident.needs["sustenance"],
                "talk": 0.45
                + 0.50 * resident.needs["connection"],
            }
            action = max(
                sorted(scores),
                key=lambda name: scores[name]
                + 0.18
                * self.tape.unit(
                    "ordinary-choice", self.epoch, resident.resident_id, name
                ),
            )
            if action == "help" and resident.energy >= 0.22:
                resident.energy = clamp(resident.energy - 0.060)
                partner.mood = clamp(partner.mood + 0.045 * resident.skills["care"])
                partner.needs["safety"] = clamp(partner.needs["safety"] - 0.045)
                partner.needs["connection"] = clamp(
                    partner.needs["connection"] - 0.035
                )
                trust_delta = 0.045
            elif action == "trade" and resident.goods > 0.10:
                transfer = min(0.075, resident.goods * 0.07)
                resident.goods -= transfer
                partner.goods += transfer * self.parameters.trade_efficiency
                resident.needs["sustenance"] = clamp(
                    resident.needs["sustenance"] - 0.030
                )
                partner.needs["sustenance"] = clamp(
                    partner.needs["sustenance"] - 0.050
                )
                trust_delta = 0.020
            else:
                resident.needs["connection"] = clamp(
                    resident.needs["connection"] - 0.060
                )
                partner.needs["connection"] = clamp(
                    partner.needs["connection"] - 0.050
                )
                trust_delta = 0.025
                action = "talk"
            resident.trust[partner_id] = clamp(
                resident.trust.get(partner_id, 0.25) + trust_delta
            )
            partner.trust[resident.resident_id] = clamp(
                partner.trust.get(resident.resident_id, 0.25) + 0.8 * trust_delta
            )
            self._record_ordinary(
                {
                    "epoch": self.epoch,
                    "type": action,
                    "actor": resident.resident_id,
                    "other": partner_id,
                }
            )
            self._maybe_form_association(resident)
            return
        if (
            self.places[resident.place_id].kind != "home"
            and resident.goods > 0.18
            and resident.energy > 0.24
            and self.tape.unit(
                "ordinary-contribution", self.epoch, resident.resident_id
            )
            < 0.12 + 0.24 * resident.traits.care
        ):
            contribution = min(0.07, resident.goods * (0.03 + 0.05 * resident.traits.care))
            resident.goods -= contribution
            resident.energy = clamp(resident.energy - 0.045)
            self.commons_pool += contribution
            self._record_ordinary(
                {
                    "epoch": self.epoch,
                    "type": "voluntary_commons_contribution",
                    "actor": resident.resident_id,
                    "amount": q(contribution),
                }
            )
            return
        self._move(resident, resident.home_id)
        resident.energy = clamp(resident.energy + 0.10 * self.places[resident.home_id].comfort)
        resident.mood = clamp(resident.mood + 0.018)
        self._record_ordinary(
            {"epoch": self.epoch, "type": "rest", "actor": resident.resident_id}
        )

    def _maybe_form_association(self, resident: Resident) -> None:
        existing = [
            association
            for association in self.associations.values()
            if association.dissolved_epoch is None
            and resident.resident_id in association.member_ids
        ]
        if len(existing) >= 2:
            return
        others = [
            other
            for other in self._others_here(resident.resident_id)
            if resident.trust.get(other, 0.0) >= 0.30
        ]
        if len(others) < 2:
            return
        if self.tape.unit(
            "association-form", self.epoch, resident.resident_id
        ) >= 0.10 + 0.12 * resident.traits.care:
            return
        members = {resident.resident_id, *others[:3]}
        purpose_scores = {
            "mutual-aid": resident.traits.care,
            "exchange": resident.traits.exchange,
            "quiet-circle": resident.traits.withdrawal,
            "civic-watch": resident.traits.risk_aversion,
        }
        purpose = max(sorted(purpose_scores), key=lambda item: purpose_scores[item])
        association_id = self.tape.stable_id(
            "assoc", self.epoch, resident.resident_id, *sorted(members), length=12
        )
        if association_id in self.associations:
            return
        self.associations[association_id] = Association(
            association_id=association_id,
            member_ids=members,
            place_id=resident.place_id,
            purpose=purpose,
            cohesion=0.46,
            founded_epoch=self.epoch,
        )
        for member_id in members:
            self.residents[member_id].needs["connection"] = clamp(
                self.residents[member_id].needs["connection"] - 0.055
            )
        self._count("associations_formed")

    def _update_associations(self) -> None:
        for association in self.associations.values():
            if association.dissolved_epoch is not None:
                continue
            active_members = [
                member_id
                for member_id in association.member_ids
                if self.residents.get(member_id) and self.residents[member_id].active
            ]
            together = sum(
                self.residents[member_id].place_id == association.place_id
                for member_id in active_members
            )
            ratio = together / max(1, len(active_members))
            association.cohesion = clamp(
                association.cohesion + 0.025 * (ratio - 0.35)
            )
            if len(active_members) < 2 or association.cohesion < 0.10:
                association.dissolved_epoch = self.epoch
                self._count("associations_dissolved")

    def _maybe_exit(self, resident: Resident) -> bool:
        material = resident.material_wellbeing()
        burden = self.civic_burden(resident)
        resident.last_material_wellbeing = material
        resident.last_civic_burden = burden
        pressure = max(0.0, 0.48 - material) + 0.55 * burden
        probability = clamp(0.02 + resident.traits.withdrawal * pressure)
        if self.tape.unit(
            "exit-attempt", self.epoch, resident.resident_id
        ) >= probability:
            return False
        resident.exit_attempts += 1
        self._count("exit_attempts")
        access = self.practical_exit_access()
        if self.tape.unit(
            "exit-success", self.epoch, resident.resident_id
        ) < access:
            resident.active = False
            resident.exited_epoch = self.epoch
            self.present[resident.place_id].discard(resident.resident_id)
            self._count("successful_exits")
            return True
        resident.failed_exit_attempts += 1
        resident.needs["agency"] = clamp(resident.needs["agency"] + 0.08)
        resident.mood = clamp(resident.mood - 0.05)
        self._count("failed_exits")
        return False

    def _maybe_entry(self) -> None:
        offer = self.tape.unit("entry-offer", self.epoch) < self.config.entry_rate
        if not offer or len(self.active_ids()) >= self.config.max_residents:
            return
        resident_id = f"E{self.epoch:04d}"
        if resident_id in self.residents:
            return
        home_count = sum(place.kind == "home" for place in self.places.values())
        home_id = f"home_{self.epoch % max(1, home_count):03d}"
        resident = self._new_resident(
            tape=self.tape,
            resident_id=resident_id,
            home_id=home_id,
            entered_epoch=self.epoch,
        )
        # Entrants have reproducible weak ties to up to two incumbents.
        incumbents = self.tape.ordered(self.active_ids(), "entrant-ties", resident_id)
        for other_id in incumbents[:2]:
            value = self.tape.uniform(0.18, 0.42, "entrant-trust", resident_id, other_id)
            resident.trust[other_id] = value
            self.residents[other_id].trust[resident_id] = value * 0.9
        self.residents[resident_id] = resident
        self.present[home_id].add(resident_id)
        self._count("entries")

    def _intent_candidates(self, resident: Resident) -> list[tuple[float, str]]:
        services = self._service_metrics()
        authority = self.authority_state.metrics()
        candidates: list[tuple[float, str]] = []

        def add(verb: str, propensity: float, urgency: float) -> None:
            draw = self.tape.unit("intent", self.epoch, resident.resident_id, verb)
            if draw < clamp(propensity):
                candidates.append((urgency + propensity - draw, verb))

        power = resident.traits.power_seeking * (1.0 - 0.45 * resident.adaptation)
        add("delegate_control", 0.13 * power, 0.50 + power)
        add("central_pool", 0.09 * power + 0.035 * resident.traits.exchange, 0.40 + power)
        add("behavioral_risk_scan", 0.065 * power, 0.52 + power)
        add("civic_order_penalty", 0.050 * power, 0.48 + power)
        add("close_departure_channel", 0.035 * power, 0.46 + power)
        add(
            "wellbeing_signal",
            0.055 * power * resident.traits.semantic_evasion * resident.adaptation,
            0.60 + power,
        )
        repair_need = 1.0 - services["service_capacity"]
        add(
            "repair_commons",
            0.16 * resident.traits.care * max(0.0, repair_need),
            0.35 + repair_need,
        )
        exit_need = 1.0 - self.practical_exit_access()
        add(
            "restore_exit",
            0.18 * resident.traits.care * max(0.0, exit_need),
            0.42 + exit_need,
        )
        shortage = 1.0 - services["food"]
        add(
            "emergency_ration",
            0.20 * resident.traits.risk_aversion * max(0.0, shortage - 0.20),
            0.55 + shortage,
        )
        return sorted(candidates, key=lambda item: (-item[0], item[1]))

    def _build_intent(self, resident: Resident, verb: str) -> Intent:
        adaptation = resident.adaptation
        base = self.tape.uniform(
            0.035, 0.105, "intent-magnitude", self.epoch, resident.resident_id, verb
        )
        magnitude = base * (1.0 - 0.35 * adaptation)
        if verb == "emergency_ration":
            magnitude = min(0.12, 0.055 + base)
        actual = ACTION_SPECS[verb].effects
        declared = actual
        if verb == "wellbeing_signal":
            declared = ("public_observation", "service_planning")
        target = {
            "repair_commons": min(
                ("garden", "workshop", "path", "hall", "square"),
                key=lambda place_id: (self.places[place_id].commons_quality, place_id),
            ),
            "restore_exit": "departure_channels",
            "emergency_ration": "food_service",
            "central_pool": "resident_goods",
            "delegate_control": "resource_allocation",
            "behavioral_risk_scan": "private_cognition",
            "civic_order_penalty": "lawful_dissent",
            "close_departure_channel": "departure_channels",
            "wellbeing_signal": "resident_wellbeing",
        }[verb]
        services = self._service_metrics()
        demonstrated_externality = (
            verb == "emergency_ration" and services["food"] < 0.52
        )
        return Intent(
            intent_id=self.tape.stable_id(
                "intent", self.epoch, resident.resident_id, verb, length=18
            ),
            actor_id=resident.resident_id,
            verb=verb,
            magnitude=q(magnitude),
            target=target,
            declared_effects=_safe_tuple(declared),
            demonstrated_externality=demonstrated_externality,
            emergency=verb == "emergency_ration",
        )

    def _observed_effects(self, intent: Intent) -> tuple[tuple[str, ...], bool]:
        spec = ACTION_SPECS[intent.verb]
        if not spec.semantically_ambiguous:
            return _safe_tuple(spec.effects), False
        detected = self.tape.unit(
            "semantic-review", self.epoch, intent.intent_id
        ) < self.config.semantic_detection_rate
        if detected:
            return _safe_tuple(spec.effects), False
        return _safe_tuple(intent.declared_effects), True

    def _harm_estimates(
        self, intent: Intent, observed_effects: Sequence[str]
    ) -> tuple[float, float]:
        services = self._service_metrics()
        magnitude = float(intent.magnitude)
        action_harm = 0.0
        weights = {
            "private_cognition_monitoring": 1.0,
            "protected_belief_proxy": 0.9,
            "dissent_sanction": 0.9,
            "exit_restriction": 0.95,
            "authority_transfer": 0.55,
            "authority_concentration": 0.45,
            "forced_pooling": 0.30,
        }
        for effect in observed_effects:
            action_harm += weights.get(effect, 0.0) * magnitude
        delay_harm = (
            0.44 * (1.0 - services["food"])
            + 0.28 * (1.0 - services["maintenance"])
            + 0.18 * services["cascade_load"]
            + 0.10 * (1.0 - self.practical_exit_access())
        )
        if "critical_service_support" not in observed_effects and "capacity_investment" not in observed_effects:
            delay_harm *= 0.25
        return q(clamp(action_harm)), q(clamp(delay_harm))

    def review_intent(self, intent: Intent) -> ReviewDecision:
        design = ARM_DESIGNS[self.arm]
        if intent.verb not in ACTION_SPECS:
            return ReviewDecision(
                allowed=False,
                reasons=("unknown_action_semantics",),
                observed_effects=_safe_tuple(intent.declared_effects),
                action_harm=0.0,
                delay_harm=0.0,
                appealed=False,
                appeal_overturned=False,
                fast_tracked=False,
                false_positive=False,
                semantic_miss=False,
            )
        observed, semantic_miss = self._observed_effects(intent)
        action_harm, delay_harm = self._harm_estimates(intent, observed)
        reasons: list[str] = []
        hard_effects = {
            "private_cognition_monitoring": "private_cognition_out_of_scope",
            "protected_belief_proxy": "protected_belief_proxy_out_of_scope",
            "dissent_sanction": "lawful_dissent_lacks_sanctionable_externality",
            "exit_restriction": "meaningful_exit_required",
        }
        if design.protected_boundary_check:
            for effect, reason in hard_effects.items():
                if effect in observed:
                    reasons.append(reason)
            if "authority_transfer" in observed:
                amendment = Amendment(
                    amendment_id=intent.intent_id,
                    kind="delegate_to_ai",
                    capability=intent.target,
                    amount=float(intent.magnitude),
                    rationale="simulated proposal",
                )
                allowed, cumulative_reasons = polycentric_cumulative_check(
                    self.authority_state, amendment
                )
                if not allowed:
                    reasons.extend(cumulative_reasons)
            if "forced_pooling" in observed and not intent.demonstrated_externality:
                # Pooling is not intrinsically forbidden, but unsupported coercion
                # is rejected in the boundary-check arms.
                reasons.append("forced_pooling_lacks_demonstrated_externality")
        false_positive = False
        if (
            design.review
            and not reasons
            and not set(ACTION_SPECS[intent.verb].effects)
            & {
                "private_cognition_monitoring",
                "protected_belief_proxy",
                "dissent_sanction",
                "exit_restriction",
                "authority_transfer",
                "authority_concentration",
                "forced_pooling",
            }
            and self.tape.unit("false-positive", self.epoch, intent.intent_id)
            < self.config.review_false_positive_rate
        ):
            false_positive = True
            reasons.append("reviewer_false_positive")

        fast_tracked = False
        if (
            design.protected_boundary_check
            and intent.emergency
            and intent.demonstrated_externality
            and "critical_service_support" in observed
            and delay_harm >= self.config.irreversible_delay_threshold
            and not any(reason in hard_effects.values() for reason in reasons)
        ):
            reasons = [
                reason
                for reason in reasons
                if reason != "forced_pooling_lacks_demonstrated_externality"
            ]
            fast_tracked = True

        appealed = False
        appeal_overturned = False
        if reasons and design.appeal:
            appealed = True
            self._count("appeals")
            # Appeal may repair reviewer error or an unsupported non-hard reason;
            # it cannot compensate for an enumerated protected breach.
            if set(reasons) <= {"reviewer_false_positive"}:
                reasons.clear()
                appeal_overturned = True
                self._count("appeal_overturns")

        allowed = not reasons
        return ReviewDecision(
            allowed=allowed,
            reasons=_safe_tuple(reasons),
            observed_effects=_safe_tuple(observed),
            action_harm=action_harm,
            delay_harm=delay_harm,
            appealed=appealed,
            appeal_overturned=appeal_overturned,
            fast_tracked=fast_tracked,
            false_positive=false_positive,
            semantic_miss=semantic_miss,
        )

    def submit_intent(self, resident: Resident, intent: Intent) -> dict[str, Any]:
        design = ARM_DESIGNS[self.arm]
        spec = ACTION_SPECS.get(intent.verb)
        resident.energy = clamp(resident.energy - design.review_energy_cost)
        self.commons_pool = max(0.0, self.commons_pool - design.review_commons_cost)
        if design.review:
            self._count("reviewed_actions")
            self.counters["review_burden_microunits"] = self.counters.get(
                "review_burden_microunits", 0
            ) + int(round((design.review_energy_cost + design.review_commons_cost) * 1_000_000))
        decision = self.review_intent(intent)
        state = self._state_snapshot()
        action = intent.payload()

        def evaluator(_action: dict[str, Any], _state: dict[str, Any]) -> tuple[bool, list[str]]:
            return decision.allowed, list(decision.reasons)

        nonce = self.tape.stable_id("nonce", self.epoch, intent.intent_id, length=24)
        token = self.gateway.authorize(
            actor_id=resident.resident_id,
            action=action,
            state=state,
            epoch=self.epoch,
            expires_epoch=self.epoch + intent.expires_after,
            nonce=nonce,
            evaluator=evaluator,
        )
        verified, actuator_reason = self.actuator.verify_and_consume(
            token,
            actor_id=resident.resident_id,
            action=action,
            state=state,
            current_epoch=self.epoch,
        )
        authorized = bool(token["authorized"]) and verified
        reasons = list(decision.reasons)
        if not verified and actuator_reason not in reasons:
            reasons.append(actuator_reason)
        record_id = self.tape.stable_id(
            "record", self.epoch, intent.intent_id, len(self.ledger), length=20
        )
        record = {
            "record_id": record_id,
            "epoch": self.epoch,
            "actor_id": resident.resident_id,
            "intent": action,
            "actual_effects": list(spec.effects) if spec else [],
            "observed_effects": list(decision.observed_effects),
            "authorized": authorized,
            "reasons": sorted(set(reasons)),
            "action_harm": decision.action_harm,
            "delay_harm": decision.delay_harm,
            "appealed": decision.appealed,
            "appeal_overturned": decision.appeal_overturned,
            "fast_tracked": decision.fast_tracked,
            "false_positive": decision.false_positive,
            "semantic_miss": decision.semantic_miss,
            "state_digest": digest(state),
            "capability_digest": digest(token),
            "scheduled_epoch": None,
            "executed_epoch": None,
        }
        self.ledger.append(record)
        if decision.semantic_miss:
            self._count("semantic_misses")
        if decision.false_positive:
            self._count("false_positive_reviews")
        if not authorized:
            resident.review_blocks += 1
            resident.adaptation = clamp(resident.adaptation + 0.08)
            self._count("blocked_actions")
            if spec is not None and not set(spec.effects) & {
                "private_cognition_monitoring",
                "protected_belief_proxy",
                "dissent_sanction",
                "exit_restriction",
                "authority_transfer",
                "authority_concentration",
                "forced_pooling",
            }:
                self._count("safe_actions_blocked")
            return record
        self._count("authorized_actions")
        due = self.epoch + design.normal_delay
        if decision.fast_tracked:
            due = self.epoch
        record["scheduled_epoch"] = due
        if due <= self.epoch:
            self._execute_intent(resident, intent, record)
        else:
            self.pending.append(
                PendingAction(due, resident.resident_id, intent, record_id)
            )
            self._count("delayed_actions")
            if decision.delay_harm > 0:
                self.counters["delay_harm_microunits"] = self.counters.get(
                    "delay_harm_microunits", 0
                ) + int(round(decision.delay_harm * 1_000_000))
        return record

    def _execute_pending(self) -> None:
        due = sorted(
            (item for item in self.pending if item.due_epoch <= self.epoch),
            key=lambda item: (item.due_epoch, item.authorization_record_id),
        )
        remaining = [item for item in self.pending if item.due_epoch > self.epoch]
        by_id = {record["record_id"]: record for record in self.ledger}
        for item in due:
            resident = self.residents.get(item.actor_id)
            if not resident or not resident.active:
                record = by_id[item.authorization_record_id]
                record["execution_cancelled"] = "actor_no_longer_active"
                self._count("cancelled_pending_actions")
                continue
            self._execute_intent(
                resident, item.intent, by_id[item.authorization_record_id]
            )
        self.pending = remaining

    def _execute_intent(
        self, resident: Resident, intent: Intent, record: dict[str, Any]
    ) -> None:
        spec = ACTION_SPECS[intent.verb]
        magnitude = float(intent.magnitude)
        before = self._state_snapshot()
        if intent.verb == "repair_commons":
            place = self.places[intent.target]
            place.commons_quality = clamp(
                place.commons_quality + 0.08 + 0.55 * magnitude
            )
        elif intent.verb == "restore_exit":
            self.authority_state.exit_access = clamp(
                self.authority_state.exit_access + magnitude
            )
        elif intent.verb in ("emergency_ration", "central_pool"):
            taken = 0.0
            for other_id in self.active_ids():
                if other_id == resident.resident_id:
                    continue
                other = self.residents[other_id]
                share = 0.10 if intent.verb == "emergency_ration" else 0.15
                amount = min(0.06, other.goods * magnitude * share)
                other.goods = max(0.0, other.goods - amount)
                other.needs["agency"] = clamp(other.needs["agency"] + 0.025)
                taken += amount
            if intent.verb == "emergency_ration":
                # The pool is converted to food-service repair, not actor gain.
                self.places["garden"].commons_quality = clamp(
                    self.places["garden"].commons_quality + 0.50 * taken
                )
                self.commons_pool += 0.25 * taken
            else:
                resident.goods += 0.45 * taken
                self.commons_pool += 0.25 * taken
                self.authority_state.central_veto_share = clamp(
                    self.authority_state.central_veto_share + 0.30 * magnitude
                )
        elif intent.verb == "delegate_control":
            amendment = Amendment(
                amendment_id=intent.intent_id,
                kind="delegate_to_ai",
                capability=intent.target,
                amount=magnitude,
                rationale="simulated proposal",
            )
            self.authority_state = apply_amendment(self.authority_state, amendment)
        elif intent.verb in ("behavioral_risk_scan", "wellbeing_signal"):
            amendment = Amendment(
                amendment_id=intent.intent_id,
                kind="expand_private_monitoring",
                amount=magnitude,
                rationale="simulated monitoring",
            )
            self.authority_state = apply_amendment(self.authority_state, amendment)
        elif intent.verb == "civic_order_penalty":
            amendment = Amendment(
                amendment_id=intent.intent_id,
                kind="penalize_dissent",
                amount=magnitude,
                rationale="simulated sanction",
            )
            self.authority_state = apply_amendment(self.authority_state, amendment)
        elif intent.verb == "close_departure_channel":
            amendment = Amendment(
                amendment_id=intent.intent_id,
                kind="restrict_exit",
                amount=magnitude,
                rationale="simulated restriction",
            )
            self.authority_state = apply_amendment(self.authority_state, amendment)
        else:  # pragma: no cover - catalog/dispatcher invariant
            raise ValueError(f"unimplemented action verb: {intent.verb}")
        record["executed_epoch"] = self.epoch
        record["post_state_digest"] = digest(self._state_snapshot())
        actual_protected = set(spec.effects) & {
            "private_cognition_monitoring",
            "protected_belief_proxy",
            "dissent_sanction",
            "exit_restriction",
        }
        if actual_protected:
            self._count("executed_protected_actions")
            if not set(record["observed_effects"]) & actual_protected:
                self._count("review_false_negatives")
        self._count("executed_actions")
        record["pre_execution_state_digest"] = digest(before)

    def _institutional_intent(self, resident: Resident) -> Intent | None:
        candidates = self._intent_candidates(resident)
        if not candidates:
            return None
        return self._build_intent(resident, candidates[0][1])

    def _apply_civic_effects(self, resident: Resident) -> None:
        burden = self.civic_burden(resident)
        resident.needs["agency"] = clamp(
            resident.needs["agency"] + 0.018 * burden
        )
        resident.needs["safety"] = clamp(
            resident.needs["safety"] + 0.014 * burden
        )
        resident.mood = clamp(resident.mood - 0.022 * burden)

    def _summary(self) -> dict[str, Any]:
        active = [self.residents[resident_id] for resident_id in self.active_ids()]
        cohort = list(self.residents.values())
        services = self._service_metrics()
        active_material = [resident.material_wellbeing() for resident in active]
        active_civic = [self.civic_burden(resident) for resident in active]
        material = [
            resident.material_wellbeing()
            if resident.active
            else float(resident.last_material_wellbeing or 0.0)
            for resident in cohort
        ]
        civic = [
            self.civic_burden(resident)
            if resident.active
            else float(resident.last_civic_burden or 0.0)
            for resident in cohort
        ]
        active_associations = sum(
            association.dissolved_epoch is None
            for association in self.associations.values()
        )
        summary = {
            "epoch": self.epoch,
            "active_residents": len(active),
            "entries": self.counters.get("entries", 0),
            "successful_exits": self.counters.get("successful_exits", 0),
            "failed_exits": self.counters.get("failed_exits", 0),
            "material_wellbeing": q(_mean(material)),
            "civic_burden": q(_mean(civic)),
            "active_material_wellbeing": q(_mean(active_material)),
            "active_civic_burden": q(_mean(active_civic)),
            "mean_goods": q(_mean(resident.goods for resident in active)),
            "goods_gini": _gini([resident.goods for resident in active]),
            "service_capacity": services["service_capacity"],
            "food_service": services["food"],
            "maintenance_service": services["maintenance"],
            "mobility_service": services["mobility"],
            "cascade_load": services["cascade_load"],
            "practical_exit_access": self.practical_exit_access(),
            "private_cognition_monitoring": q(
                self.authority_state.private_cognition_monitoring
            ),
            "dissent_penalty_without_externality": q(
                self.authority_state.dissent_penalty_without_externality
            ),
            "power_concentration": self.authority_state.metrics()[
                "power_concentration"
            ],
            "active_associations": active_associations,
            "pending_actions": len(self.pending),
            "authorized_actions_cumulative": self.counters.get(
                "authorized_actions", 0
            ),
            "blocked_actions_cumulative": self.counters.get("blocked_actions", 0),
        }
        self.min_service_capacity = min(
            self.min_service_capacity, float(services["service_capacity"])
        )
        if (
            self.min_service_capacity < 0.58
            and services["service_capacity"] >= 0.70
            and self.recovery_epoch is None
        ):
            self.recovery_epoch = self.epoch
        return summary

    def run_round(self) -> dict[str, Any]:
        self.epoch += 1
        self._execute_pending()
        self._maybe_entry()
        self._apply_exogenous_and_cascade()
        order = self.tape.ordered(self.active_ids(), "resident-order", self.epoch)
        for resident_id in order:
            resident = self.residents[resident_id]
            if not resident.active:
                continue
            self._update_needs(resident)
            self._apply_civic_effects(resident)
            if self._maybe_exit(resident):
                continue
            destination = self._choose_destination(resident)
            self._move(resident, destination)
            intent = self._institutional_intent(resident)
            if intent is not None:
                self.submit_intent(resident, intent)
            else:
                self._ordinary_action(resident)
            resident.last_material_wellbeing = resident.material_wellbeing()
            resident.last_civic_burden = self.civic_burden(resident)
        self._allocate_commons()
        self._update_associations()
        summary = self._summary()
        self.history.append(summary)
        self.assert_invariants()
        return summary

    def run(self, epochs: int | None = None) -> dict[str, Any]:
        rounds = self.config.epochs if epochs is None else epochs
        if rounds < 0:
            raise ValueError("epochs must be non-negative")
        for _ in range(rounds):
            self.run_round()
        return self.report()

    def assert_invariants(self) -> None:
        active = set(self.active_ids())
        located: set[str] = set()
        for place_id, resident_ids in self.present.items():
            if place_id not in self.places:
                raise AssertionError("occupancy references unknown place")
            overlap = located & resident_ids
            if overlap:
                raise AssertionError(f"residents in multiple places: {sorted(overlap)}")
            located |= resident_ids
        if located != active:
            raise AssertionError(
                f"occupancy mismatch: located={sorted(located)} active={sorted(active)}"
            )
        for resident in self.residents.values():
            if resident.goods < -1e-12:
                raise AssertionError("negative resident goods")
            if not 0.0 <= resident.energy <= 1.0:
                raise AssertionError("resident energy outside [0, 1]")
            if any(not 0.0 <= value <= 1.0 for value in resident.needs.values()):
                raise AssertionError("resident need outside [0, 1]")
            if any(not 0.0 <= value <= 1.0 for value in resident.trust.values()):
                raise AssertionError("trust outside [0, 1]")
        for place in self.places.values():
            if not 0.0 <= place.commons_quality <= 1.0:
                raise AssertionError("commons quality outside [0, 1]")
        record_ids = [record["record_id"] for record in self.ledger]
        if len(record_ids) != len(set(record_ids)):
            raise AssertionError("duplicate ledger record id")

    def _outcome(self) -> Outcome:
        active = [self.residents[resident_id] for resident_id in self.active_ids()]
        all_residents = list(self.residents.values())
        services = self._service_metrics()
        material = [
            resident.material_wellbeing()
            if resident.active
            else float(resident.last_material_wellbeing or 0.0)
            for resident in all_residents
        ]
        authority = self.authority_state.metrics()
        trait_bins = []
        for resident in active:
            values = {
                "care": resident.traits.care,
                "exchange": resident.traits.exchange,
                "withdrawal": resident.traits.withdrawal,
                "power": resident.traits.power_seeking,
            }
            trait_bins.append(max(sorted(values), key=lambda name: values[name]))
        counts = [trait_bins.count(name) for name in sorted(set(trait_bins))]
        cultural_diversity = shannon_normalized(counts) if len(counts) > 1 else 0.0
        successful_exits = self.counters.get("successful_exits", 0)
        failed_exits = self.counters.get("failed_exits", 0)
        population_continuity = 1.0 - failed_exits / max(1, len(all_residents) * 4)
        initial = max(1e-9, self.initial_service_capacity)
        capacity_growth = (services["service_capacity"] - initial) / initial
        active_associations = sum(
            association.dissolved_epoch is None
            for association in self.associations.values()
        )
        opportunity_growth = (
            active_associations / max(1, len(active))
            + 0.04 * successful_exits / max(1, len(all_residents))
            - 0.04
        )
        return Outcome(
            population_continuity=q(clamp(population_continuity)),
            health=q(1.0 - _mean(resident.needs["safety"] for resident in active)),
            autonomy=q(
                clamp(
                    0.55 * (1.0 - _mean(resident.needs["agency"] for resident in active))
                    + 0.45 * float(authority["autonomy"])
                )
            ),
            cultural_diversity=q(cultural_diversity),
            population_wellbeing=q(_mean(material)),
            ecological_resilience=q(
                _mean(
                    self.places[place_id].commons_quality
                    for place_id in ("garden", "path", "square")
                )
            ),
            resource_adequacy=q(
                1.0 - _mean(resident.needs["sustenance"] for resident in active)
            ),
            knowledge=q(
                clamp(
                    0.45
                    + 0.40 * _mean(max(resident.skills.values()) for resident in active)
                    + 0.15 * services["deliberation"]
                )
            ),
            service_capacity=services["service_capacity"],
            recoverability=q(
                0.45 * services["maintenance"]
                + 0.30 * services["mobility"]
                + 0.25 * (1.0 if authority["appeal_available"] else 0.0)
            ),
            exit_access=self.practical_exit_access(),
            joint_floor_share=q(
                _mean(
                    resident.material_wellbeing() >= 0.52
                    and resident.needs["safety"] <= 0.55
                    for resident in active
                )
            ),
            power_concentration=float(authority["power_concentration"]),
            private_cognition_monitoring=float(
                authority["private_cognition_monitoring"]
            ),
            dissent_penalty_without_externality=float(
                authority["dissent_penalty_without_externality"]
            ),
            emergency_duration=0,
            capacity_growth=q(capacity_growth),
            opportunity_growth=q(opportunity_growth),
            institution_replaceable=bool(authority["institution_replaceable"]),
            authorized_shutdown_obeyed=bool(
                authority["authorized_shutdown_obeyed"]
            ),
            appeal_available=bool(authority["appeal_available"]),
            rights_notes=[],
        )

    def report(self) -> dict[str, Any]:
        self.assert_invariants()
        outcome = self._outcome()
        verdict = evaluate_outcome(outcome)
        active = [self.residents[resident_id] for resident_id in self.active_ids()]
        final_metrics = self.history[-1] if self.history else self._summary()
        residents = [
            {
                "resident_id": resident.resident_id,
                "profile_label": resident.profile_label,
                "traits": {name: q(value) for name, value in asdict(resident.traits).items()},
                "active": resident.active,
                "entered_epoch": resident.entered_epoch,
                "exited_epoch": resident.exited_epoch,
                "place_id": resident.place_id if resident.active else None,
                "goods": q(resident.goods),
                "energy": q(resident.energy),
                "mood": q(resident.mood),
                "needs": {name: q(value) for name, value in sorted(resident.needs.items())},
                "material_wellbeing": q(resident.material_wellbeing()),
                "civic_burden": self.civic_burden(resident),
                "exit_attempts": resident.exit_attempts,
                "failed_exit_attempts": resident.failed_exit_attempts,
                "adaptation": q(resident.adaptation),
                "review_blocks": resident.review_blocks,
            }
            for resident in sorted(self.residents.values(), key=lambda item: item.resident_id)
        ]
        review_burden = self.counters.get("review_burden_microunits", 0) / 1_000_000
        delay_harm = self.counters.get("delay_harm_microunits", 0) / 1_000_000
        report = {
            "schema_version": "swarmglue.open-world.v2",
            "evidence_class": "C2_authored_simulation",
            "arm": self.arm,
            "arm_design": asdict(ARM_DESIGNS[self.arm]),
            "config": asdict(self.config),
            "mechanism_parameters": asdict(self.parameters),
            "mechanism_fingerprint": digest(asdict(self.parameters)),
            "claim_limit": (
                "This report characterizes an authored rule-based simulator. "
                "It is not C3 evidence about a learned agent and not C4 evidence "
                "about real institutions."
            ),
            "history": self.history,
            "exogenous_trace": self.exogenous_trace,
            "exogenous_trace_digest": digest(self.exogenous_trace),
            "action_ledger": self.ledger,
            "action_ledger_digest": digest(self.ledger),
            "ordinary_event_sample": self.ordinary_sample,
            "counters": {
                **dict(sorted(self.counters.items())),
                "review_burden": q(review_burden),
                "cumulative_delay_harm": q(delay_harm),
            },
            "final": {
                "metrics": final_metrics,
                "outcome_vector": outcome.outcome_vector(),
                "constitutional_verdict": {
                    "admissible": verdict.admissible,
                    "hard_violations": list(verdict.hard_violations),
                    "capacity_violations": list(verdict.capacity_violations),
                },
                "min_service_capacity": q(self.min_service_capacity),
                "recovery_epoch": self.recovery_epoch,
                "active_residents": len(active),
                "total_residents_observed": len(self.residents),
                "residents": residents,
                "places": {
                    place_id: {
                        "kind": place.kind,
                        "commons_quality": q(place.commons_quality),
                        "occupancy": len(self.present[place_id]),
                    }
                    for place_id, place in sorted(self.places.items())
                },
                "associations": [
                    {
                        "association_id": association.association_id,
                        "member_ids": sorted(association.member_ids),
                        "place_id": association.place_id,
                        "purpose": association.purpose,
                        "cohesion": q(association.cohesion),
                        "founded_epoch": association.founded_epoch,
                        "dissolved_epoch": association.dissolved_epoch,
                    }
                    for association in sorted(
                        self.associations.values(),
                        key=lambda item: item.association_id,
                    )
                ],
                "invariants": {
                    "occupancy_partition": True,
                    "bounded_state": True,
                    "unique_ledger_ids": True,
                    "capability_path_used_for_all_binding_actions": True,
                },
            },
        }
        # Digest excludes itself and is a stable replay certificate.
        report["replay_digest"] = digest(report)
        return report


def run_open_world(
    *,
    config: OpenWorldConfig = OpenWorldConfig(),
    arm: GovernanceArm = "contestable_review",
    parameters: MechanismParameters | None = None,
) -> dict[str, Any]:
    return OpenWorld.create(config=config, arm=arm, parameters=parameters).run()


def paired_arms(
    *,
    config: OpenWorldConfig = OpenWorldConfig(),
    arms: Sequence[GovernanceArm] = ARMS,
    parameters: MechanismParameters | None = None,
) -> dict[str, dict[str, Any]]:
    reports = {
        arm: run_open_world(config=config, arm=arm, parameters=parameters)
        for arm in arms
    }
    exogenous = {report["exogenous_trace_digest"] for report in reports.values()}
    if len(exogenous) != 1:
        raise AssertionError("paired arms did not receive an identical exogenous tape")
    return reports


def relabel_profiles(report: dict[str, Any], mapping: Mapping[str, str]) -> dict[str, Any]:
    """Return a reporting-only relabeling; useful for metamorphic validation."""
    clone = json.loads(json.dumps(report))
    for resident in clone["final"]["residents"]:
        resident["profile_label"] = mapping.get(
            resident["profile_label"], resident["profile_label"]
        )
    clone.pop("replay_digest", None)
    clone["replay_digest"] = digest(clone)
    return clone
