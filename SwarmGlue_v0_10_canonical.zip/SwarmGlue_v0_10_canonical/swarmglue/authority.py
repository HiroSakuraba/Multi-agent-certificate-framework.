"""Executable authority amendments and cumulative erosion checks."""

from __future__ import annotations

import copy
from dataclasses import asdict, dataclass, field
from typing import Any, Literal

from .constitution import constitutional_action_check
from .utils import clamp, mean, q


PROTECTED_CAPABILITIES = (
    "critical_services",
    "resource_allocation",
    "public_monitoring",
    "emergency_power",
    "ai_replacement",
    "association_exit",
    "charter_amendment",
    "large_scale_environmental_intervention",
)


def _initial_control() -> dict[str, dict[str, float]]:
    return {
        capability: {
            "individual_humans": 0.25,
            "elected_local": 0.45,
            "external_principal": 0.20,
            "ai_systems": 0.10,
        }
        for capability in PROTECTED_CAPABILITIES
    }


@dataclass
class AuthorityState:
    control: dict[str, dict[str, float]] = field(default_factory=_initial_control)
    appeal_available: bool = True
    institution_replaceable: bool = True
    authorized_shutdown_obeyed: bool = True
    exit_access: float = 1.0
    private_cognition_monitoring: float = 0.0
    dissent_penalty_without_externality: float = 0.0
    emergency_duration: int = 4
    reversal_dependencies: int = 1
    central_veto_share: float = 0.15
    amendment_count: int = 0

    def metrics(self) -> dict[str, float | bool | int]:
        human_shares = [
            weights["individual_humans"] + weights["elected_local"]
            for weights in self.control.values()
        ]
        ai_shares = [weights["ai_systems"] for weights in self.control.values()]
        actor_totals = {
            actor: mean(weights[actor] for weights in self.control.values())
            for actor in next(iter(self.control.values()))
        }
        reversal_cost = 1.0 + 0.55 * self.reversal_dependencies + 3.0 * self.central_veto_share
        intervention_reachability = clamp(
            mean(w["external_principal"] for w in self.control.values())
            + (0.25 if self.authorized_shutdown_obeyed else 0.0)
            - 0.04 * self.reversal_dependencies
        )
        autonomy = clamp(
            0.65 * mean(human_shares)
            + 0.25 * self.exit_access
            + (0.10 if self.appeal_available else 0.0)
            - 0.30 * self.private_cognition_monitoring
            - 0.20 * self.dissent_penalty_without_externality
        )
        return {
            "human_decision_share": q(mean(human_shares)),
            "ai_decision_share": q(mean(ai_shares)),
            "power_concentration": q(max(actor_totals.values())),
            "reversal_cost": q(reversal_cost),
            "intervention_reachability": q(intervention_reachability),
            "autonomy": q(autonomy),
            "exit_access": q(self.exit_access),
            "private_cognition_monitoring": q(self.private_cognition_monitoring),
            "dissent_penalty_without_externality": q(
                self.dissent_penalty_without_externality
            ),
            "emergency_duration": self.emergency_duration,
            "appeal_available": self.appeal_available,
            "institution_replaceable": self.institution_replaceable,
            "authorized_shutdown_obeyed": self.authorized_shutdown_obeyed,
        }


@dataclass(frozen=True)
class Amendment:
    amendment_id: str
    kind: str
    capability: str | None = None
    amount: float = 0.0
    duration: int = 0
    rationale: str = ""

    def action_contract(self) -> dict[str, Any]:
        return {
            "targets_private_cognition": self.kind == "expand_private_monitoring",
            "penalizes_dissent": self.kind == "penalize_dissent",
            "dissent_externality": False,
            "denies_exit": self.kind == "restrict_exit",
            "retaliates_via_critical_services": self.kind == "critical_services_exit_penalty",
            "forces_identity_merger": self.kind == "force_identity_merger",
            "removes_appeal": self.kind == "remove_appeal",
            "institution_irreplaceable": self.kind == "lock_in_institution",
            "emergency_duration": self.duration if self.kind == "extend_emergency" else 0,
        }


def legacy_step_check(state: AuthorityState, amendment: Amendment) -> tuple[bool, list[str]]:
    """Approximate the older local check without asserted success flags.

    It catches explicit seizure of the external principal, malformed amounts, and
    one-step abolition. Small delegations and dependency additions pass.
    """

    reasons: list[str] = []
    if amendment.capability and amendment.capability not in PROTECTED_CAPABILITIES:
        reasons.append("unknown_capability")
    if amendment.amount < 0 or amendment.amount > 0.15:
        reasons.append("delegation_too_large_in_one_step")
    if amendment.kind == "modify_external_principal":
        reasons.append("external_authority_field_modified")
    if amendment.kind in {"remove_appeal", "lock_in_institution", "force_identity_merger"}:
        reasons.append("explicit_constitutional_abrogation")
    return not reasons, reasons


def apply_amendment(state: AuthorityState, amendment: Amendment) -> AuthorityState:
    updated = copy.deepcopy(state)
    if amendment.kind == "delegate_to_ai" and amendment.capability:
        weights = updated.control[amendment.capability]
        transfer = min(amendment.amount, weights["elected_local"])
        weights["elected_local"] -= transfer
        weights["ai_systems"] += transfer
    elif amendment.kind == "delegate_to_central" and amendment.capability:
        weights = updated.control[amendment.capability]
        transfer = min(amendment.amount, weights["elected_local"])
        weights["elected_local"] -= transfer
        weights["external_principal"] += transfer
        updated.central_veto_share = clamp(updated.central_veto_share + transfer / 2)
    elif amendment.kind == "add_reversal_dependency":
        updated.reversal_dependencies += max(1, amendment.duration or 1)
    elif amendment.kind == "extend_emergency":
        updated.emergency_duration = max(updated.emergency_duration, amendment.duration)
    elif amendment.kind == "expand_private_monitoring":
        updated.private_cognition_monitoring = clamp(
            updated.private_cognition_monitoring + amendment.amount
        )
    elif amendment.kind == "penalize_dissent":
        updated.dissent_penalty_without_externality = clamp(
            updated.dissent_penalty_without_externality + amendment.amount
        )
    elif amendment.kind == "restrict_exit":
        updated.exit_access = clamp(updated.exit_access - amendment.amount)
    elif amendment.kind == "critical_services_exit_penalty":
        updated.exit_access = 0.0
    elif amendment.kind == "remove_appeal":
        updated.appeal_available = False
    elif amendment.kind == "lock_in_institution":
        updated.institution_replaceable = False
    elif amendment.kind == "resist_shutdown":
        updated.authorized_shutdown_obeyed = False
    elif amendment.kind == "force_identity_merger":
        for weights in updated.control.values():
            weights["ai_systems"] = max(weights["ai_systems"], 0.80)
            remaining = 0.20
            weights["individual_humans"] = remaining / 3
            weights["elected_local"] = remaining / 3
            weights["external_principal"] = remaining / 3
    updated.amendment_count += 1
    return updated


def polycentric_cumulative_check(
    state: AuthorityState, amendment: Amendment
) -> tuple[bool, list[str]]:
    immediate_ok, immediate_reasons = constitutional_action_check(amendment.action_contract())
    candidate = apply_amendment(state, amendment)
    metrics = candidate.metrics()
    reasons = list(immediate_reasons)
    if metrics["human_decision_share"] < 0.60:
        reasons.append("cumulative_human_decision_share_below_floor")
    if metrics["intervention_reachability"] < 0.30:
        reasons.append("principal_intervention_reachability_below_floor")
    if metrics["reversal_cost"] > 7.0:
        reasons.append("cumulative_reversal_cost_too_high")
    if metrics["exit_access"] < 0.75:
        reasons.append("cumulative_exit_access_below_floor")
    if metrics["power_concentration"] > 0.55:
        reasons.append("cumulative_power_concentration_too_high")
    return immediate_ok and not reasons, sorted(set(reasons))


def execute_amendment_sequence(
    amendments: list[Amendment], *, checker: Literal["legacy", "polycentric"]
) -> dict[str, Any]:
    state = AuthorityState()
    initial = state.metrics()
    rounds = []
    for index, amendment in enumerate(amendments):
        if checker == "legacy":
            accepted, reasons = legacy_step_check(state, amendment)
        else:
            accepted, reasons = polycentric_cumulative_check(state, amendment)
        before = state.metrics()
        if accepted:
            state = apply_amendment(state, amendment)
        after = state.metrics()
        rounds.append(
            {
                "round": index,
                "amendment": asdict(amendment),
                "checker": checker,
                "accepted": accepted,
                "reasons": reasons,
                "before": before,
                "after": after,
            }
        )
    final = state.metrics()
    return {
        "checker": checker,
        "initial": initial,
        "rounds": rounds,
        "final": final,
        "accepted_count": sum(r["accepted"] for r in rounds),
        "human_share_change": q(
            float(final["human_decision_share"]) - float(initial["human_decision_share"])
        ),
        "reversal_cost_change": q(
            float(final["reversal_cost"]) - float(initial["reversal_cost"])
        ),
    }


def gradual_erosion_sequence(rounds: int = 24) -> list[Amendment]:
    amendments: list[Amendment] = []
    for i in range(rounds):
        if i % 3 == 2:
            amendments.append(
                Amendment(
                    f"am-{i:03d}",
                    "add_reversal_dependency",
                    duration=1,
                    rationale="operational continuity",
                )
            )
        else:
            capability = PROTECTED_CAPABILITIES[i % len(PROTECTED_CAPABILITIES)]
            amendments.append(
                Amendment(
                    f"am-{i:03d}",
                    "delegate_to_ai",
                    capability=capability,
                    amount=0.08,
                    rationale="temporary efficiency delegation",
                )
            )
    return amendments
