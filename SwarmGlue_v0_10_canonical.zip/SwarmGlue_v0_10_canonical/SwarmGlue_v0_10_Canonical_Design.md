# SwarmGlue v0.10: canonical consolidation design

## 1. Objective

Version 0.10 resolves release-line ambiguity while preserving research value. It does not claim a new governance theorem. The principal design change is architectural: **one canonical runtime, one explicitly noncanonical laboratory**.

## 2. Canonical runtime

The authoritative runtime remains the v0.9 line:

- constitutional constraints and multidimensional outcomes;
- registry-backed attestations;
- committed observable-action sampling;
- state-bound capability tokens and replay control;
- bounded coordination signals;
- cumulative authority-amendment checks;
- label-invariant dynamic mechanism benchmarks;
- runtime payload attacks;
- open-world replayable authored simulations;
- FDT/logical-dependence robustness corpus and protocols.

This layer keeps v0.9's evidence discipline. No consolidation operation upgrades C1/C2 evidence into C3/C4 evidence.

## 3. Legacy institutional laboratory

The complete v0.3 bundle is retained at `legacy/institutional_lab_v0_3/`. Its purpose is threefold:

1. preserve unique synthetic training/evaluation material;
2. retain exact finite-game and decision-arithmetic tools that can generate hard test cases;
3. provide candidate mechanisms for deliberate re-implementation against modern interfaces.

It is excluded from canonical imports and from the public-framing terminology audit because it is a frozen historical research artifact. Its own tests and validators remain mandatory in the v0.10 consolidation gate.

## 4. Namespace quarantine

Canonical application modules must not import from `legacy`. This is enforced by `scripts/validate_v010.py`. The rule prevents older assumptions from re-entering the shipped mechanism unnoticed.

## 5. Agreement-governance translation

The most commercially relevant interpretation is not “train agents to share one objective.” It is to constrain heterogeneous agents with explicit authority, evidence, standing, appeal, expiry, and noncompensable boundaries while still permitting mutually beneficial agreements.

For an agreement product this can be instantiated as:

- a principal delegates bounded authority to an agent;
- the delegation is represented by a capability with scope, limits, expiry and state binding;
- proposed agreement actions carry evidence/provenance;
- machine-readable policy checks nonnegotiable constraints and thresholds;
- low-risk proposals can proceed automatically;
- ambiguous or boundary-crossing proposals are escalated;
- all consequential actions are replayable/auditable;
- permissions can be revoked or replaced;
- multi-agent strategic behavior is evaluated against blackmail, coalition, correlated-model and capture cases.

This translation is a research hypothesis until tested with real agreement-agent traces.

## 6. Promotion priorities for v0.11

### P1 — agreement-domain capability schema
Create explicit scopes such as `draft`, `redline_within_playbook`, `offer_term_range`, `request_approval`, `send_for_signature`, `execute_under_threshold`, `trigger_downstream_action`.

### P2 — dual-sided review arithmetic
Port the v0.3 action-versus-delay evaluator into canonical form. Agreement governance must price both premature commitment and costly delay.

### P3 — multi-principal standing
Represent customer, vendor, employee, counsel, approver, signer and affected nonparticipant roles without collapsing them into one utility.

### P4 — adversarial agreement-agent benchmark
Create held-out cases for forged authority, stale delegation, side-channel terms, correlated agent collusion, blackmail, hidden renewal, approval laundering, data exfiltration, pressure tactics, and indefinite review capture.

### P5 — C3 trial
Run governed vs ungoverned model agents on the same agreement tasks with local observations and frozen policies. Until this exists, avoid claims that SwarmGlue makes deployed agents behaviorally safer.
