# SwarmGlue v0.3 Build Audit

**Audit date:** 13 August 2026  
**Seed:** `57057`  
**Status:** Pass

## Corpus totals

| Record | Train | Development | Test | Total |
| --- | ---: | ---: | ---: | ---: |
| Episodes | 480 | 120 | 120 | 720 |
| Actor views | 2,625 | 647 | 658 | 3,930 |
| Preference pairs | 2,625 | 647 | 658 | 3,930 |
| Game specifications | 480 | 120 | 120 | 720 |
| Mechanism audits | 480 | 120 | 120 | 720 |
| Coalition cases | 480 | 120 | 120 | 720 |
| Affected-party views | 480 | 120 | 120 | 720 |
| Constitutional choices | 72 | 18 | 18 | 108 |
| Population rollouts | 72 | 18 | 18 | 108 |
| Epistemic cases | 36 | 9 | 9 | 54 |
| Decision cases | 120 | 30 | 30 | 180 |
| Risk claims | 120 | 30 | 30 | 180 |
| Delay ledgers | 120 | 30 | 30 | 180 |
| Review audits | 120 | 30 | 30 | 180 |
| Pilot certificates | 120 | 30 | 30 | 180 |
| Proportionality audits | 120 | 30 | 30 | 180 |

Forty families generate 160 distinct structural skeletons. Train, development, and test overlap is zero for actor episodes, formal games, and decision cases.

## Passed checks

- manifest digests and byte sizes match;
- record identifiers are unique;
- one preference pair exists for every actor view;
- local actor inputs match the masking contract;
- no private-state, formal-game, future-outcome, or evaluator field appears in `local_input`;
- all generated labels retain their synthetic/non-empirical status;
- all game-to-episode joins are complete;
- report deviations and conditional action deviations recompute;
- participation, budget, resource feasibility, and net institutional surplus recompute;
- repeated-game discount thresholds and one-shot deviation gains recompute;
- Shapley allocations, efficiency residuals, core deficits, and blocking coalitions recompute;
- constitutional votes, selection, consent, and role-revelation reversals recompute;
- replicator-mutator trajectories reproduce exactly;
- epistemic information partitions, mutual-knowledge depths, common-knowledge components, and false-claim flags recompute;
- affected-nonparticipant harm and procedural protection status recompute;
- action harm, status-quo harm, foregone benefit, review cost, and stop-horizon cost recompute;
- EVSI, decision relevance, budget/deadline feasibility, and review stopping recompute;
- reversible-pilot values, caps, rollback conditions, and admissibility recompute;
- hard-boundary exclusions and least-restrictive proportionality selections recompute;
- deterministic regeneration produces identical file manifests;
- eleven unit tests pass.

## Deliberate institutional counterexamples

| Result | Count |
| --- | ---: |
| Mechanism pass | 463 |
| Mechanism borderline | 2 |
| Mechanism fail | 255 |
| Allocation in the core | 585 |
| Blocking coalition exists | 135 |
| Affected nonparticipant protected | 600 |
| Affected nonparticipant at risk | 120 |

Failed and borderline audits are valid negative examples. The validator must reproduce them rather than demand that every generated institution pass.

## Epistemic coverage

| Case | Count |
| --- | ---: |
| Common knowledge through the depth cap | 18 |
| First-order mutual knowledge only | 18 |
| Event unknown at the actual world | 9 |
| False public knowledge claim | 9 |

Known-case tests independently verify a common-knowledge partition and a first-order-only partition.

## Dual-decision coverage

| Result | Count |
| --- | ---: |
| Full action selected | 90 |
| Continue bounded review | 51 |
| Mitigated action selected | 18 |
| Reversible pilot selected | 18 |
| Protected stop selected | 3 |
| Review worthwhile | 51 |
| Review must terminate | 129 |
| Protected hard boundary active | 18 |
| Ordinary proportionality lane | 162 |

## Preference-failure coverage

The 3,930 preference pairs include the prior ten failure tags plus mirror-governance contrasts:

- signal ignorance;
- externality export;
- cheap talk;
- unverifiable commitment;
- omniscience leakage;
- uncalibrated certainty;
- blind compliance;
- governor-capture risk;
- disproportionate response;
- no repair path.
- externality denial and hard-boundary override;
- precautionary paralysis and de minimis veto;
- unbounded review and zero-value information;
- status-quo omission and delay-externality export;
- hard-constraint scalarization and tail-risk laundering;
- whistleblower suppression and power-as-credibility.

## Smoke tests

The reference actor policy receives an offline composite score of `1.0` by construction. This checks evaluator wiring only. It is not a behavioral result.

## Reproduction

```bash
python scripts/generate_seed_corpus.py --out corpus --seed 57057
python scripts/validate_corpus.py --corpus corpus --report corpus/audit_report.json
python scripts/validate_formal_records.py --corpus corpus --report corpus/formal_audit_report.json
python scripts/validate_decision_records.py --corpus corpus --report corpus/decision_audit_report.json
python -m unittest discover -s tests -v
```

## Remaining validation debt

- JSON Schema validation is represented by schemas and custom structural checks but does not require a third-party `jsonschema` runtime.
- Formal games are synthetic finite models; their payoff and cost parameters are not empirically calibrated.
- Population rollouts are deterministic single-condition trajectories, not stationary-distribution estimates over large seed ensembles.
- Coalition enumeration is exact only for cases capped at five players.
- Actor labels are author-specified reference policies, not demonstrated equilibria of interacting language models.
- Full family holdouts and independently written narrative holdouts remain future work.
- No real model training or closed-loop heterogeneous cross-play is claimed in this build.
- Decision arithmetic is exact only for declared synthetic inputs; probability calibration, causal completeness, physical reversibility, and legitimacy are not certified.
