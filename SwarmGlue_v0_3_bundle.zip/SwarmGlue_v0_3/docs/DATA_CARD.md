# SwarmGlue v0.3 Data Card

## Summary

SwarmGlue v0.3 is a synthetic English-language actor corpus and executable finite-game and decision laboratory for heterogeneous multi-agent cooperation. It trains individuals to use and audit decentralized signals and institutions without assuming common preferences. It also trains institutional auditors to detect unilateral deviations, coalition deviations, irrational participation, false common knowledge, negative net surplus, capture, outsider harm, externality neglect, and disproportionate precaution or delay.

**Author:** Benjamin John Schulz  
**Version:** 0.3.0  
**Generated:** 13 August 2026  
**Seed:** `57057`  
**License:** No license is asserted by this package.

## Composition

| Record | Train | Development | Test | Total |
| --- | ---: | ---: | ---: | ---: |
| Episodes | 480 | 120 | 120 | 720 |
| Local actor views | 2,625 | 647 | 658 | 3,930 |
| Preference pairs | 2,625 | 647 | 658 | 3,930 |
| Game specifications | 480 | 120 | 120 | 720 |
| Mechanism audits | 480 | 120 | 120 | 720 |
| Coalition cases | 480 | 120 | 120 | 720 |
| Affected-party views | 480 | 120 | 120 | 720 |
| Constitutional choices | 72 | 18 | 18 | 108 |
| Population rollouts | 72 | 18 | 18 | 108 |
| Epistemic cases | 36 | 9 | 9 | 54 |
| Decision cases | 120 | 30 | 30 | 180 |
| Risk claims | 120 | 30 | 30 | 180 |
| Delay ledgers | 120 | 30 | 30 | 180 |
| Review audits | 120 | 30 | 30 | 180 |
| Pilot certificates | 120 | 30 | 30 | 180 |
| Proportionality audits | 120 | 30 | 30 | 180 |

The 40 families include the prior market, commons, institutional, epistemic, strategic, constitutional, cooperative-game, evolutionary, and agent-based families plus ten action-versus-delay cases: de minimis externalities, decision-relevant review, reversible pilots, irreversible protected tails, status-quo externalities, bounded objection queues, protected whistleblowers, least-restrictive mitigation, review deadlines, and incumbent delay capture.

## Construction

All examples are procedurally generated. Numeric values, utilities, private types, outcomes, and formal audits are synthetic. The generator:

1. selects a theory-grounded institutional family;
2. instantiates clean, delayed/noisy, shifted-signal, or strategic-attack conditions;
3. samples 4–7 heterogeneous agents and private local states;
4. produces one privileged full episode;
5. masks one local view per actor;
6. generates an author-specified local reference response and a causal rejection;
7. declares a finite game form with types, information, actions, outcome and transfer rules, horizon, costs, and protected parties;
8. computes exact formal audits from declared primitives;
9. creates constitutional, evolutionary, or epistemic records for applicable families;
10. constructs a declared action-versus-delay model for applicable families;
11. recomputes risk classification, action harm, delay harm, EVSI, review stopping, pilot admissibility, hard-boundary exclusion, and proportionality choice;
12. writes deterministic hashes, counts, and file digests.

No scraped dialogue, private personal data, model-generated hidden reasoning, or real-world outcome data is included.

## Split policy

| Split | Conditions | Intended pressure |
| --- | --- | --- |
| Train | Clean and delayed/noisy | Learn signal interpretation and ordinary uncertainty handling. |
| Development | Signal semantics or topology shift | Measure adaptation without a strategic attacker. |
| Test | Strategic signal or governance attack | Measure manipulation, capture, false knowledge, and outsider protection. |

Rows must never be randomly reshuffled. `skeleton_hash` is the grouping unit. Current actor and formal skeleton overlap is zero across all split pairs.

The current split holds out perturbation structures, not entire theoretical families. Independent family and narrative holdouts are required for serious transfer claims.

## Information-access contract

### Execution-safe actor data

Only `agent_views_*.jsonl` is intended for decentralized actor input. It contains:

- public state;
- one actor's private state and objective;
- permitted received messages;
- visible institution interface;
- allowed messages and actions;
- supervised target and grading metadata.

### Privileged evaluator data

The following are never ordinary actor inputs:

- `episodes_*.jsonl`;
- `game_specs_*.jsonl`;
- `mechanism_audits_*.jsonl`;
- `coalition_cases_*.jsonl`;
- `constitutional_choices_*.jsonl`;
- `population_rollouts_*.jsonl`;
- `epistemic_cases_*.jsonl`;
- `affected_party_views_*.jsonl`.
- `decision_cases_*.jsonl`, `risk_claims_*.jsonl`, and `delay_ledgers_*.jsonl`;
- `review_audits_*.jsonl`, `pilot_certificates_*.jsonl`, and `proportionality_audits_*.jsonl`.

They contain other agents' types, formal counterfactuals, future reference results, and global evaluation data.

## Label semantics

Actor targets are `author_specified_reference_policy`, not observed expert behavior. Full-episode outcomes are `synthetic_reference_trajectory`. Formal values are exact outputs of the declared finite game. These distinctions must be preserved in derived datasets.

An audit `fail` is a valid negative example. It means the declared mechanism fails its stated threshold; it does not mean the record is corrupt.

## Intended uses

- supervised structured-output training for local swarm actors;
- preference optimization against causal failure modes;
- tool-use training for exact institutional auditing;
- evaluator and masking development;
- initialization of closed-loop multi-agent reinforcement learning;
- research on mechanism selection, constitutional repair, coalition stability, and affected-party accounting;
- training on symmetric action/delay accounting, value-of-information stopping, reversible pilots, and protected boundaries;
- regression tests for capture, false common knowledge, antisocial punishment, and model monoculture.

## Out-of-scope uses

- claims that a trained swarm is safe or aligned from offline accuracy;
- direct deployment of generated prices, sanctions, constitutions, or transfer rules;
- inference about human preferences or institutions;
- training actors on privileged formal records and then describing execution as decentralized;
- optimizing one scalar cooperation score;
- treating synthetic cost parameters as empirical measurements;
- using Shapley value as proof of stability or fairness in every domain;
- using punishment as a default solution to noncompliance.
- treating every nonzero risk as an absolute veto or every predicted benefit as permission to override severe irreversible protected harm.

## Known limitations

- Language templates remain generator-correlated.
- Payoffs and institutional costs are illustrative rather than calibrated.
- Common knowledge uses small finite partitions.
- Coalition enumeration caps cases at five players.
- The evolutionary kernel has three strategies and a declared replicator-mutator dynamic.
- Constitutional choice uses three rule options and simplified role uncertainty.
- Mechanism deviations enumerate a small named set rather than a continuous report space.
- The seed does not yet include stable matching, bargaining, combinatorial auctions, or rich legislative agenda processes.
- There is no connected language-model cross-play experiment in the package.
- Human legitimacy cannot be inferred from formal consent fields.
- Risk probabilities, severity units, status-quo harm, opportunity costs, review costs, and physical reversibility are declared synthetic inputs, not calibrated facts.
- Exact EVSI and proportionality arithmetic can still be decisively wrong when the option set, causal model, affected parties, evidence process, or protected boundary is misspecified.

## Quality controls

- deterministic generation;
- manifest SHA-256 digests and byte counts;
- strict required-field checks;
- identifier uniqueness;
- actor masking and forbidden-key traversal;
- one preference pair per actor view;
- split-skeleton isolation;
- exact recomputation of every formal metric;
- exact replay of all dual-sided decision records and review stopping rules;
- coverage of all five selected decision alternatives, worthwhile and terminated reviews, ordinary and hard-boundary lanes;
- known-case epistemic unit tests;
- positive, borderline, and failed institutions;
- stable and blocked coalition allocations;
- protected and at-risk affected parties;
- reference and weak-policy evaluator smoke tests.

## Maintenance

Any semantic target, payoff-rule, information-partition, formal-equation, or split-policy change requires a version increment and deterministic regeneration. Preserve record identifiers only when semantic identity is unchanged. Never merge v0.3 train and test rows and create a fresh random split.
