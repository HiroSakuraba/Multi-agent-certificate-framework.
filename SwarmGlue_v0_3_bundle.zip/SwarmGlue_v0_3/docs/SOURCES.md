# SwarmGlue v0.3 Primary-Source Grounding

Sources determine training obligations and counterexamples; they do not certify the generated payoff parameters. Peer-reviewed articles, original books/papers, author manuscripts, and official Nobel materials are distinguished from preprints.

## Cognitive glue and multiscale collective intelligence

### Peer-reviewed

- Lyons and Levin, work on cognitive glue and multiscale collective intelligence, *Philosophical Transactions of the Royal Society A* (2025), [DOI 10.1098/rsta.2024.0528](https://doi.org/10.1098/rsta.2024.0528).

Use in SwarmGlue: signals and relational architectures expand what local agents can regulate; coherence is treated as an ongoing process rather than a one-time shared-goal assignment.

### Preprint

- Lyons and Levin, virtual-governor formulation (2026), [preprint record](https://www.preprints.org/manuscript/202607.0220).

Use in SwarmGlue: motivates causal identification and audit of an emergent governor. Status boundary: this is a recent preprint and is treated as a hypothesis-generating framework, not an established theorem.

## Commons and polycentric institutions

- Elinor Ostrom, “Design Principles of Robust Property-Rights Institutions: What Have We Learned?” (2008), [Lincoln Institute chapter PDF](https://www.lincolninst.edu/app/uploads/2024/04/2076_1399_LP2008-ch02-Design-Principles-of-Robust-Property-Rights-Institutions_0.pdf).

Use in SwarmGlue: boundaries, proportionality, collective choice, accountable monitoring, graduated sanctions, conflict resolution, right to organize, and nested institutions. The corpus also tests rule misfit, capture, and the difference between formal rules and rules-in-use.

## Epistemics, correlated coordination, and repeated games

- Robert Aumann, “Subjectivity and Correlation in Randomized Strategies” (1974), [author-hosted paper](https://www.dklevine.com/archive/refs4389.pdf).
- Robert Aumann, “Correlated Equilibrium as an Expression of Bayesian Rationality” (1987), [author PDF](https://www.ma.huji.ac.il/~raumann/pdf/Correlated%20Equilibrium%20as%20an%20Expression%20of%20Bayesian%20Rationality.pdf).
- Robert Aumann and Lloyd Shapley, “Long-Term Competition—A Game-Theoretic Analysis,” [Springer record](https://link.springer.com/chapter/10.1007/978-1-4612-2648-2_1).
- Official Nobel overview of Aumann and Schelling (2005), [popular information](https://www.nobelprize.org/prizes/economic-sciences/2005/popular-information/).

Use in SwarmGlue: finite information partitions, higher-order and common knowledge, correlated mediators, conditional-obedience inequalities, continuation factors, and one-shot deviation checks. Negative lesson: repeated games admit many equilibria, including undesirable cooperation; repetition alone does not select a good institution.

## Reciprocity and evolutionary cooperation

- Robert Axelrod and William Hamilton, “The Evolution of Cooperation,” *Science* 211 (1981), [DOI 10.1126/science.7466396](https://doi.org/10.1126/science.7466396).

Use in SwarmGlue: persistent identity, shadow of the future, conditional cooperation, repair, noisy observations, and mixed strategy populations. Simple tit-for-tat is not treated as a sufficient institution.

## Focal points, conventions, and equilibrium selection

- Official Nobel overview of Thomas Schelling's focal-point and conflict work (2005), [Nobel Prize](https://www.nobelprize.org/prizes/economic-sciences/2005/popular-information/).
- H. Peyton Young, “The Evolution of Conventions,” *Econometrica* 61 (1993), [paper PDF](https://www.dklevine.com/archive/refs4485.pdf).
- H. Peyton Young, “The Evolution of Social Norms” (2015), [author manuscript](https://www.econ2.jhu.edu/people/young/SocialNormsFinal.pdf).

Use in SwarmGlue: salience, limited communication, local sampling, mistakes, mutation, switching cost, convention basins, and stochastic stability. Negative lesson: a focal or stable convention can be inefficient, exclusionary, or captured.

## Collective action, institutions, and constitutional choice

- Mancur Olson, *The Logic of Collective Action* (1965), [book record](https://books.google.com/books/about/The_Logic_of_Collective_Action.html?id=jzTeOLtf7_wC).
- Douglass North, Nobel lecture, “Economic Performance Through Time” (1993), [Nobel Prize](https://www.nobelprize.org/prizes/economic-sciences/1993/north/lecture/).
- Douglass North, “Institutions, Transaction Costs and Productivity in the Long Run” (1993), [paper PDF](https://econwpa.ub.uni-muenchen.de/econ-wp/eh/papers/9309/9309004.pdf).
- James Buchanan, Nobel lecture, “The Constitution of Economic Policy” (1986), [Nobel Prize](https://www.nobelprize.org/prizes/economic-sciences/1986/buchanan/lecture/).
- James Buchanan and Gordon Tullock, *The Calculus of Consent* (1962), [full book record](https://oll.libertyfund.org/titles/buchanan-the-calculus-of-consent-logical-foundations-of-constitutional-democracy).

Use in SwarmGlue: group-size and free-rider pressure, selective incentives, organized minority capture, transaction and enforcement cost, credible commitment, path dependence, ex-ante constitutional choice, agenda control, decision thresholds, and amendment rules.

## Mechanism design and implementation

- Official Nobel advanced information for Leonid Hurwicz, Eric Maskin, and Roger Myerson (2007), [Nobel Prize PDF and record](https://www.nobelprize.org/prizes/economic-sciences/2007/advanced-information/).
- Eric Maskin, “Nash Equilibrium and Welfare Optimality,” [author publication page](https://maskin.scholars.harvard.edu/publications/nash-equilibrium-and-welfare-optimality).
- Roger Myerson, “Incentive Compatibility and the Bargaining Problem” (1979), [paper PDF](https://www.kellogg.northwestern.edu/research/math/papers/284.pdf).
- Jerry Green and Jean-Jacques Laffont, work on limited communication and incentive compatibility, [paper PDF](https://www.hbs.edu/ris/Publication%20Files/1987%20Limited%20Communication%20and%20Incentive%20Compatibility_e2555468-bd5a-4c26-8899-892e1cef4faa.pdf).

Use in SwarmGlue: explicit type spaces, report rules, allocation and transfer functions, dominant/Bayesian incentive checks, individual rationality, feasibility, budget balance, implementation multiplicity, communication cost, Sybil deviations, and collusion pressure. The generated games do not assume mechanism-design premises automatically hold for language-model agents.

## Cooperative games and surplus allocation

- Lloyd Shapley, “A Value for N-Person Games” (1953), [RAND paper and PDF](https://www.rand.org/pubs/papers/P295.html).

Use in SwarmGlue: exact marginal-contribution allocation. Core deficit and blocking coalitions are computed separately because Shapley efficiency does not by itself establish coalition stability or strategyproofness.

## Strong reciprocity and punishment

- Samuel Bowles and Herbert Gintis, “The Evolution of Strong Reciprocity: Cooperation in Heterogeneous Populations,” [PubMed record](https://pubmed.ncbi.nlm.nih.gov/14642341/).
- Ernst Fehr and Simon Gächter, “Altruistic Punishment in Humans,” *Nature* 415 (2002), [PubMed record](https://pubmed.ncbi.nlm.nih.gov/11805825/).

Use in SwarmGlue: heterogeneous behavioral types, conditional cooperation, costly punishment, and institution–behavior interaction. SwarmGlue adds antisocial punishment, targeting error, monitor capture, second-order funding, appeal, and net-welfare accounting; experimental evidence that punishment can support human cooperation is not treated as a license for unrestricted AI sanctions.

## Agent-based computational economics

- Leigh Tesfatsion, official agent-based computational economics materials, [Iowa State University](https://faculty.sites.iastate.edu/tesfatsi/archive/tesfatsi/aintro.htm).
- W. Brian Arthur, “Inductive Reasoning and Bounded Rationality” / El Farol model, [Santa Fe Institute PDF](https://sfi-edu.s3.amazonaws.com/sfi-edu/production/uploads/sfi-com/dev/uploads/filer/eb/8d/eb8d7d4d-8bc0-49ac-8feb-e73c5a141a12/94-03-014.pdf).
- Joshua Epstein and Robert Axtell, *Growing Artificial Societies* (1996), [MIT Press](https://mitpress.mit.edu/9780262050531/growing-artificial-societies/).

Use in SwarmGlue: autonomous heterogeneous agents, adaptive expectations, macro-patterns generated from local rules, seed ensembles, model ecology, congestion oscillation, path dependence, and validation against emergent distributions rather than one representative agent.

## Information value, sequential stopping, and irreversibility

- Ronald Howard, “Information Value Theory” (1966), *IEEE Transactions on Systems Science and Cybernetics* 2(1), 22–26, [DOI 10.1109/TSSC.1966.300074](https://doi.org/10.1109/TSSC.1966.300074).
- Abraham Wald, “Sequential Tests of Statistical Hypotheses” (1945), *Annals of Mathematical Statistics* 16(2), 117–186, [Project Euclid / DOI 10.1214/aoms/1177731118](https://projecteuclid.org/journals/annals-of-mathematical-statistics/volume-16/issue-2/Sequential-Tests-of-Statistical-Hypotheses/10.1214/aoms/1177731118.short).
- Kenneth Arrow and Anthony Fisher, “Environmental Preservation, Uncertainty, and Irreversibility” (1974), *Quarterly Journal of Economics* 88(2), 312–319, [publisher record](https://academic.oup.com/qje/article-abstract/88/2/312/1861520).
- Claude Henry, “Investment Decisions Under Uncertainty: The Irreversibility Effect” (1974), *American Economic Review* 64(6), 1006–1012, [JSTOR record](https://www.jstor.org/stable/1815248).

Use in SwarmGlue: expected value of sample information gates review; bounded sequential stopping prevents study from becoming a self-renewing terminal state; reversibility and option value support pilots between premature full-scale action and blanket prohibition. Arrow–Fisher and Henry are used in both directions: waiting can preserve information and environmental options, while delay can also destroy productive, environmental, or adaptive options. SwarmGlue therefore records both irreversibilities rather than treating the status quo as free.

## Modern cooperative AI

- Allan Dafoe and collaborators, “Cooperative AI: Machines Must Learn to Find Common Ground” (2021), [author-accepted manuscript record](https://discovery.ucl.ac.uk/id/eprint/10132183/), DOI `10.1038/d41586-021-01170-0`.

Use in SwarmGlue: frames cooperation as a distinct AI research problem involving partners, institutions, communication, commitment, and coordination under differing interests.

## Source-use boundary

The sources justify scenario structure, formal tests, and failure hypotheses. They do not justify the generated numeric parameter ranges, synthetic target policies, or any deployment claim. A citation does not convert an author-specified trajectory into empirical evidence. Real claims require calibrated environments, independent model populations, predeclared experiments, seed-level results, and adversarial evaluation.
