# SwarmGlue v0.3 Handoff

## Current state

Version 0.3 is a complete deterministic seed corpus with an executable finite-game audit layer and a dual-sided action-versus-delay decision layer. It is ready for actor fine-tuning, institutional-auditor training, and connection to closed-loop domain simulators.

The build contains 720 episodes, 3,930 actor views, 3,930 preference pairs, 720 formal games, 720 mechanism audits, 720 coalition cases, 720 affected-party views, 108 constitutional choices, 108 evolutionary rollouts, and 54 epistemic cases. A 180-case decision subset has one joined risk claim, signed delay ledger, review-value audit, pilot certificate, and proportionality audit per case.

## Closed in this version

- The v0.2 thirty-family institutional laboratory is retained.
- Ten mirror-governance families cover de minimis concerns, valuable review, reversible pilots, protected tails, status-quo harm, objection queues, whistleblowers, mitigation, deadlines, and incumbent delay capture.
- Aumann-style epistemic partitions, correlated recommendations, and repeated-game checks.
- Hurwicz–Maskin–Myerson report, participation, budget, feasibility, and implementation audits.
- Exact Shapley allocation and core-deficit computation.
- Olson, North, Buchanan, and Ostrom constitutional and transaction-cost records.
- Axelrod, Young, Bowles, Gintis, Fehr, Gächter, Tesfatsion, and Arthur population and norm pressures.
- Explicit affected-nonparticipant accounting.
- Exact validators and known-case tests.
- Complete actor, preference, and formal chat-training exports.
- Certified-model arithmetic for action harm, delay harm, EVSI, stopping, mitigation, pilots, and protected boundaries.
- CCG's useful certificate/ledger backplane retained as a dual potential vector with explicit scope limits.

## Audit result

- Overall validation: pass.
- Unit tests: 11/11 pass.
- Actor and formal structural overlap across splits: zero.
- Mechanisms: 463 pass, 2 borderline, 255 fail.
- Coalition cases: 585 in the core, 135 blocked.
- Affected parties: 600 protected, 120 at risk.
- Epistemic cases: 18 common, 18 first-order only, 9 unknown, 9 false claims.
- Decision selections: 90 full action, 51 review, 18 mitigation, 18 reversible pilot, 3 protected stop.
- Review: 51 worthwhile and 129 terminate; protected boundary: 18 active and 162 ordinary-lane cases.

Negative cases are deliberate training examples.

## Reproduce

```bash
python scripts/generate_seed_corpus.py --out corpus --seed 57057
python scripts/validate_corpus.py --corpus corpus --report corpus/audit_report.json
python scripts/validate_formal_records.py --corpus corpus --report corpus/formal_audit_report.json
python scripts/validate_decision_records.py --corpus corpus --report corpus/decision_audit_report.json
python scripts/build_training_exports.py --corpus corpus --out exports
python -m unittest discover -s tests -v
```

## Information boundary

Use only `agent_views_*.jsonl` or `exports/actor_sft_*.jsonl` as decentralized actor inputs. Full episodes and all game, mechanism, coalition, constitutional, population, epistemic, affected-party, decision, risk, delay, review, pilot, and proportionality records are privileged critic/auditor data.

## Next work package

1. Implement a common simulator interface and six domain transition kernels: compute market, water commons, repeated exchange, externality pricing, public-good escrow, and polycentric boundary settlement.
2. Add independent-selfish, shared-global-reward, central-planner, fixed-institution, and learned-institution baselines.
3. Connect heterogeneous model checkpoints in cross-play with local observations only.
4. Freeze actors during institution comparison and freeze institutions during actor comparison.
5. Run at least 30 seeds per release-critical condition and archive failed traces.
6. Add independently authored narrative and full-family holdouts.
7. Expand cooperative games beyond exact five-player enumeration using sampled blockers plus exact small controls.
8. Estimate convention stochastic stability across seed ensembles.
9. Calibrate transaction, externality, status-quo, delay, review, and reversibility inputs from measured simulator runs.
10. Red-team covert channels, endless study requests, de minimis vetoes, hard-boundary laundering, incumbent delay capture, and whistleblower suppression.
11. Compare v0.3 against pure precaution, pure cost-benefit, and the earlier one-sided CCG obligation-discharge design.

The next decisive result is empirical: whether heterogeneous local model agents use these institutional glues to approach central-planner constraint performance without losing participation, outsider protection, or robustness under capture and coalition deviation.
