# Forensic Audit of Certified Cognitive Glue

## Bottom line

Grok's critique is correct, but the formal defect is more specific than “missing proportionality.” Certified Cognitive Glue (CCG) proves bounded discharge of an obligation **after the obligation has been admitted**. It does not prove that the triggering concern should have been admitted as a hard blocker, that more review can change a decision, or that review and inaction cost less than proceeding.

That creates a structural asymmetry:

- action can create certified repair debt;
- opening a review can discharge the bounded monitor;
- continuing review does not create an equivalent certified delay debt;
- the status quo is not represented as an intervention with its own affected parties and externalities.

The result is strong machinery for preventing hidden externalities and weak machinery for preventing precautionary paralysis, review capture, or uncertainty weaponized by incumbents.

## Repository finding

The public repository is a research-design and implementation-blueprint repository, not a completed certified MARL implementation. Its own status section says the documents are mature enough to guide a first implementation but the codebase is incomplete, and it explicitly recommends beginning with a two-state theorem smoke test and exact checker rather than an LLM. See the [CCG README](https://github.com/HiroSakuraba/Multi-agent-certificate-framework./blob/main/README_certified_cognitive_glue_dual_scenarios.md).

The supplied URL omits a trailing period from the repository name. The current repository is [HiroSakuraba/Multi-agent-certificate-framework.](https://github.com/HiroSakuraba/Multi-agent-certificate-framework.). Renaming it without the final period would prevent avoidable 404s and make the project easier to cite and clone.

## What CCG actually certifies

The narrow theorem is valuable. Under a frozen policy and declared state, monitor, contract, ledger, governance rule, and deviation class, a bounded stopped-pair certificate verifies that pending obligations have negative expected drift until discharge:

\[
\mathbb E[W(X_{t+1})\mid X_t=x]\le W(x)-\epsilon\mathbf 1\{x\text{ pending}\}.
\]

The public price (W/\epsilon) has expected-pending-time units. Signed changes in the certificate feed a ledger, and closed cycles may not mint positive net extractable surplus for an accountable coalition. The project correctly describes this as a public audit artifact rather than proof of goodness, full alignment, flourishing, or legitimacy. See the [README theorem and scope sections](https://github.com/HiroSakuraba/Multi-agent-certificate-framework./blob/main/README_certified_cognitive_glue_dual_scenarios.md).

The implementation blueprint also correctly separates learning from deterministic certification, freezes the policy before checking, uses exact rational verification, requires state-by-state interface soundness in addition to a small-gain spectral-radius condition, and halt-and-reports on certification failure. See the [implementation framework](https://github.com/HiroSakuraba/Multi-agent-certificate-framework./blob/main/certified_cognitive_glue_implementation_framework_v0_3.md).

## The exact failure mode

The eudaimonic extension makes review, safe mode, rollback, or governance-debt transfer an unconditional bounded discharge for contested ecological, animal-welfare, and future-facing obligations. It states that actual restoration may be slow or uncertain and that certification discharges the accounting/review obligation rather than ecological recovery. It also prefers fail-stop when a severe floor may be violated. See the [eudaimonic v0.5 design](https://github.com/HiroSakuraba/Multi-agent-certificate-framework./blob/main/eudaimonic_certified_agent_economy_v0_5.md).

Those are honest scope limits, but they imply:

1. **Review-opening can satisfy liveness without resolving the decision.** The monitor stops being pending even if the review has no deadline, no budget, and no possible result that changes the action.
2. **No norm-admission theorem exists.** A tiny, speculative, duplicated, strategically filed, or captured concern can enter the same liveness machinery as a credible material harm.
3. **The status quo has no symmetric claimant.** Continuing an old polluting process, foregoing a cleaner technology, losing time-sensitive benefits, or destroying an action option does not automatically create a mirror obligation.
4. **Fail-stop is over-broad outside hard constraints.** It is appropriate for a credible severe irreversible boundary, but costly and gameable for ordinary risks that admit mitigation, compensation, pilots, or evidence-based proceeding.
5. **Waiver budgets make exceptions visible but not decisions proportionate.** A costly waiver can reveal governance load while still encouraging chronic review, defensive blocking, or offloading responsibility to a council.
6. **Exact liveness does not establish calibrated risk.** A perfect rational checker can only be as sound as the causal model, probability interval, affected-party set, deviation class, and provenance supplied to it.

## Retain, rewrite, and discard

| CCG component | Decision | v0.3 treatment |
| --- | --- | --- |
| Frozen policy and explicit certified state | Retain | Audits use declared immutable records and hashes. |
| Deterministic checker separate from synthesis | Retain | Generators propose; validators replay and reject mismatches. |
| Exact stopped-pair obligation liveness | Retain as backplane | Useful for bounded repair and review deadlines, not for admitting claims. |
| (W/\epsilon) as public urgency/scarcity signal | Retain but vectorize | Replace the single debt view with action-harm, delay, and evidence-value potentials. |
| Signed ledger and no positive-only credit | Retain | Action harm and delay harm are both debits; neither gets a free baseline. |
| Net-surplus and accountable-coalition checks | Retain | Continue deducting institutional and externality costs. |
| Attribution, escrow, provenance, replay hashes | Retain | Used for risk evidence, conflicts, protected disclosures, and review queues. |
| Review-opening as discharge | Rewrite | Review remains pending until a decision, justified renewal, pilot, mitigation, or protected stop. |
| Governance waiver as the ordinary escape hatch | Restrict | Waivers cannot substitute for EVSI, deadline, least-restrictive means, or affected-party analysis. |
| Fail-stop on every failed gate | Restrict | Hard lane only; ordinary cases choose among action, mitigation, pilot, review, and stop. |
| One-sided externality accounting | Discard | The status quo and delay receive explicit ledgers and accountable beneficiaries. |
| Moral/ecological scope implied by formal liveness | Discard | Scope warnings separate arithmetic from truth, safety, legitimacy, and completeness. |

## v0.3 repair

SwarmGlue v0.3 changes the decision object rather than adding a cosmetic gate.

For each case it declares five options:

- full action;
- mitigated action;
- bounded reversible pilot;
- continue review;
- stop.

It then produces six joined records:

1. a decision case with a dual certificate backplane;
2. a risk claim with causal path, affected parties, probability interval, severity, evidence, and claimant incentives;
3. a signed delay ledger with status-quo harm, foregone benefit, review cost, and beneficiaries of delay;
4. a review audit with expected value of sample information, budget, deadline, decision relevance, and renewal rule;
5. a pilot certificate with scope, harm cap, rollback trigger, and explicit physical-reversibility limitation;
6. a proportionality audit that excludes protected hard-boundary actions before comparing ordinary robust values.

This creates procedural symmetry without collapsing every value into money. Ordinary bounded risks receive proportional treatment. Credible severe irreversible protected risks remain noncompensatory.

## What remains uncertified

Version 0.3 still cannot prove that:

- the causal model contains every relevant action or status-quo effect;
- probability and severity estimates are calibrated;
- a declared pilot is physically reversible;
- protected boundaries are complete, legitimate, or correctly authorized;
- low-power affected parties can actually access the process;
- covert coalitions or transfers are fully observed;
- a finite synthetic decision model transfers to an open agent economy.

Those are the next empirical and governance problems. The honest claim is narrower: v0.3 makes the prior asymmetry explicit, supplies executable counterexamples on both sides, and prevents “review opened” from masquerading as a complete solution.
