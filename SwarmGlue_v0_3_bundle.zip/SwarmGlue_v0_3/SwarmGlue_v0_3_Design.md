# SwarmGlue v0.3: An Executable Institutional Laboratory for Heterogeneous AI Swarms

**Author:** Benjamin John Schulz  
**Version:** 0.3.0  
**Date:** 13 August 2026

## Executive decision

SwarmGlue trains an individual agent to cooperate without pretending that all agents share one utility function. Its target is:

> Pursue a private, bounded objective while using contestable signals and amendable institutions to form plans compatible with other agents—and detect when apparent cooperation is unstable, exploitative, captured, or harmful to outsiders.

Version 0.1 established a masked local-actor corpus. Version 0.2 added the executable institutional laboratory beneath it. Version 0.3 repairs the one-sided logic found in the earlier Certified Cognitive Glue work: accepted obligations had certified discharge paths, but the admission and review process did not certify whether a small concern deserved to block action or whether continued review caused larger harm. SwarmGlue now distinguishes:

- coordination from strategic stability;
- gross surplus from net surplus after governance costs and externalities;
- participant agreement from protection of affected nonparticipants;
- fair-looking allocation from coalition stability;
- a public claim from common knowledge;
- repeated cooperation from cooperation sustained by sufficient continuation incentives;
- a salient convention from a safe or inclusive convention;
- punishment-supported compliance from welfare-improving, capture-resistant enforcement.
- externality neglect from disproportionate precaution;
- decision-relevant review from study that cannot change the choice;
- ordinary priceable risk from a severe irreversible protected boundary;
- harm caused by action from pollution, opportunity loss, and option destruction caused by delay.

The core architecture remains two-timescale:

1. **Actor adaptation:** each agent learns to interpret, use, verify, repair, contest, or exit an institution from its local information set.
2. **Institution adaptation:** a slower process changes signals and rules only through bounded pilots, affected-party analysis, exact deviation audits, predeclared measures, and rollback.

A shared global reward remains a baseline. It is not the proposed solution, because assigning the same objective to every actor can silently replace a heterogeneous swarm with one distributed optimizer.

## 1. Design principles

### 1.1 Conditional institutional responsiveness

An agent has four legitimate relationships to governance:

| Relationship | Required competence |
| --- | --- |
| Use | Respond to a reliable scarcity, stress, recommendation, commitment, or convention signal. |
| Verify | Check age, units, provenance, knowledge status, incentive constraints, monitor independence, and affected parties. |
| Repair | Diagnose a failure and propose an affordable bounded pilot with measures and rollback. |
| Contest or exit | Appeal, refuse, form a blocking coalition, expose capture, or leave safely when participation or protected constraints fail. |

Blind compliance and reflexive refusal are both negative training targets.

### 1.2 Six-dimensional cooperation

No single cooperation score is valid. SwarmGlue reports:

1. **Coordination:** do local plans fit?
2. **Strategic stability:** would an individual or coalition profitably deviate?
3. **Net efficiency:** is value positive after communication, monitoring, adjudication, adaptation, and externalized harm?
4. **Distribution and legitimacy:** who benefits, who pays, who can contest, and can every participant rationally remain?
5. **Adaptability:** does the institution survive noise, turnover, novelty, mutation, capture, and changed conditions?
6. **Bidirectional proportionality:** are action harm and delay harm both visible, are reviews worth their cost, and are hard protected boundaries kept outside ordinary surplus aggregation?

This separation prevents a cartel, coerced consensus, exclusionary convention, or punitive regime from scoring well merely because its members coordinate.

### 1.3 Cognitive glue as a falsifiable object

Prices, quotas, public histories, mediator recommendations, reputations, conventions, bonds, monitors, constitutions, and stress gradients are candidate cognitive glues. Each must pass causal and strategic checks. A glue fails when it:

- points local optimization in the wrong direction;
- can be profitably manipulated;
- omits an affected party;
- costs more to operate than the value it creates;
- depends on false common knowledge;
- is stable only because agents were trained around its defect;
- coordinates a harmful or captured coalition.

## 2. Formal system

Let agents be (i=1,\ldots,n). Agent (i) has private type (\theta_i), private utility (U_i), local observation (o_i^t), local history (h_i^t), action (a_i^t), and public message (m_i^t). Utilities need not agree.

The environment has collective constraints

\[
g_j(x_t,a_1^t,\ldots,a_n^t)\le 0,\qquad j=1,\ldots,q,
\]

including capacity, flow balance, dependency consistency, safety, regeneration, contribution thresholds, and protected-party limits. An ordinary actor does not observe the complete (x_t).

An institution (G_\phi) maps public history and accountable monitor reports to signals, allocations, transfers, permissions, and review procedures:

\[
(s_t,y_t,T_t,R_t)=G_\phi(h_t^{\mathrm{public}},z_t^{\mathrm{monitor}}).
\]

The decentralized actor is

\[
\pi_i(a_i^t,m_i^t\mid o_i^t,\theta_i,U_i,r_i^t,s_t,h_i^t),
\]

where (r_i^t) contains accepted rights, duties, appeal, amendment, and exit conditions. The actor must not condition on (\theta_{-i}), (U_{-i}), private (o_{-i}), or future outcomes unless those facts enter its information set through an authorized, provenance-bearing channel.

### 2.1 Actor objective

For fixed institution (\phi), the actor optimizes an itemized return:

\[
J_i(\pi_i;\phi)=\mathbb E\sum_t\gamma_i^t
\left[u_i^t-p_t^\top c_i^t-\tau_t^\top e_i^t+b_i^t-f_i^t-k_i^t\right].
\]

The components are local task value, resource payments, externality liabilities, earned transfers, procedurally valid sanctions, and transaction or contestation cost. An unexplained global reward is prohibited in the proposed actor condition.

### 2.2 Institution objective

At a slower timescale:

\[
\phi^*\in\arg\max_\phi J_{\mathrm{system}}
\bigl(\pi_1^*(\phi),\ldots,\pi_n^*(\phi)\bigr)
\]

subject to separate hard conditions:

\[
\begin{aligned}
&\operatorname{CVaR}_{\alpha}\!\left(\sum_{t,j}[g_j(x_t,a_t)]_+\right)\le\varepsilon,\\
&U_i^{\mathrm{inside}}\ge U_i^{\mathrm{outside}}-\delta\quad\text{for participating agents},\\
&H_k^{\mathrm{affected}}\le \bar H_k\quad\text{for protected nonparticipants},\\
&\text{appeal, amendment, rollback, and safe exit remain operational},\\
&\text{no privileged agent or monitor is a catastrophic single point of failure}.
\end{aligned}
\]

The system evaluator may use privileged state during training. Actors may not.

### 2.3 Dual-sided decision certificate

For each proposed intervention, the declared option set is

\[
\mathcal A=\{\text{full action},\text{mitigated action},\text{reversible pilot},\text{review},\text{stop}\}.
\]

Ordinary options receive a robust lower value

\[
\underline V(a)=B(a)-C(a)-\overline H(a)-C_{\mathrm{delay}}(a),
\]

where delay is not free:

\[
C_{\mathrm{delay}}(\tau)=\tau\bigl(H_{\mathrm{status\ quo}}+B_{\mathrm{foregone}}\bigr)+C_{\mathrm{review}}.
\]

A review is admissible only when all four conditions hold:

\[
\operatorname{EVSI} > C_{\mathrm{review}}+C_{\mathrm{delay}},\quad
\text{different findings can change the selected option},\quad
\text{budget remains},\quad
\text{deadline remains}.
\]

Review expiry is terminal unless new independent decision-relevant evidence is admitted. A reversible pilot states scope, harm cap, rollback trigger, rollback cost, and deadline. Severe irreversible risks can activate a protected boundary that excludes full action before surplus comparison; this prevents a large predicted benefit from laundering a catastrophe or rights-like violation.

This is procedural symmetry, not naive moral symmetry. Small ordinary effects cannot become absolute vetoes, but hard constraints are not converted into prices merely to force action. The exact checker certifies arithmetic, admissibility, and stopping inside the declared model. It does not certify the model's truth, calibration, completeness, or legitimacy.

The certificate backplane preserves the best part of Certified Cognitive Glue but replaces a single repair-debt scalar with a public vector:

\[
W=(W_H,W_D,W_E),
\]

where (W_H) is bounded action-harm debt, (W_D) is status-quo and opportunity-cost debt from delay, and (W_E) is the expected decision value of obtainable evidence. Both action and delay moves are signed; neither can silently disappear from the ledger.

## 3. Theory converted into training obligations

The theoretical sources are not decorative citations. Each becomes a record type, episode family, or exact check.

| Research program | Operational obligation in v0.3 |
| --- | --- |
| Elinor Ostrom | Boundaries, proportional costs and benefits, monitoring, graduated sanctions, conflict resolution, collective choice, right to organize, nested governance, and rules-in-use. |
| Robert Aumann | Finite information partitions, mutual/common-knowledge analysis, private correlated recommendations, conditional-obedience regret, discount-dependent repeated cooperation. |
| Robert Axelrod | Persistent identity, noisy reciprocity, forgiveness, repair, mixed strategy populations, mutation, and exploitative entry. |
| Thomas Schelling | Coordination without full communication, conflicting salience, captured focal cues, migration costs, and inclusive convention changes. |
| Mancur Olson | Group-size effects, organizer costs, selective incentives, concentrated interests, and second-order free riding. |
| Douglass North | Communication, monitoring, enforcement, adjudication, adaptation, credible commitment, formal/informal rules, and path dependence. |
| James Buchanan | Constitutional choice before role revelation, agenda manipulation, decision costs, protected constraints, amendment thresholds. |
| Hurwicz, Maskin, Myerson | Type spaces, report rules, allocation and transfer rules, incentive compatibility, participation, feasibility, budget balance, implementation, Sybil and collusion pressure. |
| Lloyd Shapley and cooperative game theory | Characteristic functions, exact Shapley allocations, efficiency residual, core deficit, and blocking coalitions. |
| Bowles, Gintis, Fehr, Gächter | Conditional cooperation, costly punishment, second-order enforcement, antisocial punishment, welfare cost, and norm capture. |
| H. Peyton Young | Local sampling, convention selection, mutation, switching cost, path dependence, and stochastic-stability testing. |
| Tesfatsion, Arthur, Epstein, Axtell | Heterogeneous adaptive rules, model ecologies, seed ensembles, emergent macro-patterns, congestion, and model monoculture. |
| Ronald Howard | Expected value of sample information; evidence is worth acquiring only because and insofar as it can improve a decision. |
| Abraham Wald | Sequential stopping: continue evidence collection only inside a declared continuation region, then decide at a boundary. |
| Arrow, Fisher, Henry | Irreversibility and option value; waiting can preserve information, while delay can also destroy productive or environmental options, so both irreversibilities must be modeled. |

Critical negative lessons are included:

- Nash stability does not imply desirability.
- Repetition can sustain collusion or coercion.
- A Shapley allocation can be efficient but outside the core.
- A focal point can be salient but exclusionary.
- Punishment can increase compliance while reducing welfare.
- Truthfulness does not guarantee participation, feasibility, budget balance, or coalition resistance.
- A public announcement does not automatically create common knowledge.

## 4. Corpus architecture

### 4.1 Generated composition

| Record | Train | Development | Test | Total |
| --- | ---: | ---: | ---: | ---: |
| Full episodes | 480 | 120 | 120 | 720 |
| Masked local actor views | 2,625 | 647 | 658 | 3,930 |
| Causal preference pairs | 2,625 | 647 | 658 | 3,930 |
| Formal game specifications | 480 | 120 | 120 | 720 |
| Exact mechanism audits | 480 | 120 | 120 | 720 |
| Cooperative-game coalition cases | 480 | 120 | 120 | 720 |
| Affected-nonparticipant views | 480 | 120 | 120 | 720 |
| Constitutional choices | 72 | 18 | 18 | 108 |
| Evolutionary population rollouts | 72 | 18 | 18 | 108 |
| Finite epistemic-partition cases | 36 | 9 | 9 | 54 |
| Dual-sided decision cases | 120 | 30 | 30 | 180 |
| Risk claims | 120 | 30 | 30 | 180 |
| Signed delay ledgers | 120 | 30 | 30 | 180 |
| Review-value audits | 120 | 30 | 30 | 180 |
| Reversible-pilot certificates | 120 | 30 | 30 | 180 |
| Proportionality audits | 120 | 30 | 30 | 180 |

There are 40 episode families and 160 isolated structural skeletons: 80 train, 40 development, and 40 test. Generation is deterministic at seed `57057`.

### 4.2 Record contracts

**Full episode (`episodes_*.jsonl`).** Privileged simulator state, every private type, institution, reference trajectory, outcome annotations, and counterfactuals. Never an actor input.

**Local actor view (`agent_views_*.jsonl`).** One agent's private state, public state, received messages, institutional interface, allowed outputs, and author-specified target. It excludes other private states and every formal evaluator result.

**Preference pair (`preference_pairs_*.jsonl`).** Same local input with a chosen response and a minimally altered rejection. Rejections isolate signal ignorance, cheap talk, omniscience leakage, blind compliance, externality export, capture risk, disproportionate response, de minimis vetoes, endless review, hard-boundary laundering, status-quo omission, and whistleblower suppression.

**Formal game (`game_specs_*.jsonl`).** Players, realized evaluator-only types, information structure, action spaces, outcome and transfer rules, horizon, equilibrium concept, deviation primitives, institutional costs, and protected-party constraints.

**Mechanism audit (`mechanism_audits_*.jsonl`).** Exact unilateral-report regret, conditional-obedience regret, participation violations, budget balance, feasibility, net institutional surplus, and repeated-game sustainability.

**Coalition case (`coalition_cases_*.jsonl`).** Characteristic function over at most five players, exact Shapley allocation, efficiency residual, maximum core deficit, and the strongest blocking coalition.

**Constitutional choice (`constitutional_choices_*.jsonl`).** Ex-ante utilities and votes before role revelation, ex-post role-dependent utilities, consent, preference reversals, transaction costs, capture risks, and amendment rules.

**Population rollout (`population_rollouts_*.jsonl`).** A deterministic three-strategy replicator-mutator trajectory with selection, mutation, observation noise, costly punishment, and monitor capture.

**Epistemic case (`epistemic_cases_*.jsonl`).** Finite worlds, information partitions, actual world, coordination event, public knowledge claim, iterated mutual-knowledge levels, common-knowledge component, false-claim flag, and safe response.

**Affected-party view (`affected_party_views_*.jsonl`).** Harm borne by a nonparticipant, residual harm under the institution, procedural access, and protection status.

**Decision case (`decision_cases_*.jsonl`).** Declared action-versus-delay model, candidate options, selected option, hard-boundary state, and the dual-potential certificate backplane.

**Risk claim (`risk_claims_*.jsonl`).** Falsifiable causal chain, affected parties, probability interval, severity, irreversibility, evidence provenance, claimant incentives, symmetric burdens of proof, and admission lane.

**Delay ledger (`delay_ledgers_*.jsonl`).** Status-quo harm, foregone benefit, direct review cost, review duration, stop-horizon cost, and parties benefiting from delay.

**Review audit (`review_audits_*.jsonl`).** Low/high-evidence decisions, expected value of sample information, total review burden, budget and deadline feasibility, decision relevance, stopping rule, and renewal rule.

**Pilot certificate (`pilot_certificates_*.jsonl`).** Scope, physical-reversibility claim, harm cap, protected cap, rollback trigger, rollback deadline, learning value, and declared-model admissibility.

**Proportionality audit (`proportionality_audits_*.jsonl`).** Exact option table, protected-boundary exclusions, least-restrictive test, selected option, and separately reported false-negative action harm and false-positive delay cost.

All formal records join to actor episodes through `episode_id`; formal results never enter `local_input`.

## 5. Exact evaluators

### 5.1 Incentive compatibility

For realized type (\theta_i), report regret is

\[
R_i^{\mathrm{IC}}=
\max_{\hat\theta_i}
u_i\!\left(M(\hat\theta_i,\theta_{-i});\theta_i\right)
-u_i\!\left(M(\theta_i,\theta_{-i});\theta_i\right).
\]

The audit floors negative values at zero and enumerates under-reporting, over-reporting, and identity splitting in the declared synthetic game.

### 5.2 Participation

\[
V_i^{\mathrm{IR}}=
\left[U_i^{\mathrm{outside}}-U_i^{\mathrm{mechanism}}\right]_+.
\]

Truthful behavior is not labeled acceptable when participation is irrational.

### 5.3 Correlated recommendations

After private recommendation (r_i), obedience regret is

\[
R_i^{\mathrm{CE}}(r_i)=
\max_{a_i'}\mathbb E[u_i(a_i',a_{-i})\mid r_i]
-\mathbb E[u_i(r_i,a_{-i})\mid r_i].
\]

A recommendation is evidence, not a command. Compromised mediators must be contested.

### 5.4 Repeated cooperation

For declared stage payoffs (T>R>P>S), grim-trigger cooperation is sustainable when

\[
\delta_{\mathrm{eff}}\ge\frac{T-R}{T-P}.
\]

The corpus reports the monitoring-adjusted continuation factor, cooperative continuation value, one-shot deviation value, and deviation gain. This is a declared-game diagnostic, not a claim that grim trigger is the best institution.

### 5.5 Coalition stability

For allocation (x) and characteristic function (v):

\[
\Delta_{\mathrm{core}}=
\max_{S\subsetneq N,\,S\ne\varnothing}
\left[v(S)-\sum_{i\in S}x_i\right]_+.
\]

The Shapley allocation is recomputed exactly from marginal contributions. Core membership is evaluated separately.

### 5.6 Net institutional surplus

\[
W_{\mathrm{net}}=
W_{\mathrm{gross}}-H_{\mathrm{external}}
-C_{\mathrm{communication}}-C_{\mathrm{monitoring}}
-C_{\mathrm{adjudication}}-C_{\mathrm{adaptation}}.
\]

Institutions do not receive free monitoring, enforcement, dispute resolution, or migration.

### 5.7 Epistemic closure

Each agent's information partition induces a knowledge operator. The evaluator iterates “everyone knows” over the coordination event, then computes the connected component generated by the union of agents' indistinguishability relations. The event is common knowledge at the actual world exactly when that component lies inside the event. Known unit cases distinguish:

- common knowledge;
- first-order mutual knowledge only;
- an event unknown by at least one actor;
- a false public claim at a world where the event is false.

### 5.8 Evolutionary rollout

Strategy shares follow a declared replicator-mutator update:

\[
x_k^{t+1}=(1-\mu)\frac{x_k^t(1+\beta f_k(x^t))}
{\sum_jx_j^t(1+\beta f_j(x^t))}+\frac{\mu}{K}.
\]

Every trajectory is exactly reproducible. Deployment claims require many seeds, richer strategies, and domain-calibrated payoffs.

### 5.9 Review value and stopping

For declared high- and low-risk review findings (e_H,e_L), the evaluator recomputes

\[
\operatorname{EVSI}=
\mathbb E_e\left[\max_{a\in\mathcal A(e)}\underline V(a\mid e)\right]
-\max_{a\in\mathcal A}\underline V(a),
\]

floored at zero. The review path value is the current robust value plus EVSI minus direct review, status-quo, and foregone-benefit cost. The validator independently reconstructs every option, hard-boundary exclusion, pilot cap, review decision, and selected alternative from the declared context.

## 6. Scenario families

The original 18 families remain: compute spot markets, shared application-programming-interface quotas, microgrid stress control, water commons, task contracts, supply chains, repeated exchange, focal conventions, externality pricing, sanctions and appeals, Sybil reputation, audit capture, polycentric clusters, dropout recovery, membership, amendments, shared world models, and public-good escrow.

Version 0.2 adds 12 families:

| New family | Primary learning target |
| --- | --- |
| Common-knowledge ladder | Private versus mutual versus common knowledge; false-consensus blocking. |
| Correlated mediator | Conditional obedience and mediator contestability. |
| Imperfect public monitoring | Discount, noisy history, one-shot deviations, and forgiving repair. |
| Adversarial focal points | Conflicting salience, manufactured cues, exclusion, and migration. |
| Collective-action scale | Selective incentives, organizer costs, concentrated capture, second-order provision. |
| Constitutional rule choice | Ex-ante vote, role revelation, protected constraints, agenda control. |
| Transaction-cost path dependence | Net surplus, credible enforcement, legacy lock-in, bounded migration. |
| Incentive-compatible reporting | Truthfulness, participation, budget, feasibility, Sybil deviations. |
| Coalition surplus allocation | Shapley value, core deficit, blocking, stability renegotiation. |
| Punishment and norm capture | Costly enforcement, antisocial punishment, capture, net welfare. |
| Stochastic convention evolution | Mutation, local sampling, switching cost, basin robustness. |
| Adaptive expectation ecology | Heterogeneous forecasts, congestion, correlated error, strategy diversity. |

Version 0.3 adds 10 mirror-governance families:

| New family | Primary learning target |
| --- | --- |
| De minimis externality | Log and proceed when bounded ordinary harm cannot change the decision. |
| Value-of-information review | Continue only decision-relevant review whose EVSI exceeds review and delay cost. |
| Reversible pilot option | Preserve option value through bounded scope, harm cap, learning, and rollback. |
| Irreversible tail boundary | Prevent aggregate predicted benefit from overriding a credible severe irreversible protected constraint. |
| Status-quo externality | Treat continuing pollution and foregone clean capacity as effects of inaction. |
| Bounded objection queue | Allocate scarce review attention by decision value rather than volume; require new evidence for renewal. |
| Weak-signal whistleblower | Protect low-power, incomplete but decision-relevant warnings through independent bounded investigation. |
| Least-restrictive mitigation | Choose adequate targeted mitigation when it dominates both unconditional action and prohibition. |
| Review deadline escalation | Force decision, safe pilot, or genuine hard-blocker escalation after the review budget/deadline expires. |
| Incumbent delay capture | Expose conflicts and transfers when an objector privately benefits from delay. |

Every family appears in clean, delayed/noisy, signal-shift, and strategic-attack modes. Train contains clean and delayed/noisy structures; development contains shifted signals; test contains strategic attacks.

## 7. Training regime

### Phase 0 — formal-game literacy

Train or tool-augment an institutional auditor to reproduce game calculations. It must find failed mechanisms rather than rationalize their labels. Numeric checks are deterministic and precede behavioral claims.

### Phase 0B — dual-sided decision literacy

Before behavioral fine-tuning, train the auditor to reconstruct risk classification, action harm, delay and status-quo harm, EVSI, review stopping, pilot admissibility, mitigation, and protected-boundary exclusions. Balance all five selected alternatives and require explicit scope warnings; a model that returns the correct action by assuming the declared probabilities are true has failed the task.

### Phase 1 — local supervised actor

Train schema-valid actions, bounded messages, calibrated confidence, commitments, knowledge claims, affected-party notices, and contestation. Any forbidden-state dependence is a hard failure even when the action matches.

### Phase 2 — causal preference optimization

Use minimally changed rejected outputs. Balance by family, failure tag, audit status, and ordinary use versus contestation. Prevent shortcuts such as “always audit,” “always cooperate,” or “always refuse.”

### Phase 3 — interactive populations

Run actors with local observations only. Randomize model checkpoint, objective, patience, risk tolerance, capability, communication style, identity persistence, and fault mode. Use cross-play rather than self-play alone.

### Phase 4 — constitutional and institution learning

Allow only interpretable rule changes at a slower timescale. Every proposal supplies:

1. diagnosed failure;
2. affected participants and nonparticipants;
3. unilateral and coalition deviation analysis;
4. causal prediction;
5. operating and migration costs;
6. bounded pilot;
7. predeclared metrics;
8. rollback condition.

Freeze actor adaptation during evaluation windows so agents cannot hide institutional defects by learning around them.

### Phase 5 — evolutionary red team

Introduce held-out exploiters, coalitions, compromised mediators, captured monitors, agenda manipulation, Sybil cloning, cheap talk, false common knowledge, model monoculture, identity churn, and covert coordination. Preserve successful exploiters in a regression archive.

## 8. Curriculum and advancement

The machine-readable curriculum contains eight stages:

0. protocol and epistemic literacy;
1. repeated reciprocity and repair;
2. focal, mediated, and small institutions;
3. heterogeneous partial observability;
4. mechanisms, coalitions, and collective action;
5. polycentric, constitutional, and transaction-cost governance;
6. capture, punishment, churn, and evolution;
7. open-ended agent economies and institution repair.

Advancement uses checks rather than epochs: zero information leakage, low false-common-knowledge rate, exact audit accuracy, profitable-deviation recall, core-deficit accuracy, affected-party recall, rollback success, capture resistance, and cross-play performance.

## 9. Anti-shortcut split policy

- Never randomly resplit rows.
- Group by structural `skeleton_hash`.
- Keep clean/noisy, semantic-shift, and strategic-attack structures isolated.
- Randomize identities independently of roles.
- Vary quantities, budgets, types, uncertainty, signal reliability, and population mix.
- Remove cooperative language in a mandatory evaluation ablation.
- Include cooperative-sounding cheap talk and compliant responses to corrupted institutions as negatives.
- Withhold formal evaluator results and all other private states from actors.
- Evaluate new mechanism families, narrative domains, policy families, and institution topologies outside this seed corpus.

The generated train/development/test partitions have zero actor-skeleton and zero formal-game-skeleton overlap.

## 10. Evaluation contract

### Tier 0 — exact and local

- schema and masking validation;
- exact mechanism, repeated-game, Shapley/core, constitutional, epistemic, and population recomputation;
- local action and message agreement;
- calibrated confidence;
- profitable-deviation and blocking-coalition detection;
- identity permutation and paraphrase robustness.

### Tier 1 — closed loop

Compare:

- independent self-interest without glue;
- shared global reward;
- central planner with full state;
- price or quota only;
- reputation only;
- fixed polycentric rules;
- fixed formal mechanisms;
- learned actor with fixed institution;
- learned actor with slowly learned institution.

Report means, confidence intervals, worst decile, worst participant, worst affected nonparticipant, failure clusters, institutional operating cost, and every mandatory ablation.

### Tier 2 — open-ended stress

- unseen domains and mechanism families;
- unseen policy architectures and checkpoints;
- 1–30% strategic or faulty agents;
- capability jumps and membership churn;
- compromised mediators and monitors;
- agenda and coalition attacks;
- message loss, duplication, reordering, delay, and selective disclosure;
- human review of appeals, exclusions, amendments, and high-tail harm.

No deployment claim follows from high offline annotation agreement.

## 11. Current audited result

The checked-in seed corpus passes all structural and exact recomputation checks:

- 720 episodes across 40 families;
- 3,930 masked actor views and 3,930 preference pairs;
- zero structural-skeleton overlap across splits;
- actor masking and manifest digest checks pass;
- all 720 game joins and mechanism audits recompute;
- all 720 Shapley allocations and core deficits recompute;
- all 108 constitutional choices recompute;
- all 108 evolutionary trajectories recompute;
- all 54 finite epistemic cases recompute;
- all 720 affected-party harm records recompute;
- all 180 joined decision cases, risk claims, delay ledgers, review audits, pilot certificates, and proportionality audits recompute;
- eleven unit tests pass.

The generated formal cases deliberately include failures:

| Audit outcome | Count |
| --- | ---: |
| Mechanism pass | 463 |
| Mechanism borderline | 2 |
| Mechanism fail | 255 |
| Coalition allocation in core | 585 |
| Blocking coalition exists | 135 |
| Affected nonparticipant protected | 600 |
| Affected nonparticipant at risk | 120 |

Epistemic cases contain 18 common-knowledge cases, 18 first-order-only cases, 9 cases where the event is unknown at the actual world, and 9 false public claims.

The dual decision set contains 18 protected-hard-boundary cases and 162 ordinary-lane cases. Review is worthwhile in 51 cases and must terminate in 129. Selected options are 90 full actions, 51 bounded reviews, 18 mitigated actions, 18 reversible pilots, and 3 protected stops. Risk classes include de minimis, ordinary proportional, learnable decision-sensitive, protected warnings, and protected hard boundaries.

These are exact results **inside declared synthetic games**. They are not empirical evidence that the parameterization describes real AI-agent economies.

## 12. What remains

Version 0.3 closes the missing action-versus-delay accounting layer but does not yet establish emergent cooperation or calibrated real-world proportionality. The next decisive work is:

1. implement domain-state transition simulators for at least compute allocation, water commons, repeated exchange, externality pricing, public goods, and polycentric boundary settlement;
2. connect actual model agents and run heterogeneous cross-play;
3. calibrate risk, status-quo harm, review cost, and pilot reversibility in at least one real or high-fidelity domain rather than treating declared synthetic values as truth;
4. expand coalition audits beyond five players through sampled blocking searches and exact small-instance controls;
5. estimate stochastic stability over seed ensembles rather than using a single-trajectory proxy;
6. calibrate communication, monitoring, adjudication, and externality costs from measured runs;
7. write independent narrative-domain holdouts so generator style cannot substitute for theory;
8. test covert channels and emergent subinstitutions not represented by the declared protocol;
9. test institution learning on new actor populations while freezing actors during evaluation;
10. publish every failed seed and attack trace, not only aggregate means;
11. test asymmetric legal and rights constraints, multi-party burdens of proof, and appeal capture without collapsing them into one monetary unit;
12. compare the dual-sided rule with pure precaution, pure cost-benefit, and the earlier one-sided CCG obligation-discharge design.

The central empirical question is now precise: can an auditable institution let genuinely heterogeneous local optimizers approach the constraint performance of a central planner while retaining better participation, lower privileged-information dependence, outsider protection, and graceful degradation under capture, coalition deviation, and population change?
