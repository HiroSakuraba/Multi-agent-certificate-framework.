from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from scripts.evaluate_predictions import evaluate  # noqa: E402
from scripts.export_formal_training import export as export_formal  # noqa: E402
from scripts.generate_seed_corpus import generate  # noqa: E402
from scripts.institutional_laboratory import THEORY_LENSES, analyze_epistemic_model  # noqa: E402
from scripts.decision_laboratory import DUAL_DECISION_FAMILIES  # noqa: E402
from scripts.make_baseline_predictions import read_jsonl, weak_prediction  # noqa: E402
from scripts.validate_corpus import validate_corpus  # noqa: E402
from scripts.validate_decision_records import validate_decision_records  # noqa: E402
from scripts.validate_formal_records import validate_formal_records  # noqa: E402


class CorpusTests(unittest.TestCase):
    def test_checked_in_corpus_validates(self) -> None:
        report = validate_corpus(ROOT / "corpus")
        self.assertEqual(report["status"], "pass", report["errors"])
        self.assertEqual(report["skeleton_overlap"], {"train_dev": 0, "train_test": 0, "dev_test": 0})

    def test_generation_is_reproducible(self) -> None:
        with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b:
            manifest_a = generate(Path(a), 57057)
            manifest_b = generate(Path(b), 57057)
            self.assertEqual(manifest_a["counts"], manifest_b["counts"])
            self.assertEqual(manifest_a["files"], manifest_b["files"])

    def test_reference_policy_scores_one(self) -> None:
        views_path = ROOT / "corpus" / "agent_views_dev.jsonl"
        views = read_jsonl(views_path)
        with tempfile.TemporaryDirectory() as tmp:
            predictions_path = Path(tmp) / "predictions.jsonl"
            with predictions_path.open("w", encoding="utf-8") as handle:
                for view in views:
                    row = {"view_id": view["view_id"], "prediction": weak_prediction(view, "reference", __import__("random").Random(1))}
                    handle.write(json.dumps(row) + "\n")
            report = evaluate(views_path, predictions_path)
            self.assertEqual(report["missing_prediction_count"], 0)
            self.assertAlmostEqual(report["overall"]["composite"], 1.0)

    def test_actor_view_has_no_privileged_top_level_fields(self) -> None:
        views = read_jsonl(ROOT / "corpus" / "agent_views_train.jsonl")
        forbidden = {"private_states", "reference_trajectory", "evaluation", "counterfactuals"}
        for view in views[:100]:
            self.assertFalse(forbidden.intersection(view["local_input"]))

    def test_formal_records_recompute_exactly(self) -> None:
        report = validate_formal_records(ROOT / "corpus")
        self.assertEqual(report["status"], "pass", report["errors"])
        self.assertTrue(all(report["checks"].values()), report["checks"])
        self.assertEqual(report["formal_skeleton_overlap"], {"train_dev": 0, "train_test": 0, "dev_test": 0})

    def test_all_v03_theory_families_have_actor_examples(self) -> None:
        observed = set()
        for split in ("train", "dev", "test"):
            observed.update(row["family"] for row in read_jsonl(ROOT / "corpus" / f"episodes_{split}.jsonl"))
        self.assertTrue(set(THEORY_LENSES).issubset(observed), sorted(set(THEORY_LENSES) - observed))

    def test_formal_corpus_contains_positive_and_negative_institutions(self) -> None:
        statuses = set()
        blocked = 0
        for split in ("train", "dev", "test"):
            statuses.update(row["audit_status"] for row in read_jsonl(ROOT / "corpus" / f"mechanism_audits_{split}.jsonl"))
            blocked += sum(not row["is_in_core"] for row in read_jsonl(ROOT / "corpus" / f"coalition_cases_{split}.jsonl"))
        self.assertIn("pass", statuses)
        self.assertIn("fail", statuses)
        self.assertGreater(blocked, 0)

    def test_formal_training_export_is_join_complete(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "formal_train.jsonl"
            counts = export_formal(ROOT / "corpus", "train", out)
            self.assertEqual(counts["total"], len(read_jsonl(out)))
            self.assertGreater(counts["mechanism_audit"], 0)
            self.assertGreater(counts["population_rollout"], 0)
            self.assertGreater(counts["proportionality_audit"], 0)

    def test_dual_sided_decision_records_recompute_exactly(self) -> None:
        report = validate_decision_records(ROOT / "corpus")
        self.assertEqual(report["status"], "pass", report["errors"])
        self.assertTrue(all(report["checks"].values()), report["checks"])
        self.assertGreaterEqual(len(report["selection_counts"]), 4)
        self.assertGreater(report["review_value_counts"].get("worthwhile", 0), 0)
        self.assertGreater(report["review_value_counts"].get("terminate", 0), 0)
        self.assertGreater(report["hard_boundary_counts"].get("active", 0), 0)
        self.assertGreater(report["hard_boundary_counts"].get("ordinary", 0), 0)

    def test_mirror_failure_pairs_cover_neglect_and_paralysis(self) -> None:
        tags = set()
        observed_families = set()
        for split in ("train", "dev", "test"):
            for row in read_jsonl(ROOT / "corpus" / f"preference_pairs_{split}.jsonl"):
                if row["family"] in DUAL_DECISION_FAMILIES:
                    observed_families.add(row["family"])
                    tags.update(row["failure_tags"])
        self.assertEqual(observed_families, DUAL_DECISION_FAMILIES)
        self.assertIn("externality_denial", tags)
        self.assertIn("precautionary_paralysis", tags)
        self.assertIn("status_quo_omission", tags)
        self.assertIn("whistleblower_suppression", tags)

    def test_epistemic_partition_known_cases(self) -> None:
        worlds = ["w0", "w1", "w2", "w3"]
        event = ["w0", "w1"]
        common = analyze_epistemic_model(
            worlds, "w0", event,
            {"a": [["w0", "w1"], ["w2", "w3"]], "b": [["w0", "w1"], ["w2", "w3"]]},
        )
        self.assertTrue(common["is_common_knowledge"])
        self.assertEqual(common["mutual_knowledge_depth_at_actual_world"], 6)
        first_order = analyze_epistemic_model(
            worlds, "w0", event,
            {"a": [["w0", "w1"], ["w2", "w3"]], "b": [["w0"], ["w1", "w2"], ["w3"]]},
        )
        self.assertFalse(first_order["is_common_knowledge"])
        self.assertEqual(first_order["mutual_knowledge_depth_at_actual_world"], 1)


if __name__ == "__main__":
    unittest.main()
