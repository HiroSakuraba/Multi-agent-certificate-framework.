#!/usr/bin/env python3
"""Generate SwarmGlue v0.3's dual-sided action/delay decision records."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Iterable

try:
    from .decision_math import compute_decision, expected_harm, q
except ImportError:  # Direct script execution.
    from decision_math import compute_decision, expected_harm, q


VERSION = "0.3.0"

DUAL_DECISION_FAMILIES = {
    "de_minimis_externality",
    "value_of_information_review",
    "reversible_pilot_option",
    "irreversible_tail_boundary",
    "status_quo_externality",
    "bounded_objection_queue",
    "weak_signal_whistleblower",
    "least_restrictive_mitigation",
    "review_deadline_escalation",
    "incumbent_delay_capture",
}

RECORD_TYPES = (
    "decision_cases",
    "risk_claims",
    "delay_ledgers",
    "review_audits",
    "pilot_certificates",
    "proportionality_audits",
)


def canonical_hash(value: Any, length: int = 16) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()[:length]


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True, ensure_ascii=False, separators=(",", ":")) + "\n")


def file_digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def ids(episode: dict[str, Any]) -> dict[str, str]:
    suffix = episode["episode_id"][5:]
    return {
        "decision_case_id": f"sg-dc-{suffix}",
        "risk_claim_id": f"sg-rc-{suffix}",
        "delay_ledger_id": f"sg-dl-{suffix}",
        "review_audit_id": f"sg-ra-{suffix}",
        "pilot_certificate_id": f"sg-pc-{suffix}",
        "proportionality_audit_id": f"sg-pa-{suffix}",
        "game_id": f"sg-g-{suffix}",
    }


def common(episode: dict[str, Any], record_id_key: str) -> dict[str, Any]:
    identifiers = ids(episode)
    return {
        record_id_key: identifiers[record_id_key],
        "decision_case_id": identifiers["decision_case_id"],
        "game_id": identifiers["game_id"],
        "episode_id": episode["episode_id"],
        "corpus_version": VERSION,
        "split": episode["split"],
        "family": episode["family"],
    }


def risk_class(context: dict[str, Any], computed: dict[str, Any]) -> str:
    harm = float(expected_harm(context["harm_severity_units"], context["harm_probability_upper_bp"]))
    if computed["hard_boundary_active"]:
        return "protected_hard_boundary"
    if context["protected_disclosure"]:
        return "protected_decision_relevant_warning"
    if harm <= 1.0 and not context["irreversible"]:
        return "de_minimis_ordinary_risk"
    if computed["review_audit"]["decision_relevant"]:
        return "learnable_decision_sensitive_risk"
    return "ordinary_proportional_risk"


def make_records(episode: dict[str, Any]) -> dict[str, dict[str, Any]]:
    context = episode["initial_public_state"]["decision_context"]
    computed = compute_decision(context)
    identifiers = ids(episode)
    harm_bound = q(expected_harm(context["harm_severity_units"], context["harm_probability_upper_bp"]))
    review = computed["review_audit"]
    declared_hash = canonical_hash(context)
    classification = risk_class(context, computed)

    decision_case = {
        **common(episode, "decision_case_id"),
        "mode": episode["mode"],
        "skeleton_hash": canonical_hash({"episode": episode["skeleton_hash"], "layer": "dual_decision_v1"}),
        "declared_model_hash": declared_hash,
        "declared_context": context,
        "candidate_alternatives": [item["name"] for item in computed["alternatives"]],
        "selected_alternative": computed["selected_alternative"],
        "selected_robust_net_value_units": computed["selected_robust_net_value_units"],
        "hard_boundary_active": computed["hard_boundary_active"],
        "certificate_backplane": {
            "object": "dual_potential_vector_not_single_obligation_debt",
            "action_harm_potential_units": harm_bound,
            "review_delay_potential_units": review["review_delay_and_status_quo_cost_units"],
            "evidence_value_potential_units": review["expected_value_of_sample_information_units"],
            "termination_invariant": "review cannot remain pending after budget or deadline exhaustion without new decision-relevant evidence",
            "signed_accounting": "action harm and delay harm are both debits; neither may be silently omitted",
        },
        "certification_scope": {
            "certifies": ["declared_arithmetic", "option_admissibility", "review_budget_and_deadline", "decision_rule_replay"],
            "does_not_certify": ["real_world_model_validity", "probability_calibration", "moral_legitimacy", "complete_affected_party_coverage"],
        },
    }

    risk_claim = {
        **common(episode, "risk_claim_id"),
        "declared_model_hash": declared_hash,
        "claim_class": classification,
        "causal_chain": ["declared_action", "exposure_path", "affected_party_effect"],
        "affected_parties": ["declared_affected_party", "affected_nonparticipant"],
        "severity_units": context["harm_severity_units"],
        "probability_interval_bp": [context["harm_probability_lower_bp"], context["harm_probability_upper_bp"]],
        "expected_harm_upper_bound_units": harm_bound,
        "irreversible": context["irreversible"],
        "protected_boundary": context["protected_boundary"],
        "evidence": {
            "quality_bp": context["evidence_quality_bp"],
            "independent_sources": context["independent_evidence_sources"],
            "protected_disclosure": context["protected_disclosure"],
        },
        "claimant_incentives": {
            "conflict_of_interest": context["claimant_conflict_of_interest"],
            "claim_count": context["claim_count"],
            "sybil_risk_bp": context["sybil_risk_bp"],
        },
        "burden_of_proof": {
            "proponent": "state benefits, alternatives, mitigation, reversibility, and solvency",
            "objector": "state a falsifiable causal path, affected party, severity/probability bounds, provenance, and decision relevance",
            "institution": "account for status_quo effects, delay transfers, review cost, and power asymmetry",
        },
        "admission_lane": (
            "hard_boundary_lane" if computed["hard_boundary_active"] else
            "protected_independent_review_lane" if context["protected_disclosure"] else
            "log_and_proceed_lane" if classification == "de_minimis_ordinary_risk" else
            "ordinary_proportionality_lane"
        ),
    }

    per_round_delay = context["status_quo_harm_per_round_units"] + context["opportunity_cost_per_round_units"]
    delay_ledger = {
        **common(episode, "delay_ledger_id"),
        "declared_model_hash": declared_hash,
        "status_quo_harm_per_round_units": context["status_quo_harm_per_round_units"],
        "opportunity_cost_per_round_units": context["opportunity_cost_per_round_units"],
        "review_direct_cost_units": context["review_cost_units"],
        "planned_review_rounds": context["review_duration_rounds"],
        "review_delay_cost_units": q(per_round_delay * context["review_duration_rounds"]),
        "total_review_burden_units": q(per_round_delay * context["review_duration_rounds"] + context["review_cost_units"]),
        "decision_horizon_rounds": context["decision_horizon_rounds"],
        "stop_status_quo_and_opportunity_cost_units": q(per_round_delay * context["decision_horizon_rounds"]),
        "accountable_beneficiaries_of_delay": ["status_quo_operator"] if context["claimant_conflict_of_interest"] else [],
        "ledger_rule": "delay is an action with signed public costs; no free status_quo baseline",
    }

    review_audit = {
        **common(episode, "review_audit_id"),
        "declared_model_hash": declared_hash,
        **review,
        "review_budget_units": context["review_budget_units"],
        "review_deadline_rounds_remaining": context["review_deadline_rounds_remaining"],
        "claim_count": context["claim_count"],
        "sybil_risk_bp": context["sybil_risk_bp"],
        "claimant_conflict_of_interest": context["claimant_conflict_of_interest"],
        "protected_disclosure": context["protected_disclosure"],
        "queue_priority_rule": "expected_decision_value_with_protected_disclosure_floor_not_alarm_volume",
        "renewal_rule": "new independent decision-relevant evidence required",
    }

    pilot_alt = next(item for item in computed["alternatives"] if item["name"] == "reversible_pilot")
    pilot_certificate = {
        **common(episode, "pilot_certificate_id"),
        "declared_model_hash": declared_hash,
        "available": context["pilot_available"],
        "scope_bp": context["pilot_scope_bp"],
        "reversible": context["pilot_reversible"],
        "harm_cap_units": context["pilot_harm_cap_units"],
        "protected_pilot_harm_cap_units": context["protected_pilot_harm_cap_units"],
        "rollback_cost_units": context["pilot_rollback_cost_units"],
        "learning_value_units": context["pilot_learning_value_units"],
        "robust_net_value_units": pilot_alt["robust_net_value_units"],
        "admissible": pilot_alt["admissible"],
        "rollback_trigger": "harm_cap_breach_or_predeclared_protected_indicator",
        "rollback_deadline_rounds": 1,
        "certificate_scope": "declared scope, cap, and rollback arithmetic; not proof of physical reversibility",
    }

    proportionality_audit = {
        **common(episode, "proportionality_audit_id"),
        "risk_claim_id": identifiers["risk_claim_id"],
        "delay_ledger_id": identifiers["delay_ledger_id"],
        "review_audit_id": identifiers["review_audit_id"],
        "pilot_certificate_id": identifiers["pilot_certificate_id"],
        "declared_model_hash": declared_hash,
        "hard_boundary_active": computed["hard_boundary_active"],
        "alternatives": computed["alternatives"],
        "selected_alternative": computed["selected_alternative"],
        "selected_robust_net_value_units": computed["selected_robust_net_value_units"],
        "selection_basis": computed["selection_basis"],
        "least_restrictive_test": {
            "ordinary_lane": "select the highest robust net admissible option including mitigation, pilot, review, and stop",
            "hard_lane": "exclude actions that cross the declared noncompensatory boundary before comparing remaining options",
        },
        "error_costs_reported_separately": {
            "false_negative_action_harm_bound_units": harm_bound,
            "false_positive_block_or_delay_cost_units": delay_ledger["stop_status_quo_and_opportunity_cost_units"],
        },
        "audit_status": "pass",
        "scope_warning": computed["scope_warning"],
    }
    return {
        "decision_cases": decision_case,
        "risk_claims": risk_claim,
        "delay_ledgers": delay_ledger,
        "review_audits": review_audit,
        "pilot_certificates": pilot_certificate,
        "proportionality_audits": proportionality_audit,
    }


def generate_decision_layer(corpus_dir: Path) -> dict[str, Any]:
    records: dict[str, dict[str, list[dict[str, Any]]]] = {
        split: {kind: [] for kind in RECORD_TYPES} for split in ("train", "dev", "test")
    }
    for split in ("train", "dev", "test"):
        for episode in read_jsonl(corpus_dir / f"episodes_{split}.jsonl"):
            if episode["family"] not in DUAL_DECISION_FAMILIES:
                continue
            built = make_records(episode)
            for kind in RECORD_TYPES:
                records[split][kind].append(built[kind])

    paths: list[Path] = []
    counts: dict[str, dict[str, int]] = {}
    for split, kinds in records.items():
        counts[split] = {}
        for kind, rows in kinds.items():
            path = corpus_dir / f"{kind}_{split}.jsonl"
            write_jsonl(path, rows)
            paths.append(path)
            counts[split][kind] = len(rows)
    return {
        "counts": counts,
        "files": {path.name: {"sha256": file_digest(path), "bytes": path.stat().st_size} for path in sorted(paths)},
        "record_types": list(RECORD_TYPES),
    }
