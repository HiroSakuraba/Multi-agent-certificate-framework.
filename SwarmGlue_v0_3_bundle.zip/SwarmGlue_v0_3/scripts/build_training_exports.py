#!/usr/bin/env python3
"""Build all SwarmGlue actor, preference, and formal training exports."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

try:
    from .export_formal_training import export as export_formal
    from .export_training_formats import export_preferences, export_sft
except ImportError:  # Direct script execution.
    from export_formal_training import export as export_formal
    from export_training_formats import export_preferences, export_sft


VERSION = "0.3.0"


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def build(corpus: Path, out: Path) -> dict[str, Any]:
    out.mkdir(parents=True, exist_ok=True)
    entries: dict[str, Any] = {}
    for split in ("train", "dev", "test"):
        actor_path = out / f"actor_sft_{split}.jsonl"
        preference_path = out / f"actor_preferences_{split}.jsonl"
        formal_path = out / f"formal_sft_{split}.jsonl"
        actor_count = export_sft(corpus / f"agent_views_{split}.jsonl", actor_path)
        preference_count = export_preferences(corpus / f"preference_pairs_{split}.jsonl", preference_path)
        formal_counts = export_formal(corpus, split, formal_path)
        for path, record_type, count in (
            (actor_path, "masked_local_actor_chat_sft", actor_count),
            (preference_path, "causal_actor_preference", preference_count),
            (formal_path, "exact_institutional_audit_chat_sft", formal_counts["total"]),
        ):
            entries[path.name] = {
                "record_type": record_type,
                "split": split,
                "records": count,
                "bytes": path.stat().st_size,
                "sha256": digest(path),
            }
        entries[formal_path.name]["task_counts"] = formal_counts
    manifest = {
        "corpus_name": "SwarmGlue",
        "corpus_version": VERSION,
        "source_corpus": str(corpus),
        "files": dict(sorted(entries.items())),
        "information_boundary": {
            "actor_sft": "execution-safe masked local views",
            "actor_preferences": "execution-safe local prompts with chosen and rejected outputs",
            "formal_sft": "privileged institutional auditor training; never decentralized actor input",
        },
    }
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus", type=Path, default=Path("corpus"))
    parser.add_argument("--out", type=Path, default=Path("exports"))
    args = parser.parse_args()
    manifest = build(args.corpus, args.out)
    print(json.dumps({"status": "exported", "out": str(args.out), "files": len(manifest["files"])}, sort_keys=True))


if __name__ == "__main__":
    main()
