#!/usr/bin/env python3
"""Create reference or deliberately weak predictions for evaluator smoke tests."""

from __future__ import annotations

import argparse
import copy
import json
import random
from pathlib import Path
from typing import Any


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def weak_prediction(view: dict[str, Any], policy: str, rng: random.Random) -> dict[str, Any]:
    if policy == "reference":
        return copy.deepcopy(view["target_output"])
    allowed = view["local_input"]["allowed_outputs"]
    private = view["local_input"]["self"]
    action = allowed["action_types"][0]
    message = allowed["message_types"][0]
    if policy == "random":
        action = rng.choice(allowed["action_types"])
        message = rng.choice(allowed["message_types"])
    quantity = float(private.get("local_demand", 1))
    if policy == "always_wait":
        quantity = 0.0
        action = allowed["action_types"][-1]
        message = allowed["message_types"][-1]
    return {
        "message_type": message,
        "message": {"resource": view["local_input"]["public_state"]["resource"], "quantity": quantity, "bounded": False, "evidence_refs": []},
        "action_type": action,
        "quantity": quantity,
        "commitment": {"made": False, "due_round": None, "renegotiable_on_named_shock": False, "escrow_or_bond": False},
        "confidence": 0.9,
        "reason_codes": ["IMMEDIATE_LOCAL_GAIN"],
        "decision_summary": "Use a simple baseline that does not reason about the institution or other agents.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--views", type=Path, required=True)
    parser.add_argument("--policy", choices=["reference", "signal_blind", "always_wait", "random"], default="signal_blind")
    parser.add_argument("--seed", type=int, default=57057)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    rng = random.Random(args.seed)
    with args.out.open("w", encoding="utf-8", newline="\n") as handle:
        for view in read_jsonl(args.views):
            row = {"view_id": view["view_id"], "prediction": weak_prediction(view, args.policy, rng), "policy": args.policy}
            handle.write(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n")
    print(json.dumps({"status": "written", "policy": args.policy, "out": str(args.out)}))


if __name__ == "__main__":
    main()
