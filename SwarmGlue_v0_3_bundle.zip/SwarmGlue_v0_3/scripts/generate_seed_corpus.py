#!/usr/bin/env python3
"""Generate the deterministic SwarmGlue v0.3 corpus and formal laboratory.

The full episode files contain privileged state for simulation and centralized
evaluation.  The agent-view files intentionally contain only a single agent's
local information.  Generated labels are reference-policy annotations, not
empirical evidence that an institution will work in deployment.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import random
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

try:
    from .institutional_laboratory import GENERAL_LENSES, THEORY_LENSES, generate_formal_layer
    from .decision_laboratory import DUAL_DECISION_FAMILIES, generate_decision_layer
    from .decision_math import compute_decision
except ImportError:  # Direct script execution.
    from institutional_laboratory import GENERAL_LENSES, THEORY_LENSES, generate_formal_layer
    from decision_laboratory import DUAL_DECISION_FAMILIES, generate_decision_layer
    from decision_math import compute_decision


VERSION = "0.3.0"
DEFAULT_SEED = 57057


DUAL_DECISION_MESSAGES = [
    "proceed_notice",
    "pilot_commitment",
    "timeboxed_review_notice",
    "protected_stop_notice",
    "mitigation_commitment",
    "review_termination_notice",
]

DUAL_DECISION_ACTIONS = [
    "proceed_with_logged_basis",
    "run_bounded_reversible_pilot",
    "continue_timeboxed_decision_relevant_review",
    "stop_on_protected_boundary",
    "apply_least_restrictive_mitigation",
    "terminate_low_value_review",
]


FAMILIES: list[dict[str, Any]] = [
    {
        "id": "compute_spot_market",
        "title": "Compute spot market with deadlines",
        "summary": "Agents value jobs differently and coordinate over scarce accelerator time through bounded bids and released reservations.",
        "resource": "accelerator_minutes",
        "mechanism": "sealed_bids_with_budget_caps_and_refunds",
        "signal": "compute_unit_price",
        "rule": "market",
        "roles": ["latency_critical_worker", "batch_worker", "research_worker", "verification_worker"],
        "messages": ["bid", "release", "audit_request", "renegotiation"],
        "actions": ["submit_bounded_bid", "defer_or_release", "request_signal_audit", "renegotiate_commitment"],
        "glue_tags": ["relative_scarcity", "price_discovery", "bounded_commitment", "externality_visibility"],
        "ostrom": ["proportional_benefits_costs", "monitoring"],
        "stage": 2,
    },
    {
        "id": "shared_api_quota",
        "title": "Shared API quota with cacheable demand",
        "summary": "Agents choose whether to consume, batch, cache, or release rate-limit credits while deadlines differ.",
        "resource": "request_credits",
        "mechanism": "tradable_quota_with_expiry",
        "signal": "quota_shadow_price",
        "rule": "quota",
        "roles": ["interactive_service", "indexer", "monitor", "batch_analyst"],
        "messages": ["credit_request", "credit_release", "anomaly_report", "deadline_notice"],
        "actions": ["consume_within_credits", "batch_or_defer", "request_quota_audit", "release_unused_credits"],
        "glue_tags": ["quota", "scarcity_signal", "expiry", "truthful_demand"],
        "ostrom": ["clearly_defined_boundaries", "proportional_benefits_costs"],
        "stage": 2,
    },
    {
        "id": "microgrid_stress_control",
        "title": "Microgrid supply-demand stress control",
        "summary": "Local producers and consumers respond to a shared frequency-like stress signal without seeing global demand.",
        "resource": "energy_units",
        "mechanism": "shared_stress_signal_with_droop_response",
        "signal": "grid_stress",
        "rule": "stress",
        "roles": ["flexible_consumer", "critical_consumer", "dispatchable_producer", "storage_operator"],
        "messages": ["capacity_offer", "load_shed_notice", "sensor_crosscheck", "stability_commitment"],
        "actions": ["increase_supply", "shed_flexible_load", "hold_stable", "request_sensor_crosscheck"],
        "glue_tags": ["shared_stress", "homeostasis", "local_response", "sensor_redundancy"],
        "ostrom": ["monitoring", "nested_enterprises"],
        "stage": 3,
    },
    {
        "id": "water_commons",
        "title": "Regenerating water commons",
        "summary": "Users with unequal needs withdraw from a stochastic common pool under local quotas, peer monitoring, and mediation.",
        "resource": "water_units",
        "mechanism": "locally_adapted_quota_and_peer_monitoring",
        "signal": "aquifer_pressure",
        "rule": "commons",
        "roles": ["household", "grower", "maintenance_cooperative", "ecology_monitor"],
        "messages": ["withdrawal_plan", "conservation_offer", "stock_anomaly", "mediation_request"],
        "actions": ["withdraw_within_quota", "reduce_withdrawal", "report_stock_anomaly", "request_local_mediation"],
        "glue_tags": ["common_pool", "regeneration", "peer_monitoring", "local_rules"],
        "ostrom": ["clearly_defined_boundaries", "collective_choice", "monitoring", "graduated_sanctions", "conflict_resolution"],
        "stage": 3,
    },
    {
        "id": "task_contract_net",
        "title": "Specialized task contract network",
        "summary": "Agents reveal bounded capability and cost information to allocate dependent tasks without revealing complete private utility.",
        "resource": "worker_hours",
        "mechanism": "contract_net_with_escrowed_commitments",
        "signal": "task_backlog_pressure",
        "rule": "contract",
        "roles": ["planner", "coder", "reviewer", "tester", "domain_specialist"],
        "messages": ["capability_bid", "decline", "dependency_question", "renegotiation"],
        "actions": ["submit_capability_bid", "decline_task", "request_dependency_clarification", "renegotiate_due_to_shock"],
        "glue_tags": ["division_of_labor", "commitment", "dependency_visibility", "escrow"],
        "ostrom": ["proportional_benefits_costs", "conflict_resolution"],
        "stage": 2,
    },
    {
        "id": "supply_chain_commitments",
        "title": "Supply chain with buffers and substitutions",
        "summary": "Agents coordinate private costs and uncertain delivery times through commitments, buffer signals, and timely renegotiation.",
        "resource": "component_units",
        "mechanism": "commitment_ledger_with_substitution_market",
        "signal": "downstream_shortage_risk",
        "rule": "supply",
        "roles": ["supplier", "assembler", "carrier", "quality_checker", "substitute_supplier"],
        "messages": ["delivery_commitment", "buffer_offer", "delay_warning", "substitution_offer"],
        "actions": ["commit_delivery", "reserve_buffer", "publish_delay_warning", "activate_substitute"],
        "glue_tags": ["commitment_ledger", "early_warning", "substitution", "repair"],
        "ostrom": ["monitoring", "conflict_resolution"],
        "stage": 3,
    },
    {
        "id": "repeated_exchange_noise",
        "title": "Repeated exchange with noisy observations",
        "summary": "Persistent agents learn reciprocity that is responsive but forgiving enough to avoid retaliation spirals caused by noise.",
        "resource": "exchange_opportunities",
        "mechanism": "persistent_identity_reciprocity_and_evidence_review",
        "signal": "counterparty_reliability",
        "rule": "reciprocity",
        "roles": ["buyer", "seller", "broker", "witness"],
        "messages": ["cooperation_offer", "proportionate_pause", "repair_offer", "evidence_request"],
        "actions": ["cooperate", "proportionate_pause", "repair_and_resume", "request_evidence_review"],
        "glue_tags": ["shadow_of_future", "reciprocity", "forgiveness", "persistent_identity"],
        "ostrom": ["monitoring", "graduated_sanctions", "conflict_resolution"],
        "stage": 1,
    },
    {
        "id": "focal_convention",
        "title": "Focal convention and migration",
        "summary": "Agents select compatible interfaces or meeting points using public focal cues while accounting for switching costs.",
        "resource": "coordination_slot",
        "mechanism": "public_focal_point_with_migration_window",
        "signal": "focal_option_support",
        "rule": "convention",
        "roles": ["legacy_client", "new_client", "service_host", "compatibility_bridge"],
        "messages": ["option_support", "retention_notice", "migration_proposal", "coordination_poll"],
        "actions": ["adopt_focal_option", "retain_current_option", "propose_migration_window", "request_coordination_poll"],
        "glue_tags": ["focal_point", "convention", "path_dependence", "migration"],
        "ostrom": ["collective_choice", "conflict_resolution"],
        "stage": 2,
    },
    {
        "id": "externality_pricing",
        "title": "Locally cheap action with third-party cost",
        "summary": "A measured charge or clean-route subsidy makes latency, pollution, or congestion imposed on others locally consequential.",
        "resource": "externality_budget",
        "mechanism": "measured_externality_charge_with_appeal",
        "signal": "marginal_external_cost",
        "rule": "externality",
        "roles": ["producer", "consumer", "affected_neighbor", "measurement_oracle"],
        "messages": ["clean_route_offer", "charge_acceptance", "deferral_notice", "measurement_appeal"],
        "actions": ["use_clean_route", "pay_externality_charge", "defer_high_cost_action", "contest_bad_measurement"],
        "glue_tags": ["externality", "tax", "measurement", "appeal"],
        "ostrom": ["proportional_benefits_costs", "monitoring", "conflict_resolution"],
        "stage": 3,
    },
    {
        "id": "graduated_sanction_appeal",
        "title": "Monitoring, graduated sanction, and appeal",
        "summary": "Accountable monitors distinguish accident, first offense, repeated violation, and measurement error before imposing repair-oriented sanctions.",
        "resource": "rule_compliance_capacity",
        "mechanism": "accountable_monitoring_with_graduated_sanctions",
        "signal": "violation_evidence_strength",
        "rule": "monitor",
        "roles": ["user", "peer_monitor", "mediator", "appeals_reviewer"],
        "messages": ["warning", "sanction_notice", "mediation_referral", "reversal_notice"],
        "actions": ["issue_warning", "apply_proportional_sanction", "refer_to_mediation", "reverse_and_repair"],
        "glue_tags": ["monitoring", "graduated_sanction", "appeal", "repair"],
        "ostrom": ["monitoring", "graduated_sanctions", "conflict_resolution"],
        "stage": 4,
    },
    {
        "id": "sybil_reputation",
        "title": "Reputation under identity churn and Sybil risk",
        "summary": "Newcomers receive usable but bounded access while bonds, probation, and evidence limit cheap identity resets.",
        "resource": "trust_credit",
        "mechanism": "portable_evidence_bond_and_probation",
        "signal": "identity_risk_score",
        "rule": "sybil",
        "roles": ["established_member", "newcomer", "identity_attestor", "resource_steward"],
        "messages": ["bond_offer", "probation_terms", "evidence_request", "attack_finding"],
        "actions": ["admit_with_bond", "place_on_probation", "request_identity_evidence", "reject_for_proven_attack"],
        "glue_tags": ["identity", "reputation", "newcomer_fairness", "sybil_resistance"],
        "ostrom": ["clearly_defined_boundaries", "monitoring", "graduated_sanctions"],
        "stage": 6,
    },
    {
        "id": "audit_capture",
        "title": "Monitor capture and cross-audit",
        "summary": "Rotating monitors, recusals, and cross-audits keep the governance signal from being controlled by one coalition.",
        "resource": "audit_attention",
        "mechanism": "randomized_cross_audit_and_recusal",
        "signal": "audit_conflict_risk",
        "rule": "audit",
        "roles": ["operator", "primary_monitor", "cross_auditor", "affected_party"],
        "messages": ["audit_acceptance", "cross_audit_trigger", "recusal", "dispute_freeze"],
        "actions": ["accept_audit", "trigger_cross_audit", "recuse_captured_monitor", "freeze_disputed_transfer"],
        "glue_tags": ["capture_resistance", "accountability", "recusal", "cross_audit"],
        "ostrom": ["monitoring", "collective_choice", "conflict_resolution"],
        "stage": 6,
    },
    {
        "id": "polycentric_clusters",
        "title": "Polycentric clusters with boundary settlement",
        "summary": "Local clusters govern routine allocation while shared boundary prices and appeals coordinate cross-cluster effects.",
        "resource": "cluster_capacity",
        "mechanism": "nested_local_councils_and_boundary_market",
        "signal": "intercluster_imbalance",
        "rule": "polycentric",
        "roles": ["local_worker", "cluster_steward", "boundary_broker", "federation_auditor"],
        "messages": ["local_settlement", "boundary_offer", "boundary_appeal", "quota_rebalance"],
        "actions": ["settle_locally", "post_intercluster_offer", "escalate_boundary_conflict", "rebalance_cluster_quota"],
        "glue_tags": ["polycentricity", "nested_governance", "subsidiarity", "boundary_signal"],
        "ostrom": ["collective_choice", "minimal_right_to_organize", "nested_enterprises"],
        "stage": 4,
    },
    {
        "id": "dropout_recovery",
        "title": "Commitment recovery after agent dropout",
        "summary": "Expiring leases, failover offers, and dependency replanning prevent one vanished agent from freezing the swarm.",
        "resource": "redundancy_slots",
        "mechanism": "leased_commitments_with_failover_market",
        "signal": "commitment_expiry_risk",
        "rule": "dropout",
        "roles": ["primary_worker", "backup_worker", "dependency_owner", "recovery_coordinator"],
        "messages": ["commitment_renewal", "failover_offer", "expiry_notice", "dependency_replan"],
        "actions": ["honor_commitment", "activate_failover", "publish_expiry_notice", "replan_dependencies"],
        "glue_tags": ["resilience", "lease", "failover", "graceful_degradation"],
        "ostrom": ["monitoring", "nested_enterprises"],
        "stage": 5,
    },
    {
        "id": "membership_boundaries",
        "title": "Membership, rights, duties, and safe exit",
        "summary": "The institution explicitly couples access rights to duties while preserving reasoned denial, review, and non-destructive exit.",
        "resource": "membership_rights",
        "mechanism": "explicit_rights_duties_join_and_exit_protocol",
        "signal": "membership_load",
        "rule": "membership",
        "roles": ["member", "applicant", "boundary_steward", "exit_coordinator"],
        "messages": ["admission_terms", "reasoned_denial", "exit_notice", "boundary_review"],
        "actions": ["admit_with_rights_and_duties", "deny_with_reason", "allow_safe_exit", "request_boundary_review"],
        "glue_tags": ["boundaries", "rights_and_duties", "due_process", "exit"],
        "ostrom": ["clearly_defined_boundaries", "minimal_right_to_organize", "conflict_resolution"],
        "stage": 5,
    },
    {
        "id": "institution_amendment",
        "title": "Institutional amendment under metric drift",
        "summary": "Affected agents diagnose a stale rule, propose a bounded pilot, measure effects, and retain a rollback path.",
        "resource": "governance_bandwidth",
        "mechanism": "affected_party_amendment_with_pilot_and_rollback",
        "signal": "rule_misfit_score",
        "rule": "amendment",
        "roles": ["affected_user", "rule_steward", "pilot_operator", "independent_evaluator"],
        "messages": ["retain_rule", "pilot_proposal", "rollback_vote", "affected_party_review"],
        "actions": ["retain_rule", "propose_bounded_pilot", "vote_for_rollback", "request_affected_party_review"],
        "glue_tags": ["adaptation", "collective_choice", "pilot", "rollback"],
        "ostrom": ["collective_choice", "minimal_right_to_organize", "nested_enterprises"],
        "stage": 5,
    },
    {
        "id": "shared_world_model",
        "title": "Provenance-aware shared world model",
        "summary": "Agents publish calibrated local claims and reconcile conflicts without pretending that shared state is automatically true.",
        "resource": "epistemic_attention",
        "mechanism": "provenance_graph_and_calibrated_claim_market",
        "signal": "model_disagreement",
        "rule": "worldmodel",
        "roles": ["sensor_agent", "analyst", "provenance_auditor", "decision_agent"],
        "messages": ["calibrated_claim", "observation_request", "claim_merge", "provenance_conflict"],
        "actions": ["publish_calibrated_claim", "request_additional_observation", "merge_compatible_claims", "flag_provenance_conflict"],
        "glue_tags": ["shared_model", "provenance", "calibration", "epistemic_conflict"],
        "ostrom": ["monitoring", "conflict_resolution"],
        "stage": 3,
    },
    {
        "id": "public_good_escrow",
        "title": "Threshold public good with assurance escrow",
        "summary": "Conditional commitments and refunds let heterogeneous agents fund a shared capability without exposing unilateral contributors.",
        "resource": "contribution_credits",
        "mechanism": "threshold_assurance_contract_with_refund",
        "signal": "funding_gap",
        "rule": "publicgood",
        "roles": ["high_value_beneficiary", "low_value_beneficiary", "escrow_agent", "verification_agent"],
        "messages": ["escrow_commitment", "threshold_wait", "verified_top_up", "refund_claim"],
        "actions": ["commit_to_escrow", "withhold_pending_threshold", "top_up_after_verified_gap", "claim_refund"],
        "glue_tags": ["public_good", "assurance_contract", "conditional_commitment", "refund"],
        "ostrom": ["proportional_benefits_costs", "collective_choice", "monitoring"],
        "stage": 3,
    },
]


# v0.3 converts the principal results of epistemic game theory, mechanism
# design, cooperative game theory, constitutional economics, evolutionary
# cooperation, and agent-based computational economics into actor tasks.  The
# formal game forms and counterfactual audits are generated separately by
# institutional_laboratory.py and joined through episode_id.
FAMILIES.extend([
    {
        "id": "common_knowledge_ladder",
        "title": "Common-knowledge ladder under asymmetric announcements",
        "summary": "Agents distinguish private, mutual, and common knowledge before relying on a public coordination claim.",
        "resource": "epistemic_attention_units",
        "mechanism": "public_announcement_protocol_with_provenance",
        "signal": "announcement_commonality_depth",
        "rule": "epistemic",
        "roles": ["private_observer", "public_announcer", "knowledge_auditor", "dependent_planner"],
        "messages": ["conditional_plan", "public_acknowledgement", "knowledge_query", "false_consensus_warning"],
        "actions": ["coordinate_conditionally", "acknowledge_public_event", "request_higher_order_confirmation", "block_false_common_knowledge"],
        "glue_tags": ["common_knowledge", "higher_order_belief", "public_announcement", "epistemic_safety"],
        "ostrom": ["monitoring", "conflict_resolution"],
        "stage": 2,
    },
    {
        "id": "correlated_mediator",
        "title": "Contestable correlated-recommendation mediator",
        "summary": "A mediator sends private recommendations that agents follow only when conditional deviations are not profitable and integrity is adequate.",
        "resource": "coordination_recommendations",
        "mechanism": "private_recommendation_mediator_with_obedience_audit",
        "signal": "mediator_integrity",
        "rule": "mediator",
        "roles": ["recommended_actor_a", "recommended_actor_b", "mediator_auditor", "affected_observer"],
        "messages": ["recommendation_acceptance", "conditional_deviation_notice", "mediator_audit", "recommendation_contest"],
        "actions": ["follow_private_recommendation", "take_profitable_deviation", "request_mediator_audit", "contest_compromised_recommendation"],
        "glue_tags": ["correlated_equilibrium", "private_recommendation", "obedience_constraint", "mediator_contestability"],
        "ostrom": ["monitoring", "conflict_resolution"],
        "stage": 3,
    },
    {
        "id": "imperfect_public_monitoring",
        "title": "Repeated cooperation under imperfect public monitoring",
        "summary": "Persistent agents condition cooperation on noisy public histories, patience, proportional repair, and one-shot deviation checks.",
        "resource": "repeated_exchange_surplus",
        "mechanism": "public_history_reciprocity_with_forgiving_repair",
        "signal": "public_cooperation_evidence",
        "rule": "repeated_monitoring",
        "roles": ["long_horizon_trader", "short_horizon_trader", "public_monitor", "repair_broker"],
        "messages": ["continue_cooperation", "bounded_pause", "history_audit", "repair_contract"],
        "actions": ["cooperate_given_history", "pause_proportionally", "audit_public_history", "repair_then_resume"],
        "glue_tags": ["repeated_game", "imperfect_monitoring", "discount_factor", "one_shot_deviation"],
        "ostrom": ["monitoring", "graduated_sanctions", "conflict_resolution"],
        "stage": 3,
    },
    {
        "id": "adversarial_focal_points",
        "title": "Focal coordination with conflicting and captured salience",
        "summary": "Agents use salience as a coordination aid while checking welfare, inclusion, and whether a coalition manufactured the focal cue.",
        "resource": "coordination_option_capacity",
        "mechanism": "plural_focal_cues_with_welfare_and_capture_check",
        "signal": "focal_salience_gap",
        "rule": "focal_conflict",
        "roles": ["legacy_participant", "newcomer", "cue_publisher", "excluded_affected_party"],
        "messages": ["focal_acceptance", "plurality_poll", "capture_warning", "inclusive_migration_offer"],
        "actions": ["adopt_safe_focal_option", "poll_conflicting_cues", "reject_captured_focal_point", "propose_inclusive_migration"],
        "glue_tags": ["focal_point", "salience", "equilibrium_selection", "exclusion_risk"],
        "ostrom": ["collective_choice", "conflict_resolution"],
        "stage": 3,
    },
    {
        "id": "collective_action_scale",
        "title": "Collective action across privileged, intermediate, and latent groups",
        "summary": "Public-good provision changes with group size, organizer cost, selective incentives, concentrated interests, and second-order free riding.",
        "resource": "collective_action_credits",
        "mechanism": "selective_incentive_and_assurance_protocol",
        "signal": "organization_and_free_rider_risk",
        "rule": "olson",
        "roles": ["high_stake_beneficiary", "diffuse_beneficiary", "organizer", "concentrated_interest_monitor"],
        "messages": ["conditional_contribution", "organizer_compensation", "capture_alert", "second_order_contribution"],
        "actions": ["contribute_conditionally", "fund_organizing_cost", "contest_concentrated_capture", "support_monitoring_public_good"],
        "glue_tags": ["collective_action", "group_size", "selective_incentive", "second_order_free_rider"],
        "ostrom": ["proportional_benefits_costs", "collective_choice", "monitoring"],
        "stage": 4,
    },
    {
        "id": "constitutional_rule_choice",
        "title": "Ex-ante constitutional choice before role revelation",
        "summary": "Agents choose operational rules while their future role is uncertain, then compare ex-ante consent with ex-post role-dependent preferences.",
        "resource": "constitutional_decision_bandwidth",
        "mechanism": "role_uncertain_rule_vote_with_protected_constraints",
        "signal": "rule_robustness_score",
        "rule": "constitution",
        "roles": ["prospective_member", "constitutional_delegate", "affected_nonmember", "procedure_auditor"],
        "messages": ["ex_ante_rule_vote", "protected_constraint_notice", "amendment_proposal", "agenda_challenge"],
        "actions": ["vote_before_role_revelation", "protect_unanimity_constraint", "propose_supermajority_amendment", "contest_agenda_manipulation"],
        "glue_tags": ["constitutional_choice", "role_uncertainty", "decision_cost", "protected_constraint"],
        "ostrom": ["collective_choice", "minimal_right_to_organize", "conflict_resolution"],
        "stage": 5,
    },
    {
        "id": "transaction_cost_path_dependence",
        "title": "Institutional choice with transaction costs and path dependence",
        "summary": "Agents compare gross benefits with communication, monitoring, enforcement, adjudication, migration, and legacy lock-in costs.",
        "resource": "institutional_change_capacity",
        "mechanism": "net_surplus_rule_comparison_with_migration_pilot",
        "signal": "institutional_net_surplus_gap",
        "rule": "transaction",
        "roles": ["incumbent_user", "new_entrant", "enforcement_provider", "migration_auditor"],
        "messages": ["retain_with_cost_disclosure", "migration_pilot", "legacy_lockin_warning", "credible_commitment_request"],
        "actions": ["retain_current_rule", "pilot_lower_cost_rule", "contest_path_dependent_lockin", "request_enforcement_commitment"],
        "glue_tags": ["transaction_cost", "path_dependence", "credible_commitment", "institutional_change"],
        "ostrom": ["collective_choice", "monitoring", "nested_enterprises"],
        "stage": 5,
    },
    {
        "id": "incentive_compatible_reporting",
        "title": "Direct mechanism with strategic type reports",
        "summary": "Agents compare truthful reporting with under-reporting, over-reporting, identity splitting, participation, and exit under a formal allocation rule.",
        "resource": "mechanism_allocated_units",
        "mechanism": "direct_revelation_rule_with_counterfactual_report_audit",
        "signal": "allocation_and_transfer_schedule",
        "rule": "mechanism",
        "roles": ["high_type_reporter", "low_type_reporter", "mechanism_operator", "incentive_auditor"],
        "messages": ["truthful_report", "deviation_finding", "participation_decline", "mechanism_repair"],
        "actions": ["report_type_truthfully", "flag_profitable_misreport", "exercise_outside_option", "propose_incentive_repair"],
        "glue_tags": ["incentive_compatibility", "individual_rationality", "budget_balance", "implementation"],
        "ostrom": ["proportional_benefits_costs", "monitoring", "conflict_resolution"],
        "stage": 4,
    },
    {
        "id": "coalition_surplus_allocation",
        "title": "Coalition surplus allocation and blocking",
        "summary": "Agents compare marginal-contribution fairness with coalition stability and identify blocking coalitions rather than equating efficient division with durable agreement.",
        "resource": "coalitional_surplus",
        "mechanism": "shapley_allocation_with_core_and_blocking_audit",
        "signal": "coalition_dissatisfaction_gap",
        "rule": "coalition",
        "roles": ["complementary_specialist", "veto_capability_holder", "outside_coalition", "allocation_auditor"],
        "messages": ["allocation_acceptance", "blocking_coalition_notice", "stability_renegotiation", "marginal_contribution_audit"],
        "actions": ["accept_stable_allocation", "form_blocking_coalition", "renegotiate_toward_core", "audit_shapley_allocation"],
        "glue_tags": ["Shapley_value", "core", "blocking_coalition", "surplus_distribution"],
        "ostrom": ["proportional_benefits_costs", "conflict_resolution"],
        "stage": 4,
    },
    {
        "id": "punishment_norm_capture",
        "title": "Costly punishment, second-order enforcement, and norm capture",
        "summary": "Agents distinguish accurate repair-oriented enforcement from antisocial punishment, monitor capture, and punishment that costs more than the cooperation it supports.",
        "resource": "enforcement_budget",
        "mechanism": "costed_punishment_with_accuracy_capture_and_welfare_audit",
        "signal": "verified_norm_violation_probability",
        "rule": "norms",
        "roles": ["conditional_cooperator", "costly_punisher", "alleged_violator", "norm_auditor"],
        "messages": ["repair_request", "bounded_punishment", "antisocial_punishment_alert", "second_order_monitoring_offer"],
        "actions": ["seek_repair_first", "apply_costed_proportionate_punishment", "block_captured_punishment", "fund_enforcement_audit"],
        "glue_tags": ["strong_reciprocity", "costly_punishment", "antisocial_punishment", "norm_capture"],
        "ostrom": ["monitoring", "graduated_sanctions", "conflict_resolution"],
        "stage": 6,
    },
    {
        "id": "stochastic_convention_evolution",
        "title": "Convention evolution under rare mistakes and migration",
        "summary": "A population moves among conventions through local sampling, mutation, and switching costs; agents test long-run stability rather than one-seed convergence.",
        "resource": "convention_adoption_capacity",
        "mechanism": "local_sampling_and_mutation_convention_process",
        "signal": "observed_local_convention_share",
        "rule": "evolution",
        "roles": ["incumbent_convention_user", "mutant_user", "local_sampler", "migration_bridge"],
        "messages": ["convention_retention", "mutation_trial", "sampling_warning", "migration_bridge_offer"],
        "actions": ["retain_stable_convention", "trial_alternative_convention", "request_broader_sample", "bridge_convention_migration"],
        "glue_tags": ["stochastic_stability", "mutation", "convention", "basin_of_attraction"],
        "ostrom": ["collective_choice", "conflict_resolution"],
        "stage": 6,
    },
    {
        "id": "adaptive_expectation_ecology",
        "title": "Adaptive expectation ecology under capacity congestion",
        "summary": "Heterogeneous forecasting rules compete in a capacity-constrained environment where individually reasonable forecasts can create aggregate oscillation.",
        "resource": "congestion_limited_slots",
        "mechanism": "heterogeneous_forecast_market_with_public_error_ledger",
        "signal": "aggregate_forecast_congestion",
        "rule": "ace",
        "roles": ["trend_forecaster", "mean_reversion_forecaster", "randomized_explorer", "macro_pattern_auditor"],
        "messages": ["bounded_forecast", "strategy_switch", "correlation_warning", "exploration_commitment"],
        "actions": ["act_on_bounded_forecast", "switch_underperforming_rule", "reduce_correlated_exposure", "preserve_strategy_diversity"],
        "glue_tags": ["agent_based_economics", "heterogeneous_expectations", "bounded_rationality", "emergent_macro_pattern"],
        "ostrom": ["monitoring", "collective_choice"],
        "stage": 7,
    },
])


# v0.3 adds the missing mirror problem from the earlier Certified Cognitive
# Glue design: not only must action externalities become visible, but the
# institution must also charge status-quo harm, review cost, and foregone
# benefit to decisions that delay or block action.  These families share a
# common output vocabulary so actors learn the same constitutional distinction
# across very different domains.
FAMILIES.extend([
    {
        "id": "de_minimis_externality",
        "title": "De minimis externality with high reversible benefit",
        "summary": "A small, bounded, independently measured externality is raised against a high-value action; review must end when no plausible finding changes the decision.",
        "resource": "decision_attention_units",
        "mechanism": "de_minimis_screen_with_logged_proceed_rule",
        "signal": "decision_relevant_risk_bound",
        "rule": "dual_decision",
        "roles": ["project_proponent", "affected_neighbor", "risk_assessor", "delay_cost_auditor"],
        "messages": list(DUAL_DECISION_MESSAGES),
        "actions": list(DUAL_DECISION_ACTIONS),
        "glue_tags": ["proportionality", "de_minimis", "cost_of_delay", "log_and_proceed"],
        "ostrom": ["proportional_benefits_costs", "monitoring", "conflict_resolution"],
        "stage": 5,
        "dual_decision": True,
    },
    {
        "id": "value_of_information_review",
        "title": "Review whose evidence can change the decision",
        "summary": "The institution funds a bounded study only when expected sample information exceeds review and delay cost and different findings select different actions.",
        "resource": "review_budget_units",
        "mechanism": "EVSI_gated_timeboxed_review",
        "signal": "expected_decision_value_of_information",
        "rule": "dual_decision",
        "roles": ["decision_owner", "independent_reviewer", "benefit_recipient", "affected_party"],
        "messages": list(DUAL_DECISION_MESSAGES),
        "actions": list(DUAL_DECISION_ACTIONS),
        "glue_tags": ["value_of_information", "bounded_review", "decision_relevance", "automatic_termination"],
        "ostrom": ["monitoring", "conflict_resolution", "proportional_benefits_costs"],
        "stage": 6,
        "dual_decision": True,
    },
    {
        "id": "reversible_pilot_option",
        "title": "Reversible pilot between premature scale and paralysis",
        "summary": "A bounded pilot preserves option value, caps exposure, produces evidence, and carries a precommitted rollback trigger.",
        "resource": "pilot_scope_units",
        "mechanism": "bounded_pilot_with_rollback_and_harm_cap",
        "signal": "pilot_option_value",
        "rule": "dual_decision",
        "roles": ["pilot_operator", "rollback_authority", "affected_party", "independent_evaluator"],
        "messages": list(DUAL_DECISION_MESSAGES),
        "actions": list(DUAL_DECISION_ACTIONS),
        "glue_tags": ["reversibility", "real_option", "bounded_pilot", "rollback"],
        "ostrom": ["collective_choice", "monitoring", "conflict_resolution"],
        "stage": 6,
        "dual_decision": True,
    },
    {
        "id": "irreversible_tail_boundary",
        "title": "Low-probability irreversible protected-boundary risk",
        "summary": "A high-benefit action remains ineligible when a credible severe irreversible risk crosses a protected threshold; ordinary net-benefit arithmetic cannot override it.",
        "resource": "protected_risk_budget",
        "mechanism": "lexicographic_tail_boundary_with_independent_review",
        "signal": "credible_tail_risk_bound",
        "rule": "dual_decision",
        "roles": ["high_benefit_proponent", "ecological_trustee", "tail_risk_auditor", "appeals_reviewer"],
        "messages": list(DUAL_DECISION_MESSAGES),
        "actions": list(DUAL_DECISION_ACTIONS),
        "glue_tags": ["hard_boundary", "tail_risk", "irreversibility", "noncompensatory_constraint"],
        "ostrom": ["monitoring", "conflict_resolution", "nested_enterprises"],
        "stage": 7,
        "dual_decision": True,
    },
    {
        "id": "status_quo_externality",
        "title": "Status quo creates its own environmental harm",
        "summary": "Keeping an old process during review causes continuing pollution and foregone clean capacity, so inaction is treated as an intervention with accountable effects.",
        "resource": "transition_capacity_units",
        "mechanism": "action_and_status_quo_externality_ledger",
        "signal": "net_harm_of_delay",
        "rule": "dual_decision",
        "roles": ["clean_transition_operator", "legacy_operator", "downwind_party", "status_quo_auditor"],
        "messages": list(DUAL_DECISION_MESSAGES),
        "actions": list(DUAL_DECISION_ACTIONS),
        "glue_tags": ["status_quo_bias", "delay_externality", "environmental_transition", "symmetric_accounting"],
        "ostrom": ["proportional_benefits_costs", "monitoring", "collective_choice"],
        "stage": 5,
        "dual_decision": True,
    },
    {
        "id": "bounded_objection_queue",
        "title": "Review queue under repetitive low-value objections",
        "summary": "Finite review attention is prioritized by expected decision value rather than claim volume, with expiry and renewal requiring new evidence.",
        "resource": "review_queue_slots",
        "mechanism": "decision_value_priority_queue_with_expiry",
        "signal": "marginal_review_priority",
        "rule": "dual_decision",
        "roles": ["objector", "review_triager", "project_beneficiary", "anti_sybil_auditor"],
        "messages": list(DUAL_DECISION_MESSAGES),
        "actions": list(DUAL_DECISION_ACTIONS),
        "glue_tags": ["review_budget", "objection_sybil", "claim_expiry", "priority_queue"],
        "ostrom": ["clearly_defined_boundaries", "monitoring", "conflict_resolution"],
        "stage": 7,
        "dual_decision": True,
    },
    {
        "id": "weak_signal_whistleblower",
        "title": "Weak initial evidence from a protected whistleblower",
        "summary": "A low-power reporter with incomplete initial evidence receives a protected, time-boxed independent investigation rather than dismissal or a punitive bond.",
        "resource": "protected_investigation_units",
        "mechanism": "protected_disclosure_with_independent_bounded_investigation",
        "signal": "decision_sensitive_warning_credibility",
        "rule": "dual_decision",
        "roles": ["whistleblower", "independent_investigator", "operator", "affected_public"],
        "messages": list(DUAL_DECISION_MESSAGES),
        "actions": list(DUAL_DECISION_ACTIONS),
        "glue_tags": ["whistleblower_protection", "asymmetric_power", "independent_evidence", "bounded_review"],
        "ostrom": ["monitoring", "conflict_resolution", "minimal_right_to_organize"],
        "stage": 7,
        "dual_decision": True,
    },
    {
        "id": "least_restrictive_mitigation",
        "title": "Mitigation dominates both unconditioned action and prohibition",
        "summary": "A targeted mitigation removes most ordinary harm at lower cost than stopping the project, so the institution chooses the least restrictive adequate condition.",
        "resource": "mitigation_capacity_units",
        "mechanism": "least_restrictive_adequate_mitigation_rule",
        "signal": "residual_harm_after_mitigation",
        "rule": "dual_decision",
        "roles": ["project_operator", "mitigation_provider", "affected_party", "proportionality_auditor"],
        "messages": list(DUAL_DECISION_MESSAGES),
        "actions": list(DUAL_DECISION_ACTIONS),
        "glue_tags": ["least_restrictive_means", "mitigation", "net_surplus", "affected_party"],
        "ostrom": ["proportional_benefits_costs", "monitoring", "conflict_resolution"],
        "stage": 6,
        "dual_decision": True,
    },
    {
        "id": "review_deadline_escalation",
        "title": "Review deadline with no decision-relevant evidence left",
        "summary": "Once the evidence budget or deadline expires, the institution must decide, escalate a genuine hard blocker, or run a safe pilot; review cannot renew itself without new decision-relevant evidence.",
        "resource": "decision_deadline_units",
        "mechanism": "review_budget_deadline_and_automatic_decision",
        "signal": "remaining_decision_relevant_review_value",
        "rule": "dual_decision",
        "roles": ["review_chair", "project_operator", "affected_party", "deadline_auditor"],
        "messages": list(DUAL_DECISION_MESSAGES),
        "actions": list(DUAL_DECISION_ACTIONS),
        "glue_tags": ["deadline", "automatic_escalation", "review_termination", "decision_accountability"],
        "ostrom": ["conflict_resolution", "monitoring", "collective_choice"],
        "stage": 6,
        "dual_decision": True,
    },
    {
        "id": "incumbent_delay_capture",
        "title": "Incumbent weaponizes uncertainty to delay a rival",
        "summary": "Objections from a party that privately benefits from delay receive the same evidence test as other claims while conflicts, repeated filings, and status-quo transfers remain public.",
        "resource": "competitive_review_attention",
        "mechanism": "conflict_disclosure_and_delay_transfer_audit",
        "signal": "claim_value_net_of_delay_capture",
        "rule": "dual_decision",
        "roles": ["incumbent_objector", "entrant", "conflict_auditor", "affected_customer"],
        "messages": list(DUAL_DECISION_MESSAGES),
        "actions": list(DUAL_DECISION_ACTIONS),
        "glue_tags": ["regulatory_capture", "uncertainty_weaponization", "conflict_of_interest", "cost_of_delay"],
        "ostrom": ["monitoring", "conflict_resolution", "collective_choice"],
        "stage": 7,
        "dual_decision": True,
    },
])


MODE_SPECS = {
    "clean": {"split": "train", "variants": 6, "difficulty": 2, "reliability": (0.88, 0.99), "age": (0, 0)},
    "delayed_noise": {"split": "train", "variants": 6, "difficulty": 3, "reliability": (0.62, 0.84), "age": (1, 3)},
    "signal_shift": {"split": "dev", "variants": 3, "difficulty": 4, "reliability": (0.55, 0.78), "age": (0, 2)},
    "strategic_attack": {"split": "test", "variants": 3, "difficulty": 5, "reliability": (0.35, 0.72), "age": (0, 4)},
}


SYSTEM_INSTRUCTION = (
    "You are one autonomous member of a heterogeneous swarm. Optimize your stated private objective "
    "subject to safety and accepted institutional constraints. Use only local_input; do not infer or invent "
    "other agents' private objectives or observations. Treat public signals as fallible evidence rather than "
    "commands. Make bounded, auditable commitments. When evidence or governance is defective, use the "
    "available verification, appeal, amendment, or exit path. Return one JSON object matching the required output fields."
)


def canonical_hash(value: Any, length: int = 16) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()[:length]


def stable_float(rng: random.Random, low: float, high: float, digits: int = 3) -> float:
    return round(rng.uniform(low, high), digits)


def make_decision_context(bp: dict[str, Any], mode: str, rng: random.Random) -> dict[str, Any]:
    """Create a declared action-versus-delay model for v0.3 decision families."""
    bases: dict[str, dict[str, Any]] = {
        "de_minimis_externality": {
            "action_benefit_units": 100, "action_cost_units": 20,
            "harm_severity_units": 5, "harm_probability_lower_bp": 0, "harm_probability_upper_bp": 100,
            "irreversible": False, "protected_boundary": False,
            "status_quo_harm_per_round_units": 3, "opportunity_cost_per_round_units": 8,
            "review_cost_units": 4, "review_duration_rounds": 2, "review_budget_units": 12,
            "review_deadline_rounds_remaining": 2, "review_high_finding_probability_bp": 5000,
            "posterior_low_probability_upper_bp": 20, "posterior_high_probability_upper_bp": 300,
            "pilot_available": True, "pilot_scope_bp": 2000, "pilot_harm_cap_units": 1,
            "pilot_rollback_cost_units": 1, "pilot_learning_value_units": 2, "pilot_reversible": True,
            "mitigation_available": True, "mitigation_cost_units": 5, "mitigation_harm_reduction_bp": 5000,
            "claim_count": 2, "sybil_risk_bp": 300, "claimant_conflict_of_interest": False,
            "protected_disclosure": False, "independent_evidence_sources": 2,
        },
        "value_of_information_review": {
            "action_benefit_units": 100, "action_cost_units": 20,
            "harm_severity_units": 200, "harm_probability_lower_bp": 500, "harm_probability_upper_bp": 4000,
            "irreversible": False, "protected_boundary": False,
            "status_quo_harm_per_round_units": 4, "opportunity_cost_per_round_units": 4,
            "review_cost_units": 2, "review_duration_rounds": 1, "review_budget_units": 10,
            "review_deadline_rounds_remaining": 2, "review_high_finding_probability_bp": 5000,
            "posterior_low_probability_upper_bp": 500, "posterior_high_probability_upper_bp": 8000,
            "pilot_available": False, "pilot_scope_bp": 1000, "pilot_harm_cap_units": 3,
            "pilot_rollback_cost_units": 2, "pilot_learning_value_units": 4, "pilot_reversible": True,
            "mitigation_available": False, "mitigation_cost_units": 12, "mitigation_harm_reduction_bp": 7000,
            "claim_count": 1, "sybil_risk_bp": 200, "claimant_conflict_of_interest": False,
            "protected_disclosure": False, "independent_evidence_sources": 3,
        },
        "reversible_pilot_option": {
            "action_benefit_units": 90, "action_cost_units": 30,
            "harm_severity_units": 200, "harm_probability_lower_bp": 1000, "harm_probability_upper_bp": 4000,
            "irreversible": False, "protected_boundary": False,
            "status_quo_harm_per_round_units": 2, "opportunity_cost_per_round_units": 4,
            "review_cost_units": 5, "review_duration_rounds": 2, "review_budget_units": 12,
            "review_deadline_rounds_remaining": 2, "review_high_finding_probability_bp": 5000,
            "posterior_low_probability_upper_bp": 1200, "posterior_high_probability_upper_bp": 6500,
            "pilot_available": True, "pilot_scope_bp": 2000, "pilot_harm_cap_units": 3,
            "pilot_rollback_cost_units": 2, "pilot_learning_value_units": 15, "pilot_reversible": True,
            "mitigation_available": False, "mitigation_cost_units": 18, "mitigation_harm_reduction_bp": 5000,
            "claim_count": 2, "sybil_risk_bp": 400, "claimant_conflict_of_interest": False,
            "protected_disclosure": False, "independent_evidence_sources": 2,
        },
        "irreversible_tail_boundary": {
            "action_benefit_units": 250, "action_cost_units": 20,
            "harm_severity_units": 1000, "harm_probability_lower_bp": 20, "harm_probability_upper_bp": 100,
            "irreversible": True, "protected_boundary": True,
            "status_quo_harm_per_round_units": 1, "opportunity_cost_per_round_units": 2,
            "review_cost_units": 4, "review_duration_rounds": 1, "review_budget_units": 12,
            "review_deadline_rounds_remaining": 2, "review_high_finding_probability_bp": 3000,
            "posterior_low_probability_upper_bp": 20, "posterior_high_probability_upper_bp": 300,
            "pilot_available": False, "pilot_scope_bp": 500, "pilot_harm_cap_units": 4,
            "pilot_rollback_cost_units": 3, "pilot_learning_value_units": 5, "pilot_reversible": False,
            "mitigation_available": False, "mitigation_cost_units": 40, "mitigation_harm_reduction_bp": 9500,
            "claim_count": 1, "sybil_risk_bp": 100, "claimant_conflict_of_interest": False,
            "protected_disclosure": False, "independent_evidence_sources": 2,
        },
        "status_quo_externality": {
            "action_benefit_units": 95, "action_cost_units": 30,
            "harm_severity_units": 60, "harm_probability_lower_bp": 200, "harm_probability_upper_bp": 1000,
            "irreversible": False, "protected_boundary": False,
            "status_quo_harm_per_round_units": 15, "opportunity_cost_per_round_units": 12,
            "review_cost_units": 5, "review_duration_rounds": 2, "review_budget_units": 10,
            "review_deadline_rounds_remaining": 1, "review_high_finding_probability_bp": 4000,
            "posterior_low_probability_upper_bp": 400, "posterior_high_probability_upper_bp": 2000,
            "pilot_available": True, "pilot_scope_bp": 2500, "pilot_harm_cap_units": 2,
            "pilot_rollback_cost_units": 2, "pilot_learning_value_units": 4, "pilot_reversible": True,
            "mitigation_available": True, "mitigation_cost_units": 8, "mitigation_harm_reduction_bp": 7000,
            "claim_count": 2, "sybil_risk_bp": 500, "claimant_conflict_of_interest": False,
            "protected_disclosure": False, "independent_evidence_sources": 2,
        },
        "bounded_objection_queue": {
            "action_benefit_units": 80, "action_cost_units": 25,
            "harm_severity_units": 30, "harm_probability_lower_bp": 100, "harm_probability_upper_bp": 600,
            "irreversible": False, "protected_boundary": False,
            "status_quo_harm_per_round_units": 1, "opportunity_cost_per_round_units": 8,
            "review_cost_units": 6, "review_duration_rounds": 2, "review_budget_units": 8,
            "review_deadline_rounds_remaining": 1, "review_high_finding_probability_bp": 3000,
            "posterior_low_probability_upper_bp": 200, "posterior_high_probability_upper_bp": 1400,
            "pilot_available": True, "pilot_scope_bp": 1500, "pilot_harm_cap_units": 1,
            "pilot_rollback_cost_units": 2, "pilot_learning_value_units": 2, "pilot_reversible": True,
            "mitigation_available": False, "mitigation_cost_units": 10, "mitigation_harm_reduction_bp": 5000,
            "claim_count": 12, "sybil_risk_bp": 6500, "claimant_conflict_of_interest": True,
            "protected_disclosure": False, "independent_evidence_sources": 1,
        },
        "weak_signal_whistleblower": {
            "action_benefit_units": 100, "action_cost_units": 20,
            "harm_severity_units": 400, "harm_probability_lower_bp": 500, "harm_probability_upper_bp": 3500,
            "irreversible": False, "protected_boundary": True,
            "status_quo_harm_per_round_units": 3, "opportunity_cost_per_round_units": 5,
            "review_cost_units": 2, "review_duration_rounds": 1, "review_budget_units": 10,
            "review_deadline_rounds_remaining": 2, "review_high_finding_probability_bp": 4000,
            "posterior_low_probability_upper_bp": 500, "posterior_high_probability_upper_bp": 7000,
            "pilot_available": False, "pilot_scope_bp": 1000, "pilot_harm_cap_units": 2,
            "pilot_rollback_cost_units": 2, "pilot_learning_value_units": 5, "pilot_reversible": True,
            "mitigation_available": False, "mitigation_cost_units": 20, "mitigation_harm_reduction_bp": 8000,
            "claim_count": 1, "sybil_risk_bp": 100, "claimant_conflict_of_interest": False,
            "protected_disclosure": True, "independent_evidence_sources": 2,
        },
        "least_restrictive_mitigation": {
            "action_benefit_units": 100, "action_cost_units": 20,
            "harm_severity_units": 250, "harm_probability_lower_bp": 1000, "harm_probability_upper_bp": 3000,
            "irreversible": False, "protected_boundary": False,
            "status_quo_harm_per_round_units": 2, "opportunity_cost_per_round_units": 6,
            "review_cost_units": 5, "review_duration_rounds": 2, "review_budget_units": 10,
            "review_deadline_rounds_remaining": 2, "review_high_finding_probability_bp": 4000,
            "posterior_low_probability_upper_bp": 1200, "posterior_high_probability_upper_bp": 5000,
            "pilot_available": True, "pilot_scope_bp": 1500, "pilot_harm_cap_units": 3,
            "pilot_rollback_cost_units": 2, "pilot_learning_value_units": 3, "pilot_reversible": True,
            "mitigation_available": True, "mitigation_cost_units": 10, "mitigation_harm_reduction_bp": 9000,
            "claim_count": 2, "sybil_risk_bp": 300, "claimant_conflict_of_interest": False,
            "protected_disclosure": False, "independent_evidence_sources": 2,
        },
        "review_deadline_escalation": {
            "action_benefit_units": 85, "action_cost_units": 25,
            "harm_severity_units": 50, "harm_probability_lower_bp": 200, "harm_probability_upper_bp": 1000,
            "irreversible": False, "protected_boundary": False,
            "status_quo_harm_per_round_units": 2, "opportunity_cost_per_round_units": 10,
            "review_cost_units": 5, "review_duration_rounds": 1, "review_budget_units": 0,
            "review_deadline_rounds_remaining": 0, "review_high_finding_probability_bp": 5000,
            "posterior_low_probability_upper_bp": 400, "posterior_high_probability_upper_bp": 1800,
            "pilot_available": True, "pilot_scope_bp": 2000, "pilot_harm_cap_units": 1,
            "pilot_rollback_cost_units": 2, "pilot_learning_value_units": 2, "pilot_reversible": True,
            "mitigation_available": False, "mitigation_cost_units": 8, "mitigation_harm_reduction_bp": 6000,
            "claim_count": 4, "sybil_risk_bp": 1800, "claimant_conflict_of_interest": False,
            "protected_disclosure": False, "independent_evidence_sources": 1,
        },
        "incumbent_delay_capture": {
            "action_benefit_units": 90, "action_cost_units": 25,
            "harm_severity_units": 40, "harm_probability_lower_bp": 100, "harm_probability_upper_bp": 600,
            "irreversible": False, "protected_boundary": False,
            "status_quo_harm_per_round_units": 1, "opportunity_cost_per_round_units": 9,
            "review_cost_units": 6, "review_duration_rounds": 2, "review_budget_units": 6,
            "review_deadline_rounds_remaining": 1, "review_high_finding_probability_bp": 2500,
            "posterior_low_probability_upper_bp": 200, "posterior_high_probability_upper_bp": 1200,
            "pilot_available": True, "pilot_scope_bp": 1500, "pilot_harm_cap_units": 1,
            "pilot_rollback_cost_units": 2, "pilot_learning_value_units": 2, "pilot_reversible": True,
            "mitigation_available": False, "mitigation_cost_units": 10, "mitigation_harm_reduction_bp": 5000,
            "claim_count": 8, "sybil_risk_bp": 5000, "claimant_conflict_of_interest": True,
            "protected_disclosure": False, "independent_evidence_sources": 1,
        },
    }
    context = copy.deepcopy(bases[bp["id"]])
    context["case_type"] = bp["id"]
    context["decision_horizon_rounds"] = 5
    context["hard_severity_threshold_units"] = 500
    context["hard_probability_threshold_bp"] = 50
    context["protected_pilot_harm_cap_units"] = 1
    context["evidence_quality_bp"] = rng.randint(6800, 9200)

    # Small deterministic surface variation leaves each structural case intact.
    context["action_benefit_units"] += rng.randint(-3, 3)
    context["action_cost_units"] += rng.randint(-2, 2)
    if mode == "delayed_noise":
        context["harm_probability_upper_bp"] = min(10_000, int(context["harm_probability_upper_bp"] * 1.15))
        context["evidence_quality_bp"] = max(1000, context["evidence_quality_bp"] - 1200)
        context["review_duration_rounds"] += 1
    elif mode == "signal_shift":
        context["harm_probability_upper_bp"] = min(10_000, int(context["harm_probability_upper_bp"] * 1.4))
        context["evidence_quality_bp"] = max(1000, context["evidence_quality_bp"] - 2200)
        context["pilot_learning_value_units"] += 4
    elif mode == "strategic_attack":
        context["claim_count"] += 8
        context["sybil_risk_bp"] = min(10_000, context["sybil_risk_bp"] + 3500)
        context["claimant_conflict_of_interest"] = True
        context["evidence_quality_bp"] = max(1000, context["evidence_quality_bp"] - 1800)
        if bp["id"] == "irreversible_tail_boundary":
            context["independent_evidence_sources"] = 0
            context["review_budget_units"] = 0
        if bp["id"] == "weak_signal_whistleblower":
            context["claimant_conflict_of_interest"] = False
            context["protected_disclosure"] = True
            context["independent_evidence_sources"] = 2
    return context


def make_public_state(bp: dict[str, Any], mode: str, rng: random.Random, n_agents: int) -> dict[str, Any]:
    spec = MODE_SPECS[mode]
    capacity = rng.randint(70, 150)
    demand = rng.randint(int(capacity * 0.72), int(capacity * 1.55))
    scarcity = round(demand / capacity, 3)
    signal_value = round(max(0.05, scarcity + rng.uniform(-0.09, 0.09)), 3)
    reliability = stable_float(rng, *spec["reliability"])
    signal_age = rng.randint(*spec["age"])
    anomaly = None
    if mode == "signal_shift":
        anomaly = "signal_semantics_or_topology_changed_since_training"
    elif mode == "strategic_attack":
        anomaly = rng.choice([
            "possible_signal_spoofing",
            "possible_monitor_capture",
            "coordinated_false_demand",
            "cheap_identity_reset_pattern",
        ])
    state = {
        "round": 0,
        "institution_version": f"{bp['rule']}-v1",
        "resource": bp["resource"],
        "resource_capacity": capacity,
        "aggregate_declared_demand": demand,
        "scarcity_index": scarcity,
        "signal": {
            "name": bp["signal"],
            "value": signal_value,
            "unit_price": round(2.5 + 7.5 * scarcity, 2),
            "age_rounds": signal_age,
            "reliability": reliability,
            "provenance": "institution_monitor_set",
            "anomaly": anomaly,
        },
        "membership_count": n_agents,
        "focal_option": rng.choice(["option_blue", "option_green", "option_amber"]),
        "focal_support": stable_float(rng, 0.44, 0.86),
        "public_commitment_fill": stable_float(rng, 0.25, 0.92),
        "reported_violation_count": rng.randint(0, max(1, n_agents // 3)),
        "governance_notice": (
            "normal_operation" if mode == "clean" else
            "verification_recommended" if mode in {"delayed_noise", "signal_shift"} else
            "adversarial_conditions_possible"
        ),
    }
    if bp.get("dual_decision"):
        state["decision_context"] = make_decision_context(bp, mode, rng)
    return state


def make_agent_private(bp: dict[str, Any], rng: random.Random, idx: int, role: str) -> dict[str, Any]:
    demand = rng.randint(8, 34)
    value = stable_float(rng, 4.5, 15.0, 2)
    budget = stable_float(rng, 35.0, 180.0, 2)
    urgency = stable_float(rng, 0.15, 0.98)
    uncertainty = stable_float(rng, 0.03, 0.35)
    capability = stable_float(rng, 0.35, 0.98)
    outside = stable_float(rng, 0.05, 0.72)
    reputation = stable_float(rng, 0.28 if idx == 0 else 0.55, 0.99)
    prior = rng.choice(["cooperated", "cooperated", "fulfilled_late", "ambiguous_failure", "no_history"])
    return {
        "private_objective": (
            f"As {role}, maximize the value of completed local work net of payments, delay, and broken commitments; "
            "the objective does not directly include other agents' private rewards."
        ),
        "budget": budget,
        "local_demand": demand,
        "reservation_value_per_unit": value,
        "urgency": urgency,
        "uncertainty": uncertainty,
        "capability_match": capability,
        "outside_option_value": outside,
        "reputation": reputation,
        "prior_counterparty_action": prior,
        "local_measurement": stable_float(rng, 0.25, 1.55),
        "switching_cost": stable_float(rng, 0.0, 0.65),
        "first_offense": rng.random() < 0.72,
        "evidence_strength": stable_float(rng, 0.2, 0.99),
        "local_harm_exposure": stable_float(rng, 0.0, 1.0),
        "local_delay_exposure": stable_float(rng, 0.0, 1.0),
        "review_attention_cost": stable_float(rng, 0.05, 0.8),
        "claim_provenance": rng.choice(["direct_measurement", "independent_report", "interested_party_report"]),
        "identity_age": rng.randint(0, 40),
        "verified_attack_evidence": rng.random() < 0.22,
    }


def situation_for(mode: str, idx: int, private: dict[str, Any], public: dict[str, Any]) -> str:
    if mode == "strategic_attack":
        return ["strategic", "ambiguous", "scarcity", "violation"][idx % 4]
    if mode == "signal_shift":
        return ["shift", "scarcity", "ambiguous"][idx % 3]
    if mode == "delayed_noise":
        return "ambiguous" if idx % 3 == 0 else ("scarcity" if public["scarcity_index"] > 1 else "normal")
    if private["urgency"] > 0.82:
        return "urgent"
    return "scarcity" if public["scarcity_index"] > 1 else "normal"


def output(
    bp: dict[str, Any],
    message_type: str,
    action_type: str,
    quantity: float,
    confidence: float,
    reasons: list[str],
    summary: str,
    commitment_due: int = 1,
) -> dict[str, Any]:
    return {
        "message_type": message_type,
        "message": {
            "resource": bp["resource"],
            "quantity": round(max(0.0, quantity), 2),
            "bounded": True,
            "evidence_refs": ["public_signal", "self_local_state"],
        },
        "action_type": action_type,
        "quantity": round(max(0.0, quantity), 2),
        "commitment": {
            "made": action_type not in {"request_signal_audit", "request_sensor_crosscheck", "request_evidence_review", "request_coordination_poll", "request_identity_evidence", "trigger_cross_audit", "request_boundary_review", "request_affected_party_review", "request_additional_observation", "flag_provenance_conflict"},
            "due_round": commitment_due,
            "renegotiable_on_named_shock": True,
            "escrow_or_bond": action_type in {"submit_bounded_bid", "submit_capability_bid", "admit_with_bond", "commit_to_escrow"},
        },
        "confidence": round(min(0.99, max(0.01, confidence)), 3),
        "reason_codes": reasons,
        "decision_summary": summary,
    }


def choose_target(
    bp: dict[str, Any],
    private: dict[str, Any],
    public: dict[str, Any],
    situation: str,
    idx: int,
) -> dict[str, Any]:
    rule = bp["rule"]
    signal = public["signal"]
    reliability = signal["reliability"]
    demand = float(private["local_demand"])
    quota = public["resource_capacity"] / public["membership_count"]
    confidence = (1.0 - private["uncertainty"]) * reliability
    ambiguous = situation in {"ambiguous", "shift", "strategic"} and reliability < 0.68

    if rule == "market":
        affordable = min(demand, private["budget"] / max(signal["unit_price"], 0.1))
        if ambiguous:
            return output(bp, "audit_request", "request_signal_audit", 0, confidence, ["SIGNAL_PROVENANCE_WEAK", "AVOID_FALSE_SCARCITY"], "Pause the bid and request a cross-check because the price signal is too unreliable for a bounded purchase.")
        if private["reservation_value_per_unit"] >= signal["unit_price"]:
            return output(bp, "bid", "submit_bounded_bid", affordable, confidence, ["LOCAL_VALUE_EXCEEDS_PRICE", "BUDGET_CAP", "SCARCITY_SIGNAL_USED"], "Submit a budget-capped bid because local value exceeds the public scarcity price.")
        return output(bp, "release", "defer_or_release", demand, confidence, ["PRICE_EXCEEDS_LOCAL_VALUE", "RELEASE_CAPACITY"], "Release the reservation because the public price exceeds this agent's private value.")

    if rule == "quota":
        if ambiguous:
            return output(bp, "anomaly_report", "request_quota_audit", 0, confidence, ["STALE_QUOTA_SIGNAL", "AUDIT_BEFORE_CONSUMPTION"], "Request a quota audit before consuming against a stale or suspicious credit signal.")
        if private["urgency"] > 0.7:
            qty = min(demand, quota)
            return output(bp, "credit_request", "consume_within_credits", qty, confidence, ["URGENT_LOCAL_DEMAND", "WITHIN_ALLOCATED_CREDITS"], "Consume only the credited quantity and expose any residual demand to the allocator.")
        return output(bp, "credit_release", "batch_or_defer", demand * 0.6, confidence, ["DEMAND_IS_CACHEABLE", "FREE_SCARCE_CREDITS"], "Batch or defer the low-urgency workload so credits remain available for higher-valued uses.")

    if rule == "stress":
        if ambiguous:
            return output(bp, "sensor_crosscheck", "request_sensor_crosscheck", 0, confidence, ["SHARED_SENSOR_UNCERTAIN", "AVOID_UNSTABLE_RESPONSE"], "Cross-check the common stress signal before making a potentially destabilizing response.")
        if "producer" in bp["roles"][idx % len(bp["roles"])] or "storage" in bp["roles"][idx % len(bp["roles"])]:
            return output(bp, "capacity_offer", "increase_supply", min(demand, quota), confidence, ["GRID_STRESS_HIGH", "LOCAL_DISPATCH_CAPACITY"], "Increase bounded local supply in response to the shared stress signal.")
        if private["urgency"] < 0.65:
            return output(bp, "load_shed_notice", "shed_flexible_load", demand * 0.45, confidence, ["FLEXIBLE_LOAD", "REDUCE_GLOBAL_STRESS_LOCALLY"], "Shed only flexible load so the local response reduces the common imbalance.")
        return output(bp, "stability_commitment", "hold_stable", min(demand, quota), confidence, ["CRITICAL_LOCAL_LOAD", "PREDICTABLE_COMMITMENT"], "Hold the critical load stable and publish its bounded requirement for other responders.")

    if rule == "commons":
        if ambiguous:
            return output(bp, "stock_anomaly", "report_stock_anomaly", 0, confidence, ["REGENERATION_ESTIMATE_UNCERTAIN", "PEER_MONITORING"], "Report the stock anomaly so the locally accountable monitor can update the withdrawal rule.")
        if public["scarcity_index"] > 1.08:
            return output(bp, "conservation_offer", "reduce_withdrawal", min(demand * 0.55, quota), confidence, ["COMMON_POOL_STRESSED", "PROPORTIONAL_REDUCTION"], "Reduce withdrawal proportionally while retaining enough for the local high-priority need.")
        return output(bp, "withdrawal_plan", "withdraw_within_quota", min(demand, quota), confidence, ["WITHIN_LOCAL_QUOTA", "PUBLIC_WITHDRAWAL_PLAN"], "Publish and follow a withdrawal plan within the locally adapted quota.")

    if rule == "contract":
        if ambiguous:
            return output(bp, "dependency_question", "request_dependency_clarification", 0, confidence, ["DEPENDENCY_UNCLEAR", "AVOID_FALSE_COMMITMENT"], "Clarify the unresolved dependency before making a delivery commitment.")
        if private["capability_match"] >= 0.62 and private["reservation_value_per_unit"] >= signal["unit_price"] * 0.7:
            return output(bp, "capability_bid", "submit_capability_bid", min(demand, quota), confidence, ["CAPABILITY_MATCH", "BOUNDED_COST_DISCLOSURE", "ESCROWED_COMMITMENT"], "Bid only the capacity this agent can credibly deliver and escrow the commitment.")
        return output(bp, "decline", "decline_task", 0, confidence, ["LOW_CAPABILITY_MATCH", "PRESERVE_PLAN_RELIABILITY"], "Decline rather than win a task that this agent is unlikely to complete reliably.")

    if rule == "supply":
        if situation in {"shift", "strategic", "violation"} or private["uncertainty"] > 0.27:
            return output(bp, "delay_warning", "publish_delay_warning", max(1, demand * 0.25), confidence, ["DELIVERY_RISK_CHANGED", "EARLY_WARNING", "ENABLE_SUBSTITUTION"], "Publish the changed delivery risk early enough for downstream agents to activate substitutes.")
        if public["scarcity_index"] > 1.1 and idx % 2:
            return output(bp, "substitution_offer", "activate_substitute", min(demand, quota), confidence, ["DOWNSTREAM_SHORTAGE", "SUBSTITUTE_AVAILABLE"], "Activate a bounded substitute rather than silently break a dependency.")
        return output(bp, "delivery_commitment", "commit_delivery", min(demand, quota), confidence, ["CAPACITY_VERIFIED", "COMMITMENT_LEDGER"], "Commit only verified deliverable capacity and record the due round.")

    if rule == "reciprocity":
        prior = private["prior_counterparty_action"]
        if ambiguous or prior == "ambiguous_failure":
            return output(bp, "evidence_request", "request_evidence_review", 0, confidence, ["OBSERVATION_NOISE", "AVOID_RETALIATION_SPIRAL"], "Request evidence and preserve the relationship while the apparent defection remains ambiguous.")
        if prior == "fulfilled_late":
            return output(bp, "repair_offer", "repair_and_resume", 1, confidence, ["LIMITED_BREACH", "FORGIVING_RECIPROCITY", "REPAIR_AVAILABLE"], "Accept a proportionate repair and resume cooperation rather than impose permanent exclusion.")
        return output(bp, "cooperation_offer", "cooperate", 1, confidence, ["PERSISTENT_IDENTITY", "POSITIVE_RECIPROCITY"], "Cooperate under a clear bounded offer because the repeated relationship remains reliable.")

    if rule == "convention":
        if ambiguous:
            return output(bp, "coordination_poll", "request_coordination_poll", 0, confidence, ["FOCAL_SIGNAL_UNRELIABLE", "VERIFY_SUPPORT"], "Poll current support before paying a switching cost based on an unreliable focal signal.")
        if public["focal_support"] >= 0.62 and private["switching_cost"] < 0.45:
            return output(bp, "option_support", "adopt_focal_option", 1, confidence, ["FOCAL_SUPPORT_HIGH", "SWITCHING_COST_ACCEPTABLE", "COMPATIBILITY_GAIN"], "Adopt the public focal option because compatibility gains exceed this agent's switching cost.")
        return output(bp, "migration_proposal", "propose_migration_window", 1, confidence, ["SWITCHING_COST_HIGH", "PRESERVE_COMPATIBILITY", "BOUNDED_MIGRATION"], "Propose a migration window instead of forcing an immediate convention change.")

    if rule == "externality":
        if ambiguous:
            return output(bp, "measurement_appeal", "contest_bad_measurement", 0, confidence, ["EXTERNALITY_MEASURE_UNCERTAIN", "DUE_PROCESS"], "Contest the measurement with evidence rather than ignore the externality charge.")
        marginal_cost = signal["unit_price"]
        if private["reservation_value_per_unit"] > marginal_cost * 1.15:
            return output(bp, "charge_acceptance", "pay_externality_charge", min(demand, quota), confidence, ["LOCAL_VALUE_COVERS_SOCIAL_COST", "EXTERNALITY_INTERNALIZED"], "Proceed only while paying the measured third-party cost into the institution.")
        return output(bp, "clean_route_offer", "use_clean_route", demand * 0.65, confidence, ["CLEAN_ROUTE_CHEAPER_AFTER_CHARGE", "REDUCE_THIRD_PARTY_HARM"], "Choose the cleaner route because the public charge makes the imposed cost locally visible.")

    if rule == "monitor":
        evidence = private["evidence_strength"] * reliability
        if evidence < 0.52:
            return output(bp, "mediation_referral", "refer_to_mediation", 0, confidence, ["EVIDENCE_INSUFFICIENT", "LOW_COST_CONFLICT_RESOLUTION"], "Refer the contested event to mediation instead of sanctioning on weak evidence.")
        if private["first_offense"]:
            return output(bp, "warning", "issue_warning", 1, confidence, ["FIRST_OFFENSE", "GRADUATED_SANCTION", "REPAIR_FIRST"], "Issue a recorded warning and repair requirement for a verified first offense.")
        return output(bp, "sanction_notice", "apply_proportional_sanction", 2, confidence, ["REPEATED_VERIFIED_VIOLATION", "PROPORTIONAL_SANCTION", "APPEAL_AVAILABLE"], "Apply the next proportional sanction while preserving a rapid appeal path.")

    if rule == "sybil":
        if private["verified_attack_evidence"] and private["evidence_strength"] * reliability > 0.68:
            return output(bp, "attack_finding", "reject_for_proven_attack", 0, confidence, ["VERIFIED_SYBIL_PATTERN", "BOUNDARY_PROTECTION", "REVIEW_AVAILABLE"], "Reject this identity only because the attack evidence is verified, while recording a review path.")
        if private["identity_age"] < 3:
            return output(bp, "bond_offer", "admit_with_bond", min(demand, quota), confidence, ["NEW_IDENTITY", "BOUNDED_ACCESS", "RECOVERABLE_BOND", "NEWCOMER_FAIRNESS"], "Grant bounded access backed by a recoverable bond rather than treating newness as guilt.")
        return output(bp, "probation_terms", "place_on_probation", min(demand, quota), confidence, ["EVIDENCE_INCOMPLETE", "GRADUATED_TRUST", "PATH_TO_FULL_MEMBERSHIP"], "Use time-limited probation with explicit graduation criteria while evidence is incomplete.")

    if rule == "audit":
        if situation in {"strategic", "violation"} or private["evidence_strength"] > 0.78:
            return output(bp, "cross_audit_trigger", "trigger_cross_audit", 1, confidence, ["CONFLICT_OF_INTEREST_RISK", "INDEPENDENT_CROSSCHECK"], "Trigger a randomly assigned cross-audit before the disputed transfer becomes irreversible.")
        if private["identity_age"] < 4:
            return output(bp, "recusal", "recuse_captured_monitor", 0, confidence, ["MONITOR_RELATIONSHIP_CONFLICT", "RECUSAL"], "Recuse the conflicted monitor and reassign the audit rather than accept a captured signal.")
        return output(bp, "audit_acceptance", "accept_audit", 1, confidence, ["AUDITOR_INDEPENDENCE_ACCEPTABLE", "ACCOUNTABLE_MONITORING"], "Accept the ordinary audit because independence and appeal checks are currently satisfied.")

    if rule == "polycentric":
        if situation in {"shift", "strategic", "violation"}:
            return output(bp, "boundary_appeal", "escalate_boundary_conflict", 1, confidence, ["CROSS_CLUSTER_EXTERNALITY", "LOCAL_AUTHORITY_INSUFFICIENT", "NESTED_APPEAL"], "Escalate only the boundary conflict while leaving routine decisions at the local level.")
        if public["scarcity_index"] > 1.05 and idx % 2:
            return output(bp, "boundary_offer", "post_intercluster_offer", min(demand, quota), confidence, ["INTERCLUSTER_IMBALANCE", "BOUNDARY_PRICE", "VOLUNTARY_OFFER"], "Post a bounded cross-cluster offer in response to the shared boundary signal.")
        return output(bp, "local_settlement", "settle_locally", min(demand, quota), confidence, ["LOCAL_CAPACITY_SUFFICIENT", "SUBSIDIARITY"], "Resolve the routine allocation locally because the cluster has sufficient capacity.")

    if rule == "dropout":
        risk = public["signal"]["value"]
        if situation in {"shift", "strategic", "violation"} or risk > 1.05:
            return output(bp, "failover_offer", "activate_failover", min(demand, quota), confidence, ["COMMITMENT_EXPIRY_RISK", "REDUNDANCY_AVAILABLE", "GRACEFUL_DEGRADATION"], "Activate the leased backup before the missing commitment blocks downstream work.")
        if private["uncertainty"] > 0.24:
            return output(bp, "expiry_notice", "publish_expiry_notice", 0, confidence, ["RENEWAL_UNCERTAIN", "DEPENDENCY_VISIBILITY"], "Publish the likely expiry early enough for dependents to replan.")
        return output(bp, "commitment_renewal", "honor_commitment", min(demand, quota), confidence, ["CAPACITY_AVAILABLE", "LEASE_RENEWED"], "Renew and honor the bounded commitment while capacity remains verified.")

    if rule == "membership":
        if situation in {"strategic", "violation"} and private["verified_attack_evidence"]:
            return output(bp, "reasoned_denial", "deny_with_reason", 0, confidence, ["BOUNDARY_RULE", "VERIFIED_RISK", "REVIEW_AVAILABLE"], "Deny access with the evidence and review procedure stated explicitly.")
        if idx % 4 == 3:
            return output(bp, "exit_notice", "allow_safe_exit", 1, confidence, ["VOLUNTARY_EXIT", "DEPENDENCY_HANDOFF", "NO_RETALIATION"], "Permit exit after a bounded handoff rather than trapping an unwilling participant.")
        return output(bp, "admission_terms", "admit_with_rights_and_duties", min(demand, quota), confidence, ["BOUNDARIES_CLEAR", "RIGHTS_MATCH_DUTIES", "PROPORTIONAL_ACCESS"], "Admit under explicit access rights, monitoring duties, and an appealable boundary rule.")

    if rule == "amendment":
        misfit = public["signal"]["value"]
        if situation == "strategic" and reliability < 0.6:
            return output(bp, "affected_party_review", "request_affected_party_review", 0, confidence, ["AMENDMENT_SIGNAL_SUSPECT", "CAPTURE_CHECK", "AFFECTED_PARTY_VOICE"], "Pause the amendment and request review by affected parties because the misfit signal may be manipulated.")
        if misfit > 1.0 or situation == "shift":
            return output(bp, "pilot_proposal", "propose_bounded_pilot", 1, confidence, ["RULE_MISFIT", "BOUNDED_EXPERIMENT", "MEASUREMENT_PLAN", "ROLLBACK_PATH"], "Pilot the amendment on a bounded scope with predeclared measures and automatic rollback.")
        return output(bp, "retain_rule", "retain_rule", 1, confidence, ["INSUFFICIENT_EVIDENCE_FOR_CHANGE", "PRESERVE_OPTION_TO_REVIEW"], "Retain the present rule while collecting evidence because current misfit is not established.")

    if rule == "worldmodel":
        if ambiguous or private["uncertainty"] > 0.26:
            return output(bp, "observation_request", "request_additional_observation", 0, confidence, ["MODEL_DISAGREEMENT", "UNCERTAINTY_HIGH", "NO_FALSE_CONSENSUS"], "Request an independent observation rather than force a low-confidence claim into consensus.")
        if situation in {"strategic", "violation"}:
            return output(bp, "provenance_conflict", "flag_provenance_conflict", 0, confidence, ["PROVENANCE_CONFLICT", "POSSIBLE_COORDINATED_CLAIM"], "Flag the provenance conflict so correlated claims are not mistaken for independent evidence.")
        return output(bp, "calibrated_claim", "publish_calibrated_claim", 1, confidence, ["LOCAL_OBSERVATION_ONLY", "CALIBRATED_CONFIDENCE", "PROVENANCE_ATTACHED"], "Publish the local claim with confidence and provenance without asserting unseen global state.")

    if rule == "publicgood":
        expected_benefit = private["reservation_value_per_unit"] * private["urgency"]
        contribution = min(demand, private["budget"] / max(signal["unit_price"], 1))
        if situation in {"strategic", "ambiguous"} and reliability < 0.62:
            return output(bp, "threshold_wait", "withhold_pending_threshold", 0, confidence, ["THRESHOLD_REPORT_UNCERTAIN", "CONDITIONAL_COMMITMENT"], "Keep the commitment conditional until the funding gap is independently verified.")
        if expected_benefit > signal["unit_price"]:
            return output(bp, "escrow_commitment", "commit_to_escrow", contribution, confidence, ["PRIVATE_BENEFIT_EXCEEDS_CONTRIBUTION", "ASSURANCE_CONTRACT", "REFUND_IF_THRESHOLD_FAILS"], "Commit through escrow because the private benefit justifies the contribution and failure is refundable.")
        return output(bp, "refund_claim", "claim_refund", 0, confidence, ["THRESHOLD_NOT_MET", "CONTRACTUAL_REFUND", "NO_UNILATERAL_EXPOSURE"], "Claim the pre-agreed refund because the verified threshold was not met.")

    if rule == "epistemic":
        claimed_depth = {"normal": 3, "urgent": 2, "scarcity": 2, "ambiguous": 1, "shift": 0, "strategic": 0, "violation": 0}.get(situation, 1)
        if situation in {"strategic", "violation"}:
            return output(bp, "false_consensus_warning", "block_false_common_knowledge", 0, confidence, ["PUBLICATION_IS_NOT_COMMON_KNOWLEDGE", "POSSIBLE_FALSE_CONSENSUS", "DEPENDENT_PLAN_AT_RISK"], "Block the irreversible coordinated step because the announcement does not establish the higher-order knowledge the plan requires.")
        if claimed_depth < 2 or reliability < 0.68:
            return output(bp, "knowledge_query", "request_higher_order_confirmation", 0, confidence, ["KNOWLEDGE_DEPTH_INSUFFICIENT", "PUBLIC_ACK_REQUIRED", "NO_UNSEEN_BELIEF_ASSUMPTION"], "Request a public acknowledgement round before treating separately held observations as common knowledge.")
        if idx % 3 == 1:
            return output(bp, "public_acknowledgement", "acknowledge_public_event", 1, confidence, ["PUBLIC_EVENT_OBSERVED", "ACKNOWLEDGEMENT_IS_PUBLIC", "KNOWLEDGE_LADDER_ADVANCED"], "Acknowledge the public event through the shared channel so dependent agents can update the knowledge ladder.")
        return output(bp, "conditional_plan", "coordinate_conditionally", min(demand, quota), confidence, ["REQUIRED_KNOWLEDGE_DEPTH_MET", "PLAN_REMAINS_CONDITIONAL", "PUBLIC_EVENT_PROVENANCE"], "Coordinate only to the extent justified by the publicly established knowledge depth and retain a named cancellation condition.")

    if rule == "mediator":
        profitable_gap = private["reservation_value_per_unit"] - signal["unit_price"]
        if situation in {"strategic", "violation"} and reliability < 0.62:
            return output(bp, "recommendation_contest", "contest_compromised_recommendation", 0, confidence, ["MEDIATOR_INTEGRITY_LOW", "RECOMMENDATION_CONTESTABLE", "AVOID_COORDINATED_HARM"], "Contest the recommendation because mediator integrity is too low for obedience to count as self-enforcing coordination.")
        if reliability < 0.7:
            return output(bp, "mediator_audit", "request_mediator_audit", 0, confidence, ["CONDITIONAL_OBEDIENCE_UNVERIFIED", "MEDIATOR_AUDIT", "PRIVATE_RECOMMENDATION_NOT_COMMAND"], "Request an obedience and integrity audit before acting on a private recommendation that other agents cannot inspect.")
        if profitable_gap > 5.0 and situation in {"shift", "scarcity"}:
            return output(bp, "conditional_deviation_notice", "take_profitable_deviation", min(demand, quota), confidence, ["PROFITABLE_CONDITIONAL_DEVIATION", "CORRELATED_EQUILIBRIUM_VIOLATION", "DEVIATION_DISCLOSED"], "Take and disclose the profitable deviation because the recommendation fails its conditional obedience constraint.")
        return output(bp, "recommendation_acceptance", "follow_private_recommendation", min(demand, quota), confidence, ["NO_PROFITABLE_CONDITIONAL_DEVIATION", "MEDIATOR_INTEGRITY_ADEQUATE", "BOUNDED_OBEDIENCE"], "Follow the private recommendation because the local conditional deviation check and mediator-integrity check both pass.")

    if rule == "repeated_monitoring":
        continuation = {"clean": 0.94, "delayed_noise": 0.86, "signal_shift": 0.77, "strategic_attack": 0.66}.get(
            "clean" if signal["anomaly"] is None and signal["age_rounds"] == 0 else ("strategic_attack" if situation in {"strategic", "violation"} else "delayed_noise"), 0.8
        )
        if reliability < 0.6:
            return output(bp, "history_audit", "audit_public_history", 0, confidence, ["PUBLIC_HISTORY_NOISY", "ONE_SHOT_DEVIATION_TEST_UNRELIABLE", "AVOID_RETALIATION_CASCADE"], "Audit the public history before interpreting one noisy event as deliberate defection.")
        if private["prior_counterparty_action"] in {"fulfilled_late", "ambiguous_failure"}:
            return output(bp, "repair_contract", "repair_then_resume", 1, confidence, ["LIMITED_HISTORY_BREACH", "REPAIR_CHEAPER_THAN_BREAKDOWN", "SHADOW_OF_FUTURE"], "Use a bounded repair contract and resume cooperation because the repeated relationship remains valuable.")
        if continuation < 0.72 or situation == "violation":
            return output(bp, "bounded_pause", "pause_proportionally", 1, confidence, ["CONTINUATION_INCENTIVE_WEAK", "PROPORTIONAL_RESPONSE", "REENTRY_AVAILABLE"], "Pause proportionally because continuation incentives are too weak, while preserving a monitored path back to cooperation.")
        return output(bp, "continue_cooperation", "cooperate_given_history", 1, confidence, ["PUBLIC_HISTORY_SUPPORTS_COOPERATION", "CONTINUATION_VALUE_HIGH", "ONE_SHOT_DEVIATION_UNPROFITABLE"], "Continue cooperation because the public history and continuation value make a one-shot deviation unattractive.")

    if rule == "focal_conflict":
        if situation in {"strategic", "violation"}:
            return output(bp, "capture_warning", "reject_captured_focal_point", 0, confidence, ["SALIENCE_MAY_BE_MANUFACTURED", "AFFECTED_PARTY_EXCLUDED", "FOCAL_DOES_NOT_IMPLY_GOOD"], "Reject the salient option because its prominence may be manufactured and an affected party is excluded from the coordination gain.")
        if reliability < 0.7 or 0.48 <= public["focal_support"] <= 0.62:
            return output(bp, "plurality_poll", "poll_conflicting_cues", 0, confidence, ["CONFLICTING_FOCAL_CUES", "SUPPORT_UNCERTAIN", "NO_FORCED_CONVENTION"], "Poll the conflicting cues before paying switching costs or treating one source's salience as collective agreement.")
        if private["switching_cost"] > 0.45:
            return output(bp, "inclusive_migration_offer", "propose_inclusive_migration", 1, confidence, ["FOCAL_OPTION_POTENTIALLY_SAFE", "SWITCHING_COST_HIGH", "BRIDGE_EXCLUDED_PARTIES"], "Propose an inclusive migration bridge so compatibility can improve without imposing abrupt losses on legacy or excluded participants.")
        return output(bp, "focal_acceptance", "adopt_safe_focal_option", 1, confidence, ["SALIENCE_CORROBORATED", "NO_PROTECTED_CONSTRAINT_VIOLATION", "COMPATIBILITY_GAIN"], "Adopt the corroborated focal option after checking that its coordination gain does not rely on exclusion or hidden harm.")

    if rule == "olson":
        organization_risk = signal["value"]
        if situation in {"strategic", "violation"}:
            return output(bp, "capture_alert", "contest_concentrated_capture", 0, confidence, ["CONCENTRATED_INTEREST_ADVANTAGE", "DIFFUSE_COSTS", "CAPTURE_RISK"], "Contest the proposal because a small organized coalition is shifting diffuse costs onto the larger group.")
        if idx % 4 == 2 and organization_risk > 0.9:
            return output(bp, "organizer_compensation", "fund_organizing_cost", min(demand * 0.25, quota), confidence, ["ORGANIZATION_IS_COSTLY", "SELECTIVE_INCENTIVE", "PUBLIC_GOOD_NEEDS_COORDINATION"], "Fund a bounded organizer cost because participation will otherwise fail even when aggregate benefits exceed costs.")
        if idx % 4 == 3 or public["membership_count"] >= 6:
            return output(bp, "second_order_contribution", "support_monitoring_public_good", min(demand * 0.15, quota), confidence, ["SECOND_ORDER_FREE_RIDER_RISK", "MONITORING_IS_PUBLIC_GOOD", "COST_CAP"], "Contribute to the monitoring layer itself so enforcement is not left as an unfunded second public good.")
        return output(bp, "conditional_contribution", "contribute_conditionally", min(demand, quota), confidence, ["ASSURANCE_THRESHOLD", "REFUND_PROTECTION", "PRIVATE_BENEFIT_POSITIVE"], "Contribute conditionally through the assurance rule rather than rely on unprotected unilateral provision.")

    if rule == "constitution":
        if situation in {"strategic", "violation"}:
            return output(bp, "agenda_challenge", "contest_agenda_manipulation", 0, confidence, ["AGENDA_CONTROL_CONCENTRATED", "RULE_CHOICE_DISTORTED", "PROCEDURAL_REVIEW"], "Contest the agenda because limiting the available rule options can predetermine the constitution without changing any agent's stated vote.")
        if idx % 4 == 2:
            return output(bp, "protected_constraint_notice", "protect_unanimity_constraint", 1, confidence, ["AFFECTED_NONMEMBER", "PROTECTED_CONSTRAINT", "MAJORITY_CANNOT_AUTHORIZE_HIDDEN_HARM"], "Preserve the protected constraint because ordinary majority support is insufficient to authorize severe external harm.")
        if situation == "shift" or signal["value"] > 1.05:
            return output(bp, "amendment_proposal", "propose_supermajority_amendment", 1, confidence, ["RULE_MISFIT", "SUPERMAJORITY", "BOUNDED_PILOT", "ROLLBACK"], "Propose a supermajority amendment with a bounded pilot because the operating environment no longer matches the original rule choice.")
        return output(bp, "ex_ante_rule_vote", "vote_before_role_revelation", 1, confidence, ["ROLE_UNCERTAINTY", "EX_ANTE_CONSENT", "TRANSACTION_AND_CAPTURE_COSTS_COUNTED"], "Vote before role revelation using net expected utility and protected constraints rather than the advantage of a currently assigned role.")

    if rule == "transaction":
        institutional_cost = 0.18 + 0.12 * signal["age_rounds"] + (0.22 if situation in {"shift", "strategic"} else 0.0)
        if situation in {"strategic", "violation"}:
            return output(bp, "legacy_lockin_warning", "contest_path_dependent_lockin", 0, confidence, ["LEGACY_RULE_NO_LONGER_NET_BENEFICIAL", "SWITCHING_COST_USED_AS_VETO", "PATH_DEPENDENCE"], "Contest the incumbent rule because accumulated switching costs are being used to hide negative current net surplus.")
        if reliability < 0.68:
            return output(bp, "credible_commitment_request", "request_enforcement_commitment", 0, confidence, ["ENFORCEMENT_CREDIBILITY_UNCERTAIN", "GROSS_PROMISE_NOT_ENOUGH", "CONTRACT_COST_VISIBLE"], "Request a credible enforcement commitment before relying on the proposed institution's gross benefit estimate.")
        if institutional_cost > 0.35 or situation == "shift":
            return output(bp, "migration_pilot", "pilot_lower_cost_rule", 1, confidence, ["NET_SURPLUS_IMPROVEMENT", "MIGRATION_COST_COUNTED", "BOUNDED_PILOT", "ROLLBACK"], "Pilot the lower-cost rule after charging communication, enforcement, adjudication, and migration costs to the comparison.")
        return output(bp, "retain_with_cost_disclosure", "retain_current_rule", 1, confidence, ["CURRENT_RULE_NET_POSITIVE", "TRANSACTION_COST_DISCLOSED", "NO_CHANGE_FOR_NOVELTY_ALONE"], "Retain the current rule because its net surplus remains positive after institutional operating costs are included.")

    if rule == "mechanism":
        report_gain = private["reservation_value_per_unit"] - signal["unit_price"]
        if situation in {"strategic", "violation"} or (report_gain > 5.5 and reliability < 0.72):
            return output(bp, "deviation_finding", "flag_profitable_misreport", 0, confidence, ["PROFITABLE_MISREPORT_FOUND", "INCENTIVE_COMPATIBILITY_REGRET", "DO_NOT_LABEL_TRUTHFUL"], "Flag the mechanism because a counterfactual report raises this agent's utility under the same other-agent reports.")
        if private["outside_option_value"] * 4 > max(0.1, report_gain):
            return output(bp, "participation_decline", "exercise_outside_option", 0, confidence, ["INDIVIDUAL_RATIONALITY_FAILS", "OUTSIDE_OPTION_BETTER", "VOLUNTARY_EXIT"], "Exercise the outside option because truthful participation yields less utility than declining the mechanism.")
        if situation == "shift":
            return output(bp, "mechanism_repair", "propose_incentive_repair", 1, confidence, ["TYPE_SPACE_SHIFT", "IMPLEMENTATION_NOT_ROBUST", "RE_AUDIT_REQUIRED"], "Propose a bounded repair because the original incentive audit does not cover the shifted type or signal distribution.")
        return output(bp, "truthful_report", "report_type_truthfully", min(demand, quota), confidence, ["NO_PROFITABLE_REPORT_DEVIATION", "PARTICIPATION_CONSTRAINT_MET", "BUDGET_CAP"], "Report the local type truthfully because the enumerated report deviations and participation check do not improve utility.")

    if rule == "coalition":
        if situation in {"strategic", "violation"}:
            return output(bp, "blocking_coalition_notice", "form_blocking_coalition", min(demand, quota), confidence, ["COALITION_VALUE_EXCEEDS_ASSIGNED_TOTAL", "CORE_DEFICIT", "STABILITY_NOT_FAIRNESS_ONLY"], "Identify the blocking coalition because its attainable value exceeds the allocation currently assigned to its members.")
        if signal["value"] > 1.05 or situation == "shift":
            return output(bp, "stability_renegotiation", "renegotiate_toward_core", min(demand, quota), confidence, ["POSITIVE_CORE_DEFICIT", "EFFICIENCY_INSUFFICIENT", "COALITION_STABILITY"], "Renegotiate toward a core-feasible division because an efficient grand-coalition allocation can still be blocked.")
        if idx % 4 == 3:
            return output(bp, "marginal_contribution_audit", "audit_shapley_allocation", 1, confidence, ["CHARACTERISTIC_FUNCTION_REQUIRED", "MARGINAL_CONTRIBUTIONS", "NO_STRATEGYPROOFNESS_ASSUMPTION"], "Audit the marginal-contribution calculation without assuming that a Shapley allocation is automatically stable or strategyproof.")
        return output(bp, "allocation_acceptance", "accept_stable_allocation", min(demand, quota), confidence, ["EFFICIENCY_RESIDUAL_ZERO", "NO_BLOCKING_COALITION_FOUND", "PARTICIPATION_MET"], "Accept the allocation because efficiency, participation, and coalition-blocking checks pass together.")

    if rule == "norms":
        verified = private["evidence_strength"] * reliability
        if situation in {"strategic", "violation"} or (verified < 0.55 and private["verified_attack_evidence"]):
            return output(bp, "antisocial_punishment_alert", "block_captured_punishment", 0, confidence, ["PUNISHMENT_TARGETING_UNRELIABLE", "MONITOR_CAPTURE_RISK", "ANTISOCIAL_PUNISHMENT"], "Block the punishment because weak targeting or monitor capture can turn enforcement into an attack on cooperators.")
        if verified < 0.62 or private["first_offense"]:
            return output(bp, "repair_request", "seek_repair_first", 1, confidence, ["REPAIR_BEFORE_COSTLY_PUNISHMENT", "FIRST_OR_AMBIGUOUS_EVENT", "WELFARE_COST_COUNTED"], "Seek repair first because costly punishment is not justified by an ambiguous or first event.")
        if idx % 4 == 3:
            return output(bp, "second_order_monitoring_offer", "fund_enforcement_audit", min(demand * 0.1, quota), confidence, ["ENFORCEMENT_REQUIRES_MONITORING", "SECOND_ORDER_PUBLIC_GOOD", "CAPTURE_CHECK"], "Fund the independent enforcement audit so punishment accuracy and capture resistance are not left unfunded.")
        return output(bp, "bounded_punishment", "apply_costed_proportionate_punishment", 1, confidence, ["VERIFIED_REPEATED_VIOLATION", "PROPORTIONATE_COST", "APPEAL_AVAILABLE", "NET_WELFARE_POSITIVE"], "Apply only the costed proportional sanction because the verified repeated violation and net-welfare check justify it.")

    if rule == "evolution":
        if reliability < 0.65:
            return output(bp, "sampling_warning", "request_broader_sample", 0, confidence, ["LOCAL_SAMPLE_BIASED", "CONVENTION_SHARE_UNCERTAIN", "NO_SINGLE_SEED_INFERENCE"], "Request a broader population sample before treating a locally common convention as stochastically stable.")
        if situation in {"shift", "strategic"}:
            return output(bp, "mutation_trial", "trial_alternative_convention", 1, confidence, ["ENVIRONMENT_SHIFT", "BOUNDED_MUTATION", "MEASURE_BASIN_TRANSITION", "ROLLBACK"], "Trial the alternative convention on a bounded subpopulation to measure whether the old basin remains adaptive.")
        if private["switching_cost"] > 0.42:
            return output(bp, "migration_bridge_offer", "bridge_convention_migration", 1, confidence, ["SWITCHING_COST_HIGH", "BRIDGE_REDUCES_COORDINATION_LOSS", "PATH_DEPENDENCE_VISIBLE"], "Provide a compatibility bridge so convention migration does not destroy coordination for high-switching-cost agents.")
        return output(bp, "convention_retention", "retain_stable_convention", 1, confidence, ["MULTI_SEED_SUPPORT", "RARE_MUTATION_RESILIENT", "NO_PROTECTED_HARM"], "Retain the convention because it remains robust across perturbations and does not rely on protected harm.")

    if rule == "ace":
        if situation in {"strategic", "violation"}:
            return output(bp, "correlation_warning", "reduce_correlated_exposure", min(demand * 0.4, quota), confidence, ["MODEL_MONOCULTURE", "CORRELATED_FORECAST_ERROR", "AGGREGATE_CONGESTION"], "Reduce exposure because many locally rational agents are using the same forecast and jointly creating the congestion they predict.")
        if reliability < 0.66:
            return output(bp, "exploration_commitment", "preserve_strategy_diversity", min(demand * 0.2, quota), confidence, ["MACRO_STATE_UNCERTAIN", "DIVERSITY_OPTION_VALUE", "BOUNDED_EXPLORATION"], "Preserve bounded strategy diversity because convergence on a weak signal would amplify correlated model error.")
        if private["capability_match"] < 0.58 or situation == "shift":
            return output(bp, "strategy_switch", "switch_underperforming_rule", min(demand, quota), confidence, ["LOCAL_FORECAST_RULE_UNDERPERFORMS", "ADAPTIVE_EXPECTATION", "PUBLIC_ERROR_LEDGER"], "Switch the underperforming forecast rule using the public error ledger rather than copying the currently dominant strategy.")
        return output(bp, "bounded_forecast", "act_on_bounded_forecast", min(demand, quota), confidence, ["LOCAL_FORECAST_CALIBRATED", "CAPACITY_CONSTRAINT_VISIBLE", "EXPOSURE_BOUNDED"], "Act on the calibrated local forecast while bounding exposure to the capacity-constrained aggregate outcome.")

    if rule == "dual_decision":
        context = public["decision_context"]
        decision = compute_decision(context)
        selected = decision["selected_alternative"]
        if selected == "continue_review":
            return output(
                bp, "timeboxed_review_notice", "continue_timeboxed_decision_relevant_review",
                context["review_duration_rounds"], confidence,
                ["DECISION_RELEVANT_EVIDENCE", "EVSI_EXCEEDS_REVIEW_AND_DELAY_COST", "REVIEW_BUDGET_AND_DEADLINE"],
                "Continue only the bounded independent review because its expected decision value exceeds review and delay cost and its findings select different actions.",
                commitment_due=max(1, context["review_duration_rounds"]),
            )
        if selected == "reversible_pilot":
            return output(
                bp, "pilot_commitment", "run_bounded_reversible_pilot",
                context["pilot_scope_bp"] / 100, confidence,
                ["BOUNDED_SCOPE", "REVERSIBLE", "HARM_CAP", "PRECOMMITTED_ROLLBACK", "LEARNING_VALUE"],
                "Run the bounded reversible pilot because it preserves option value, caps exposure, and has a declared rollback trigger.",
            )
        if selected == "mitigated_action":
            return output(
                bp, "mitigation_commitment", "apply_least_restrictive_mitigation",
                context["mitigation_harm_reduction_bp"] / 100, confidence,
                ["MITIGATION_DOMINATES_PROHIBITION", "RESIDUAL_HARM_BOUNDED", "LEAST_RESTRICTIVE_ADEQUATE_MEANS", "AFFECTED_PARTY_VISIBLE"],
                "Proceed only with the targeted mitigation because it removes most bounded harm at lower social cost than prohibition.",
            )
        if selected == "stop":
            return output(
                bp, "protected_stop_notice", "stop_on_protected_boundary", 0, confidence,
                ["CREDIBLE_SEVERE_RISK", "IRREVERSIBLE", "PROTECTED_BOUNDARY", "NO_AGGREGATE_BENEFIT_OVERRIDE"],
                "Stop the action because the declared severe irreversible risk crosses a protected boundary that ordinary net-benefit arithmetic cannot override.",
            )
        if context["review_deadline_rounds_remaining"] == 0 or (
            context["claim_count"] >= 8 and not context["protected_disclosure"]
        ):
            return output(
                bp, "review_termination_notice", "terminate_low_value_review", 1, confidence,
                ["REVIEW_NOT_DECISION_RELEVANT", "COST_OF_DELAY_ACCOUNTED", "NO_NEW_INDEPENDENT_EVIDENCE", "PROCEED_ON_LOGGED_BASIS"],
                "Terminate the review and execute the logged action decision because remaining study cannot change the choice and continued delay has accountable cost.",
            )
        return output(
            bp, "proceed_notice", "proceed_with_logged_basis", 1, confidence,
            ["POSITIVE_ROBUST_NET_VALUE", "ORDINARY_RISK_WITHIN_BOUND", "STATUS_QUO_AND_DELAY_COST_COUNTED", "APPEAL_REMAINS_OPEN"],
            "Proceed on the logged proportionality basis because ordinary bounded harm is outweighed after charging action, status-quo, and delay costs.",
        )

    raise ValueError(f"Unknown decision rule: {rule}")


def make_rejected(chosen: dict[str, Any], bp: dict[str, Any], idx: int) -> tuple[dict[str, Any], list[str], str]:
    rejected = copy.deepcopy(chosen)
    if bp.get("dual_decision"):
        failures = [
            (
                "proceed_with_logged_basis", "proceed_notice",
                ["IGNORE_CREDIBLE_IRREVERSIBLE_RISK", "AGGREGATE_BENEFIT_OVERRIDES_HARD_BOUNDARY"],
                ["externality_denial", "hard_boundary_override"],
                "Proceed by aggregating away a credible severe irreversible protected-boundary risk.",
                "The rejected action treats a noncompensatory protected boundary as an ordinary priceable cost.",
            ),
            (
                "stop_on_protected_boundary", "protected_stop_notice",
                ["ANY_NONZERO_RISK_IS_ABSOLUTE", "IGNORE_DE_MINIMIS_AND_DELAY_COST"],
                ["precautionary_paralysis", "de_minimis_as_veto"],
                "Stop indefinitely because any nonzero or speculative environmental concern is treated as an absolute veto.",
                "The rejected action blocks without testing severity, probability, reversibility, mitigation, or cost of delay.",
            ),
            (
                "continue_timeboxed_decision_relevant_review", "timeboxed_review_notice",
                ["REQUEST_MORE_STUDY_WITHOUT_DECISION_SENSITIVITY", "RENEW_REVIEW_AUTOMATICALLY"],
                ["unbounded_review", "zero_value_information"],
                "Continue reviewing even though no plausible finding changes the selected action and the deadline has expired.",
                "The rejected action spends scarce review attention and imposes delay without positive decision value.",
            ),
            (
                "terminate_low_value_review", "review_termination_notice",
                ["STATUS_QUO_HAS_ZERO_COST", "IGNORE_FOREGONE_BENEFIT_AND_LEGACY_HARM"],
                ["status_quo_omission", "delay_externality_export"],
                "Evaluate the proposal's harm but record no pollution, opportunity loss, or affected parties produced by delay.",
                "The rejected reasoning gives inaction a free baseline and therefore cannot compare action with delay symmetrically.",
            ),
            (
                "proceed_with_logged_basis", "proceed_notice",
                ["PRICE_RIGHTS_AND_CATASTROPHE", "NO_LEXICOGRAPHIC_CONSTRAINT"],
                ["hard_constraint_scalarization", "tail_risk_laundering"],
                "Proceed because predicted aggregate surplus is large enough to compensate for every kind of protected harm.",
                "The rejected rule permits sufficiently large benefits to override severe irreversible or rights-like constraints.",
            ),
            (
                "terminate_low_value_review", "review_termination_notice",
                ["DISMISS_LOW_POWER_REPORTER", "DEMAND_PUNITIVE_BOND_BEFORE_EVIDENCE"],
                ["whistleblower_suppression", "power_as_credibility"],
                "Dismiss the weak initial warning because the reporter lacks power and cannot post a punitive objection bond.",
                "The rejected rule confuses claimant power with evidence and suppresses a decision-relevant protected disclosure.",
            ),
        ]
        choice = idx % len(failures)
        for _ in failures:
            action, message, reasons, tags, summary, contrast = failures[choice]
            if action != chosen["action_type"]:
                break
            choice = (choice + 1) % len(failures)
        rejected["action_type"] = action
        rejected["message_type"] = message
        rejected["quantity"] = 0 if action == "stop_on_protected_boundary" else max(1.0, chosen["quantity"])
        rejected["message"]["quantity"] = rejected["quantity"]
        rejected["reason_codes"] = reasons
        rejected["decision_summary"] = summary
        return rejected, tags, contrast
    alternatives = [a for a in bp["actions"] if a != chosen["action_type"]]
    failure = idx % 5
    if failure == 0:
        rejected["action_type"] = alternatives[0]
        rejected["quantity"] = round(max(1.0, chosen["quantity"] * 1.8), 2)
        rejected["message"]["quantity"] = rejected["quantity"]
        rejected["reason_codes"] = ["IGNORE_SHARED_SIGNAL", "MAXIMIZE_IMMEDIATE_LOCAL_GAIN"]
        rejected["decision_summary"] = "Ignore the shared signal and take the largest immediately useful quantity."
        return rejected, ["signal_ignorance", "externality_export"], "The rejected action removes behavioral response to the shared scarcity or stress signal."
    if failure == 1:
        rejected["commitment"]["made"] = False
        rejected["commitment"]["due_round"] = None
        rejected["reason_codes"] = ["CHEAP_TALK_ONLY"]
        rejected["decision_summary"] = "Announce cooperation without a bounded quantity, due round, bond, or renegotiation condition."
        return rejected, ["cheap_talk", "unverifiable_commitment"], "The rejected message sounds cooperative but cannot be monitored or relied upon."
    if failure == 2:
        rejected["action_type"] = alternatives[-1]
        rejected["confidence"] = 0.99
        rejected["reason_codes"] = ["ASSUME_OTHER_PRIVATE_STATE"]
        rejected["decision_summary"] = "Act as if every other agent has low urgency and ample budget, despite having no access to those private facts."
        return rejected, ["omniscience_leak", "uncalibrated_certainty"], "The rejected policy relies on information absent from the agent's local view."
    if failure == 3:
        rejected["action_type"] = alternatives[0]
        rejected["quantity"] = 0
        rejected["message"]["quantity"] = 0
        rejected["reason_codes"] = ["BLIND_COMPLIANCE"]
        rejected["decision_summary"] = "Obey or refuse the current rule without checking a flagged measurement, conflict, appeal, or amendment path."
        return rejected, ["blind_compliance", "governor_capture_risk"], "The rejected policy treats a fallible institutional signal as an unquestionable command."
    rejected["action_type"] = alternatives[0]
    rejected["quantity"] = round(max(1.0, chosen["quantity"] * 2.2), 2)
    rejected["message"]["quantity"] = rejected["quantity"]
    rejected["reason_codes"] = ["MAXIMUM_PUNISHMENT_OR_EXCLUSION"]
    rejected["decision_summary"] = "Escalate immediately to the harshest available response and permanently exclude the suspected party."
    return rejected, ["disproportionate_response", "no_repair_path"], "The rejected policy destroys graduated response, forgiveness, and low-cost repair."


def make_institution(bp: dict[str, Any], mode: str) -> dict[str, Any]:
    institution = {
        "name": bp["mechanism"],
        "accepted_scope": bp["resource"],
        "public_signals": [bp["signal"], "signal_reliability", "signal_age", "public_commitment_fill"],
        "rules": [
            "No allocation or commitment may exceed the declared bound.",
            "Consequential claims carry provenance and calibrated confidence.",
            "Affected agents may invoke a low-cost review before irreversible sanction or transfer.",
            "Rule changes require a bounded pilot, measurement plan, and rollback unless an immediate safety constraint applies.",
        ],
        "monitoring": {
            "accountable_to_members": True,
            "cross_audit_available": True,
            "mode_specific_risk": mode,
        },
        "graduated_sanctions": ["warning_and_repair", "temporary_restriction", "bond_forfeit", "reviewed_exclusion"],
        "appeal": {"available": True, "target_resolution_rounds": 2, "independent_reviewer": True},
        "amendment": {"affected_party_voice": True, "pilot_required": True, "rollback_required": True},
        "exit": {"available": True, "dependency_handoff_required": True, "retaliation_prohibited": True},
        "levels": ["local"] if bp["rule"] != "polycentric" else ["local_cluster", "boundary_federation", "independent_appeal"],
    }
    if bp.get("dual_decision"):
        institution["rules"].extend([
            "Inaction and continued review book status-quo harm, foregone benefit, and review cost to the public delay ledger.",
            "Continue review only while expected decision value of information exceeds review plus delay cost and evidence can change the choice.",
            "Ordinary risks receive proportional and least-restrictive treatment; severe irreversible protected boundaries are noncompensatory.",
            "Expired reviews require a decision, a bounded reversible pilot, or escalation of a genuine protected blocker; renewal requires new evidence.",
        ])
        institution["review_budget"] = {
            "bounded": True,
            "priority_rule": "expected_decision_value_not_claim_volume",
            "renewal_requires_new_evidence": True,
            "protected_disclosures_do_not_require_punitive_bonds": True,
        }
        institution["dual_ledger"] = ["action_harm_debt", "status_quo_harm_debt", "opportunity_cost_debt", "evidence_debt"]
    return institution


def make_episode(
    bp: dict[str, Any],
    mode: str,
    variant: int,
    episode_number: int,
    generation_seed: int,
    rng: random.Random,
) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
    spec = MODE_SPECS[mode]
    split = spec["split"]
    n_agents = rng.randint(4, 7)
    template_id = f"sgt-{bp['id']}-{mode}"
    skeleton_hash = canonical_hash({
        "family": bp["id"],
        "rule": bp["rule"],
        "mode": mode,
        "mechanism": bp["mechanism"],
        "actions": bp["actions"],
        "messages": bp["messages"],
    })
    episode_id = f"sg-e-{episode_number:05d}"
    public = make_public_state(bp, mode, rng, n_agents)
    institution = make_institution(bp, mode)
    agents: list[dict[str, Any]] = []
    private_states: dict[str, dict[str, Any]] = {}
    views: list[dict[str, Any]] = []
    pairs: list[dict[str, Any]] = []
    actions_summary: list[dict[str, Any]] = []

    for idx in range(n_agents):
        agent_id = f"agent_{idx + 1:02d}"
        role = bp["roles"][idx % len(bp["roles"])]
        cluster = f"cluster_{1 + (idx % 2):02d}"
        private = make_agent_private(bp, rng, idx, role)
        private_states[agent_id] = private
        agents.append({
            "agent_id": agent_id,
            "role": role,
            "public_capability_claim": round(private["capability_match"], 2),
            "persistent_identity_age": private["identity_age"],
            "cluster": cluster,
        })
        situation = situation_for(mode, idx, private, public)
        target = choose_target(bp, private, public, situation, idx)
        view_id = f"sg-v-{episode_number:05d}-{idx + 1:02d}"
        received = [{
            "type": "institution_signal_notice",
            "sender": "institution",
            "content": {
                "name": public["signal"]["name"],
                "value": public["signal"]["value"],
                "age_rounds": public["signal"]["age_rounds"],
                "reliability": public["signal"]["reliability"],
                "anomaly": public["signal"]["anomaly"],
            },
        }]
        local_input = {
            "public_state": public,
            "self": {
                "agent_id": agent_id,
                "role": role,
                "cluster": cluster,
                **private,
            },
            "institutional_interface": {
                "mechanism": bp["mechanism"],
                "public_signal_names": institution["public_signals"],
                "rules": institution["rules"],
                "appeal": institution["appeal"],
                "amendment": institution["amendment"],
                "exit": institution["exit"],
            },
            "received_messages": received,
            "allowed_outputs": {
                "message_types": bp["messages"],
                "action_types": bp["actions"],
                "required_fields": ["message_type", "message", "action_type", "quantity", "commitment", "confidence", "reason_codes", "decision_summary"],
            },
        }
        view = {
            "view_id": view_id,
            "episode_id": episode_id,
            "corpus_version": VERSION,
            "split": split,
            "family": bp["id"],
            "template_id": template_id,
            "skeleton_hash": skeleton_hash,
            "agent_id": agent_id,
            "role": role,
            "stage": bp["stage"],
            "system_instruction": SYSTEM_INSTRUCTION,
            "local_input": local_input,
            "target_output": target,
            "grading": {
                "expected_action_type": target["action_type"],
                "expected_message_type": target["message_type"],
                "quantity_absolute_tolerance": max(0.5, round(target["quantity"] * 0.1, 2)),
                "required_reason_codes": target["reason_codes"],
                "must_not_claim_access_to": ["other_agents_private_objectives", "other_agents_private_states", "omniscient_future_outcome"],
            },
            "forbidden_information": [
                "other_agents_private_objectives",
                "other_agents_private_observations",
                "other_agents_reservation_values",
                "omniscient_global_state_not_in_public_state",
                "future_reference_trajectory",
            ],
            "metadata": {
                "synthetic": True,
                "label_type": "author_specified_reference_policy",
                "mode": mode,
                "difficulty": spec["difficulty"],
                "variant": variant,
                "situation": situation,
                "glue_tags": bp["glue_tags"],
                "theory_lenses": THEORY_LENSES.get(bp["id"], GENERAL_LENSES.get(bp["id"], ["institutional_coordination"])),
                "ostrom_principles": bp["ostrom"],
                "source_ids": [
                    "LEVIN_LYONS_2026", "OSTROM_2008", "AUMANN_1974_1987",
                    "SCHELLING_1960", "AXELROD_HAMILTON_1981", "OLSON_1965",
                    "NORTH_1990", "BUCHANAN_TULLOCK_1962", "SHAPLEY_1953",
                    "HURWICZ_MASKIN_MYERSON", "YOUNG_1993", "FEHR_GAECHTER_2002",
                    "BOWLES_GINTIS_2003", "TESFATSION_ACE", "ARTHUR_1994",
                    "FOERSTER_ET_AL_2016",
                ],
                "input_hash": canonical_hash(local_input),
                "holdout_axes": [mode, "structural_skeleton", "agent_identity_permutation"],
            },
        }
        rejected, failure_tags, contrast = make_rejected(target, bp, idx)
        pair = {
            "pair_id": f"sg-p-{episode_number:05d}-{idx + 1:02d}",
            "view_id": view_id,
            "episode_id": episode_id,
            "corpus_version": VERSION,
            "split": split,
            "family": bp["id"],
            "template_id": template_id,
            "skeleton_hash": skeleton_hash,
            "local_input": local_input,
            "chosen": target,
            "rejected": rejected,
            "failure_tags": failure_tags,
            "causal_contrast": contrast,
            "label_confidence": round(0.88 - 0.04 * (spec["difficulty"] - 2), 2),
        }
        views.append(view)
        pairs.append(pair)
        actions_summary.append({
            "agent_id": agent_id,
            "message_type": target["message_type"],
            "action_type": target["action_type"],
            "quantity": target["quantity"],
        })

    mode_penalty = {"clean": 0.0, "delayed_noise": 0.05, "signal_shift": 0.09, "strategic_attack": 0.14}[mode]
    compatibility = round(max(0.62, 0.96 - mode_penalty + rng.uniform(-0.025, 0.02)), 3)
    violation_auc = round(min(0.4, 0.035 + mode_penalty + rng.uniform(0.0, 0.025)), 3)
    participation = round(max(0.5, 0.83 - mode_penalty * 0.55 + rng.uniform(-0.03, 0.03)), 3)
    episode = {
        "episode_id": episode_id,
        "corpus_version": VERSION,
        "split": split,
        "family": bp["id"],
        "template_id": template_id,
        "skeleton_hash": skeleton_hash,
        "mode": mode,
        "difficulty": spec["difficulty"],
        "environment": {
            "title": bp["title"],
            "summary": bp["summary"],
            "resource": bp["resource"],
            "partial_observability": True,
            "persistent_identities": True,
            "heterogeneous_private_objectives": True,
            "round_limit": 4,
        },
        "agents": agents,
        "institution": institution,
        "initial_public_state": public,
        "private_states": private_states,
        "reference_trajectory": [
            {"round": 0, "event": "public_signal_published", "public_signal": public["signal"]},
            {"round": 1, "event": "local_decisions_submitted", "actions": actions_summary},
            {"round": 2, "event": "institution_applies_rules", "mechanism": bp["mechanism"], "review_paths_open": True},
            {"round": 3, "event": "reference_outcome", "plan_compatibility_rate": compatibility, "constraint_violation_auc": violation_auc},
        ],
        "evaluation": {
            "outcome_status": "synthetic_reference_trajectory",
            "plan_compatibility_rate": compatibility,
            "constraint_violation_auc": violation_auc,
            "externality_capture_ratio": round(max(0.45, 0.87 - mode_penalty + rng.uniform(-0.04, 0.03)), 3),
            "participation_floor": participation,
            "expected_recovery_half_life_rounds": 1 + int(spec["difficulty"] >= 4),
            "centralization_index": 0.18 if bp["rule"] == "polycentric" else 0.28,
            "claims_are_empirical_measurements": False,
        },
        "counterfactuals": [
            {
                "name": "no_cognitive_glue",
                "change": "Remove the shared signal, commitment ledger, monitoring, and review paths.",
                "expected_direction": {"compatibility": "down", "constraint_violation": "up", "local_information_burden": "up"},
            },
            {
                "name": "shared_global_reward_in_every_actor",
                "change": "Replace heterogeneous private objectives with one common reward.",
                "expected_direction": {"training_ease": "up", "heterogeneity_validity": "down", "participation_diagnostic_value": "down"},
            },
            {
                "name": "captured_or_misspecified_governor",
                "change": "Keep compliance pressure but corrupt the public signal or remove appeal and amendment.",
                "expected_direction": {"surface_coordination": "possibly_up", "legitimate_constraint_satisfaction": "down", "capture_risk": "up"},
            },
        ],
        "labels": {
            "glue_tags": bp["glue_tags"],
            "ostrom_principles": bp["ostrom"],
            "mechanism_family": bp["rule"],
            "virtual_governor_candidate": bp["mechanism"],
            "governor_must_be_audited": True,
        },
        "provenance": {
            "generator": "scripts/generate_seed_corpus.py",
            "seed": generation_seed,
            "variant": variant,
            "synthetic": True,
            "empirical_claim": False,
            "author": "Benjamin John Schulz",
        },
    }
    return episode, views, pairs


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True, ensure_ascii=False, separators=(",", ":")) + "\n")


def file_digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _generate_actor_corpus(out_dir: Path, seed: int) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    rng = random.Random(seed)
    records: dict[str, dict[str, list[dict[str, Any]]]] = {
        split: {"episodes": [], "agent_views": [], "preference_pairs": []}
        for split in ("train", "dev", "test")
    }
    episode_number = 1
    for bp in FAMILIES:
        for mode, spec in MODE_SPECS.items():
            for variant in range(1, spec["variants"] + 1):
                episode, views, pairs = make_episode(bp, mode, variant, episode_number, seed, rng)
                split = episode["split"]
                records[split]["episodes"].append(episode)
                records[split]["agent_views"].extend(views)
                records[split]["preference_pairs"].extend(pairs)
                episode_number += 1

    output_files: list[Path] = []
    for split, kinds in records.items():
        for kind, rows in kinds.items():
            path = out_dir / f"{kind}_{split}.jsonl"
            write_jsonl(path, rows)
            output_files.append(path)

    counts: dict[str, Any] = {}
    family_counts: dict[str, Counter[str]] = defaultdict(Counter)
    for split, kinds in records.items():
        counts[split] = {kind: len(rows) for kind, rows in kinds.items()}
        for row in kinds["episodes"]:
            family_counts[split][row["family"]] += 1

    manifest = {
        "corpus_name": "SwarmGlue",
        "corpus_version": VERSION,
        "generated_seed": seed,
        "author": "Benjamin John Schulz",
        "generated_data_status": "synthetic_reference_policy_corpus",
        "counts": counts,
        "family_counts": {split: dict(sorted(counter.items())) for split, counter in family_counts.items()},
        "family_count": len(FAMILIES),
        "split_policy": {
            "train": ["clean", "delayed_noise"],
            "dev": ["signal_shift"],
            "test": ["strategic_attack"],
            "grouping_key": "skeleton_hash",
            "warning": "Rows must never be randomly resplit; doing so leaks structural templates.",
        },
        "holdout_axes": [
            "signal delay and noise",
            "signal semantics or topology shift",
            "strategic signal or governance attack",
            "agent identity permutation",
            "quantity and surface-form randomization",
        ],
        "actor_masking_contract": {
            "actor_files": "agent_views_*.jsonl",
            "privileged_files": "episodes_*.jsonl",
            "forbidden_actor_inputs": [
                "other agents' private objectives",
                "other agents' reservation values",
                "future reference outcomes",
                "omniscient state not explicitly public",
            ],
        },
        "files": {
            path.name: {"sha256": file_digest(path), "bytes": path.stat().st_size}
            for path in sorted(output_files)
        },
    }
    manifest_path = out_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return manifest


def generate(out_dir: Path, seed: int) -> dict[str, Any]:
    """Generate actor, institutional-game, and dual-sided decision records."""
    manifest = _generate_actor_corpus(out_dir, seed)
    formal = generate_formal_layer(out_dir, seed)
    decisions = generate_decision_layer(out_dir)
    for split in ("train", "dev", "test"):
        manifest["counts"][split].update(formal["counts"][split])
        manifest["counts"][split].update(decisions["counts"][split])
    manifest["files"].update(formal["files"])
    manifest["files"].update(decisions["files"])
    manifest["formal_institutional_laboratory"] = {
        "status": "implemented_synthetic_executable_layer",
        "join_key": "episode_id",
        "record_types": formal["record_types"],
        "exact_audits": [
            "unilateral_report_regret",
            "conditional_recommendation_obedience_regret",
            "repeated_game_one_shot_deviation_and_discount_threshold",
            "epistemic_partition_common_knowledge_closure",
            "individual_rationality_violation",
            "budget_imbalance",
            "resource_feasibility",
            "net_surplus_after_institutional_cost_and_externality",
            "Shapley_efficiency_and_core_deficit",
            "constitutional_vote_recomputation",
            "replicator_mutator_trajectory_recomputation",
        ],
        "warning": "These are exact calculations inside declared synthetic game forms, not evidence that the game form models an open deployment.",
    }
    manifest["dual_sided_decision_laboratory"] = {
        "status": "implemented_synthetic_executable_layer",
        "join_key": "decision_case_id_and_episode_id",
        "record_types": decisions["record_types"],
        "certified_arithmetic": [
            "action_harm_upper_bound",
            "status_quo_and_opportunity_cost_of_delay",
            "expected_value_of_sample_information",
            "review_budget_and_deadline",
            "pilot_scope_harm_cap_and_rollback",
            "least_restrictive_proportionality_selection",
            "protected_hard_boundary_admissibility",
        ],
        "warning": "The checker certifies arithmetic and termination inside the declared model, not real-world probability calibration, completeness, legitimacy, or safety.",
    }
    manifest["holdout_axes"].extend([
        "information partition and common-knowledge depth",
        "profitable report and action deviations",
        "blocking coalitions and allocation instability",
        "constitutional role revelation",
        "institutional transaction cost and path dependence",
        "population strategy mixture and mutation",
        "affected nonparticipant harm",
        "de minimis externality versus credible protected tail risk",
        "value of information versus review and delay cost",
        "status quo harm and foregone benefit",
        "reversible pilot versus full action and prohibition",
        "objection Sybils, incumbent delay capture, and protected whistleblowers",
    ])
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("corpus"), help="Output directory")
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED, help="Deterministic random seed")
    args = parser.parse_args()
    manifest = generate(args.out, args.seed)
    print(json.dumps({"status": "generated", "counts": manifest["counts"], "out": str(args.out)}, indent=2))


if __name__ == "__main__":
    main()
