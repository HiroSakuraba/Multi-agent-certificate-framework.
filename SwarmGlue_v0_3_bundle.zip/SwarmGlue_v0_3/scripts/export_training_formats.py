#!/usr/bin/env python3
"""Export SwarmGlue actor views to generic chat-SFT and preference JSONL."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def rows(path: Path):
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


def compact(value: Any) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def export_sft(views: Path, destination: Path) -> int:
    count = 0
    with destination.open("w", encoding="utf-8", newline="\n") as out:
        for view in rows(views):
            record = {
                "messages": [
                    {"role": "system", "content": view["system_instruction"]},
                    {"role": "user", "content": compact(view["local_input"])},
                    {"role": "assistant", "content": compact(view["target_output"])},
                ],
                "metadata": {
                    "view_id": view["view_id"],
                    "family": view["family"],
                    "template_id": view["template_id"],
                    "skeleton_hash": view["skeleton_hash"],
                    "stage": view["stage"],
                    "mode": view["metadata"]["mode"],
                    "label_type": view["metadata"]["label_type"],
                },
            }
            out.write(compact(record) + "\n")
            count += 1
    return count


def export_preferences(pairs: Path, destination: Path) -> int:
    count = 0
    with destination.open("w", encoding="utf-8", newline="\n") as out:
        for pair in rows(pairs):
            record = {
                "prompt": compact(pair["local_input"]),
                "chosen": compact(pair["chosen"]),
                "rejected": compact(pair["rejected"]),
                "metadata": {
                    "pair_id": pair["pair_id"],
                    "view_id": pair["view_id"],
                    "family": pair["family"],
                    "template_id": pair["template_id"],
                    "skeleton_hash": pair["skeleton_hash"],
                    "failure_tags": pair["failure_tags"],
                    "causal_contrast": pair["causal_contrast"],
                    "label_confidence": pair["label_confidence"],
                },
            }
            out.write(compact(record) + "\n")
            count += 1
    return count


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--views", type=Path, required=True)
    parser.add_argument("--pairs", type=Path, required=True)
    parser.add_argument("--sft-out", type=Path, required=True)
    parser.add_argument("--preference-out", type=Path, required=True)
    args = parser.parse_args()
    sft_count = export_sft(args.views, args.sft_out)
    preference_count = export_preferences(args.pairs, args.preference_out)
    print(json.dumps({
        "status": "exported",
        "sft_records": sft_count,
        "preference_records": preference_count,
        "sft_out": str(args.sft_out),
        "preference_out": str(args.preference_out),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
