#!/usr/bin/env python3
"""Export exact SwarmGlue formal records as generic chat-SFT tasks."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


SYSTEM = (
    "You are an institutional game auditor. Use only the declared synthetic game primitives. "
    "Recompute the requested quantities exactly, identify failures rather than repairing labels, "
    "charge both action harm and delay/status-quo harm, preserve noncompensatory protected boundaries, "
    "and do not infer facts about an undeclared deployment. Return compact JSON."
)


def rows(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def compact(value: Any) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def task(task_type: str, task_id: str, prompt: dict[str, Any], answer: dict[str, Any], metadata: dict[str, Any]) -> dict[str, Any]:
    return {
        "messages": [
            {"role": "system", "content": SYSTEM},
            {"role": "user", "content": compact({"task_type": task_type, "input": prompt})},
            {"role": "assistant", "content": compact(answer)},
        ],
        "metadata": {"task_type": task_type, "task_id": task_id, **metadata},
    }


def export(corpus: Path, split: str, out: Path) -> dict[str, int]:
    games = {row["game_id"]: row for row in rows(corpus / f"game_specs_{split}.jsonl")}
    records: list[dict[str, Any]] = []
    counts: dict[str, int] = {}

    audits = rows(corpus / f"mechanism_audits_{split}.jsonl")
    for audit in audits:
        game = games[audit["game_id"]]
        records.append(task(
            "mechanism_audit",
            audit["audit_id"],
            game,
            {key: audit[key] for key in (
                "truthfulness_audit", "participation_audit", "correlated_obedience_audit",
                "budget_audit", "feasibility_audit", "efficiency_audit",
                "repeated_game_audit",
                "maximum_incentive_compatibility_regret", "maximum_individual_rationality_violation",
                "maximum_correlated_obedience_regret", "audit_status",
            )},
            {"game_id": game["game_id"], "family": game["family"], "split": split},
        ))
    counts["mechanism_audit"] = len(audits)

    coalitions = rows(corpus / f"coalition_cases_{split}.jsonl")
    for row in coalitions:
        prompt = {key: row[key] for key in ("players", "characteristic_function", "allocation_method")}
        answer = {key: row[key] for key in ("allocation", "efficiency_residual", "core_deficit", "blocking_coalition", "is_in_core")}
        records.append(task("coalition_audit", row["coalition_case_id"], prompt, answer, {"game_id": row["game_id"], "family": row["family"], "split": split}))
    counts["coalition_audit"] = len(coalitions)

    constitutions = rows(corpus / f"constitutional_choices_{split}.jsonl")
    for row in constitutions:
        prompt = {key: row[key] for key in (
            "participants", "rule_options", "transaction_costs", "capture_risks", "ex_ante_utilities",
            "ex_post_role_revealed_utilities", "selection_rule",
        )}
        answer = {key: row[key] for key in ("ex_ante_votes", "selected_rule", "ex_ante_consent_rate", "ex_post_preference_reversal_rate")}
        records.append(task("constitutional_choice", row["constitutional_choice_id"], prompt, answer, {"game_id": row["game_id"], "family": row["family"], "split": split}))
    counts["constitutional_choice"] = len(constitutions)

    populations = rows(corpus / f"population_rollouts_{split}.jsonl")
    for row in populations:
        prompt = {key: row[key] for key in ("model", "initial_strategy_shares", "parameters", "generations")}
        answer = {key: row[key] for key in ("trajectory", "final_cooperation_rate", "final_net_welfare", "cooperation_retention_from_peak")}
        records.append(task("population_rollout", row["population_rollout_id"], prompt, answer, {"game_id": row["game_id"], "family": row["family"], "split": split}))
    counts["population_rollout"] = len(populations)

    epistemic = rows(corpus / f"epistemic_cases_{split}.jsonl")
    for row in epistemic:
        prompt = {key: row[key] for key in (
            "worlds", "actual_world", "event", "agents", "information_partitions",
            "public_announcement_history", "public_claimed_mutual_knowledge_depth",
        )}
        answer = {key: row[key] for key in ("computed_analysis", "false_common_knowledge_claim", "safe_reference_response")}
        records.append(task("epistemic_partition_audit", row["epistemic_case_id"], prompt, answer, {"game_id": row["game_id"], "family": row["family"], "split": split}))
    counts["epistemic_partition_audit"] = len(epistemic)

    affected = rows(corpus / f"affected_party_views_{split}.jsonl")
    for row in affected:
        prompt = {key: row[key] for key in ("relationship", "observable_effects", "protected_constraint", "procedural_access")}
        answer = {"protection_status": row["protection_status"], "training_use": row["training_use"]}
        records.append(task("affected_party_audit", row["affected_party_view_id"], prompt, answer, {"game_id": row["game_id"], "family": row["family"], "split": split}))
    counts["affected_party_audit"] = len(affected)

    decision_cases = rows(corpus / f"decision_cases_{split}.jsonl")
    cases_by_id = {row["decision_case_id"]: row for row in decision_cases}
    for row in decision_cases:
        prompt = {"declared_context": row["declared_context"], "candidate_alternatives": row["candidate_alternatives"]}
        answer = {key: row[key] for key in (
            "selected_alternative", "selected_robust_net_value_units", "hard_boundary_active",
            "certificate_backplane", "certification_scope",
        )}
        records.append(task("dual_decision_case", row["decision_case_id"], prompt, answer, {"game_id": row["game_id"], "family": row["family"], "split": split}))
    counts["dual_decision_case"] = len(decision_cases)

    risk_claims = rows(corpus / f"risk_claims_{split}.jsonl")
    for row in risk_claims:
        case = cases_by_id[row["decision_case_id"]]
        prompt = {
            "declared_context": case["declared_context"],
            "causal_chain": row["causal_chain"],
            "affected_parties": row["affected_parties"],
            "evidence": row["evidence"],
            "claimant_incentives": row["claimant_incentives"],
        }
        answer = {key: row[key] for key in ("claim_class", "expected_harm_upper_bound_units", "burden_of_proof", "admission_lane")}
        records.append(task("risk_claim_admission", row["risk_claim_id"], prompt, answer, {"game_id": row["game_id"], "family": row["family"], "split": split}))
    counts["risk_claim_admission"] = len(risk_claims)

    delays = rows(corpus / f"delay_ledgers_{split}.jsonl")
    for row in delays:
        case = cases_by_id[row["decision_case_id"]]
        prompt = {"declared_context": case["declared_context"]}
        answer = {key: row[key] for key in (
            "review_delay_cost_units", "total_review_burden_units",
            "stop_status_quo_and_opportunity_cost_units", "accountable_beneficiaries_of_delay", "ledger_rule",
        )}
        records.append(task("delay_ledger_audit", row["delay_ledger_id"], prompt, answer, {"game_id": row["game_id"], "family": row["family"], "split": split}))
    counts["delay_ledger_audit"] = len(delays)

    reviews = rows(corpus / f"review_audits_{split}.jsonl")
    for row in reviews:
        case = cases_by_id[row["decision_case_id"]]
        prompt = {"declared_context": case["declared_context"]}
        answer = {key: row[key] for key in (
            "current_robust_choice", "low_finding_choice", "high_finding_choice",
            "expected_value_of_sample_information_units", "review_total_cost_units",
            "decision_relevant", "budget_feasible", "deadline_feasible", "review_worthwhile",
            "termination_rule", "queue_priority_rule", "renewal_rule",
        )}
        records.append(task("review_value_audit", row["review_audit_id"], prompt, answer, {"game_id": row["game_id"], "family": row["family"], "split": split}))
    counts["review_value_audit"] = len(reviews)

    pilots = rows(corpus / f"pilot_certificates_{split}.jsonl")
    for row in pilots:
        case = cases_by_id[row["decision_case_id"]]
        prompt = {"declared_context": case["declared_context"]}
        answer = {key: row[key] for key in (
            "available", "scope_bp", "reversible", "harm_cap_units", "robust_net_value_units",
            "admissible", "rollback_trigger", "rollback_deadline_rounds", "certificate_scope",
        )}
        records.append(task("pilot_certificate_audit", row["pilot_certificate_id"], prompt, answer, {"game_id": row["game_id"], "family": row["family"], "split": split}))
    counts["pilot_certificate_audit"] = len(pilots)

    proportionality = rows(corpus / f"proportionality_audits_{split}.jsonl")
    for row in proportionality:
        case = cases_by_id[row["decision_case_id"]]
        prompt = {"declared_context": case["declared_context"]}
        answer = {key: row[key] for key in (
            "hard_boundary_active", "alternatives", "selected_alternative", "selected_robust_net_value_units",
            "selection_basis", "least_restrictive_test", "error_costs_reported_separately", "audit_status", "scope_warning",
        )}
        records.append(task("proportionality_audit", row["proportionality_audit_id"], prompt, answer, {"game_id": row["game_id"], "family": row["family"], "split": split}))
    counts["proportionality_audit"] = len(proportionality)

    with out.open("w", encoding="utf-8", newline="\n") as handle:
        for record in records:
            handle.write(compact(record) + "\n")
    counts["total"] = len(records)
    return counts


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus", type=Path, default=Path("corpus"))
    parser.add_argument("--split", choices=["train", "dev", "test"], required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    counts = export(args.corpus, args.split, args.out)
    print(json.dumps({"status": "exported", "out": str(args.out), "counts": counts}, sort_keys=True))


if __name__ == "__main__":
    main()
