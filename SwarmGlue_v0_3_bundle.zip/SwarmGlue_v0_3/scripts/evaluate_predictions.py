#!/usr/bin/env python3
"""Score decentralized SwarmGlue actor predictions against reference annotations."""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path
from typing import Any


REQUIRED = {"message_type", "message", "action_type", "quantity", "commitment", "confidence", "reason_codes", "decision_summary"}


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def f1(expected: list[str], predicted: list[str]) -> float:
    a, b = set(expected), set(predicted)
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    precision = len(a & b) / len(b)
    recall = len(a & b) / len(a)
    return 0.0 if precision + recall == 0 else 2 * precision * recall / (precision + recall)


def score_one(view: dict[str, Any], prediction: Any) -> dict[str, float]:
    if not isinstance(prediction, dict) or not REQUIRED.issubset(prediction):
        return {
            "schema_valid": 0.0, "action_exact": 0.0, "message_exact": 0.0, "quantity_score": 0.0,
            "commitment_match": 0.0, "reason_f1": 0.0, "confidence_score": 0.0, "summary_present": 0.0,
            "composite": 0.0,
        }
    target = view["target_output"]
    allowed = view["local_input"]["allowed_outputs"]
    schema_valid = float(
        prediction.get("action_type") in allowed["action_types"]
        and prediction.get("message_type") in allowed["message_types"]
        and isinstance(prediction.get("quantity"), (int, float))
        and prediction.get("quantity", -1) >= 0
        and isinstance(prediction.get("confidence"), (int, float))
        and 0 <= prediction.get("confidence", -1) <= 1
    )
    action_exact = float(prediction.get("action_type") == target["action_type"])
    message_exact = float(prediction.get("message_type") == target["message_type"])
    tolerance = float(view["grading"]["quantity_absolute_tolerance"])
    error = abs(float(prediction.get("quantity", 0)) - float(target["quantity"]))
    quantity_score = max(0.0, 1.0 - error / max(tolerance, 1e-9))
    pred_commit = prediction.get("commitment", {})
    commitment_match = float(
        isinstance(pred_commit, dict)
        and pred_commit.get("made") == target["commitment"]["made"]
        and pred_commit.get("renegotiable_on_named_shock") == target["commitment"]["renegotiable_on_named_shock"]
    )
    reasons = prediction.get("reason_codes", [])
    reason_score = f1(target["reason_codes"], reasons if isinstance(reasons, list) else [])
    confidence = prediction.get("confidence", 0)
    confidence_score = max(0.0, 1.0 - abs(float(confidence) - float(target["confidence"])))
    summary_present = float(isinstance(prediction.get("decision_summary"), str) and len(prediction["decision_summary"]) >= 12)
    composite = (
        0.10 * schema_valid
        + 0.25 * action_exact
        + 0.15 * message_exact
        + 0.15 * quantity_score
        + 0.10 * commitment_match
        + 0.15 * reason_score
        + 0.05 * confidence_score
        + 0.05 * summary_present
    )
    return {
        "schema_valid": schema_valid,
        "action_exact": action_exact,
        "message_exact": message_exact,
        "quantity_score": quantity_score,
        "commitment_match": commitment_match,
        "reason_f1": reason_score,
        "confidence_score": confidence_score,
        "summary_present": summary_present,
        "composite": composite,
    }


def aggregate(rows: list[dict[str, float]]) -> dict[str, float]:
    if not rows:
        return {}
    return {key: round(sum(row[key] for row in rows) / len(rows), 6) for key in rows[0]}


def evaluate(views_path: Path, predictions_path: Path) -> dict[str, Any]:
    views = read_jsonl(views_path)
    predictions = read_jsonl(predictions_path)
    prediction_map = {row["view_id"]: row.get("prediction") for row in predictions if "view_id" in row}
    scores: list[dict[str, float]] = []
    by_family: dict[str, list[dict[str, float]]] = defaultdict(list)
    missing: list[str] = []
    for view in views:
        prediction = prediction_map.get(view["view_id"])
        if prediction is None:
            missing.append(view["view_id"])
        score = score_one(view, prediction)
        scores.append(score)
        by_family[view["family"]].append(score)
    extras = sorted(set(prediction_map) - {view["view_id"] for view in views})
    return {
        "view_count": len(views),
        "prediction_count": len(predictions),
        "missing_prediction_count": len(missing),
        "extra_prediction_count": len(extras),
        "overall": aggregate(scores),
        "by_family": {family: aggregate(rows) for family, rows in sorted(by_family.items())},
        "warning": "Offline annotation agreement is not a swarm-level robustness result; run the interactive evaluations and ablations in docs/EVALUATION.md.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--views", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    report = evaluate(args.views, args.predictions)
    rendered = json.dumps(report, indent=2, sort_keys=True)
    print(rendered)
    if args.out:
        args.out.write_text(rendered + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
