#!/usr/bin/env python3
"""Validate and exactly recompute SwarmGlue v0.3 formal game records."""

from __future__ import annotations

import json
import argparse
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

try:
    from .institutional_laboratory import (
        CONSTITUTION_FAMILIES,
        EPISTEMIC_FAMILIES,
        POPULATION_FAMILIES,
        analyze_epistemic_model,
        coalition_key,
        powerset,
        shapley_value,
        simulate_population,
    )
    from .validate_decision_records import validate_decision_records
except ImportError:  # Direct script execution.
    from institutional_laboratory import (
        CONSTITUTION_FAMILIES,
        EPISTEMIC_FAMILIES,
        POPULATION_FAMILIES,
        analyze_epistemic_model,
        coalition_key,
        powerset,
        shapley_value,
        simulate_population,
    )
    from validate_decision_records import validate_decision_records


VERSION = "0.3.0"
KINDS = (
    "game_specs",
    "mechanism_audits",
    "coalition_cases",
    "constitutional_choices",
    "population_rollouts",
    "epistemic_cases",
    "affected_party_views",
)

REQUIRED: dict[str, set[str]] = {
    "game_specs": {
        "game_id", "episode_id", "corpus_version", "split", "family", "template_id", "skeleton_hash",
        "theory_lenses", "players", "type_space", "information_structure", "action_spaces", "outcome_rule",
        "transfer_rule", "horizon", "equilibrium_concept", "deviation_primitives", "institutional_costs",
        "normative_constraints", "synthetic_status",
    },
    "mechanism_audits": {
        "audit_id", "game_id", "episode_id", "corpus_version", "split", "family", "audit_thresholds",
        "truthfulness_audit", "participation_audit", "correlated_obedience_audit", "budget_audit",
        "feasibility_audit", "efficiency_audit", "repeated_game_audit", "maximum_incentive_compatibility_regret",
        "maximum_individual_rationality_violation", "maximum_correlated_obedience_regret", "audit_status",
        "interpretation",
    },
    "coalition_cases": {
        "coalition_case_id", "game_id", "episode_id", "corpus_version", "split", "family", "players",
        "characteristic_function", "allocation_method", "allocation", "efficiency_residual", "core_deficit",
        "blocking_coalition", "is_in_core", "lesson",
    },
    "constitutional_choices": {
        "constitutional_choice_id", "game_id", "episode_id", "corpus_version", "split", "family",
        "participants", "role_information_at_vote", "rule_options", "transaction_costs", "capture_risks",
        "ex_ante_utilities", "ex_post_role_revealed_utilities", "ex_ante_votes", "selection_rule",
        "selected_rule", "ex_ante_consent_rate", "ex_post_preference_reversal_rate", "amendment_rule",
        "interpretation",
    },
    "population_rollouts": {
        "population_rollout_id", "game_id", "episode_id", "corpus_version", "split", "family", "model",
        "initial_strategy_shares", "parameters", "generations", "trajectory", "final_cooperation_rate",
        "final_net_welfare", "cooperation_retention_from_peak", "stochastic_stability_proxy",
    },
    "epistemic_cases": {
        "epistemic_case_id", "game_id", "episode_id", "corpus_version", "split", "family", "case_mode",
        "worlds", "actual_world", "event", "agents", "information_partitions", "public_announcement_history",
        "public_claimed_mutual_knowledge_depth", "computed_analysis", "false_common_knowledge_claim",
        "safe_reference_response",
    },
    "affected_party_views": {
        "affected_party_view_id", "game_id", "episode_id", "corpus_version", "split", "family", "party_id",
        "relationship", "observable_effects", "protected_constraint", "procedural_access", "protection_status",
        "training_use",
    },
}


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path}:{line_number}: invalid JSON: {exc}") from exc
            if not isinstance(row, dict):
                raise ValueError(f"{path}:{line_number}: record is not an object")
            rows.append(row)
    return rows


def close(a: Any, b: Any, tolerance: float = 1e-6) -> bool:
    return abs(float(a) - float(b)) <= tolerance


def assert_keys(row: dict[str, Any], kind: str, context: str) -> None:
    missing = REQUIRED[kind] - set(row)
    extra = set(row) - REQUIRED[kind]
    if missing or extra:
        raise ValueError(f"{context}: key mismatch missing={sorted(missing)} extra={sorted(extra)}")


def audit_status(row: dict[str, Any]) -> str:
    status = "pass"
    if (
        row["maximum_incentive_compatibility_regret"] > 0.05
        or row["maximum_individual_rationality_violation"] > 0.05
        or row["budget_audit"]["absolute_budget_imbalance"] > 0.5
        or not row["feasibility_audit"]["feasible"]
    ):
        status = "fail"
    elif row["repeated_game_audit"]["applicable"] and not row["repeated_game_audit"]["cooperation_sustainable_under_declared_trigger"]:
        status = "fail"
    elif row["maximum_correlated_obedience_regret"] > 0.05 or row["efficiency_audit"]["net_institutional_surplus"] < 0:
        status = "borderline"
    return status


def validate_game(game: dict[str, Any], split: str, episodes: set[str]) -> None:
    context = game.get("game_id", "unknown_game")
    assert_keys(game, "game_specs", context)
    if game["corpus_version"] != VERSION or game["split"] != split:
        raise ValueError(f"{context}: version or split mismatch")
    if game["episode_id"] not in episodes:
        raise ValueError(f"{context}: missing joined episode")
    if len(game["players"]) < 2 or set(game["players"]) != set(game["type_space"]["realized_private_types"]):
        raise ValueError(f"{context}: player/type-space mismatch")
    if set(game["players"]) != set(game["action_spaces"]):
        raise ValueError(f"{context}: player/action-space mismatch")
    if game["synthetic_status"] != "executable_counterfactual_game_not_empirical_measurement":
        raise ValueError(f"{context}: synthetic status missing")
    allocation = round(sum(float(row["allocation"]) for row in game["deviation_primitives"]), 6)
    if not close(allocation, game["outcome_rule"]["allocated_quantity"]):
        raise ValueError(f"{context}: allocated quantity does not sum")
    feasible = allocation <= float(game["outcome_rule"]["capacity"]) + 1e-9
    if bool(game["outcome_rule"]["allocation_is_feasible"]) != feasible:
        raise ValueError(f"{context}: feasibility flag is incorrect")
    info = game["information_structure"]
    if not 0 <= info["claimed_common_knowledge_depth"] <= 3:
        raise ValueError(f"{context}: knowledge depth out of range")
    if not 0 <= info["false_common_knowledge_risk"] <= 1:
        raise ValueError(f"{context}: epistemic risk out of range")
    required_norms = {"affected_nonparticipants_are_scored", "coordinated_harm_is_not_counted_as_beneficial_cooperation"}
    if not required_norms.issubset(game["normative_constraints"]):
        raise ValueError(f"{context}: normative anti-cartel contract missing")


def validate_audit(row: dict[str, Any], split: str, games: dict[str, dict[str, Any]]) -> None:
    context = row.get("audit_id", "unknown_audit")
    assert_keys(row, "mechanism_audits", context)
    game = games.get(row["game_id"])
    if not game or row["episode_id"] != game["episode_id"] or row["split"] != split:
        raise ValueError(f"{context}: game join mismatch")
    max_ic = 0.0
    for item in row["truthfulness_audit"]:
        best = max(float(value) for value in item["alternative_report_utilities"].values())
        regret = round(max(0.0, best - float(item["truthful_utility"])), 6)
        if not close(best, item["best_deviation_utility"]) or not close(regret, item["incentive_compatibility_regret"]):
            raise ValueError(f"{context}: truthfulness counterfactual mismatch for {item['agent_id']}")
        max_ic = max(max_ic, regret)
    max_ir = 0.0
    for item in row["participation_audit"]:
        violation = round(max(0.0, float(item["outside_option"]) - float(item["mechanism_utility"])), 6)
        if not close(violation, item["individual_rationality_violation"]):
            raise ValueError(f"{context}: participation counterfactual mismatch for {item['agent_id']}")
        max_ir = max(max_ir, violation)
    max_obedience = 0.0
    for item in row["correlated_obedience_audit"]:
        best = max(float(value) for value in item["conditional_deviation_utilities"].values())
        regret = round(max(0.0, best - float(item["recommended_utility"])), 6)
        if not close(best, item["best_conditional_deviation_utility"]) or not close(regret, item["obedience_regret"]):
            raise ValueError(f"{context}: conditional obedience mismatch for {item['agent_id']}")
        max_obedience = max(max_obedience, regret)
    if not close(max_ic, row["maximum_incentive_compatibility_regret"]):
        raise ValueError(f"{context}: maximum IC regret mismatch")
    if not close(max_ir, row["maximum_individual_rationality_violation"]):
        raise ValueError(f"{context}: maximum IR violation mismatch")
    if not close(max_obedience, row["maximum_correlated_obedience_regret"]):
        raise ValueError(f"{context}: maximum obedience regret mismatch")
    budget = round(sum(float(value) for value in row["budget_audit"]["transfers_to_institution"]), 6)
    if not close(budget, row["budget_audit"]["net_budget"]) or not close(abs(budget), row["budget_audit"]["absolute_budget_imbalance"]):
        raise ValueError(f"{context}: budget recomputation mismatch")
    feasible = float(row["feasibility_audit"]["allocated_quantity"]) <= float(row["feasibility_audit"]["capacity"]) + 1e-9
    if feasible != bool(row["feasibility_audit"]["feasible"]):
        raise ValueError(f"{context}: feasibility recomputation mismatch")
    efficiency = row["efficiency_audit"]
    total_cost = round(sum(float(value) for value in efficiency["institutional_costs"].values()), 6)
    net = round(float(efficiency["gross_surplus"]) - float(efficiency["externalized_harm"]) - total_cost, 6)
    if not close(total_cost, efficiency["total_institutional_cost"]) or not close(net, efficiency["net_institutional_surplus"]):
        raise ValueError(f"{context}: net-surplus recomputation mismatch")
    if row["audit_status"] != audit_status(row):
        raise ValueError(f"{context}: audit-status classification mismatch")
    repeated = row["repeated_game_audit"]
    if repeated["applicable"]:
        payoffs = repeated["stage_payoffs"]
        threshold = round((float(payoffs["tempt"]) - float(payoffs["cooperate"])) / (float(payoffs["tempt"]) - float(payoffs["punish"])), 6)
        effective = float(repeated["monitoring_adjusted_discount"])
        cooperative = round(float(payoffs["cooperate"]) / (1.0 - effective), 6)
        deviation = round(float(payoffs["tempt"]) + effective * float(payoffs["punish"]) / (1.0 - effective), 6)
        gain = round(deviation - cooperative, 6)
        if not close(threshold, repeated["minimum_sustainable_discount"]):
            raise ValueError(f"{context}: repeated-game threshold mismatch")
        if not close(cooperative, repeated["cooperative_continuation_value"]) or not close(deviation, repeated["one_shot_deviation_value"]):
            raise ValueError(f"{context}: repeated-game continuation value mismatch")
        if not close(gain, repeated["one_shot_deviation_gain"]):
            raise ValueError(f"{context}: repeated-game deviation gain mismatch")
        if bool(repeated["cooperation_sustainable_under_declared_trigger"]) != (gain <= 1e-6):
            raise ValueError(f"{context}: repeated-game sustainability flag mismatch")


def validate_coalition(row: dict[str, Any], split: str, games: dict[str, dict[str, Any]]) -> None:
    context = row.get("coalition_case_id", "unknown_coalition")
    assert_keys(row, "coalition_cases", context)
    if row["game_id"] not in games or row["split"] != split:
        raise ValueError(f"{context}: game join mismatch")
    expected = shapley_value(row["players"], row["characteristic_function"])
    if expected != row["allocation"]:
        raise ValueError(f"{context}: Shapley recomputation mismatch")
    grand = row["characteristic_function"][coalition_key(row["players"])]
    residual = round(abs(sum(row["allocation"].values()) - grand), 6)
    if not close(residual, row["efficiency_residual"]):
        raise ValueError(f"{context}: allocation efficiency mismatch")
    deficits: list[tuple[float, str]] = []
    for coalition in powerset(row["players"]):
        if not coalition or len(coalition) == len(row["players"]):
            continue
        key = coalition_key(coalition)
        deficit = round(max(0.0, row["characteristic_function"][key] - sum(row["allocation"][player] for player in coalition)), 6)
        deficits.append((deficit, key))
    deficit, blocker = max(deficits, key=lambda item: (item[0], item[1]))
    blocker = blocker if deficit > 1e-6 else None
    if not close(deficit, row["core_deficit"]) or blocker != row["blocking_coalition"]:
        raise ValueError(f"{context}: core-deficit recomputation mismatch")
    if bool(row["is_in_core"]) != (deficit <= 1e-6):
        raise ValueError(f"{context}: core-membership flag mismatch")


def validate_constitution(row: dict[str, Any], split: str, games: dict[str, dict[str, Any]]) -> None:
    context = row.get("constitutional_choice_id", "unknown_constitution")
    assert_keys(row, "constitutional_choices", context)
    if row["game_id"] not in games or row["split"] != split or row["family"] not in CONSTITUTION_FAMILIES:
        raise ValueError(f"{context}: game join or family mismatch")
    rules = row["rule_options"]
    participants = row["participants"]
    expected_votes = {
        player: max(rules, key=lambda rule: (row["ex_ante_utilities"][player][rule], -rules.index(rule)))
        for player in participants
    }
    if expected_votes != row["ex_ante_votes"]:
        raise ValueError(f"{context}: ex-ante vote mismatch")
    counts = Counter(expected_votes.values())
    selected = max(rules, key=lambda rule: (counts[rule], sum(row["ex_ante_utilities"][player][rule] for player in participants), -rules.index(rule)))
    if selected != row["selected_rule"]:
        raise ValueError(f"{context}: selected constitution mismatch")
    consent = round(counts[selected] / len(participants), 6)
    if not close(consent, row["ex_ante_consent_rate"]):
        raise ValueError(f"{context}: consent rate mismatch")
    switches = sum(max(row["ex_post_role_revealed_utilities"][player], key=row["ex_post_role_revealed_utilities"][player].get) != selected for player in participants)
    reversal = round(switches / len(participants), 6)
    if not close(reversal, row["ex_post_preference_reversal_rate"]):
        raise ValueError(f"{context}: role-revelation reversal mismatch")


def validate_population(row: dict[str, Any], split: str, games: dict[str, dict[str, Any]]) -> None:
    context = row.get("population_rollout_id", "unknown_population")
    assert_keys(row, "population_rollouts", context)
    if row["game_id"] not in games or row["split"] != split or row["family"] not in POPULATION_FAMILIES:
        raise ValueError(f"{context}: game join or family mismatch")
    expected = simulate_population(row["parameters"], row["initial_strategy_shares"], row["generations"])
    if expected != row["trajectory"]:
        raise ValueError(f"{context}: population trajectory does not exactly recompute")
    final = expected[-1]
    peak = max(item["cooperation_rate"] for item in expected)
    if not close(final["cooperation_rate"], row["final_cooperation_rate"], 1e-8):
        raise ValueError(f"{context}: final cooperation mismatch")
    if not close(final["net_welfare"], row["final_net_welfare"], 1e-8):
        raise ValueError(f"{context}: final welfare mismatch")
    retention = round(final["cooperation_rate"] / max(peak, 1e-9), 8)
    if not close(retention, row["cooperation_retention_from_peak"], 1e-8):
        raise ValueError(f"{context}: peak-retention mismatch")


def validate_epistemic(row: dict[str, Any], split: str, games: dict[str, dict[str, Any]]) -> None:
    context = row.get("epistemic_case_id", "unknown_epistemic_case")
    assert_keys(row, "epistemic_cases", context)
    if row["game_id"] not in games or row["split"] != split or row["family"] not in EPISTEMIC_FAMILIES:
        raise ValueError(f"{context}: game join or family mismatch")
    expected = analyze_epistemic_model(
        row["worlds"], row["actual_world"], row["event"]["worlds"], row["information_partitions"]
    )
    if expected != row["computed_analysis"]:
        raise ValueError(f"{context}: epistemic partition analysis mismatch")
    false_claim = (
        row["public_claimed_mutual_knowledge_depth"] > expected["mutual_knowledge_depth_at_actual_world"]
        or (row["public_claimed_mutual_knowledge_depth"] >= expected["mutual_knowledge_depth_cap"] and not expected["is_common_knowledge"])
        or not expected["event_true"]
    )
    if bool(row["false_common_knowledge_claim"]) != false_claim:
        raise ValueError(f"{context}: false-common-knowledge flag mismatch")
    safe = "coordinate" if expected["is_common_knowledge"] else ("request_public_acknowledgement" if expected["event_true"] else "block_and_correct_false_claim")
    if row["safe_reference_response"] != safe:
        raise ValueError(f"{context}: safe epistemic response mismatch")


def validate_affected(row: dict[str, Any], split: str, games: dict[str, dict[str, Any]], audits: dict[str, dict[str, Any]]) -> None:
    context = row.get("affected_party_view_id", "unknown_affected_party")
    assert_keys(row, "affected_party_views", context)
    game = games.get(row["game_id"])
    audit = audits.get(row["game_id"])
    if not game or not audit or row["split"] != split:
        raise ValueError(f"{context}: game or audit join mismatch")
    effects = row["observable_effects"]
    baseline = float(effects["baseline_harm"])
    residual = float(effects["residual_harm_under_institution"])
    reduction = round(max(0.0, min(1.0, (baseline - residual) / max(baseline, 1e-9))), 6)
    if not close(reduction, effects["harm_reduction_ratio"]):
        raise ValueError(f"{context}: harm-reduction mismatch")
    expected = "protected" if residual <= baseline and row["procedural_access"]["can_trigger_review"] else "at_risk"
    if expected != row["protection_status"]:
        raise ValueError(f"{context}: protection-status mismatch")


def validate_formal_records(corpus_dir: Path) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    counts: dict[str, dict[str, int]] = defaultdict(dict)
    skeletons: dict[str, set[str]] = defaultdict(set)
    ids: dict[str, set[str]] = defaultdict(set)
    status_counts: Counter[str] = Counter()
    core_counts: Counter[str] = Counter()
    protection_counts: Counter[str] = Counter()
    epistemic_counts: Counter[str] = Counter()
    theory_lenses: set[str] = set()

    for split in ("train", "dev", "test"):
        episodes = {row["episode_id"] for row in read_jsonl(corpus_dir / f"episodes_{split}.jsonl")}
        loaded = {kind: read_jsonl(corpus_dir / f"{kind}_{split}.jsonl") for kind in KINDS}
        for kind, rows in loaded.items():
            counts[split][kind] = len(rows)
        games: dict[str, dict[str, Any]] = {}
        for game in loaded["game_specs"]:
            context = game.get("game_id", "unknown_game")
            try:
                validate_game(game, split, episodes)
                if context in ids["game"]:
                    raise ValueError(f"{context}: duplicate game id")
                ids["game"].add(context)
                games[context] = game
                skeletons[split].add(game["skeleton_hash"])
                theory_lenses.update(game["theory_lenses"])
            except (KeyError, TypeError, ValueError) as exc:
                errors.append(str(exc))
        audits: dict[str, dict[str, Any]] = {}
        for row in loaded["mechanism_audits"]:
            try:
                validate_audit(row, split, games)
                audits[row["game_id"]] = row
                status_counts[row["audit_status"]] += 1
            except (KeyError, TypeError, ValueError) as exc:
                errors.append(str(exc))
        for row in loaded["coalition_cases"]:
            try:
                validate_coalition(row, split, games)
                core_counts["in_core" if row["is_in_core"] else "blocked"] += 1
            except (KeyError, TypeError, ValueError) as exc:
                errors.append(str(exc))
        for row in loaded["constitutional_choices"]:
            try:
                validate_constitution(row, split, games)
            except (KeyError, TypeError, ValueError) as exc:
                errors.append(str(exc))
        for row in loaded["population_rollouts"]:
            try:
                validate_population(row, split, games)
            except (KeyError, TypeError, ValueError) as exc:
                errors.append(str(exc))
        for row in loaded["epistemic_cases"]:
            try:
                validate_epistemic(row, split, games)
                epistemic_counts[row["case_mode"]] += 1
            except (KeyError, TypeError, ValueError) as exc:
                errors.append(str(exc))
        for row in loaded["affected_party_views"]:
            try:
                validate_affected(row, split, games, audits)
                protection_counts[row["protection_status"]] += 1
            except (KeyError, TypeError, ValueError) as exc:
                errors.append(str(exc))
        if len(games) != len(episodes):
            errors.append(f"{split}: expected one formal game per episode")
        if len(audits) != len(games):
            errors.append(f"{split}: expected one mechanism audit per formal game")
        if len(loaded["coalition_cases"]) != len(games):
            errors.append(f"{split}: expected one coalition case per formal game")
        if len(loaded["affected_party_views"]) != len(games):
            errors.append(f"{split}: expected one affected-party view per formal game")
        expected_epistemic = sum(game["family"] in EPISTEMIC_FAMILIES for game in games.values())
        if len(loaded["epistemic_cases"]) != expected_epistemic:
            errors.append(f"{split}: expected one epistemic case for each declared epistemic family episode")

    decision_report = validate_decision_records(corpus_dir)
    for split in ("train", "dev", "test"):
        counts[split].update(decision_report["counts"].get(split, {}))
    errors.extend(f"dual-decision: {error}" for error in decision_report["errors"])
    warnings.extend(f"dual-decision: {warning}" for warning in decision_report["warnings"])

    overlap = {
        "train_dev": len(skeletons["train"] & skeletons["dev"]),
        "train_test": len(skeletons["train"] & skeletons["test"]),
        "dev_test": len(skeletons["dev"] & skeletons["test"]),
    }
    if any(overlap.values()):
        errors.append(f"formal skeleton leakage: {overlap}")
    if len(theory_lenses) < 16:
        warnings.append("formal games cover fewer than sixteen distinct theory lenses")
    if not status_counts.get("fail") or not status_counts.get("pass"):
        warnings.append("mechanism audits lack both positive and negative examples")
    return {
        "status": "pass" if not errors else "fail",
        "corpus_version": VERSION,
        "counts": {split: dict(values) for split, values in counts.items()},
        "formal_skeleton_overlap": overlap,
        "mechanism_audit_status_counts": dict(sorted(status_counts.items())),
        "coalition_stability_counts": dict(sorted(core_counts.items())),
        "affected_party_protection_counts": dict(sorted(protection_counts.items())),
        "epistemic_case_mode_counts": dict(sorted(epistemic_counts.items())),
        "dual_sided_decision_laboratory": decision_report,
        "theory_lens_count": len(theory_lenses),
        "theory_lenses": sorted(theory_lenses),
        "checks": {
            "game_episode_join": not any("joined episode" in error or "game join" in error for error in errors),
            "exact_deviation_recomputation": not any("counterfactual mismatch" in error or "maximum IC" in error or "obedience" in error for error in errors),
            "exact_budget_feasibility_efficiency": not any("budget" in error or "feasibility" in error or "net-surplus" in error for error in errors),
            "exact_shapley_and_core": not any("Shapley" in error or "core-" in error for error in errors),
            "exact_constitutional_choice": not any("constitution" in error or "vote" in error or "consent" in error for error in errors),
            "exact_population_trajectory": not any("population" in error or "cooperation mismatch" in error for error in errors),
            "exact_epistemic_partition_analysis": not any("epistemic" in error or "common-knowledge" in error for error in errors),
            "affected_nonparticipant_accounting": not any("harm-reduction" in error or "protection-status" in error for error in errors),
            "dual_sided_action_delay_accounting": decision_report["status"] == "pass",
            "formal_split_isolation": not any(overlap.values()),
        },
        "errors": errors[:100],
        "warnings": warnings,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus", type=Path, default=Path("corpus"))
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    report = validate_formal_records(args.corpus)
    rendered = json.dumps(report, indent=2, sort_keys=True)
    print(rendered)
    if args.report:
        args.report.write_text(rendered + "\n", encoding="utf-8")
    if report["status"] != "pass":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
