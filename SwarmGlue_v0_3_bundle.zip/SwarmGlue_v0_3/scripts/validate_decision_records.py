#!/usr/bin/env python3
"""Validate and replay SwarmGlue v0.3 dual-sided decision records."""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

try:
    from .decision_laboratory import DUAL_DECISION_FAMILIES, RECORD_TYPES, canonical_hash, risk_class
    from .decision_math import compute_decision, expected_harm, q
except ImportError:  # Direct script execution.
    from decision_laboratory import DUAL_DECISION_FAMILIES, RECORD_TYPES, canonical_hash, risk_class
    from decision_math import compute_decision, expected_harm, q


VERSION = "0.3.0"

REQUIRED: dict[str, set[str]] = {
    "decision_cases": {
        "decision_case_id", "game_id", "episode_id", "corpus_version", "split", "family", "mode",
        "skeleton_hash", "declared_model_hash", "declared_context", "candidate_alternatives",
        "selected_alternative", "selected_robust_net_value_units", "hard_boundary_active",
        "certificate_backplane", "certification_scope",
    },
    "risk_claims": {
        "risk_claim_id", "decision_case_id", "game_id", "episode_id", "corpus_version", "split",
        "family", "declared_model_hash", "claim_class", "causal_chain", "affected_parties",
        "severity_units", "probability_interval_bp", "expected_harm_upper_bound_units",
        "irreversible", "protected_boundary", "evidence", "claimant_incentives", "burden_of_proof",
        "admission_lane",
    },
    "delay_ledgers": {
        "delay_ledger_id", "decision_case_id", "game_id", "episode_id", "corpus_version", "split",
        "family", "declared_model_hash", "status_quo_harm_per_round_units",
        "opportunity_cost_per_round_units", "review_direct_cost_units", "planned_review_rounds",
        "review_delay_cost_units", "total_review_burden_units", "decision_horizon_rounds",
        "stop_status_quo_and_opportunity_cost_units", "accountable_beneficiaries_of_delay", "ledger_rule",
    },
    "review_audits": {
        "review_audit_id", "decision_case_id", "game_id", "episode_id", "corpus_version", "split",
        "family", "declared_model_hash", "current_robust_choice", "low_finding_choice",
        "high_finding_choice", "review_high_finding_probability_bp", "current_robust_value_units",
        "expected_post_review_value_units", "expected_value_of_sample_information_units",
        "review_direct_cost_units", "review_delay_and_status_quo_cost_units", "review_total_cost_units",
        "review_path_robust_net_value_units", "budget_feasible", "deadline_feasible", "decision_relevant",
        "independent_evidence_available", "review_worthwhile", "termination_rule", "review_budget_units",
        "review_deadline_rounds_remaining", "claim_count", "sybil_risk_bp",
        "claimant_conflict_of_interest", "protected_disclosure", "queue_priority_rule", "renewal_rule",
    },
    "pilot_certificates": {
        "pilot_certificate_id", "decision_case_id", "game_id", "episode_id", "corpus_version", "split",
        "family", "declared_model_hash", "available", "scope_bp", "reversible", "harm_cap_units",
        "protected_pilot_harm_cap_units", "rollback_cost_units", "learning_value_units",
        "robust_net_value_units", "admissible", "rollback_trigger", "rollback_deadline_rounds",
        "certificate_scope",
    },
    "proportionality_audits": {
        "proportionality_audit_id", "decision_case_id", "game_id", "episode_id", "corpus_version",
        "split", "family", "risk_claim_id", "delay_ledger_id", "review_audit_id",
        "pilot_certificate_id", "declared_model_hash", "hard_boundary_active", "alternatives",
        "selected_alternative", "selected_robust_net_value_units", "selection_basis",
        "least_restrictive_test", "error_costs_reported_separately", "audit_status", "scope_warning",
    },
}


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def assert_keys(row: dict[str, Any], kind: str) -> None:
    missing = REQUIRED[kind] - set(row)
    extra = set(row) - REQUIRED[kind]
    if missing or extra:
        raise ValueError(f"{kind}:{row.get('episode_id', 'unknown')}: key mismatch missing={sorted(missing)} extra={sorted(extra)}")


def validate_decision_records(corpus_dir: Path) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    counts: dict[str, dict[str, int]] = defaultdict(dict)
    skeletons: dict[str, set[str]] = defaultdict(set)
    selections: Counter[str] = Counter()
    risk_classes: Counter[str] = Counter()
    review_counts: Counter[str] = Counter()
    hard_counts: Counter[str] = Counter()

    for split in ("train", "dev", "test"):
        episodes = {
            row["episode_id"]: row
            for row in read_jsonl(corpus_dir / f"episodes_{split}.jsonl")
            if row["family"] in DUAL_DECISION_FAMILIES
        }
        loaded = {kind: read_jsonl(corpus_dir / f"{kind}_{split}.jsonl") for kind in RECORD_TYPES}
        for kind, rows in loaded.items():
            counts[split][kind] = len(rows)
            if len(rows) != len(episodes):
                errors.append(f"{split}:{kind}: expected {len(episodes)} records, found {len(rows)}")
        by_episode = {kind: {row["episode_id"]: row for row in rows} for kind, rows in loaded.items()}
        for episode_id, episode in episodes.items():
            if any(episode_id not in by_episode[kind] for kind in RECORD_TYPES):
                errors.append(f"{episode_id}: incomplete dual-decision join")
                continue
            context = episode["initial_public_state"].get("decision_context")
            if not context:
                errors.append(f"{episode_id}: decision_context missing")
                continue
            computed = compute_decision(context)
            declared_hash = canonical_hash(context)
            rows = {kind: by_episode[kind][episode_id] for kind in RECORD_TYPES}
            try:
                for kind, row in rows.items():
                    assert_keys(row, kind)
                    if row["corpus_version"] != VERSION or row["split"] != split or row["family"] != episode["family"]:
                        raise ValueError(f"{episode_id}:{kind}: version, split, or family mismatch")
                    if row["decision_case_id"] != rows["decision_cases"]["decision_case_id"]:
                        raise ValueError(f"{episode_id}:{kind}: decision-case join mismatch")
                    if row["declared_model_hash"] != declared_hash:
                        raise ValueError(f"{episode_id}:{kind}: declared-model hash mismatch")

                case = rows["decision_cases"]
                if case["declared_context"] != context:
                    raise ValueError(f"{episode_id}: declared context differs from episode")
                if case["candidate_alternatives"] != [item["name"] for item in computed["alternatives"]]:
                    raise ValueError(f"{episode_id}: candidate alternatives mismatch")
                if case["selected_alternative"] != computed["selected_alternative"]:
                    raise ValueError(f"{episode_id}: selected alternative mismatch")
                if case["selected_robust_net_value_units"] != computed["selected_robust_net_value_units"]:
                    raise ValueError(f"{episode_id}: selected value mismatch")
                if case["hard_boundary_active"] != computed["hard_boundary_active"]:
                    raise ValueError(f"{episode_id}: hard-boundary mismatch")
                skeletons[split].add(case["skeleton_hash"])
                selections[case["selected_alternative"]] += 1
                hard_counts["active" if case["hard_boundary_active"] else "ordinary"] += 1

                risk = rows["risk_claims"]
                if risk["claim_class"] != risk_class(context, computed):
                    raise ValueError(f"{episode_id}: risk classification mismatch")
                expected = q(expected_harm(context["harm_severity_units"], context["harm_probability_upper_bp"]))
                if risk["expected_harm_upper_bound_units"] != expected:
                    raise ValueError(f"{episode_id}: expected-harm bound mismatch")
                risk_classes[risk["claim_class"]] += 1

                delay = rows["delay_ledgers"]
                per_round = context["status_quo_harm_per_round_units"] + context["opportunity_cost_per_round_units"]
                if delay["review_delay_cost_units"] != q(per_round * context["review_duration_rounds"]):
                    raise ValueError(f"{episode_id}: review delay cost mismatch")
                if delay["total_review_burden_units"] != q(per_round * context["review_duration_rounds"] + context["review_cost_units"]):
                    raise ValueError(f"{episode_id}: total review burden mismatch")
                if delay["stop_status_quo_and_opportunity_cost_units"] != q(per_round * context["decision_horizon_rounds"]):
                    raise ValueError(f"{episode_id}: stop cost mismatch")

                review = rows["review_audits"]
                for key, value in computed["review_audit"].items():
                    if review[key] != value:
                        raise ValueError(f"{episode_id}: review recomputation mismatch at {key}")
                review_counts["worthwhile" if review["review_worthwhile"] else "terminate"] += 1

                pilot = rows["pilot_certificates"]
                pilot_alt = next(item for item in computed["alternatives"] if item["name"] == "reversible_pilot")
                if pilot["robust_net_value_units"] != pilot_alt["robust_net_value_units"] or pilot["admissible"] != pilot_alt["admissible"]:
                    raise ValueError(f"{episode_id}: pilot certificate mismatch")

                proportionality = rows["proportionality_audits"]
                if proportionality["alternatives"] != computed["alternatives"]:
                    raise ValueError(f"{episode_id}: proportionality table mismatch")
                if proportionality["selected_alternative"] != computed["selected_alternative"]:
                    raise ValueError(f"{episode_id}: proportionality selection mismatch")
                if proportionality["audit_status"] != "pass":
                    raise ValueError(f"{episode_id}: declared audit does not pass its own arithmetic")
            except (KeyError, TypeError, ValueError) as exc:
                errors.append(str(exc))

    overlap = {
        "train_dev": len(skeletons["train"] & skeletons["dev"]),
        "train_test": len(skeletons["train"] & skeletons["test"]),
        "dev_test": len(skeletons["dev"] & skeletons["test"]),
    }
    if any(overlap.values()):
        errors.append(f"decision skeleton leakage: {overlap}")
    if len(selections) < 4:
        warnings.append("dual-decision cases cover fewer than four selected alternatives")
    if not hard_counts.get("active") or not hard_counts.get("ordinary"):
        warnings.append("dual-decision cases lack both hard-boundary and ordinary lanes")
    return {
        "status": "pass" if not errors else "fail",
        "corpus_version": VERSION,
        "counts": {split: dict(values) for split, values in counts.items()},
        "selection_counts": dict(sorted(selections.items())),
        "risk_class_counts": dict(sorted(risk_classes.items())),
        "review_value_counts": dict(sorted(review_counts.items())),
        "hard_boundary_counts": dict(sorted(hard_counts.items())),
        "decision_skeleton_overlap": overlap,
        "checks": {
            "complete_episode_join": not any("join" in error or "expected" in error for error in errors),
            "declared_model_hashes": not any("hash mismatch" in error for error in errors),
            "action_and_delay_arithmetic": not any("cost mismatch" in error or "expected-harm" in error for error in errors),
            "EVSI_review_recomputation": not any("review recomputation" in error for error in errors),
            "pilot_reversibility_recomputation": not any("pilot certificate" in error for error in errors),
            "protected_boundary_and_proportionality": not any("hard-boundary" in error or "proportionality" in error for error in errors),
            "decision_split_isolation": not any(overlap.values()),
        },
        "errors": errors[:100],
        "warnings": warnings,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus", type=Path, default=Path("corpus"))
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    report = validate_decision_records(args.corpus)
    rendered = json.dumps(report, indent=2, sort_keys=True)
    print(rendered)
    if args.report:
        args.report.write_text(rendered + "\n", encoding="utf-8")
    if report["status"] != "pass":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
