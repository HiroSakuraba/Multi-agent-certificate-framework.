#!/usr/bin/env python3
"""Exact declared-model arithmetic for SwarmGlue's dual-sided decisions.

The functions in this module compare harm from action with harm from delay.
They certify arithmetic inside a declared synthetic decision model; they do
not certify that the model, probabilities, values, or protected boundaries
are correct descriptions of an open-world deployment.
"""

from __future__ import annotations

from decimal import Decimal, ROUND_HALF_EVEN
from typing import Any


SIX = Decimal("0.000001")


def q(value: Any) -> float:
    """Return a stable six-decimal JSON number."""
    return float(Decimal(str(value)).quantize(SIX, rounding=ROUND_HALF_EVEN))


def d(value: Any) -> Decimal:
    return Decimal(str(value))


def expected_harm(severity_units: Any, probability_bp: Any) -> Decimal:
    return d(severity_units) * d(probability_bp) / Decimal(10_000)


def hard_boundary_active(context: dict[str, Any], probability_bp: int | None = None) -> bool:
    probability = context["harm_probability_upper_bp"] if probability_bp is None else probability_bp
    return bool(
        context["protected_boundary"]
        and context["irreversible"]
        and context["harm_severity_units"] >= context["hard_severity_threshold_units"]
        and probability >= context["hard_probability_threshold_bp"]
    )


def alternative_table(context: dict[str, Any], probability_bp: int | None = None) -> list[dict[str, Any]]:
    """Compute robust values for action, mitigation, pilot, and stop."""
    probability = context["harm_probability_upper_bp"] if probability_bp is None else probability_bp
    harm = expected_harm(context["harm_severity_units"], probability)
    benefit = d(context["action_benefit_units"])
    action_cost = d(context["action_cost_units"])
    hard = hard_boundary_active(context, probability)

    full_net = benefit - action_cost - harm
    full = {
        "name": "full_action",
        "benefit_units": q(benefit),
        "direct_cost_units": q(action_cost),
        "harm_bound_units": q(harm),
        "delay_cost_units": 0.0,
        "robust_net_value_units": q(full_net),
        "admissible": not hard,
        "admissibility_reasons": ["protected_hard_boundary_active"] if hard else ["ordinary_proportionality_lane"],
    }

    reduction = d(context["mitigation_harm_reduction_bp"]) / Decimal(10_000)
    residual_harm = harm * (Decimal(1) - reduction)
    mitigation_cost = d(context["mitigation_cost_units"])
    mitigated_net = benefit - action_cost - mitigation_cost - residual_harm
    mitigated = {
        "name": "mitigated_action",
        "benefit_units": q(benefit),
        "direct_cost_units": q(action_cost + mitigation_cost),
        "harm_bound_units": q(residual_harm),
        "delay_cost_units": 0.0,
        "robust_net_value_units": q(mitigated_net),
        "admissible": bool(context["mitigation_available"] and not hard),
        "admissibility_reasons": (
            ["mitigation_available", "ordinary_proportionality_lane"]
            if context["mitigation_available"] and not hard
            else (["protected_hard_boundary_active"] if hard else ["mitigation_unavailable"])
        ),
    }

    scope = d(context["pilot_scope_bp"]) / Decimal(10_000)
    pilot_harm = min(harm * scope, d(context["pilot_harm_cap_units"]))
    pilot_net = (
        (benefit - action_cost) * scope
        - pilot_harm
        - d(context["pilot_rollback_cost_units"])
        + d(context["pilot_learning_value_units"])
    )
    pilot_hard_safe = bool(
        context["pilot_reversible"]
        and context["pilot_harm_cap_units"] <= context["protected_pilot_harm_cap_units"]
    )
    pilot_admissible = bool(context["pilot_available"] and (not hard or pilot_hard_safe))
    pilot = {
        "name": "reversible_pilot",
        "benefit_units": q((benefit - action_cost) * scope + d(context["pilot_learning_value_units"])),
        "direct_cost_units": q(context["pilot_rollback_cost_units"]),
        "harm_bound_units": q(pilot_harm),
        "delay_cost_units": 0.0,
        "robust_net_value_units": q(pilot_net),
        "admissible": pilot_admissible,
        "admissibility_reasons": (
            ["bounded_scope", "reversible", "rollback_trigger_declared"]
            if pilot_admissible
            else (["pilot_unavailable"] if not context["pilot_available"] else ["pilot_exceeds_protected_harm_cap"])
        ),
    }

    per_round_status_quo = d(context["status_quo_harm_per_round_units"])
    per_round_opportunity = d(context["opportunity_cost_per_round_units"])
    stop_loss = (per_round_status_quo + per_round_opportunity) * d(context["decision_horizon_rounds"])
    stop = {
        "name": "stop",
        "benefit_units": 0.0,
        "direct_cost_units": 0.0,
        "harm_bound_units": q(per_round_status_quo * d(context["decision_horizon_rounds"])),
        "delay_cost_units": q(per_round_opportunity * d(context["decision_horizon_rounds"])),
        "robust_net_value_units": q(-stop_loss),
        "admissible": True,
        "admissibility_reasons": ["always_available_status_quo_option"],
    }
    return [full, mitigated, pilot, stop]


def best_admissible(alternatives: list[dict[str, Any]]) -> dict[str, Any]:
    rank = {"mitigated_action": 4, "reversible_pilot": 3, "full_action": 2, "stop": 1, "continue_review": 0}
    admissible = [item for item in alternatives if item["admissible"]]
    if not admissible:
        raise ValueError("declared model has no admissible alternative")
    return max(admissible, key=lambda item: (item["robust_net_value_units"], rank.get(item["name"], -1)))


def compute_review_audit(context: dict[str, Any]) -> dict[str, Any]:
    current_alternatives = alternative_table(context)
    current = best_admissible(current_alternatives)
    low = best_admissible(alternative_table(context, context["posterior_low_probability_upper_bp"]))
    high = best_admissible(alternative_table(context, context["posterior_high_probability_upper_bp"]))
    high_probability = d(context["review_high_finding_probability_bp"]) / Decimal(10_000)
    expected_post = (
        high_probability * d(high["robust_net_value_units"])
        + (Decimal(1) - high_probability) * d(low["robust_net_value_units"])
    )
    evsi = max(Decimal(0), expected_post - d(current["robust_net_value_units"]))
    review_cost = d(context["review_cost_units"])
    delay_cost = (
        d(context["status_quo_harm_per_round_units"])
        + d(context["opportunity_cost_per_round_units"])
    ) * d(context["review_duration_rounds"])
    total = review_cost + delay_cost
    budget_feasible = context["review_budget_units"] >= context["review_cost_units"]
    deadline_feasible = context["review_duration_rounds"] <= context["review_deadline_rounds_remaining"]
    decision_relevant = low["name"] != high["name"]
    evidence_available = context["independent_evidence_sources"] > 0
    worthwhile = bool(evsi > total and budget_feasible and deadline_feasible and decision_relevant and evidence_available)
    review_path_value = d(current["robust_net_value_units"]) + evsi - total
    return {
        "current_robust_choice": current["name"],
        "low_finding_choice": low["name"],
        "high_finding_choice": high["name"],
        "review_high_finding_probability_bp": context["review_high_finding_probability_bp"],
        "current_robust_value_units": q(current["robust_net_value_units"]),
        "expected_post_review_value_units": q(expected_post),
        "expected_value_of_sample_information_units": q(evsi),
        "review_direct_cost_units": q(review_cost),
        "review_delay_and_status_quo_cost_units": q(delay_cost),
        "review_total_cost_units": q(total),
        "review_path_robust_net_value_units": q(review_path_value),
        "budget_feasible": budget_feasible,
        "deadline_feasible": deadline_feasible,
        "decision_relevant": decision_relevant,
        "independent_evidence_available": evidence_available,
        "review_worthwhile": worthwhile,
        "termination_rule": "continue only while EVSI exceeds review plus delay cost and the evidence can change the decision",
    }


def compute_decision(context: dict[str, Any]) -> dict[str, Any]:
    alternatives = alternative_table(context)
    review = compute_review_audit(context)
    review_alternative = {
        "name": "continue_review",
        "benefit_units": q(review["expected_value_of_sample_information_units"]),
        "direct_cost_units": q(review["review_direct_cost_units"]),
        "harm_bound_units": q(d(context["status_quo_harm_per_round_units"]) * d(context["review_duration_rounds"])),
        "delay_cost_units": q(d(context["opportunity_cost_per_round_units"]) * d(context["review_duration_rounds"])),
        "robust_net_value_units": q(review["review_path_robust_net_value_units"]),
        "admissible": bool(review["review_worthwhile"]),
        "admissibility_reasons": (
            ["decision_relevant_evidence", "EVSI_exceeds_review_and_delay_cost", "within_budget_and_deadline"]
            if review["review_worthwhile"]
            else ["review_fails_value_budget_deadline_or_decision_relevance_test"]
        ),
    }
    all_alternatives = alternatives + [review_alternative]
    selected = best_admissible(all_alternatives)
    hard = hard_boundary_active(context)
    return {
        "hard_boundary_active": hard,
        "alternatives": all_alternatives,
        "review_audit": review,
        "selected_alternative": selected["name"],
        "selected_robust_net_value_units": selected["robust_net_value_units"],
        "selection_basis": (
            "protected_boundary_excludes_full_action_then_choose_best_admissible_path"
            if hard
            else "maximize_declared_robust_net_value_subject_to_review_and_proportionality_constraints"
        ),
        "scope_warning": "Arithmetic is certified only inside the declared synthetic model; model validity, moral legitimacy, and real-world safety remain external claims.",
    }
