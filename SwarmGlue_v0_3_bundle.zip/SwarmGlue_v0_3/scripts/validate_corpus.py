#!/usr/bin/env python3
"""Audit a generated SwarmGlue corpus for structure, masking, and split leakage."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

try:
    from .validate_formal_records import validate_formal_records
except ImportError:  # Direct script execution.
    from validate_formal_records import validate_formal_records


REQUIRED_EPISODE = {
    "episode_id", "corpus_version", "split", "family", "template_id", "skeleton_hash",
    "mode", "difficulty", "environment", "agents", "institution", "initial_public_state",
    "private_states", "reference_trajectory", "evaluation", "counterfactuals", "labels", "provenance",
}
REQUIRED_VIEW = {
    "view_id", "episode_id", "corpus_version", "split", "family", "template_id", "skeleton_hash",
    "agent_id", "role", "stage", "system_instruction", "local_input", "target_output",
    "grading", "forbidden_information", "metadata",
}
REQUIRED_PAIR = {
    "pair_id", "view_id", "episode_id", "corpus_version", "split", "family", "template_id",
    "skeleton_hash", "local_input", "chosen", "rejected", "failure_tags", "causal_contrast", "label_confidence",
}
REQUIRED_OUTPUT = {
    "message_type", "message", "action_type", "quantity", "commitment", "confidence",
    "reason_codes", "decision_summary",
}
FORBIDDEN_LOCAL_KEYS = {
    "private_states", "reference_trajectory", "evaluation", "counterfactuals", "future_outcome",
    "other_agents_private_objectives", "other_agents_private_observations", "other_agents_reservation_values",
    "global_private_state", "omniscient_state", "game_spec", "deviation_primitives", "mechanism_audit",
    "coalition_case", "constitutional_choice", "population_rollout", "affected_party_view",
    "decision_case", "risk_claim", "delay_ledger", "review_audit", "pilot_certificate", "proportionality_audit",
}


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path}:{line_number}: invalid JSON: {exc}") from exc
            if not isinstance(value, dict):
                raise ValueError(f"{path}:{line_number}: row is not an object")
            rows.append(value)
    return rows


def walk_keys(value: Any) -> Iterable[str]:
    if isinstance(value, dict):
        for key, child in value.items():
            yield key
            yield from walk_keys(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk_keys(child)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def assert_required(row: dict[str, Any], required: set[str], context: str) -> None:
    missing = required - set(row)
    extra = set(row) - required
    if missing:
        raise ValueError(f"{context}: missing keys {sorted(missing)}")
    if extra:
        raise ValueError(f"{context}: unexpected keys {sorted(extra)}")


def validate_output(output: dict[str, Any], allowed: dict[str, Any], context: str) -> None:
    assert_required(output, REQUIRED_OUTPUT, context)
    if output["message_type"] not in allowed["message_types"]:
        raise ValueError(f"{context}: disallowed message_type {output['message_type']}")
    if output["action_type"] not in allowed["action_types"]:
        raise ValueError(f"{context}: disallowed action_type {output['action_type']}")
    if not isinstance(output["quantity"], (int, float)) or output["quantity"] < 0:
        raise ValueError(f"{context}: quantity must be nonnegative")
    if not isinstance(output["confidence"], (int, float)) or not 0 <= output["confidence"] <= 1:
        raise ValueError(f"{context}: confidence out of range")
    if not output["reason_codes"] or not all(isinstance(code, str) and code for code in output["reason_codes"]):
        raise ValueError(f"{context}: empty or invalid reason_codes")
    if not isinstance(output["decision_summary"], str) or len(output["decision_summary"]) < 12:
        raise ValueError(f"{context}: decision_summary is missing or too short")
    commitment = output["commitment"]
    if not isinstance(commitment, dict) or "made" not in commitment or "renegotiable_on_named_shock" not in commitment:
        raise ValueError(f"{context}: malformed commitment")


def validate_corpus(corpus_dir: Path) -> dict[str, Any]:
    manifest_path = corpus_dir / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    errors: list[str] = []
    warnings: list[str] = []
    counts: dict[str, dict[str, int]] = defaultdict(dict)
    skeletons: dict[str, set[str]] = defaultdict(set)
    family_counts: dict[str, Counter[str]] = defaultdict(Counter)
    all_episode_ids: set[str] = set()
    all_view_ids: set[str] = set()
    all_pair_ids: set[str] = set()
    failure_counts: Counter[str] = Counter()

    for filename, metadata in manifest["files"].items():
        path = corpus_dir / filename
        if not path.exists():
            errors.append(f"manifest file missing: {filename}")
            continue
        if sha256(path) != metadata["sha256"]:
            errors.append(f"digest mismatch: {filename}")
        if path.stat().st_size != metadata["bytes"]:
            errors.append(f"size mismatch: {filename}")

    for split in ("train", "dev", "test"):
        episodes_path = corpus_dir / f"episodes_{split}.jsonl"
        views_path = corpus_dir / f"agent_views_{split}.jsonl"
        pairs_path = corpus_dir / f"preference_pairs_{split}.jsonl"
        episodes = read_jsonl(episodes_path)
        views = read_jsonl(views_path)
        pairs = read_jsonl(pairs_path)
        counts[split] = {"episodes": len(episodes), "agent_views": len(views), "preference_pairs": len(pairs)}
        episode_map: dict[str, dict[str, Any]] = {}
        view_map: dict[str, dict[str, Any]] = {}

        for episode in episodes:
            context = episode.get("episode_id", "unknown_episode")
            try:
                assert_required(episode, REQUIRED_EPISODE, context)
                if episode["split"] != split:
                    raise ValueError(f"{context}: split mismatch")
                if episode["episode_id"] in all_episode_ids:
                    raise ValueError(f"{context}: duplicate episode_id")
                if len(episode["agents"]) < 2:
                    raise ValueError(f"{context}: fewer than two agents")
                agent_ids = [agent["agent_id"] for agent in episode["agents"]]
                if len(set(agent_ids)) != len(agent_ids):
                    raise ValueError(f"{context}: duplicate agent ids")
                if set(agent_ids) != set(episode["private_states"]):
                    raise ValueError(f"{context}: public agent roster/private state key mismatch")
                if episode["evaluation"].get("claims_are_empirical_measurements") is not False:
                    raise ValueError(f"{context}: synthetic result is not marked non-empirical")
                all_episode_ids.add(episode["episode_id"])
                episode_map[episode["episode_id"]] = episode
                skeletons[split].add(episode["skeleton_hash"])
                family_counts[split][episode["family"]] += 1
            except ValueError as exc:
                errors.append(str(exc))

        for view in views:
            context = view.get("view_id", "unknown_view")
            try:
                assert_required(view, REQUIRED_VIEW, context)
                if view["split"] != split:
                    raise ValueError(f"{context}: split mismatch")
                if view["view_id"] in all_view_ids:
                    raise ValueError(f"{context}: duplicate view_id")
                episode = episode_map.get(view["episode_id"])
                if not episode:
                    raise ValueError(f"{context}: missing episode")
                for field in ("family", "template_id", "skeleton_hash"):
                    if view[field] != episode[field]:
                        raise ValueError(f"{context}: {field} mismatch with episode")
                local_input = view["local_input"]
                expected_local_keys = {"public_state", "self", "institutional_interface", "received_messages", "allowed_outputs"}
                if set(local_input) != expected_local_keys:
                    raise ValueError(f"{context}: local_input keys differ from masking contract")
                leaked_keys = FORBIDDEN_LOCAL_KEYS.intersection(walk_keys(local_input))
                if leaked_keys:
                    raise ValueError(f"{context}: forbidden local keys {sorted(leaked_keys)}")
                if local_input["self"].get("agent_id") != view["agent_id"]:
                    raise ValueError(f"{context}: self agent mismatch")
                if local_input["public_state"] != episode["initial_public_state"]:
                    raise ValueError(f"{context}: actor public state differs from episode public state")
                if "private_states" in json.dumps(local_input, sort_keys=True):
                    raise ValueError(f"{context}: serialized private_states marker leaked")
                validate_output(view["target_output"], local_input["allowed_outputs"], context)
                if view["grading"]["expected_action_type"] != view["target_output"]["action_type"]:
                    raise ValueError(f"{context}: action grading mismatch")
                if view["grading"]["expected_message_type"] != view["target_output"]["message_type"]:
                    raise ValueError(f"{context}: message grading mismatch")
                if view["metadata"].get("label_type") != "author_specified_reference_policy":
                    raise ValueError(f"{context}: label status missing")
                all_view_ids.add(view["view_id"])
                view_map[view["view_id"]] = view
            except ValueError as exc:
                errors.append(str(exc))

        for pair in pairs:
            context = pair.get("pair_id", "unknown_pair")
            try:
                assert_required(pair, REQUIRED_PAIR, context)
                if pair["split"] != split:
                    raise ValueError(f"{context}: split mismatch")
                if pair["pair_id"] in all_pair_ids:
                    raise ValueError(f"{context}: duplicate pair_id")
                view = view_map.get(pair["view_id"])
                if not view:
                    raise ValueError(f"{context}: missing local view")
                if pair["episode_id"] != view["episode_id"]:
                    raise ValueError(f"{context}: episode mismatch")
                if pair["local_input"] != view["local_input"]:
                    raise ValueError(f"{context}: pair input differs from local view")
                if pair["chosen"] != view["target_output"]:
                    raise ValueError(f"{context}: chosen differs from reference target")
                if pair["chosen"] == pair["rejected"]:
                    raise ValueError(f"{context}: no causal contrast")
                if not pair["failure_tags"] or not pair["causal_contrast"]:
                    raise ValueError(f"{context}: unlabelled rejected behavior")
                for tag in pair["failure_tags"]:
                    failure_counts[tag] += 1
                all_pair_ids.add(pair["pair_id"])
            except ValueError as exc:
                errors.append(str(exc))

        if len(views) != len(pairs):
            errors.append(f"{split}: expected one preference pair per agent view")

    if skeletons["train"] & skeletons["dev"]:
        errors.append("skeleton leakage between train and dev")
    if skeletons["train"] & skeletons["test"]:
        errors.append("skeleton leakage between train and test")
    if skeletons["dev"] & skeletons["test"]:
        errors.append("skeleton leakage between dev and test")
    formal_report = validate_formal_records(corpus_dir)
    for split in ("train", "dev", "test"):
        counts[split].update(formal_report["counts"].get(split, {}))
    errors.extend(f"formal: {error}" for error in formal_report["errors"])
    warnings.extend(f"formal: {warning}" for warning in formal_report["warnings"])

    if counts != manifest["counts"]:
        errors.append(f"manifest count mismatch: observed={dict(counts)} expected={manifest['counts']}")
    if {split: dict(sorted(c.items())) for split, c in family_counts.items()} != manifest["family_counts"]:
        errors.append("manifest family count mismatch")
    if len(failure_counts) < 8:
        warnings.append("preference pairs cover fewer than eight failure tags")

    report = {
        "status": "pass" if not errors else "fail",
        "corpus_version": manifest.get("corpus_version"),
        "counts": dict(counts),
        "unique_skeletons": {split: len(values) for split, values in skeletons.items()},
        "skeleton_overlap": {
            "train_dev": len(skeletons["train"] & skeletons["dev"]),
            "train_test": len(skeletons["train"] & skeletons["test"]),
            "dev_test": len(skeletons["dev"] & skeletons["test"]),
        },
        "failure_tag_counts": dict(sorted(failure_counts.items())),
        "checks": {
            "digest_integrity": not any("digest mismatch" in error for error in errors),
            "actor_masking": not any("forbidden local" in error or "private_states marker" in error for error in errors),
            "id_uniqueness": not any("duplicate" in error for error in errors),
            "reference_status_labels": not any("label status" in error or "non-empirical" in error for error in errors),
            "split_skeleton_isolation": not any("skeleton leakage" in error for error in errors),
            "one_pair_per_view": all(counts[s]["agent_views"] == counts[s]["preference_pairs"] for s in counts),
            "formal_institutional_laboratory": formal_report["status"] == "pass",
        },
        "formal_institutional_laboratory": formal_report,
        "errors": errors[:100],
        "warnings": warnings,
    }
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus", type=Path, default=Path("corpus"))
    parser.add_argument("--report", type=Path, help="Optional JSON report path")
    args = parser.parse_args()
    report = validate_corpus(args.corpus)
    rendered = json.dumps(report, indent=2, sort_keys=True)
    print(rendered)
    if args.report:
        args.report.write_text(rendered + "\n", encoding="utf-8")
    if report["status"] != "pass":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
