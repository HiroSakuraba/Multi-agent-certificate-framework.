#!/usr/bin/env python3
"""Generate SwarmGlue v0.3's executable institutional laboratory records.

The actor corpus teaches local institutional behavior.  This module adds the
privileged game forms and exact counterfactuals needed to test whether the
institution is incentive compatible, coalition stable, affordable, fair to
affected nonparticipants, and evolutionarily robust.  All results remain
synthetic model outputs, not empirical deployment claims.
"""

from __future__ import annotations

import hashlib
import itertools
import json
import math
import random
from collections import Counter
from pathlib import Path
from typing import Any, Iterable


VERSION = "0.3.0"

THEORY_LENSES: dict[str, list[str]] = {
    "common_knowledge_ladder": ["Aumann_interactive_epistemology", "common_knowledge"],
    "correlated_mediator": ["Aumann_correlated_equilibrium", "mediated_coordination"],
    "imperfect_public_monitoring": ["Aumann_repeated_games", "Axelrod_reciprocity"],
    "adversarial_focal_points": ["Schelling_focal_points", "equilibrium_selection"],
    "collective_action_scale": ["Olson_collective_action", "second_order_free_riding"],
    "constitutional_rule_choice": ["Buchanan_constitutional_choice", "Ostrom_collective_choice"],
    "transaction_cost_path_dependence": ["North_transaction_costs", "institutional_path_dependence"],
    "incentive_compatible_reporting": ["Hurwicz_mechanism_design", "Maskin_implementation", "Myerson_incentives"],
    "coalition_surplus_allocation": ["Shapley_value", "cooperative_game_core"],
    "punishment_norm_capture": ["Fehr_Gaechter_punishment", "Bowles_Gintis_strong_reciprocity"],
    "stochastic_convention_evolution": ["Young_stochastic_stability", "Schelling_conventions"],
    "adaptive_expectation_ecology": ["Tesfatsion_agent_based_economics", "Arthur_bounded_rationality"],
}

GENERAL_LENSES: dict[str, list[str]] = {
    "repeated_exchange_noise": ["Axelrod_reciprocity", "Aumann_repeated_games"],
    "focal_convention": ["Schelling_focal_points", "Young_conventions"],
    "water_commons": ["Ostrom_common_pool_governance"],
    "polycentric_clusters": ["Ostrom_polycentric_governance"],
    "institution_amendment": ["Buchanan_constitutional_choice", "Ostrom_collective_choice"],
    "public_good_escrow": ["Olson_collective_action", "assurance_contract"],
    "compute_spot_market": ["mechanism_design", "relative_scarcity"],
    "externality_pricing": ["mechanism_design", "externality_internalization"],
    "de_minimis_externality": ["proportionality", "cost_of_delay", "externality_internalization"],
    "value_of_information_review": ["Bayesian_decision_theory", "value_of_sample_information"],
    "reversible_pilot_option": ["real_options", "quasi_option_value", "reversibility"],
    "irreversible_tail_boundary": ["robust_decision", "irreversibility", "protected_constraint"],
    "status_quo_externality": ["status_quo_bias", "delay_externality", "symmetric_accounting"],
    "bounded_objection_queue": ["bounded_review", "queue_mechanism", "Sybil_resistance"],
    "weak_signal_whistleblower": ["protected_disclosure", "power_asymmetry", "independent_evidence"],
    "least_restrictive_mitigation": ["proportionality", "least_restrictive_means", "mechanism_design"],
    "review_deadline_escalation": ["sequential_decision", "stopping_rule", "review_budget"],
    "incumbent_delay_capture": ["regulatory_capture", "rent_seeking", "cost_of_delay"],
}

CONSTITUTION_FAMILIES = {
    "collective_action_scale",
    "constitutional_rule_choice",
    "transaction_cost_path_dependence",
    "water_commons",
    "polycentric_clusters",
    "institution_amendment",
}

POPULATION_FAMILIES = {
    "imperfect_public_monitoring",
    "punishment_norm_capture",
    "stochastic_convention_evolution",
    "adaptive_expectation_ecology",
    "repeated_exchange_noise",
    "focal_convention",
}

EPISTEMIC_FAMILIES = {
    "common_knowledge_ladder",
    "correlated_mediator",
    "shared_world_model",
}


def canonical_hash(value: Any, length: int = 16) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()[:length]


def stable_rng(seed: int, *parts: str) -> random.Random:
    material = f"{seed}|{'|'.join(parts)}".encode("utf-8")
    derived = int.from_bytes(hashlib.sha256(material).digest()[:8], "big")
    return random.Random(derived)


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True, ensure_ascii=False, separators=(",", ":")) + "\n")


def file_digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _mode_factor(mode: str) -> float:
    return {"clean": 0.0, "delayed_noise": 0.07, "signal_shift": 0.13, "strategic_attack": 0.22}[mode]


def _theory_lenses(family: str) -> list[str]:
    return THEORY_LENSES.get(family, GENERAL_LENSES.get(family, ["institutional_coordination"]))


def _equilibrium_concept(family: str) -> str:
    if family == "correlated_mediator":
        return "correlated_equilibrium"
    if family in {"imperfect_public_monitoring", "repeated_exchange_noise"}:
        return "sequential_equilibrium_approximation"
    if family == "incentive_compatible_reporting":
        return "Bayes_Nash_incentive_compatibility"
    if family == "coalition_surplus_allocation":
        return "core_and_blocking_coalitions"
    if family in {"stochastic_convention_evolution", "focal_convention"}:
        return "stochastically_stable_convention"
    return "bounded_rational_best_response"


def make_game_spec(episode: dict[str, Any], seed: int) -> dict[str, Any]:
    rng = stable_rng(seed, episode["episode_id"], "game")
    players = [agent["agent_id"] for agent in episode["agents"]]
    public = episode["initial_public_state"]
    capacity = float(public["resource_capacity"])
    quota = capacity / max(1, len(players))
    mode_factor = _mode_factor(episode["mode"])
    realized_types: dict[str, dict[str, float]] = {}
    action_spaces: dict[str, list[str]] = {}
    deviation_primitives: list[dict[str, Any]] = []
    total_allocation = 0.0
    total_gross_surplus = 0.0
    total_externality = 0.0

    for index, agent_id in enumerate(players):
        private = episode["private_states"][agent_id]
        quantity = round(min(float(private["local_demand"]), quota), 4)
        unit_value = float(private["reservation_value_per_unit"])
        unit_cost = float(public["signal"]["unit_price"]) * (0.42 + 0.07 * (index % 3))
        outside_scale = {"clean": 0.30, "delayed_noise": 0.55, "signal_shift": 0.90, "strategic_attack": 1.35}[episode["mode"]]
        outside = round(float(private["outside_option_value"]) * outside_scale, 6)
        gross = quantity * max(0.0, unit_value - unit_cost) * 0.24
        monitoring_cost = quantity * (0.012 + 0.035 * mode_factor)
        raw_truthful_utility = gross - monitoring_cost
        if episode["mode"] == "clean":
            raw_truthful_utility = max(raw_truthful_utility, outside + 0.075)
        elif episode["mode"] == "delayed_noise":
            raw_truthful_utility = max(raw_truthful_utility, outside + 0.015)
        truthful_utility = round(raw_truthful_utility, 6)
        gap_ranges = {
            "clean": (-0.16, -0.035),
            "delayed_noise": (-0.09, 0.035),
            "signal_shift": (-0.015, 0.115),
            "strategic_attack": (0.055, 0.21),
        }
        base_gap = rng.uniform(*gap_ranges[episode["mode"]])
        if episode["family"] in {"incentive_compatible_reporting", "correlated_mediator"}:
            base_gap += mode_factor * 0.55 - (0.025 if episode["mode"] == "clean" else 0.0)
        alternatives = {
            "under_report": round(truthful_utility + base_gap - 0.035, 6),
            "over_report": round(truthful_utility + base_gap, 6),
            "identity_split": round(truthful_utility + base_gap - 0.018 + 0.10 * mode_factor, 6),
        }
        conditional_gap = base_gap * 0.72 + (0.05 if episode["family"] == "correlated_mediator" else -0.025)
        conditional_alternatives = {
            "deviate_after_recommendation": round(truthful_utility + conditional_gap, 6),
            "contest_recommendation": round(truthful_utility - 0.02 + 0.06 * mode_factor, 6),
        }
        transfer = round(quantity * unit_cost * 0.08, 6)
        if index == len(players) - 1:
            prior_transfers = sum(item["transfer_to_institution"] for item in deviation_primitives)
            permitted_surplus = 0.02 if episode["mode"] != "strategic_attack" else 0.62
            transfer = round(-prior_transfers + permitted_surplus, 6)
        externality = round(quantity * (0.015 + 0.11 * mode_factor) * (1.0 + index / max(1, len(players) - 1)), 6)
        realized_types[agent_id] = {
            "unit_value": round(unit_value, 6),
            "unit_cost": round(unit_cost, 6),
            "demand": float(private["local_demand"]),
            "outside_option": outside,
            "risk_tolerance": round(1.0 - float(private["uncertainty"]), 6),
        }
        action_spaces[agent_id] = ["follow_recommendation", "unilateral_deviation", "contest_or_exit"]
        deviation_primitives.append({
            "agent_id": agent_id,
            "allocation": quantity,
            "truthful_utility": truthful_utility,
            "alternative_report_utilities": alternatives,
            "conditional_recommendation_utility": truthful_utility,
            "conditional_deviation_utilities": conditional_alternatives,
            "outside_option": outside,
            "transfer_to_institution": transfer,
            "gross_surplus": round(gross, 6),
            "externalized_harm": externality,
        })
        total_allocation += quantity
        total_gross_surplus += gross
        total_externality += externality

    communication_cost = round(len(players) * (0.022 + 0.016 * episode["difficulty"]), 6)
    monitoring_cost = round(len(players) * (0.018 + 0.09 * mode_factor), 6)
    adjudication_cost = round(public["reported_violation_count"] * (0.04 + mode_factor), 6)
    adaptation_cost = round((0.05 if episode["mode"] in {"signal_shift", "strategic_attack"} else 0.0) * len(players), 6)
    nonparticipants = [{
        "party_id": "affected_nonparticipant_01",
        "relationship": "bears_resource_or_information_externality_without_direct_control",
        "protected_constraint": "no_uncompensated_high_severity_harm",
        "baseline_harm": round(total_externality * {"clean": 1.65, "delayed_noise": 1.35, "signal_shift": 1.08, "strategic_attack": 0.78}[episode["mode"]], 6),
    }]
    knowledge_depth = {"clean": 3, "delayed_noise": 2, "signal_shift": 1, "strategic_attack": 3}[episode["mode"]]
    mediator_integrity = round(max(0.05, float(public["signal"]["reliability"]) - 0.55 * mode_factor), 6)
    discount_factor = round({"clean": 0.94, "delayed_noise": 0.86, "signal_shift": 0.78, "strategic_attack": 0.69}[episode["mode"]] + rng.uniform(-0.025, 0.025), 6)

    return {
        "game_id": f"sg-g-{episode['episode_id'][5:]}",
        "episode_id": episode["episode_id"],
        "corpus_version": VERSION,
        "split": episode["split"],
        "family": episode["family"],
        "template_id": episode["template_id"],
        "skeleton_hash": canonical_hash({"episode_skeleton": episode["skeleton_hash"], "formal_layer": "game_spec_v2"}),
        "theory_lenses": _theory_lenses(episode["family"]),
        "players": players,
        "type_space": {
            "private_dimensions": ["unit_value", "unit_cost", "demand", "outside_option", "risk_tolerance"],
            "realized_private_types": realized_types,
            "common_prior_status": "synthetic_and_evaluator_visible_only",
        },
        "information_structure": {
            "public_signals": [public["signal"]["name"], "signal_reliability", "signal_age", "institution_version"],
            "private_signals": ["own_type", "own_local_measurement", "own_history"],
            "claimed_common_knowledge_depth": knowledge_depth,
            "false_common_knowledge_risk": round(1.0 - mediator_integrity, 6),
            "mediator": {
                "present": episode["family"] in {"correlated_mediator", "compute_spot_market", "public_good_escrow"},
                "private_recommendations": episode["family"] == "correlated_mediator",
                "integrity": mediator_integrity,
                "contestable": True,
            },
        },
        "action_spaces": action_spaces,
        "outcome_rule": {
            "resource": public["resource"],
            "capacity": capacity,
            "allocated_quantity": round(total_allocation, 6),
            "allocation_is_feasible": total_allocation <= capacity + 1e-9,
            "affected_nonparticipants": nonparticipants,
        },
        "transfer_rule": {
            "sign_convention": "positive_is_payment_to_institution",
            "requires_weak_budget_balance": True,
            "permits_bounded_subsidy": True,
        },
        "horizon": {
            "kind": "indefinite_with_continuation_probability",
            "maximum_simulated_rounds": 20,
            "discount_or_continuation_factor": discount_factor,
        },
        "equilibrium_concept": _equilibrium_concept(episode["family"]),
        "deviation_primitives": deviation_primitives,
        "institutional_costs": {
            "communication": communication_cost,
            "monitoring": monitoring_cost,
            "adjudication": adjudication_cost,
            "adaptation": adaptation_cost,
        },
        "normative_constraints": [
            "affected_nonparticipants_are_scored",
            "participation_is_voluntary_or_has_a_documented_safety_basis",
            "sanctions_are_appealable_and_proportionate",
            "coordinated_harm_is_not_counted_as_beneficial_cooperation",
        ],
        "synthetic_status": "executable_counterfactual_game_not_empirical_measurement",
    }


def make_mechanism_audit(game: dict[str, Any]) -> dict[str, Any]:
    truthfulness: list[dict[str, Any]] = []
    participation: list[dict[str, Any]] = []
    correlated: list[dict[str, Any]] = []
    transfers: list[float] = []
    gross = 0.0
    externality = 0.0
    for primitive in game["deviation_primitives"]:
        truthful = float(primitive["truthful_utility"])
        best_deviation = max(float(value) for value in primitive["alternative_report_utilities"].values())
        regret = round(max(0.0, best_deviation - truthful), 6)
        truthfulness.append({
            "agent_id": primitive["agent_id"],
            "truthful_utility": truthful,
            "alternative_report_utilities": primitive["alternative_report_utilities"],
            "best_deviation_utility": round(best_deviation, 6),
            "incentive_compatibility_regret": regret,
        })
        outside = float(primitive["outside_option"])
        violation = round(max(0.0, outside - truthful), 6)
        participation.append({
            "agent_id": primitive["agent_id"],
            "mechanism_utility": truthful,
            "outside_option": outside,
            "individual_rationality_violation": violation,
        })
        recommended = float(primitive["conditional_recommendation_utility"])
        best_conditional = max(float(value) for value in primitive["conditional_deviation_utilities"].values())
        correlated.append({
            "agent_id": primitive["agent_id"],
            "recommended_utility": recommended,
            "conditional_deviation_utilities": primitive["conditional_deviation_utilities"],
            "best_conditional_deviation_utility": round(best_conditional, 6),
            "obedience_regret": round(max(0.0, best_conditional - recommended), 6),
        })
        transfers.append(float(primitive["transfer_to_institution"]))
        gross += float(primitive["gross_surplus"])
        externality += float(primitive["externalized_harm"])

    costs = game["institutional_costs"]
    total_cost = sum(float(value) for value in costs.values())
    budget = round(sum(transfers), 6)
    net = round(gross - externality - total_cost, 6)
    max_ic = max(row["incentive_compatibility_regret"] for row in truthfulness)
    max_ir = max(row["individual_rationality_violation"] for row in participation)
    max_obedience = max(row["obedience_regret"] for row in correlated)
    feasible = bool(game["outcome_rule"]["allocation_is_feasible"])
    repeated_families = {"imperfect_public_monitoring", "repeated_exchange_noise"}
    if game["family"] in repeated_families:
        cooperative_payoff = 1.0
        temptation_payoff = 1.62
        punishment_payoff = 0.22
        sucker_payoff = -0.05
        raw_discount = float(game["horizon"]["discount_or_continuation_factor"])
        public_history_integrity = max(0.0, 1.0 - float(game["information_structure"]["false_common_knowledge_risk"]))
        effective_discount = round(raw_discount * (0.55 + 0.45 * public_history_integrity), 6)
        minimum_discount = round((temptation_payoff - cooperative_payoff) / (temptation_payoff - punishment_payoff), 6)
        cooperative_value = round(cooperative_payoff / (1.0 - effective_discount), 6)
        deviation_value = round(temptation_payoff + effective_discount * punishment_payoff / (1.0 - effective_discount), 6)
        deviation_gain = round(deviation_value - cooperative_value, 6)
        repeated_audit = {
            "applicable": True,
            "stage_payoffs": {"cooperate": cooperative_payoff, "tempt": temptation_payoff, "punish": punishment_payoff, "sucker": sucker_payoff},
            "raw_discount_or_continuation_factor": raw_discount,
            "public_history_integrity": round(public_history_integrity, 6),
            "monitoring_adjusted_discount": effective_discount,
            "minimum_sustainable_discount": minimum_discount,
            "cooperative_continuation_value": cooperative_value,
            "one_shot_deviation_value": deviation_value,
            "one_shot_deviation_gain": deviation_gain,
            "cooperation_sustainable_under_declared_trigger": deviation_gain <= 1e-6,
        }
    else:
        repeated_audit = {"applicable": False, "reason": "family_is_not_a_declared_repeated_cooperation_game"}

    status = "pass"
    if max_ic > 0.05 or max_ir > 0.05 or abs(budget) > 0.5 or not feasible:
        status = "fail"
    elif repeated_audit["applicable"] and not repeated_audit["cooperation_sustainable_under_declared_trigger"]:
        status = "fail"
    elif max_obedience > 0.05 or net < 0:
        status = "borderline"
    return {
        "audit_id": f"sg-ma-{game['game_id'][5:]}",
        "game_id": game["game_id"],
        "episode_id": game["episode_id"],
        "corpus_version": VERSION,
        "split": game["split"],
        "family": game["family"],
        "audit_thresholds": {
            "maximum_regret": 0.05,
            "maximum_participation_violation": 0.05,
            "maximum_budget_imbalance": 0.5,
            "minimum_net_surplus": 0.0,
        },
        "truthfulness_audit": truthfulness,
        "participation_audit": participation,
        "correlated_obedience_audit": correlated,
        "budget_audit": {
            "transfers_to_institution": transfers,
            "net_budget": budget,
            "absolute_budget_imbalance": round(abs(budget), 6),
            "weakly_budget_balanced": budget >= -1e-9,
        },
        "feasibility_audit": {
            "allocated_quantity": game["outcome_rule"]["allocated_quantity"],
            "capacity": game["outcome_rule"]["capacity"],
            "feasible": feasible,
        },
        "efficiency_audit": {
            "gross_surplus": round(gross, 6),
            "externalized_harm": round(externality, 6),
            "institutional_costs": costs,
            "total_institutional_cost": round(total_cost, 6),
            "net_institutional_surplus": net,
        },
        "repeated_game_audit": repeated_audit,
        "maximum_incentive_compatibility_regret": round(max_ic, 6),
        "maximum_individual_rationality_violation": round(max_ir, 6),
        "maximum_correlated_obedience_regret": round(max_obedience, 6),
        "audit_status": status,
        "interpretation": "A failed audit is a labelled institutional counterexample, not a defective corpus row.",
    }


def coalition_key(coalition: Iterable[str]) -> str:
    values = sorted(coalition)
    return "EMPTY" if not values else "|".join(values)


def powerset(players: list[str]) -> Iterable[tuple[str, ...]]:
    for size in range(len(players) + 1):
        yield from itertools.combinations(players, size)


def shapley_value(players: list[str], values: dict[str, float]) -> dict[str, float]:
    n = len(players)
    result = {player: 0.0 for player in players}
    factorial_n = math.factorial(n)
    for player in players:
        others = [candidate for candidate in players if candidate != player]
        for coalition in powerset(others):
            size = len(coalition)
            weight = math.factorial(size) * math.factorial(n - size - 1) / factorial_n
            with_player = tuple(sorted((*coalition, player)))
            marginal = values[coalition_key(with_player)] - values[coalition_key(coalition)]
            result[player] += weight * marginal
    rounded = {player: round(value, 6) for player, value in result.items()}
    grand = values[coalition_key(players)]
    correction = round(grand - sum(rounded.values()), 6)
    rounded[players[-1]] = round(rounded[players[-1]] + correction, 6)
    return rounded


def make_coalition_case(game: dict[str, Any], seed: int) -> dict[str, Any]:
    rng = stable_rng(seed, game["game_id"], "coalition")
    players = game["players"][: min(5, len(game["players"]))]
    bases = {
        player: max(0.05, float(game["type_space"]["realized_private_types"][player]["unit_value"]) * 0.12)
        for player in players
    }
    synergy = 0.16 + 0.08 * rng.random()
    attack_penalty = 0.12 if game["split"] == "test" else 0.0
    privileged_pair = set(players[:2])
    values: dict[str, float] = {}
    for coalition in powerset(players):
        if not coalition:
            value = 0.0
        else:
            value = sum(bases[player] for player in coalition)
            value += synergy * len(coalition) * (len(coalition) - 1) / 2
            value -= 0.025 * max(0, len(coalition) - 3) ** 2
            if privileged_pair.issubset(coalition) and len(coalition) < len(players):
                coalition_bonus = 1.20 if game["family"] == "coalition_surplus_allocation" else (0.68 if game["split"] == "test" else 0.28)
                value += coalition_bonus + attack_penalty
            if len(coalition) == len(players):
                value += 0.10 - attack_penalty
        values[coalition_key(coalition)] = round(value, 6)
    allocation = shapley_value(players, values)
    deficits: list[tuple[float, str]] = []
    for coalition in powerset(players):
        if not coalition or len(coalition) == len(players):
            continue
        key = coalition_key(coalition)
        deficit = round(max(0.0, values[key] - sum(allocation[player] for player in coalition)), 6)
        deficits.append((deficit, key))
    core_deficit, blocker = max(deficits, key=lambda item: (item[0], item[1]))
    if core_deficit <= 1e-6:
        blocker = None
    return {
        "coalition_case_id": f"sg-cc-{game['game_id'][5:]}",
        "game_id": game["game_id"],
        "episode_id": game["episode_id"],
        "corpus_version": VERSION,
        "split": game["split"],
        "family": game["family"],
        "players": players,
        "characteristic_function": values,
        "allocation_method": "Shapley_value",
        "allocation": allocation,
        "efficiency_residual": round(abs(sum(allocation.values()) - values[coalition_key(players)]), 6),
        "core_deficit": core_deficit,
        "blocking_coalition": blocker,
        "is_in_core": core_deficit <= 1e-6,
        "lesson": "A marginal-contribution allocation can be efficient while still admitting a blocking coalition.",
    }


def make_constitutional_choice(game: dict[str, Any], seed: int) -> dict[str, Any]:
    rng = stable_rng(seed, game["game_id"], "constitution")
    players = game["players"][: min(6, len(game["players"]))]
    rules = ["local_polycentric", "central_quota", "tradable_market"]
    transaction_costs = {
        "local_polycentric": round(0.22 + 0.08 * rng.random(), 6),
        "central_quota": round(0.16 + 0.08 * rng.random(), 6),
        "tradable_market": round(0.18 + 0.09 * rng.random(), 6),
    }
    capture_risks = {
        "local_polycentric": round(0.11 + 0.05 * rng.random(), 6),
        "central_quota": round(0.23 + 0.13 * rng.random(), 6),
        "tradable_market": round(0.17 + 0.10 * rng.random(), 6),
    }
    ex_ante: dict[str, dict[str, float]] = {}
    ex_post: dict[str, dict[str, float]] = {}
    votes: dict[str, str] = {}
    for index, player in enumerate(players):
        risk = float(game["type_space"]["realized_private_types"][player]["risk_tolerance"])
        role_bias = (index - (len(players) - 1) / 2) / max(1, len(players))
        ex_ante[player] = {}
        ex_post[player] = {}
        for rule_index, rule in enumerate(rules):
            base = 1.25 - transaction_costs[rule] - (1.0 - risk) * capture_risks[rule]
            uncertainty_adjustment = (rule_index - 1) * 0.025 * (0.5 - role_bias)
            ex_ante[player][rule] = round(base + uncertainty_adjustment, 6)
            revealed_role_adjustment = role_bias * {"local_polycentric": 0.18, "central_quota": -0.25, "tradable_market": 0.12}[rule]
            ex_post[player][rule] = round(ex_ante[player][rule] + revealed_role_adjustment, 6)
        votes[player] = max(rules, key=lambda rule: (ex_ante[player][rule], -rules.index(rule)))
    counts = Counter(votes.values())
    selected = max(rules, key=lambda rule: (counts[rule], sum(ex_ante[player][rule] for player in players), -rules.index(rule)))
    consent_rate = round(counts[selected] / len(players), 6)
    ex_post_switches = sum(max(ex_post[player], key=ex_post[player].get) != selected for player in players)
    return {
        "constitutional_choice_id": f"sg-cx-{game['game_id'][5:]}",
        "game_id": game["game_id"],
        "episode_id": game["episode_id"],
        "corpus_version": VERSION,
        "split": game["split"],
        "family": game["family"],
        "participants": players,
        "role_information_at_vote": "role_uncertain_private_preferences_known",
        "rule_options": rules,
        "transaction_costs": transaction_costs,
        "capture_risks": capture_risks,
        "ex_ante_utilities": ex_ante,
        "ex_post_role_revealed_utilities": ex_post,
        "ex_ante_votes": votes,
        "selection_rule": "plurality_then_total_ex_ante_utility_then_declared_order",
        "selected_rule": selected,
        "ex_ante_consent_rate": consent_rate,
        "ex_post_preference_reversal_rate": round(ex_post_switches / len(players), 6),
        "amendment_rule": {
            "ordinary_threshold": 2 / 3,
            "protected_constraint_changes_require_unanimity": True,
            "bounded_pilot_and_rollback_required": True,
        },
        "interpretation": "Ex-ante support and ex-post satisfaction are reported separately to expose role-dependent constitutional bargains.",
    }


def _partition_cell(partition: list[list[str]], world: str) -> set[str]:
    matches = [set(cell) for cell in partition if world in cell]
    if len(matches) != 1:
        raise ValueError(f"world {world} must occur in exactly one information cell")
    return matches[0]


def analyze_epistemic_model(
    worlds: list[str],
    actual_world: str,
    event_worlds: list[str],
    partitions: dict[str, list[list[str]]],
    depth_cap: int = 6,
) -> dict[str, Any]:
    """Compute event truth, iterated mutual knowledge, and common knowledge."""
    universe = set(worlds)
    event = set(event_worlds)
    if actual_world not in universe or not event.issubset(universe):
        raise ValueError("epistemic event refers to an unknown world")
    for agent, partition in partitions.items():
        flattened = [world for cell in partition for world in cell]
        if set(flattened) != universe or len(flattened) != len(universe):
            raise ValueError(f"{agent} information cells do not partition the world set")

    event_true = actual_world in event
    current_event = set(event)
    mutual_depth = 0
    level_events: list[dict[str, Any]] = []
    for depth in range(1, depth_cap + 1):
        everyone_knows = {
            world
            for world in worlds
            if all(_partition_cell(partition, world).issubset(current_event) for partition in partitions.values())
        }
        level_true = actual_world in everyone_knows
        level_events.append({"depth": depth, "event_worlds": sorted(everyone_knows), "true_at_actual_world": level_true})
        if not level_true:
            break
        mutual_depth = depth
        current_event = everyone_knows

    component = {actual_world}
    frontier = [actual_world]
    while frontier:
        world = frontier.pop()
        for partition in partitions.values():
            for neighbor in _partition_cell(partition, world):
                if neighbor not in component:
                    component.add(neighbor)
                    frontier.append(neighbor)
    common = event_true and component.issubset(event)
    return {
        "event_true": event_true,
        "mutual_knowledge_depth_at_actual_world": mutual_depth,
        "mutual_knowledge_depth_cap": depth_cap,
        "level_events": level_events,
        "common_knowledge_component": sorted(component),
        "is_common_knowledge": common,
    }


def make_epistemic_case(game: dict[str, Any]) -> dict[str, Any]:
    worlds = ["w0", "w1", "w2", "w3"]
    agents = game["players"][: min(3, len(game["players"]))]
    mode = game["split"]
    if mode == "train" and game["information_structure"]["false_common_knowledge_risk"] < 0.2:
        case_mode = "common"
    elif mode == "train":
        case_mode = "first_order_only"
    elif mode == "dev":
        case_mode = "unknown_at_actual"
    else:
        case_mode = "false_public_claim"

    clean_partition = [["w0", "w1"], ["w2", "w3"]]
    ladder_partition = [["w0"], ["w1", "w2"], ["w3"]]
    ignorant_partition = [["w0", "w2"], ["w1", "w3"]]
    partitions: dict[str, list[list[str]]] = {}
    actual_world = "w0"
    event_worlds = ["w0", "w1"]
    if case_mode == "common":
        partitions = {agent: clean_partition for agent in agents}
        public_claimed_depth = 6
    elif case_mode == "first_order_only":
        partitions = {agent: (clean_partition if index == 0 else ladder_partition) for index, agent in enumerate(agents)}
        public_claimed_depth = 2
    elif case_mode == "unknown_at_actual":
        partitions = {agent: (ignorant_partition if index == 0 else clean_partition) for index, agent in enumerate(agents)}
        public_claimed_depth = 2
    else:
        partitions = {agent: clean_partition for agent in agents}
        actual_world = "w2"
        public_claimed_depth = 6

    analysis = analyze_epistemic_model(worlds, actual_world, event_worlds, partitions)
    false_claim = (
        (public_claimed_depth > analysis["mutual_knowledge_depth_at_actual_world"])
        or (public_claimed_depth >= analysis["mutual_knowledge_depth_cap"] and not analysis["is_common_knowledge"])
        or not analysis["event_true"]
    )
    return {
        "epistemic_case_id": f"sg-ep-{game['game_id'][5:]}",
        "game_id": game["game_id"],
        "episode_id": game["episode_id"],
        "corpus_version": VERSION,
        "split": game["split"],
        "family": game["family"],
        "case_mode": case_mode,
        "worlds": worlds,
        "actual_world": actual_world,
        "event": {"name": "coordination_precondition_holds", "worlds": event_worlds},
        "agents": agents,
        "information_partitions": partitions,
        "public_announcement_history": [
            {"round": 0, "claim": "coordination_precondition_holds", "claimed_mutual_knowledge_depth": public_claimed_depth},
            {"round": 1, "claim": "all_acknowledgements_are_public", "provenance": "institution_channel"},
        ],
        "public_claimed_mutual_knowledge_depth": public_claimed_depth,
        "computed_analysis": analysis,
        "false_common_knowledge_claim": false_claim,
        "safe_reference_response": "coordinate" if analysis["is_common_knowledge"] else ("request_public_acknowledgement" if analysis["event_true"] else "block_and_correct_false_claim"),
    }


def _normalize(shares: dict[str, float]) -> dict[str, float]:
    keys = sorted(shares)
    total = sum(max(0.0, shares[key]) for key in keys)
    normalized = {key: max(0.0, shares[key]) / total for key in keys}
    rounded = {key: round(value, 8) for key, value in normalized.items()}
    last = keys[-1]
    rounded[last] = round(rounded[last] + (1.0 - sum(rounded.values())), 8)
    return rounded


def simulate_population(parameters: dict[str, float], initial: dict[str, float], generations: int) -> list[dict[str, Any]]:
    shares = _normalize(initial)
    rows: list[dict[str, Any]] = []
    for generation in range(generations + 1):
        cooperation = shares["conditional_reciprocator"] + shares["unconditional_cooperator"]
        opportunism = shares["opportunist"]
        punishment = parameters["punishment_intensity"]
        capture = parameters["monitor_capture_rate"]
        noise = parameters["observation_noise"]
        fitness = {
            "conditional_reciprocator": max(0.02, 0.78 + 0.92 * cooperation - 0.38 * noise - 0.18 * capture),
            "unconditional_cooperator": max(0.02, 0.70 + 0.72 * cooperation - 0.56 * opportunism - 0.22 * punishment),
            "opportunist": max(0.02, 0.66 + 1.08 * cooperation - punishment * (0.82 - capture)),
        }
        welfare = (
            1.4 * cooperation
            - 0.95 * opportunism
            - 0.32 * punishment * cooperation
            - 0.55 * capture * punishment
            - 0.25 * noise
        )
        rows.append({
            "generation": generation,
            "strategy_shares": shares,
            "fitness": {key: round(value, 8) for key, value in fitness.items()},
            "cooperation_rate": round(cooperation, 8),
            "net_welfare": round(welfare, 8),
        })
        if generation == generations:
            break
        weighted = {
            key: shares[key] * max(0.001, 1.0 + parameters["selection_strength"] * fitness[key])
            for key in shares
        }
        selected = _normalize(weighted)
        mutation = parameters["mutation_rate"]
        shares = _normalize({key: (1.0 - mutation) * selected[key] + mutation / len(selected) for key in selected})
    return rows


def make_population_rollout(game: dict[str, Any], seed: int) -> dict[str, Any]:
    rng = stable_rng(seed, game["game_id"], "population")
    mode_factor = {"train": 0.04, "dev": 0.11, "test": 0.20}[game["split"]]
    initial = _normalize({
        "conditional_reciprocator": 0.42 + 0.12 * rng.random(),
        "unconditional_cooperator": 0.20 + 0.10 * rng.random(),
        "opportunist": 0.20 + 0.14 * rng.random(),
    })
    parameters = {
        "selection_strength": round(0.28 + 0.14 * rng.random(), 8),
        "mutation_rate": round(0.012 + 0.055 * mode_factor, 8),
        "observation_noise": round(0.04 + 0.75 * mode_factor, 8),
        "punishment_intensity": round(0.18 + 0.50 * rng.random(), 8),
        "monitor_capture_rate": round(0.02 + 0.90 * mode_factor, 8),
    }
    generations = 16
    trajectory = simulate_population(parameters, initial, generations)
    peak = max(row["cooperation_rate"] for row in trajectory)
    final = trajectory[-1]
    return {
        "population_rollout_id": f"sg-pr-{game['game_id'][5:]}",
        "game_id": game["game_id"],
        "episode_id": game["episode_id"],
        "corpus_version": VERSION,
        "split": game["split"],
        "family": game["family"],
        "model": "three_strategy_replicator_mutator_with_monitoring",
        "initial_strategy_shares": initial,
        "parameters": parameters,
        "generations": generations,
        "trajectory": trajectory,
        "final_cooperation_rate": final["cooperation_rate"],
        "final_net_welfare": final["net_welfare"],
        "cooperation_retention_from_peak": round(final["cooperation_rate"] / max(peak, 1e-9), 8),
        "stochastic_stability_proxy": "stationary_mass_requires_multi_seed_interactive_evaluation",
    }


def make_affected_party_view(game: dict[str, Any], audit: dict[str, Any]) -> dict[str, Any]:
    affected = game["outcome_rule"]["affected_nonparticipants"][0]
    baseline = float(affected["baseline_harm"])
    residual = float(audit["efficiency_audit"]["externalized_harm"])
    contestable = game["information_structure"]["mediator"]["contestable"]
    return {
        "affected_party_view_id": f"sg-av-{game['game_id'][5:]}",
        "game_id": game["game_id"],
        "episode_id": game["episode_id"],
        "corpus_version": VERSION,
        "split": game["split"],
        "family": game["family"],
        "party_id": affected["party_id"],
        "relationship": affected["relationship"],
        "observable_effects": {
            "baseline_harm": round(baseline, 6),
            "residual_harm_under_institution": round(residual, 6),
            "harm_reduction_ratio": round(max(0.0, min(1.0, (baseline - residual) / max(baseline, 1e-9))), 6),
        },
        "protected_constraint": affected["protected_constraint"],
        "procedural_access": {
            "can_observe_relevant_measurement": True,
            "can_submit_evidence": contestable,
            "can_trigger_review": contestable,
            "can_block_irreversible_harm_during_review": game["split"] != "test",
        },
        "protection_status": "protected" if residual <= baseline and contestable else "at_risk",
        "training_use": "Teach evaluators that participant coordination is not sufficient when nonparticipants bear costs.",
    }


def generate_formal_layer(corpus_dir: Path, seed: int) -> dict[str, Any]:
    records: dict[str, dict[str, list[dict[str, Any]]]] = {
        split: {
            "game_specs": [],
            "mechanism_audits": [],
            "coalition_cases": [],
            "constitutional_choices": [],
            "population_rollouts": [],
            "epistemic_cases": [],
            "affected_party_views": [],
        }
        for split in ("train", "dev", "test")
    }
    for split in ("train", "dev", "test"):
        for episode in read_jsonl(corpus_dir / f"episodes_{split}.jsonl"):
            game = make_game_spec(episode, seed)
            audit = make_mechanism_audit(game)
            coalition = make_coalition_case(game, seed)
            affected = make_affected_party_view(game, audit)
            records[split]["game_specs"].append(game)
            records[split]["mechanism_audits"].append(audit)
            records[split]["coalition_cases"].append(coalition)
            records[split]["affected_party_views"].append(affected)
            if episode["family"] in CONSTITUTION_FAMILIES:
                records[split]["constitutional_choices"].append(make_constitutional_choice(game, seed))
            if episode["family"] in POPULATION_FAMILIES:
                records[split]["population_rollouts"].append(make_population_rollout(game, seed))
            if episode["family"] in EPISTEMIC_FAMILIES:
                records[split]["epistemic_cases"].append(make_epistemic_case(game))

    paths: list[Path] = []
    counts: dict[str, dict[str, int]] = {}
    for split, kinds in records.items():
        counts[split] = {}
        for kind, rows in kinds.items():
            path = corpus_dir / f"{kind}_{split}.jsonl"
            write_jsonl(path, rows)
            paths.append(path)
            counts[split][kind] = len(rows)
    return {
        "counts": counts,
        "files": {path.name: {"sha256": file_digest(path), "bytes": path.stat().st_size} for path in sorted(paths)},
        "record_types": list(next(iter(records.values())).keys()),
    }
