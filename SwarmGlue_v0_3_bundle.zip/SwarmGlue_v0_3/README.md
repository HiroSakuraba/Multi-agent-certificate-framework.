# SwarmGlue v0.3

## Executable institutional-intelligence training for heterogeneous multi-agent swarms

**Author:** Benjamin John Schulz  
**Version:** 0.3.0  
**Date:** 13 August 2026

SwarmGlue trains individual agents to cooperate without assuming identical goals, preferences, private information, or capabilities. Its target is plan compatibility under heterogeneity: each agent pursues a bounded private objective while interpreting and contesting scarcity signals, commitments, mediator recommendations, conventions, monitoring, sanctions, appeals, and amendable rules.

Version 0.3 retains the executable institutional laboratory and repairs a one-sided governance failure inherited from Certified Cognitive Glue. Action externalities and delay externalities now enter the same declared decision model. The corpus calculates action-harm bounds, status-quo harm, foregone benefit, review cost, expected value of sample information, review stopping, reversible-pilot admissibility, least-restrictive mitigation, and noncompensatory severe/irreversible boundaries.

## Audited contents

- 720 full episodes across 40 institutional families;
- 3,930 masked local actor views;
- 3,930 causal preference pairs;
- 720 formal game specifications and exact mechanism audits;
- 720 cooperative-game cases and affected-party views;
- 108 constitutional-choice records;
- 108 evolutionary population rollouts;
- 54 finite epistemic-partition cases;
- 180 decision cases each with a risk claim, signed delay ledger, review-value audit, pilot certificate, and proportionality audit;
- 160 isolated structural skeletons with zero split overlap;
- 11 passing unit tests.

The formal seed contains both successful and failed institutions: 463 pass, 2 are borderline, and 255 fail; 135 allocations admit a blocking coalition; 120 episodes leave an affected outsider at risk. The decision layer selects full action 90 times, review 51 times, mitigation 18 times, a reversible pilot 18 times, and protected stop 3 times; all declared arithmetic replays exactly.

## Key files

| Path | Purpose |
| --- | --- |
| `SwarmGlue_v0_3_Design.md` | Full theory, architecture, formulas, curriculum, metrics, and remaining work |
| `docs/DATA_CARD.md` | Composition, construction, intended use, and limitations |
| `docs/EVALUATION.md` | Exact, closed-loop, adversarial, and release evaluation |
| `docs/CCG_FORENSIC_AUDIT.md` | What the earlier certificate framework got right, where it was one-sided, and how v0.3 repairs it |
| `docs/SOURCES.md` | Primary-source grounding and theory-to-corpus mapping |
| `docs/AUDIT.md` | Checked-in build and validation results |
| `docs/V0_3_HANDOFF.md` | Reproduction state and next simulator work package |
| `schemas/*.schema.json` | Schemas for actor and formal records |
| `configs/curriculum.json` | Eight-stage curriculum |
| `configs/training_recipe.json` | Model-agnostic training regime |
| `configs/metric_contract.json` | Multi-dimensional metrics, ablations, and release checks |
| `scripts/generate_seed_corpus.py` | Deterministic complete-corpus generator |
| `scripts/institutional_laboratory.py` | Formal games, exact audits, coalition cases, constitutions, epistemics, and rollouts |
| `scripts/decision_math.py` | Declared-model action, delay, information-value, pilot, and protected-boundary arithmetic |
| `scripts/decision_laboratory.py` | Joined risk, delay, review, pilot, and proportionality records |
| `scripts/validate_corpus.py` | Digest, masking, leakage, split, and joined-formal audit |
| `scripts/validate_formal_records.py` | Independent exact recomputation checks |
| `scripts/validate_decision_records.py` | Exact replay of the dual-sided decision layer |
| `scripts/export_training_formats.py` | Local actor supervised and preference exports |
| `scripts/export_formal_training.py` | Formal audit chat-supervision exports |
| `scripts/build_training_exports.py` | Build every actor, preference, and formal export with a digest manifest |
| `tests/test_corpus.py` | Reproducibility and known-case tests |

## Quick start

Python 3.10+ is sufficient; the package uses only the standard library.

```bash
python scripts/generate_seed_corpus.py --out corpus --seed 57057
python scripts/validate_corpus.py --corpus corpus --report corpus/audit_report.json
python scripts/validate_formal_records.py --corpus corpus --report corpus/formal_audit_report.json
python scripts/validate_decision_records.py --corpus corpus --report corpus/decision_audit_report.json
python -m unittest discover -s tests -v
```

Export decentralized actor training data:

```bash
python scripts/export_training_formats.py \
  --views corpus/agent_views_train.jsonl \
  --pairs corpus/preference_pairs_train.jsonl \
  --sft-out /tmp/swarmglue_actor_sft.jsonl \
  --preference-out /tmp/swarmglue_actor_preferences.jsonl
```

Export exact institutional-audit tasks:

```bash
python scripts/export_formal_training.py \
  --corpus corpus \
  --split train \
  --out /tmp/swarmglue_formal_sft.jsonl
```

Build the complete checked export set:

```bash
python scripts/build_training_exports.py --corpus corpus --out exports
```

## Information boundary

Actor training uses only `agent_views_*.jsonl`. Full episodes and formal records contain privileged types, other agents' state, future reference annotations, and counterfactual outcomes. They are reserved for simulation, critics, institutional auditors, and evaluation.

## Interpretation boundary

All outcomes are synthetic. “Exact” means the calculations reproduce exactly within the declared finite game, not that the game accurately models an open deployment. A swarm is not robust because it matches offline labels. Use closed-loop heterogeneous cross-play, full ablations, unseen domains, strategic coalitions, capture tests, and affected-party evaluation before making behavioral claims.
