# Source audit — Qiu & Gill 2026

Source: `2608.18167v1.pdf`, *Adversarial Review: Structured Disagreement for Grounded Agentic Code Review*.

## Results used by Freehold Commons

Table 1 on LiveCodeBench reports:

| Method | pass / 105 | hard / 57 | agents |
|---|---:|---:|---:|
| Zero-shot | 77% | 35/57 | 1 |
| Self-Refine | 77% | 35/57 | 1 |
| Single-reviewer | 77% | 36/57 | 2 |
| Two-reviewers | 75% | 34/57 | 3 |
| MARS | **82%** | 39/57 | 5 |
| AR | **87%** | 43/57 | 3 |

The paper says AR is +5 percentage points over MARS, which is consistent with the Table 1 values 87% and 82%.

## Internal inconsistency in the paper

Nearby prose states that MARS gains +5pp and gives its pass rate as **85%**, while Table 1 gives **82%**. The prose also describes hard-task values that do not match Table 1 in the same sentence.

Therefore:

- numerical comparisons in our current deck use **Table 1**;
- do not silently “correct” the paper;
- if a publication-grade document depends on the exact MARS number, cite the table and note the internal inconsistency.

## Generalization boundary

The paper studies code generation/review. Freehold Commons uses it as evidence that interaction topology, explicit disagreement, artifact freezing, and false consensus can matter in one real agentic domain. It does not validate SCP/EDG/DSO as a general institutional safety solution.
