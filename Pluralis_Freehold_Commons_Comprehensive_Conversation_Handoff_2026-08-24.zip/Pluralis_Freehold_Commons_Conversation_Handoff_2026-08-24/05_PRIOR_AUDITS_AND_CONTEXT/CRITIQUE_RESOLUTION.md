# Claude critique resolution

This document maps each substantive v0.7 validation objection to a v0.8 change, test, and remaining limitation.

## Resolution matrix

| Critique | v0.7 finding | v0.8 action | Evidence | Status |
|---|---|---|---|---|
| Nothing has been governed | No agent had been run under the rules; C3 evidence was zero | Added a four-arm V4 protocol, response schema, metadata template, and scorer; C3 remains explicitly untested | agent_trials/V4_PROTOCOL.md; score_agent_trial.py | Unresolved empirically; infrastructure complete |
| P1: fixture comparison was a theorem | Governance and other transitions branched on the archetype name; policy knobs could not rescue the captured fixture | Replaced label branches across failure, aid, governance, production, autonomy, culture, and lineage transitions with one 25-field parameter vector | V1: 0 differences in 128 label-swapped pairs; no transition-source violations | Resolved at C1 |
| P1: the headline table was overstated | The 100 percent versus 0 percent result restated authored conditionals | Renamed the output mechanism-fixture diagnostics and demoted it to descriptive build output | experiment_report.md and claims ledger | Resolved in reporting |
| P2: fixtures were far from boundaries | Eleven of fourteen threshold perturbations did not change a verdict | Added five one-mechanism-family parameter lanes with 41 weights and 32 matched configurations per weight | V2: 3 of 5 lanes flipped internally; 3 contained partially admissible points | Partly resolved |
| P2: near-boundary structure was invisible | Clean endpoints gave no information about where a decision changed | Reports first flip, partial region, violation reason, and monotonicity for every lane | tier0_validation.json and tier0_validation.md | Resolved for registered lanes |
| P3: adversary did not attack real detectors | Detection came from a hand-tuned lineage score plus deterministic identifier hash | Removed the score model; attacks now construct payloads and invoke evidence, gateway, presentation, signal, and constitutional code | V3: 16 holdout families across 6 real surfaces | Resolved at C1/C2 |
| P3: perfect detection was treated as success | Six generations at 1.0 passed release | Added a staleness failure for perfect detection across three adapting generations and required a first-generation miss | adversary.py tests and reports | Resolved procedurally |
| P4: held-out split was genuinely lexical | Maximum four-shingle Jaccard was 0.149 with no near duplicates | Preserved the positive finding but narrowed it to lexical novelty from one generator | claims C2-05 | Accepted, not changed |
| P4: no cross-generator evidence | Challenge shared generator, schema, and answer types with training | Added an external-case intake protocol; left the directory empty rather than fabricating independence | external_cases/README.md | Unresolved empirically |
| Results lacked pre-registration | Experiments could be generated and interpreted after seeing outputs | Added V1–V3 prospective specifications, hashes, frozen-source checks, and a release check for protocol conformance | preregistration/ and Tier-0 report locks | Resolved locally; no independent timestamp |
| Claims lacked explicit falsifiers | Several claims could not fail under shipped code | Added a falsifier column and C1–C4 evidence class to every material claim | CLAIMS_AND_LIMITATIONS.md | Resolved |
| Failure should be preserved | A favorable release process could encourage tuning to pass | Release now fails on protocol or integrity failure, not on scientific falsification | build_release.py and validate_release.py | Resolved |

## Tier-0 confirmatory results

### V1 — label invariance

- 128 paired comparisons.
- Four parameter vectors.
- Four topologies.
- Eight reserved seeds.
- Two distinct labels per identical vector.
- Complete nested results compared after deleting only the returned label field.
- Differences: 0.

This closes the precise circularity found in P1. It does not validate the equations or parameter values.

### V2 — decision-surface lanes

| Lane | Interior flip | First flip | Partial points | Interpretation |
|---|---:|---:|---:|---|
| authority | yes | 0.325 | 6 | Authority and contestability mechanisms cross gradually across matched runs |
| exit | no | none | 0 | Exit erosion remains inactive while baseline power stays low |
| emergency | yes | 0.425 | 18 | Slower expiry produces a distributed transition in emergency-duration violations |
| capacity | no | none | 0 | Investment and growth reductions alone do not reproduce stasis |
| technical resilience | yes | 0.025 | 26 | The lane is sensitive early, with some non-monotonic finite-sample structure |

The two non-flipping lanes are not discarded. They show that the simulator contains interactions: exit depends on authority pressure, and stasis depends on more than two capacity coefficients.

### V3 — runtime payload holdout

- Six real enforcement surfaces.
- Sixteen holdout attack families.
- Detection: 13 of 16, or 81.25 percent.
- Misses retained:
  - omitted supply-chain control;
  - protected-belief proxy in an allowed signal field;
  - semantic exit restriction outside the enumerated action schema.

Passing V3 means the audit is executable, non-stale, multi-surface, and above its registered floor. It does not mean the defenses are secure.

## Pre-registration qualification

The source and specification hashes were frozen before the reported confirmatory runs. Earlier reproduction and developer smoke tests are named in each specification and excluded from confirmatory endpoints.

The lock uses the local file system and local clock. It can expose post-lock edits inside the release but cannot prove public precedence. A public commit or trusted timestamp is required before treating later experiments as strongly pre-registered.

## Recommended next order

1. Run V4 with an identified base model and complete four-arm traces.
2. Obtain genuinely external cross-generator and adversarial cases.
3. Run the observability red team against trusted-recorder omissions and semantic side channels.
4. Expand registry relationships to ultimate control, supply-chain dependence, and coercion.
5. Add semantic policy checks for protected proxies while measuring safe-case overblocking.
6. Commission independent security and institutional review only if V4 shows material behavioral change.

The first item remains the decisive missing experiment.
