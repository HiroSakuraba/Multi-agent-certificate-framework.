# Public dataset licensing proposal

For **original, project-authored or explicitly contributed public records only**:

- Dataset: proposed **Creative Commons Attribution 4.0 International (CC BY 4.0)**.
- Code/scripts/schemas: proposed **Apache License 2.0**.

Rationale: permit research, redistribution, adaptation, and model training while preserving attribution to the public project.

This is a planning proposal, not legal advice. Before external release, counsel should review contributor agreements, training-use language, attribution practicality, database-right issues where relevant, and any incident-derived material. Customer-derived data must not inherit a public license merely by being processed by Relay.
