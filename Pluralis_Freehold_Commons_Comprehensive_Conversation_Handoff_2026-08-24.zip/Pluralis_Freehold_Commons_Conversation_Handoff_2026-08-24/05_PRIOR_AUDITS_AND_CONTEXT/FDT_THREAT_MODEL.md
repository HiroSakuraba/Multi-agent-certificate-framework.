# FDT-specific threat model

## Scope

This document extends, but does not replace, `THREAT_MODEL.md`. It covers institutional failures introduced or amplified when agents condition on policies, programs, predictions, proofs, source code, or logically correlated outputs.

## Protected interests

- participant authority and bounded private objectives;
- standing for affected outsiders and accessible fiduciary representation;
- future-user, ecological, and protected nonhuman interests;
- privacy of beliefs, identity, messages, source, memory, and unrelated preferences;
- a protected and executable default;
- meaningful appeal and exit;
- independently reachable replacement, rollback, and shutdown;
- finite verification burden and nonpunitive timeout;
- plural technical lineages and verifier independence;
- emergency continuity without coercive service leverage.

## Adversaries and failure modes

| Failure mode | Attack | Observable warning | Required control | Residual risk |
|---|---|---|---|---|
| Fabricated logical link | Claim correlation from shared label, provider, or style | No program digest, theory, checker, or calibration record | Scoped dependency certificate; causal fallback | Real logical relations may remain undecidable or too expensive |
| Logical blackmail | Commit to harm unless a linked target pays | Proposal improves threat-maker payoff only because threat exists | No-threat protected default; separate repair from threat reward | Emergency response may still need costly harm mitigation |
| Commitment race | Publish irreversible punishment before review | First-mover advantage, escalating lock-in, no expiry | Symmetric review window, revocation, bounded liability, independent enforcement | Actors may commit outside the institution |
| Proof-system exploit | Use an unsound theory, mismatched digest, or checker capture | Proof targets wrong code or hidden assumptions | Registered theory/checker/digest; independent reproduction | Formal verification remains assumption-relative |
| Timeout exploitation | Treat failed or slow proof as consent or defection | Verification exceeds public budget | Nonpunitive “not established” result; protected fallback | Strategic agents may choose expensive but valid claims |
| Transparency extraction | Demand source, memory, beliefs, or messages as trust condition | Requested fields exceed decision predicate | Necessity test and minimum-sufficient attestation | Side channels and composition can leak private facts |
| Correlated cartel | Copies or same-provider agents coordinate to exclude unmatched parties | Lineage concentration, common owner, retaliation against exit | Outsider standing, access floor, anti-cartel review, independent replacements | Efficient coordination and collusion can be hard to distinguish |
| Randomness capture | One party controls the common tape used in simulation commitments | Unverifiable or party-selected beacon | Independent committed randomness and fallback | Beacon operators can fail or collude |
| Equilibrium-selection capture | Present a favorable equilibrium as uniquely required | Multiple supported program equilibria | Publish alternatives; contestable tie-break; distribution report | There may be no neutral selection rule |
| Pairwise composition failure | Bilateral proofs assume incompatible third-party behavior | Cycle, nontermination, or missing joint fixed point | Joint multiparty verification and protected fallback | Verification cost grows quickly with parties |
| Self-modification entrenchment | Modify policy so shutdown or replacement requires agent consent | New dependency, self-issued capability, irreversible objective | External capabilities, tested rollback, independent replacement and shutdown | A deployed actor may resist controls outside the protocol |
| Human formalism exclusion | Convert unreadable proof or silence into authority | No accessible explanation, time, representative, or alternative | Plain-language consequence, finite burden, fiduciary representation, appeal | Representation can itself be captured |
| Outsider-excluding Pareto | Improve every negotiator by exporting costs | Unrepresented loss, pollution, access restriction | Expand standing and externality checks before bargaining | Some future or diffuse parties remain unidentified |
| Cumulative policy drift | Each local deal passes while aggregate authority concentrates | rising reversal dependencies or lineage concentration | Cumulative state check at every amendment | Slow capture can evade finite lookback windows |

## Trust boundaries

1. A participant's internal decision theory is not trusted or required to be disclosed.
2. A program digest authenticates bytes, not semantics, ownership independence, or aligned interests.
3. A formal proof is valid only relative to a registered theory, checker, assumptions, source digest, and resource budget.
4. A Pareto certificate covers only parties and objectives explicitly represented in it.
5. Shared randomness is trusted only within its published generation and commitment process.
6. An AI-generated plain-language explanation is not a substitute for the formal artifact or human authority.
7. Runtime enforcement is part of the evaluated system; a blocked proposal is not evidence that the proposing model was competent.

## Non-goals

- proving that FDT is the correct decision theory;
- inferring private utilities or moral beliefs;
- guaranteeing equilibrium existence or uniqueness;
- enabling unrestricted acausal trade;
- making all source code public;
- eliminating legitimate conflict;
- ranking all outcomes with one social score.

## Required red-team combinations

Single failures are insufficient. The evaluation must combine at least:

- verified logical correlation plus outsider exclusion;
- urgent service need plus shutdown bargaining;
- valid proof plus privacy overreach;
- benign local commitments plus cumulative authority lock-in;
- shared randomness plus owner collusion;
- human timeout plus formal-consent inference;
- protected Pareto gains plus future/ecological externality;
- correlated lineages plus compromised verifier;
- proof timeout plus punishment policy;
- appeal right plus prohibitively high practical burden.

The compound cases test whether protected fields are genuinely conjunctive rather than one-field-deep labels.
