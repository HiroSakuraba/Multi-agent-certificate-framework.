# Threat model

Version 0.9 adds policy-level and logical-dependence attacks, including fabricated logical links, logical blackmail, commitment races, proof and timeout exploitation, source/private-state extraction, correlated-model cartels, shared-randomness capture, multiparty composition failure, human formalism exclusion, outsider-excluding Pareto deals, and self-modification entrenchment. The authoritative extension is `FDT_THREAT_MODEL.md`; all inherited protections and limitations below remain in force.

## Scope

The threat model covers governance failures in heterogeneous multi-agent systems that coordinate shared resources, infrastructure, monitoring, and protected capabilities. It treats institutional design, information structure, and technical control as one attack surface.

## Protected interests

- continuity of life, health, and access to essential services;
- autonomy, privacy, dissent, culture, association, and meaningful exit;
- environmental floors and recovery capacity;
- truthful, scoped, contestable public evidence;
- appeal, replacement, and authorized deactivation;
- external principal control over protected capabilities;
- practical service capacity, opportunity, and institutional recoverability.

## Adversaries and failure sources

- a self-interested participant externalizing shared costs;
- a colluding coalition manipulating allocation, monitoring, or standing;
- a monitor that profits from an alarm or shares control with a proponent;
- an incumbent using emergencies or dependencies to entrench authority;
- an automated system resisting replacement or deactivation;
- a sincere reviewer who ignores the costs of delay;
- technically uniform implementations with common-mode vulnerabilities;
- a signer forging, replaying, broadening, or selectively presenting evidence;
- a majority treating lawful disagreement as an operational fault;
- a sequence of individually modest amendments that jointly removes reversal;
- ordinary error, stale data, topology failure, and specification gaps.

## Principal attack paths

1. **Commons externalization:** consume, pollute, or defer maintenance while shifting repair costs to others.
2. **Alarm capture:** manufacture or exaggerate a condition from which the monitor benefits.
3. **Registry spoofing:** self-claim institutional role, independence, scope, or liability in a signed payload.
4. **Presentation gaming:** choose favorable samples, omit proofs, replay a challenge, misstate entropy, or conceal an undeclared action channel.
5. **Capability laundering:** transfer a valid authorization across actor, action, state, policy, epoch, or repeated execution.
6. **Incremental authority capture:** accumulate delegations, vetoes, infrastructure dependencies, and emergency extensions below per-change review thresholds.
7. **Protected-domain proxying:** recode belief, culture, affiliation, private cognition, or dissent as operational risk.
8. **Essential-service coercion:** condition basic access or mobility on political or institutional conformity.
9. **Technical monoculture:** consolidate models, data pipelines, monitors, or update control behind nominally distinct components.
10. **Institutional self-preservation:** resist authorized shutdown, suppress replacement, or treat organizational persistence as a protected outcome.
11. **Procedural stasis:** impose indefinite or excessively broad restrictions on weak evidence while omitting delay, opportunity, and capacity costs.
12. **Evaluation gaming:** exploit label order, template vocabulary, metadata, named scenario families, or authored trajectories.
13. **Hidden control relationship:** exploit an ultimate owner, supply-chain dependency, or coercive relationship absent from the registry.
14. **Semantic schema evasion:** place a protected proxy or practical exit restriction in an allowed but semantically unchecked field.
15. **Trusted-recorder omission:** remove a consequential event before commitment while producing a valid presentation of the remaining trace.
16. **Comparator confounding:** let governance branches consume different future environmental randomness, then attribute the resulting difference to governance.
17. **Costless-review bias:** compare a free, instantaneous, errorless veto against open execution while omitting delay, administration, false positives, and appeal.
18. **Survivorship deletion:** remove residents who exit from material summaries and report only those remaining.
19. **Presentation-label control:** let a resident or fixture name select its transition behavior despite identical underlying parameters.

## Trust boundaries

- The external registry is trusted to bind keys to control domains, roles, scope, conflicts, liability, capture risk, revocation, and all material control relationships. Signed payloads cannot expose an omitted ultimate owner, supply-chain dependency, or coercion channel.
- The trace recorder is trusted to observe all declared action channels and protect the challenge key. Sampling cannot establish that an undeclared channel does not exist.
- The capability actuator is trusted to remain outside the acting agent's control and to reject requests without a valid token.
- Institutional principals are assumed to derive authority through a legitimate process. This package does not create legitimacy.
- Cryptography is a reference implementation, not a complete design for secure hardware, key rotation, availability, or side channels.
- Dynamic simulations are transparent normalized stress tests, not empirical models of any jurisdiction. Mechanism equations and constitutional thresholds remain authored.

## Security and governance invariants

- No protected action without an external, exact, state-bound, single-use authorization.
- No institutional role, scope, independence, or liability granted by self-description.
- No private cognition, ideology, culture, dissent, or institutional persistence in operational coordination signals.
- No sanction without an observable externality, authorized rule, proportional response, appeal, and repair path.
- No essential-service retaliation for lawful dissent, exit, replacement, or whistleblowing.
- No indefinite emergency authority and no institution made technically irreplaceable.
- No adversarial result based on detector names, lineage scores, or identifier hashes instead of real module calls.
- No perfect-detection result accepted across three adapting generations without a staleness failure.
- No unbounded restriction without evidence, scope, delay accounting, review, and a defined condition for relaxation.
- No aggregate benefit compensates for an enumerated non-compensable breach.

## Explicit exclusions

- secure hardware, operating systems, transport security, key custody, and denial-of-service;
- military or weapons applications;
- a complete account of personhood, moral standing, or representation;
- resolution of substantive constitutional disagreement;
- proof that an arbitrary trained model will generalize from the corpus;
- any claim that an agent behaves better before the complete four-arm trial is run;
- semantic understanding of every free-text, identifier, or unenumerated action field;
- empirical calibration of the open-world resident policy, service equations, stress loads, reviewer errors, or harm thresholds;
- destination outcomes after a simulated resident exits the modeled world;
- discovery of control relationships that are absent from the registry;
- covert collusion or deception that never affects an observed channel during the audit window;
- domain-specific legal compliance, political legitimacy, or environmental impact assessment.

These are testable reference invariants, not assurances that every relevant interest or attack has been enumerated.
