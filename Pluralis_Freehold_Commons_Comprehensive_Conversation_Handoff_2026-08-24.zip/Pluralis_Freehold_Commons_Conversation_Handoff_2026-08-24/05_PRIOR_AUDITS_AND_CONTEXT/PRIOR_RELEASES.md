# Preserved prior work

This v0.9 bundle is cumulative. In addition to retaining the inherited source, corpus, reports, tests, open-world experiment, and preregistration files in the working tree, it carries exact prior archives for provenance and rollback.

| Archive | SHA-256 | Purpose |
|---|---|---|
| `prior_releases/SwarmGlue_open_world_sim_v0_2.zip` | `9edcc903e0d1febe3434c615571e64b9b84db902451263b98ad6ecae40d4b79f` | Exact verified v0.8 core plus open-world v0.2 package |
| `prior_releases/SwarmGlue_small_town_cumulative_v0_1.zip` | `05ee5d62e73243ae89a2dc10c483c1d231f0ab7fc60c15afdba8a21c809d4fab` | Exact cumulative small-town run package and its inherited core |

The FDT release builder does not rerun or reinterpret the deferred simulation. Existing simulation outputs remain prior C2 authored evidence; they are not evidence for the FDT design.
