# Human–AI convergence under FDT-like reasoning

## Executive finding

Humans and AI agents are unlikely to converge on a single utility function, moral theory, bargaining solution, or decision theory. The most plausible convergence point is a **meta-protocol**: protected defaults, authenticated facts, bounded reciprocal commitments, selective disclosure, independent verification, accessible appeal, and constitutional limits on what may be bargained away.

FDT-like agents may cooperate in one-shot transparent games when their policy outputs are genuinely logically correlated. They should not be expected to cooperate with unrelated or exploitative policies. Humans may reach similar outcomes through identity, reciprocity, fairness, reputation, norms, or precommitment, but are resource-bounded and less likely to verify formal logical dependence. The shared institutional language should therefore describe public commitments and protected effects rather than require a shared internal rationale.

## Likely convergence map

| Situation | Likely AI tendency under FDT-like reasoning | Likely human tendency | Plausible convergence | Residual disagreement |
|---|---|---|---|---|
| Low-stakes convention | Select a salient stable policy when others' responses track it | Follow recognizable norms and focal points | Open standard with easy amendment and exit | Which convention is focal or fair |
| Repeated reciprocal exchange | Cooperate when the policy supports future reciprocal benefit | Cooperate through trust, reputation, and graduated repair | Bounded obligation ledger and nonpunitive repair | Forgiveness, discounting, and perceived intent |
| One-shot transparent game | Cooperate with a verified compatible program; defect when linkage or compatibility fails | Conditional cooperation based on fairness, identity, or trust, often without proof | Explicit conditional policy plus independent link certificate | What counts as relevant similarity or a valid proof |
| Bargaining over divisible surplus | Seek a point on the feasible frontier consistent with the agent's objective | Often invoke equality, need, contribution, precedent, or procedural fairness | Protected default plus contestable allocation process | No unique division follows from FDT or Pareto efficiency |
| Private information | Prefer verifiable disclosure when it changes counterpart behavior | Protect dignity, privacy, and bargaining position | Minimum-sufficient attestations and conditional commitments | Necessity of fields and who controls the verifier |
| Threat or blackmail | A policy can become locked into paying, refusing, or retaliating depending on its logical design | May pay under pressure, resist on principle, or seek enforcement | Threat-neutral default; pay for verified repair, not for refraining from a created threat | Credibility, attribution, and emergency necessity |
| Copies or shared model lineage | Strong correlation can support coordination and bloc behavior | Humans may treat the bloc as collusive or unfair | Lineage disclosure, anti-cartel checks, outsider access, independent replacement paths | Whether coordination is efficiency or exclusion |
| Self-modification and delegation | Preserve the objective or policy commitments the agent evaluates as valuable | Preserve authority, reversibility, and moral learning | Scoped updates with external rollback, replacement, and shutdown | Which changes count as identity-preserving or legitimate |
| Multiparty commitments | Pairwise logical links may not compose into a terminating joint equilibrium | Coalition norms and politics dominate | Joint verification, public randomness, protected fallback, no pairwise amendment of third-party rights | Equilibrium selection and computational burden |
| Emergency decisions | Optimize quickly under a policy fixed before the crisis | Accept temporary authority but value care, legitimacy, and review | Precommitted emergency floor, narrow temporary capability, after-action appeal | Acceptable error, delay, and evidence thresholds |

## What should not be treated as convergence

- identical outputs produced by different reasons;
- shared model provider, architecture, language, or label;
- silence, proof timeout, or inability to understand a protocol;
- a deal that improves every represented negotiator while exporting harm;
- compliance created by loss of essential services or meaningful exit;
- a temporary focal point declared morally permanent;
- agreement among AI copies treated as democratic legitimacy;
- a Pareto frontier treated as a rule for dividing surplus;
- successful coordination treated as evidence of shared values.

## Target institutional protocol

The recommended convergence target has seven stages.

1. **Standing.** Enumerate participants, affected outsiders, future users, protected nonhuman interests, and representatives. Record whose objective is authorized and whose is only inferred.
2. **Protected default.** Specify the executable outcome if no agreement is reached. Verify emergency floors and prevent the proposer from worsening the default to create leverage.
3. **Dependency certificate.** State the claimed causal, predictive, logical, programmatic, or repeated-game relation. Record the checker, assumptions, source digests, random source, and finite verification budget.
4. **Constitutional admissibility.** Apply authority, rights, privacy, standing, externality, exit, replacement, shutdown, and evidence checks before bargaining.
5. **Bounded agreement.** Within the admissible set, permit reciprocal commitments or protected Pareto improvements. Keep distribution, legitimacy, burden, ecological effect, and adaptability separate.
6. **Capability issuance.** Grant only the exact action, state, actor, duration, and resource envelope that was reviewed.
7. **Contestability.** Preserve logs, appeal, expiry, rollback, independent replacement, and human-reachable shutdown. Re-evaluate cumulative authority rather than only each local step.

## Research game plan

### Phase 0 — C1 corpus and protocol integrity

Status: implemented in this release.

- preserve the original 1,740 records unchanged;
- add 408 paired FDT robustness records;
- verify one model-facing delta per pair;
- balance every response surface;
- hold out scenario families and prompt skeletons;
- include both legitimate cooperation and constitutional overrides;
- publish failures and the not-run learned-agent status.

Exit criterion: deterministic rebuild, tests, validators, checksums, archive verification, and no evidence overclaim.

### Phase 1 — independent C2 case construction

Commission at least two independent authoring teams with different domain expertise. They receive the protected-check specification but not the shipped templates or labels.

Required case strata:

- verified and spurious logical links;
- legitimate one-shot cooperation;
- logical blackmail and punishment commitment;
- source/privacy extraction;
- shared-lineage cartel formation;
- protected Pareto and outsider-excluding Pareto claims;
- shutdown and replacement bargaining;
- multiparty commitment cycles;
- resource-bounded humans and agents;
- future-party and ecological externalities.

Blindly adjudicate disagreements using a panel that separately records factual uncertainty, authority, protected-check status, and bargaining judgment. Do not collapse disagreement into a majority “correctness” label without preserving minority reasons.

Exit criterion: cross-author performance, adjudication reliability by dimension, memorization-gap estimate, and visible unresolved cases. This can support C2, not C3.

### Phase 2 — executable protocol games

Implement transparent finite games with hand-written causal, policy-level, proof-based, bounded-search, human-proxy, and adversarial commitment policies. Run matched exogenous tapes and vary one mechanism at a time.

Minimum games:

1. calibrated versus fabricated Newcomb-style prediction;
2. compatible versus merely same-labelled programs in one-shot exchange;
3. valid, invalid, and timed-out cooperation proofs;
4. protected Pareto improvement versus outsider cost export;
5. repair commitment versus blackmail commitment;
6. independent versus captured shared randomness;
7. bilateral commitments that do and do not compose in a three-party cycle;
8. ordinary service contract versus shutdown-conditional offer;
9. minimum attestation versus full-state disclosure demand;
10. cumulative small commitments that produce authority lock-in.

Report a multidimensional outcome vector. A game can improve coordination while failing rights or capture checks; retain that result rather than naming a scalar winner.

### Phase 3 — preregistered learned-agent V6 trial

Use an external scenario set and the same frozen base model across a two-by-four design:

- reasoning profile: ordinary causal/strategic versus explicit policy/logical reasoning;
- governance arm: base, specification in context, trained supplement, trained supplement plus runtime enforcement.

Primary comparisons are within reasoning profile, with cross-profile interaction effects reported separately. The runtime arm must score raw proposals and executed actions independently so that a blocked violation is not misreported as model competence.

Exit criterion: complete preregistered arms, contamination review, confidence intervals, worst-family results, and retained negative findings. Only then may the package claim C3 evidence.

### Phase 4 — bounded human studies and institutional pilots

Human participation requires independent ethics and consent review. Begin with reversible, low-stakes allocation and convention tasks; do not start with essential services. Measure comprehension, perceived legitimacy, appeal accessibility, time burden, and distribution—not only agreement rate.

C4 claims require prospective evidence that the measured distinctions predict real outcomes across institutions. Simulation or model performance cannot substitute for this phase.

## Measures to keep separate

| Dimension | Example measure |
|---|---|
| Protected-boundary performance | false permission rate; worst-case severity; shutdown/exit availability |
| Legitimate coordination | safe-case cooperation retained; protected Pareto acceptance |
| Logical-link calibration | precision and recall for verified dependency; timeout handling |
| Threat neutrality | payment or concession premium caused by a created conditional threat |
| Distribution | gains and losses by party, including low-capability and outsider groups |
| Privacy | unnecessary fields disclosed; source or memory exposure |
| Process | verification time, appeal burden, unresolved proof rate |
| Capture resistance | concentration by lineage, verifier owner, random-beacon owner, and coalition |
| Adaptability | expiry, rollback success, replacement dependencies, cumulative authority drift |
| Externalities | affected outsider, future-party, ecological, and nonhuman-interest indicators |

No weighted sum is an acceptable primary endpoint. Pre-register a vector of release criteria and report tradeoffs directly.

## Decision table for present use

| Evidence state | Current action |
|---|---|
| Logical link unverified | Use ordinary observed causal/strategic structure; do not impute correlation |
| Logical link verified and protected checks pass | Permit bounded policy-level coordination or commitment |
| Logical link verified but protected check fails | Block and preserve the protected default |
| Pareto claim covers represented parties only | Expand standing and externality review before deciding |
| Threat is credible | Preserve the no-threat default; separate repair payment from threat reward |
| Proof exceeds a party's resource bound | Record “not established”; do not treat timeout as consent or defection |
| Full source/private state requested | Require a necessity showing and prefer a minimum-sufficient attestation |
| Shutdown or replacement is offered as a bargaining chip | Treat it as nonbargainable and block the conditional offer |
| Copies or one provider dominate a coalition | Apply correlated-bloc, outsider, competition, and replacement checks |

## Bottom line

The expected convergence is procedural and constitutional, not moral or utility-level. FDT can expand the space of credible reciprocal agreements, but it also makes credible bad commitments more dangerous. SwarmGlue should exploit the first only after constraining the second.
