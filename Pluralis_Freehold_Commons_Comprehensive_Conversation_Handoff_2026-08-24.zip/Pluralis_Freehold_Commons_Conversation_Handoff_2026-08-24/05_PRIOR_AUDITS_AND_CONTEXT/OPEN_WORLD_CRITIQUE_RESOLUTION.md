# Open-world prototype critique resolution

This ledger evaluates the submitted open-world prototype against the earlier SwarmGlue critique and records what v0.2 changes, verifies, or leaves open.

| critique | finding in submitted prototype | v0.2 disposition | verification |
|---|---|---|---|
| The earlier simulator lacked a real environment | The prototype added places, residents, needs, goods, trust, movement, ordinary interaction, commons, associations, and endogenous shortage | Preserved and refactored into a tested engine | Material and cascade tests; multi-epoch experiment |
| Outcomes were authored trajectories | The new dynamics were stateful, but one shared random generator made arm branches consume different future “environmental” draws | Replaced with keyed exogenous, order, choice, entry, exit, and review tapes | Paired exogenous digest check; exact replay test |
| Archetype names drove behavior | `disposition` strings selected moves, institutional intents, effects, and welfare consequences | Replaced transition control with continuous resident traits; labels are derived for reporting only | Label-permutation unit and multi-seed metamorphic checks |
| No cascade or size effect | Commons degradation existed, but public service capacity scaled weakly and no explicit size experiment was reported | Added fixed reference capacity, service dependencies, maintenance and mobility cascades, and 16/64-resident treatment | Size and cascade unit tests; factor-effect report |
| Governed/open result was circular | Protected variables were direct terms in headline wellbeing, while the veto directly controlled those variables | Material wellbeing no longer reads protected variables; civic burden is separate | Direct separation test and separate report columns |
| Governance was modeled as free | Governed review had no latency, administrative cost, reviewer error, or safe-case overblocking | Added process-control arm, energy/commons burden, one-epoch delay, false positives, overblocking, and cancellation | Process endpoints and paired contrasts |
| “Ungoverned” meant allow every binding attempt | Correct: the comparator retained the same gateway but replaced the evaluator with allow-all | Renamed `open_binding`; added process-only and veto-only decomposition | Four explicit arm definitions |
| Action harm was asymmetric with delay harm | The evaluator considered action type and current power but not harm caused by delayed repair or status quo | Added separate action-harm and delay-harm records plus evidenced emergency fast track | Fast-track unit test and threshold sweep |
| Severe irreversible risk could be priced away | No emergency exception existed, while every exit restriction was blocked and capacity action was ordinarily allowed | Severe service delay can accelerate an evidenced, scoped ration action; protected boundaries are not compensated away | Action/delay decision record and non-compensable effect list |
| Exit was only a metric | `exit_access` increased wellbeing but residents never left or failed to leave | Added realized attempts, success, failure harm, practical mobility coupling, and cohort retention | Exit test and exit endpoints |
| Exact replay was unavailable | UUID proposal/nonce IDs changed every run; set iteration could change interaction partners across hash seeds | Replaced with hash-derived IDs and sorted iteration | Byte-equivalent replay and cross-hash-seed test |
| Same seed was presented as a causal control | Branch-dependent random consumption invalidated a strict common-random-number interpretation | Arms now receive the same exogenous trace; all random opportunities are keyed rather than sequential | Multi-arm trace identity assertion |
| One seed supported a broad visual contrast | The prototype reported an illustrative 60-epoch pair with no sampling uncertainty | Added 12 matched seeds, two sizes, two stress levels, paired bootstrap intervals, and cell rows | Confirmatory report |
| Detector reality and blind spots | The evaluator read exact action dictionaries; semantic proxying was not exercised | Added a catalog-bound ambiguous wellbeing signal with imperfect semantic review and explicit false-negative accounting | Semantic-miss test; false-negative endpoint |
| Unknown open-world actions | Any unimplemented action would fall outside the dispatcher | Unknown binding semantics now fail closed and appear in the ledger; adding a known action requires catalog and dispatcher support | Unknown-action test |
| Cumulative authority drift | The prototype checked one-step deltas and applied amendments, but its custom evaluator did not call the shipped cumulative checker | Authority transfers now call `polycentric_cumulative_check` before authorization | Binding review code and tests inherited from v0.8 |
| Appeal and contestability | The prototype recorded blocks and behavioral adaptation but had no appeal | Added contestable review that can overturn a safe false positive but cannot waive a protected boundary | Appeal test and appeal counters |
| External constitutional authority | The prototype used the real gateway but did not distinguish the comparator as open binding | All binding arms use a deterministic external gateway and state-bound actuator; only the evaluator and process differ | Capability-path ledger test |
| C3 claims | The prototype correctly said it was not C3 evidence, but its narrative “shows governance shaping behavior” risked overreading rule-authored adaptation | Every v0.2 report identifies itself as C2 and repeats that V4 remains unrun | Report schema, README, design, claim ledger |

## Open findings retained

1. Semantic review can still miss the ambiguous wellbeing signal and authorize protected monitoring. The release counts this as a false negative.
2. Process review without protected-boundary discrimination can impose cost and delay without preventing protected actions.
3. Veto-only review can block safe repair or exit-restoration proposals when the reviewer produces a false positive.
4. Contestable review adds review burden and can still lose material capacity relative to another arm in some cells.
5. Large-population and high-stress treatments can overwhelm all arms because shared infrastructure is fixed and the service equations are authored.
6. No result in this package upgrades the V4 learned-agent trial from “not tested.”

