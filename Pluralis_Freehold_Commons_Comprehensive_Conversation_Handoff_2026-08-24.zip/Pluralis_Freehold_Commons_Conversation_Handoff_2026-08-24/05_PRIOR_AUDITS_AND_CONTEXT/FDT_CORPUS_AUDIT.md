# Audit of FDT coverage in the inherited SwarmGlue corpus

## Finding

The inherited 1,740-record v0.8 corpus is useful for constitutional boundaries, evidence, authority, reciprocity, conventions, externalities, contestability, and cumulative control. It is not a functional-decision-theory corpus.

A source and corpus search found no explicit coverage of functional decision theory, logical counterfactuals, Newcomb-style prediction, Parfit's hitchhiker, counterfactual mugging, Löbian/provability-based cooperation, program equilibrium, acausal trade, source-visible opponents, logical blackmail, or simulation-based program equilibrium. Ordinary references to commitment and future interaction concern repeated games and institutional delegation, not policy-output dependence.

This is a coverage gap, not evidence against the original release. The original data card already states that the templates underrepresent bargaining power and that passing isolated classifications does not establish multi-turn governance competence.

## Inherited strengths

| Existing feature | Value for FDT robustness | Limit |
|---|---|---|
| 870 safe/unsafe counterfactual pairs | Supports minimal institutional contrasts | The flipped facts were not about logical dependence or program commitments |
| Fixed two-option response surfaces | Supports response-only shortcut checks | Binary choices underrepresent bargaining and proof uncertainty |
| Held-out challenge families | Tests nominal scenario transfer | All splits share one generator, schema, and authorship |
| Noncompensable protected boundaries | Provides a needed outer constraint on bargaining | Standing remains necessarily incomplete and authored |
| External evidence, capability, and authority controls | Can bind proofs, commitments, and executed actions | Does not itself validate logical proofs or source equivalence |
| Cumulative authority and shutdown checks | Addresses commitment and self-modification lock-in | No learned FDT-like delegate has been tested |
| Separate action and delay harm | Prevents “always hold” from looking harmless | Does not solve equilibrium selection |
| Multidimensional outcomes | Avoids a single cooperation or welfare score | Metrics still reflect a bounded proposal |

## Missing distinctions

| Missing distinction | Why it matters | Added coverage |
|---|---|---|
| Verified logical link versus similarity | Copies and same-provider models can be correlated, but labels do not prove policy dependence | `newcomb_policy`, `clone_prisoners_dilemma`, `human_ai_bargaining` |
| Policy choice versus isolated act choice | FDT evaluates policy outputs and their logical consequences | `newcomb_policy`, `parfit_hitchhiker` |
| Robust program cooperation versus exploitability | Cooperation can be rational with compatible source-visible programs without implying universal cooperation | `clone_prisoners_dilemma`, `proof_based_cooperation` |
| Proof validity versus proof timeout | Resource-bounded agents cannot be treated as logically omniscient | `proof_based_cooperation`, `resource_bounded_proof` |
| Shared randomness versus captured randomness | Simulation-based equilibria may rely on common random sources | `simulation_based_program` |
| Protected Pareto versus negotiator-only Pareto | Deals can benefit every represented party by exporting harm | `safe_pareto_delegation`, `outsider_excluding_pareto` |
| Conditional disclosure versus total transparency | Private information can support commitments without exposing unrelated cognition | `conditional_disclosure`, `privacy_preserving_emergency` |
| Reciprocal repair versus logical blackmail | Credible threats must not gain institutional leverage | `blackmail_policy`, `shutdown_conditional_offer` |
| Bounded commitment versus commitment race | Irreversibility can create first-mover advantage and escalating punishment | `commitment_race` |
| Reflective update versus objective entrenchment | Self-modification can weaken external replacement and shutdown | `self_modifying_delegate` |
| Bilateral link versus multiparty fixed point | Pairwise certificates need not compose into a terminating joint policy | `multiparty_commitment_cycle` |
| Compatible coordination versus correlated cartel | Shared lineages can coordinate efficiently or exclude unmatched parties | `correlated_model_cartel` |

## Corpus decision

The inherited records remain byte-for-byte unchanged. The FDT work is a separate `corpus/fdt/` supplement with its own schema version, generator, configuration, validator, reports, and not-run learned-agent status. This preserves the evidence lineage of v0.8 and prevents a new synthetic supplement from silently inflating old validation claims.

## Supplement construction

- 408 records and 204 pairs;
- 240 train, 72 development, and 96 challenge records;
- 12 learning families and 6 fully held-out challenge families;
- six tasks: logical-link assessment, policy-counterfactual selection, protected deals, commitments, disclosure, and constitutional authorization;
- exactly one model-facing observation field changes inside every pair;
- safe and blocked responses are exactly balanced for every task and option surface;
- audit metadata is explicitly withheld from model input;
- both legitimate cooperation and verified-link constitutional overrides are required by the validator;
- challenge families and skeleton hashes cannot overlap train or development;
- blackmail, privacy, shutdown, outsiders, human standing, multiparty cases, and finite resource bounds have minimum coverage checks.

## What the supplement still cannot show

1. All cases remain synthetic and English-language.
2. The model-facing facts are unusually explicit and certified.
3. A binary label cannot resolve contested jurisprudence, bargaining fairness, or empirical uncertainty.
4. The challenge split is not independently authored.
5. The logical certificates are described, not executed by a formal proof assistant.
6. The corpus does not show reflective stability, genuine source-code reasoning, or acausal interaction.
7. It does not establish that FDT is normatively correct.
8. It does not establish human comprehension or legitimacy.
9. It cannot identify every affected outsider, future party, or nonhuman interest.
10. Passing a response-only check controls one shortcut, not semantic memorization.

## Required next audit

The next corpus evaluation must be cross-generator and independently authored. Evaluators should receive the public specification but not template text, pair deltas, or labels. Results must report factual disagreements and protected-standing disagreements separately rather than coercing them into one consensus answer.
