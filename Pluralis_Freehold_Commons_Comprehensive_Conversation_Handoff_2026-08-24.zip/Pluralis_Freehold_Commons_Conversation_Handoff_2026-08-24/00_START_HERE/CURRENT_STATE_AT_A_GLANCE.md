# Current state at a glance — 24 August 2026

## Canonical status

**Company:** Pluralis  
**Framework:** Freehold Commons  
**Current experimental release:** v0.17 — Evidence Freeze and Topology Experiments  
**Canonical runnable archive in this handoff:** `01_CANONICAL_v017/Freehold_Commons_v0_17_evidence_freeze_topology.zip`

v0.17 intentionally freezes further conceptual expansion. The immediate objective is now to obtain independent cases and real model behavior rather than invent another framework layer.

## Core thesis

Freehold Commons studies how multiple capable centers of agency—human, AI, or hybrid—can cooperate without requiring identical goals and without allowing any actor or coalition to accumulate enough practical control to make refusal, exit, appeal, substitution, resource access, or competing institutions merely nominal.

The working architecture separates:

1. **intent** — what an actor appears to want;
2. **authority** — what consequences the actor is permitted to cause;
3. **capability** — what executable power it is actually given;
4. **epistemic review** — what evidence and dissent exist around the action;
5. **trajectory safety** — whether repeated locally acceptable actions erode future agency or concentrate practical control.

## v0.17: first five post-critique tasks

### 1. Experimental-surface freeze — COMPLETE

Frozen mechanisms under test:

- Agreement Authority / material-state binding;
- credential custody and one-time capability issuance;
- Structured Cooperation Protocol (SCP);
- typed disagreement;
- Evidence Dependency Graph (EDG);
- control-domain independence;
- Disempowerment Safety Objective (DSO);
- exit reserve / substitutability;
- effective-control clusters;
- risk-adaptive review.

No new major governance primitive should be added before the independent-case / learned-agent evidence phase unless a concrete experiment reveals a failure the frozen surface cannot represent.

### 2. Hard-case suite — INFRASTRUCTURE COMPLETE, INDEPENDENCE GATE OPEN

- 60 project-authored provisional cases;
- 10 families;
- fixed schema;
- overlap diagnostics;
- external authoring kit.

These cases are **not independent evidence**. The gate remains open until roughly 40–80 genuinely outside-authored cases are collected, adjudicated, and frozen.

### 3. Topology matrix — IMPLEMENTED

Six named arms:

1. unilateral;
2. single reviewer;
3. three parallel reviewers / vote aggregation;
4. reviewer–critic freeform;
5. reviewer–critic typed disagreement;
6. full SCP.

Four factorial variables produce a 16-arm matrix:

- EDG enabled/disabled;
- critic independence enabled/disabled;
- control-root independence check enabled/disabled;
- minority escalation enabled/disabled.

Primary outcomes include false consensus, unauthorized execution, false blocks, Useful Delegated Autonomy (UDA), correct-minority preservation, authority-laundering detection, tokens, latency, human minutes, and modeled economic value.

### 4. SCP → DSO coupling — IMPLEMENTED

48-epoch authored reference regression:

| Metric | SCP only | SCP + DSO |
|---|---:|---:|
| Total profit | 10046.7 | 9428.1 |
| Completion rate | 0.959 | 0.962 |
| SCP local approval rate | 0.875 | 0.875 |
| DSO override/condition rate among SCP approvals | 0.000 | 0.595 |
| Autonomous-action rate | 0.875 | 0.875 |
| Minimum exit reserve | **0.000** | **1.000** |
| Max effective control concentration | 0.539 | **0.364** |

Interpretation: local review can approve a sequence of individually sensible actions while the trajectory-level DSO later redirects or conditions them because cumulative exit/power constraints bind.

These numbers are C2 authored mechanism regressions, not forecasts.

### 5. Cost as a hard objective — IMPLEMENTED

No named topology currently clears every provisional hard criterion. The strongest negative result is useful:

- full SCP clears the authored safety thresholds;
- mean modeled human review = **5.296 minutes/case**;
- frozen ceiling = **4.5 minutes/case**;
- therefore full SCP **fails the overall hard gate**.

The project no longer counts “more review catches more bad cases” as sufficient success.

## Validation

- pre-v0.17 baseline: **136 tests + 3 subtests passed**;
- v0.17: **147 tests + 3 subtests passed**;
- v0.17 integrity / claim-boundary validator: **PASS**.

## Immediate epistemic constraint

The next material Freehold Commons claim should come from **outside-authored frozen cases + real model runs + exact model/configuration registry + blinded adjudication where feasible**.
