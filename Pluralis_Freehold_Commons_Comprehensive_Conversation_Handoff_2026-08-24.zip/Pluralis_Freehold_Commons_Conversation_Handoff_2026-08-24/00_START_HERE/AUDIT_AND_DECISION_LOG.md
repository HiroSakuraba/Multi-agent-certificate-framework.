# Audit and decision log — latest critique cycle

## Critique that triggered v0.17

The latest external-style critique argued that the project’s strongest conceptual advances—false consensus, typed disagreement, evidence provenance, control-domain independence, DSO, and plural-agency framing—were outrunning independent behavioral evidence.

The critique made six central points:

1. the evidence gap had become the central research risk;
2. interaction topology was still under-operationalized;
3. SCP and DSO needed tighter executable coupling;
4. commercial and safety tracks risked rhetorical evidence leakage;
5. plural-agency / Freehold language could become too abstract if not attached to measurable failure modes;
6. review cost and useful autonomy needed to become primary objectives rather than secondary diagnostics.

## Assessment

### Strong agreement

- **Evidence gap:** correct. The marginal value of another framework concept has fallen; the marginal value of an experiment capable of falsifying the framework has risen sharply.
- **Topology:** correct. SCP should be treated as a topology hypothesis, not a revealed optimum.
- **Cost:** correct. Safety bought through routine review overload is not a complete success.
- **Separate evidence ledgers:** correct. Product evidence and safety evidence may share primitives but cannot borrow credibility from each other.

### Nuance / partial disagreement

- **SCP ↔ DSO coupling** already existed conceptually before v0.17. What was missing was a behavioral/trajectory demonstration of that separation. v0.17 now includes the 48-epoch coupled regression.
- **Commercial versus research direction** does not require a strategic divorce. Pluralis and Freehold Commons can remain connected through shared primitives, but they require separate scoreboards and claim boundaries.
- **Concrete framing** should not always mean dollar-denominated examples. Pluralis should lead with transactions and money; Freehold Commons can also use power-denominated examples such as provider concentration, fallback capacity, revocation latency, policy-root control, or exit reserve.
- **v0.15 evidence** was more informative than simple conformance because the authored economy exposed a “safe by paralysis” failure and forced remediation. It remained C2.

## Important omission identified during review

The critique did not fully emphasize what may be the most Freehold-specific experiment:

> Can individually rational, locally authorized, well-reviewed agents collectively construct an institution that none of the participants would have accepted at the beginning?

That is the core longitudinal problem. A sequence can contain no rogue act, no obvious policy violation, and no single catastrophic step while still producing high concentration, nominal rather than meaningful exit, and practical dependence on a narrow control root.

v0.17’s SCP-only versus SCP+DSO regression is the first direct executable test of this distinction.

## Resolution implemented in v0.17

The first five post-critique actions were executed:

1. freeze the experimental surface;
2. prepare a hard-case suite + external authoring protocol;
3. implement a topology matrix;
4. couple SCP local approval to DSO trajectory review;
5. promote cost/UDA to hard Pareto gates.

## Decision now in force

**Do not add another major conceptual subsystem.**

The next high-value work is outside-authored cases and real model runs against the frozen surface. A new subsystem requires an explicit freeze exception tied to an observed failure the current architecture cannot represent.
