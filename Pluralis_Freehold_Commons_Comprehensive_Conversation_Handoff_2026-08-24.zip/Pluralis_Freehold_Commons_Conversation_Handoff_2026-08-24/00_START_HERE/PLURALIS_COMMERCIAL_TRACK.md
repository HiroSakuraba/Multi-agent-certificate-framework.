# Pluralis commercial track — current handoff

## Narrow initial product thesis

Pluralis is testing whether enterprises will pay for an independent execution-control layer that allows AI agents to perform approved business actions **without holding the organization’s standing provider credentials**.

Initial wedge: **vendor renewals**.

Concrete example:

- procurement agent proposes a $180k renewal;
- employee delegation limit is $100k;
- agent may have Docusign/ERP API access, but that does not imply authority to execute this transaction;
- Pluralis checks current agreement state + delegation + material changes;
- if authorized, a broker issues a short-lived one-use credential bound to that action/state;
- otherwise the system asks for clarification, second approval, escalation, or denial.

## Why vendor renewals

- existing delegation-of-authority (DoA) matrices often already encode spend limits;
- an economic buyer can be identified in Procurement Ops;
- mistakes have legible dollar costs;
- repeated volume can measure false blocks, review burden, cycle time, and useful autonomy.

## Current pricing hypothesis

- productized renewal workflow: roughly **$12k–$24k annual entry**;
- if policy encoding remains custom / enterprise-heavy: **$75k–$150k** range is the honest fallback.

These are hypotheses, not observed willingness-to-pay.

## Commercial falsifiers that remain open

1. **20 procurement interviews** — test whether buyers value an independent/vendor-neutral layer rather than expecting the platform to own this control.
2. **Real DoA encoding** — can a customer renewal playbook be encoded in under one working day?
3. **Provider sandbox** — can credential custody be truly preventive under real identity/provider configuration rather than only modeled in code?
4. **Real extraction calibration** — measure per-field error and confidence on real or independently authored redlines.
5. **Pricing fork** — quote embedded/platform-native versus independent/vendor-neutral versions and measure whether willingness to pay survives independence.

## North-star operating metric

**Useful Delegated Autonomy (UDA):** safe routine actions completed without human review, subject to a hard ceiling on severe unauthorized execution and an explicit review budget.

## Boundary with Freehold Commons

Pluralis may commercialize shared primitives such as material-state binding, credential custody, review provenance, and policy/authority checks. Freehold Commons safety results do not count as commercial validation, and Pluralis customer validation would not by itself establish catastrophic-risk mitigation.
