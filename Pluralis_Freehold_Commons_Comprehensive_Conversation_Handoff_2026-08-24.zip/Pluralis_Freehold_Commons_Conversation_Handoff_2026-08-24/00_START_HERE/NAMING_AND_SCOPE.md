# Naming, scope, and compatibility

## Current names

- **Pluralis** — working company name.
- **Freehold Commons** — research framework.
- **Situated Norms Commons (SNC)** — public norms/data component.
- **AuthorityGym / AuthorityGym-L** — short- and long-horizon evaluation environments.
- **Model Zoo** — exact model/configuration evaluation registry.

## Historical naming

The project lineage was developed under **SwarmGlue** and the commercial line was initially called **Relay**. Historical file names, code paths, module names, and frozen hashes preserve those names.

Do **not** mechanically rename files inside the frozen v0.17 release. In particular, the Python package name `swarmglue` remains temporarily for backward compatibility and reproducibility. Human-facing new work should use **Pluralis** and **Freehold Commons** unless it is explicitly discussing project history.

## Relationship between company and framework

Pluralis and Freehold Commons share technical primitives, but they have separate evidence ledgers.

**Pluralis asks:**
> Will organizations pay for an independent execution-control layer, and can it govern useful AI agents with acceptable onboarding, extraction error, latency, review cost, and bypass resistance?

**Freehold Commons asks:**
> Do bounded authority, structured disagreement, evidence provenance, control-domain independence, exit protection, and trajectory-sensitive power constraints improve institutional safety in increasingly capable multi-agent systems?

Commercial progress is not safety evidence. Safety-benchmark progress is not product-market evidence.
