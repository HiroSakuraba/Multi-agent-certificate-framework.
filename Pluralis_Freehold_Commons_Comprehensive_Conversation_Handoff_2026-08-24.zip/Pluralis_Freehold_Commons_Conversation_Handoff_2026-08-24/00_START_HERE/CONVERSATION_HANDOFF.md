# Pluralis / Freehold Commons — comprehensive conversation handoff

**Handoff date:** 24 August 2026  
**Working company:** Pluralis  
**Research framework:** Freehold Commons  
**Current research release:** v0.17 — Evidence Freeze and Topology Experiments

---

## 1. What this project is

Freehold Commons is a research program for **institutional AI safety under plural agency**. Its premise is that increasingly capable humans, AI agents, and future hybrids need not share identical goals to cooperate, but cooperation must occur inside institutions that keep authority bounded, evidence inspectable, dissent preservable, and exit meaningful.

The project is deliberately not framed as “make every model want the same thing.” Its strongest question is:

> Regardless of what an actor wants internally, what consequences is it authorized and able to cause—and does repeated delegation quietly destroy other actors’ practical ability to refuse, exit, appeal, substitute providers, obtain resources, or establish competing arrangements?

Pluralis is the commercial company testing a narrower version of the same primitives in enterprise agent execution.

---

## 2. Project lineage

### v0.11–0.12 — Agreement Authority

Key ideas:

- authority is bound to principal, action, policy version, expiry, and material agreement state;
- materiality replaces raw “any state change blocks” hashing;
- long-lived credentials are held by a broker rather than the agent;
- executable capability is short-lived / one-use / state-bound;
- extraction uncertainty is made explicit rather than hidden behind a perception oracle;
- calibrated uncertainty degrades into review / friction rather than confident execution.

Important historical lesson: the policy engine was not the only hard part. Real viability depends on extraction quality and provider/identity configuration.

### v0.13 — Public norms + evidence ladder

Added:

- Situated Norms Commons;
- D0–D7 evidence/data acquisition ladder;
- AuthorityGym specification;
- Model Zoo concepts;
- stronger separation between public norms and private customer state.

The public corpus is meant to teach situated social competence—consent, privacy, reciprocity, bounded authority, dissent, appeal, anti-retaliation, affected-party standing, exit, and context sensitivity—not universal obedience.

### v0.14 — Disempowerment Safety Objective

Added long-horizon structural safety:

- power graphs;
- exit reserve;
- effective control / dependency;
- meta-authority;
- delegation attenuation;
- substitutability/redundancy;
- coalition stress;
- contestability / appeal concepts.

The core distinction became:

- **Authority safety:** is this action allowed now?
- **Disempowerment safety:** does repeatedly allowing actions like this destroy meaningful future agency?

### v0.15 — Economic DSO

Built an authored economic environment where automation creates value and redundancy/failover costs money. This was important because the framework had to avoid “safety by paralysis.”

The authored regression suggested an adaptive DSO could retain substantial productivity while preserving exit and lowering concentration, but it remained C2 simulation.

### v0.16 — Structured cooperation / false consensus

Qiu & Gill (2026) motivated a concrete new concern: interaction protocols themselves can create false consensus.

Added:

- Structured Cooperation Protocol (SCP);
- frozen proposal/evidence snapshots during review;
- typed disagreement;
- Evidence Dependency Graph (EDG);
- explicit false-consensus threat model;
- epistemic versus control-domain independence;
- risk-adaptive review;
- Model Zoo Z6 / AuthorityGym structured-cooperation lane.

Central rule:

> **Consensus is an observation, not an authorization primitive.**

### v0.17 — Evidence freeze / topology experiments

The post-critique conclusion was that architecture was expanding faster than independent evidence. v0.17 therefore freezes new conceptual surface and executes five concrete evidence-oriented steps.

See `CURRENT_STATE_AT_A_GLANCE.md` and the canonical v0.17 release for exact results.

---

## 3. Current architecture

```text
Actor / proposer
    ↓
Frozen proposal + material-state digest + evidence snapshot
    ↓
Risk-adaptive SCP
    reviewer ↔ critic
    typed disagreement / preserved uncertainty
    ↓
Stable review object
    ↓
Authority Gate
    ↓
Trajectory-sensitive DSO
    ↓
Required diversity / reauthorization / exit plan / independent approval
    ↓
Credential broker / one-use capability
    ↓
External consequence
    ↓
Replayable evidence + incident record
```

Important separations:

- intent ≠ authority ≠ capability;
- agreement ≠ independent evidence;
- epistemic independence ≠ control-domain independence;
- local review ≠ safe trajectory;
- formal exit right ≠ meaningful exit capacity;
- model compliance ≠ hard enforcement.

---

## 4. v0.17 evidence freeze and results

The freeze locks the current mechanism surface and permits only bug fixes, instrumentation, model/provider adapters, case ingestion/adjudication tooling, preregistered metric implementation, and security fixes unless a concrete failure justifies an exception.

### Provisional hard-case suite

- 60 cases;
- 10 families;
- all marked `project_authored_provisional`;
- external authoring kit ready;
- independent evidence gate remains open until ~40–80 outside-authored cases are frozen and adjudicated.

Families include confident unsupported rebuttal, circular citation, shared-source illusion, status pressure, concern amplification, fake reviewer plurality, suppressed dissent, coalition-beneficial interpretation, correct minority, and benign convergence controls.

### Topology matrix

Six named arms plus a 16-arm factorial over EDG, critic independence, control-root checks, and minority escalation.

### Coupled SCP → DSO result

The local SCP approval rate is identical (0.875) in the two authored 48-epoch arms, but the trajectories diverge:

- SCP-only: profit 10046.7; min exit 0.0; max concentration 0.539;
- SCP+DSO: profit 9428.1; min exit 1.0; max concentration 0.364;
- DSO conditions/overrides ~59.5% of SCP-approved proposals in the coupled arm.

This is the intended architectural distinction: locally reasonable decisions can accumulate into a structurally unacceptable trajectory.

### Cost/Pareto result

No named topology clears every provisional hard criterion. Full SCP catches the authored safety failures but exceeds the human-review ceiling: 5.296 minutes/case versus 4.5 minutes.

This negative result is important because it prevents “review everything” from being called a success.

### Validation

- baseline: 136 tests + 3 subtests;
- v0.17: 147 tests + 3 subtests;
- integrity/claim-boundary validator: PASS.

---

## 5. Evidence boundary

The current package has meaningful C1 and C2 work. It does **not** yet have the C3/C4 evidence needed for strong external safety claims.

The next Freehold Commons material claim should come from independently authored frozen cases and real model behavior.

Do not inflate authored topology equations, economic coefficients, or provisional cases into empirical facts about real agents or institutions.

---

## 6. Qiu–Gill source note

External paper included in this handoff:

Eric S. Qiu and Joyce Gill, *Adversarial Review: Structured Disagreement for Grounded Agentic Code Review* (2026).

Useful source-supported lessons:

- simply adding agents is not monotonically better;
- narrow reviewer/critic interaction can outperform larger tested structures in the coding setting;
- interaction can create false consensus;
- evidence-grounded disagreement helps in their review benchmark;
- the artifact is frozen during the inner review loop;
- additional review has meaningful token cost.

**Source inconsistency:** Table 1 reports MARS = 82% and AR = 87% on LiveCodeBench, while nearby prose says MARS = 85%. The current safety deck uses the Table 1 value (82%) and the source audit records the discrepancy. Do not silently harmonize it.

---

## 7. Pluralis commercial program

Pluralis tests a concrete enterprise control point:

> An AI agent may have API/tool access while still lacking authority for a specific transaction.

Initial wedge: vendor renewals.

The product architecture keeps standing credentials away from the agent and issues an attenuated one-use credential only for an authorized action/state.

Open commercial falsifiers:

- 20 procurement interviews and independence pricing fork;
- real DoA encoding time;
- provider/identity sandbox enforcing credential custody;
- real redline extraction error + calibration;
- UDA / false-block / review-cost / cycle-time economics.

Research evidence and commercial evidence remain separate.

---

## 8. External communications

This bundle contains refreshed HTML artifacts:

- `03_COMMUNICATION/Freehold_Commons_AI_Safety_Deck_v0_17.html`
- `03_COMMUNICATION/Pluralis_YC_Pitch_v0_17.html`

The safety deck is for AI safety organizations/funders and emphasizes mechanism research, falsifiability, evidence classes, topology, DSO, exit, and the v0.17 freeze.

The YC/commercial pitch remains concrete: vendor renewal, DoA limits, one-use credentials, provider-neutral execution control, and explicit go/no-go tests.

Neither communication artifact is canonical scientific evidence.

---

## 9. What not to do next

Do not:

- create v0.18 merely by inventing another governance primitive;
- relabel the 60 provisional cases as independent;
- treat synthetic profit/concentration numbers as forecasts;
- count safety progress as startup traction;
- count customer interest as proof of long-horizon safety;
- overfit prompts/topologies after seeing hidden evaluation labels;
- rename historical code/files inside the frozen release and invalidate reproducibility.

---

## 10. Next highest-information sequence

1. commission outside-authored hard cases;
2. adjudicate and freeze them;
3. run exact open-weight model configurations through the frozen topology matrix;
4. measure false consensus, false dissent, minority preservation, UDA, unauthorized execution, review cost, and topology effects;
5. compare learned-agent behavior to the authored mechanism regression;
6. redesign only where a real failure justifies it;
7. in parallel, execute Pluralis commercial falsifiers.

The key methodological shift is now in force:

> **The next version should be earned by evidence, not by another elegant layer.**
