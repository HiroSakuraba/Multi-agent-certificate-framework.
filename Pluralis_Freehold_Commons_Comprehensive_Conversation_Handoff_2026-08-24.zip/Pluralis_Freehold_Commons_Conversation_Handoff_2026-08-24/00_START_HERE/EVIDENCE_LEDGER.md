# Evidence ledger and claim boundary

Freehold Commons uses a deliberately strict evidence ladder. Do not collapse these classes.

## C1 — implementation conformance

Examples:

- schema validation;
- unit/integration tests;
- deterministic replay;
- release integrity and hash checks;
- credential-broker refusal paths under stated assumptions;
- code produces the specified DSO/SCP dispositions.

Current status: substantial C1 evidence exists. v0.17 passes 147 tests + 3 subtests and its claim-boundary validator.

## C2 — project-authored simulation / discriminative behavior

Examples:

- synthetic economic DSO trajectories;
- project-authored hard cases;
- authored topology dynamics;
- cost coefficients and hard thresholds;
- SNC synthetic paired records.

Current status: substantial C2 scaffolding exists. **All v0.17 numeric results are C2.**

Important distinction: some C2 results have exposed real framework failures and forced changes; that is more informative than pure label conformance, but it still is not C3.

## C3 — behavioral effect on actual agents / humans

Examples needed:

- frozen independently authored cases run on exact open-weight model configurations;
- frontier-model runs where version/configuration is recorded as exactly as the provider permits;
- human or human/AI mixed review experiments;
- measured false-consensus, dissent-preservation, over-refusal, review-cost, and topology effects.

Current status: **not yet established for the v0.17 mechanisms.**

## C4 — real institutional outcomes

Examples needed:

- customer shadow-mode outcomes;
- controlled production enforcement;
- measured real-world delegation errors, bypasses, incidents, false blocks, productivity, exit/failover, and concentration effects;
- privacy-preserving multi-customer incident evidence.

Current status: **not established.**

## Claims that must not be made

Do not claim that Freehold Commons:

- solves AI alignment;
- proves multi-agent safety;
- prevents strategic collusion or deception;
- prevents real-world gradual disempowerment;
- has validated SCP/DSO on frontier agents;
- has an independent hidden benchmark already;
- has customer or production safety evidence;
- has discovered universal DSO thresholds or political constants.

Do not claim that Pluralis has customer traction, product-market fit, measured real redline extraction accuracy, or provider-enforced credential custody until those tests actually occur.

## External-paper boundary

Qiu & Gill (2026) supports a coding-domain result about reviewer/critic interaction, false consensus, evidence-grounded disagreement, and review cost. It does **not** validate the institutional extension of SCP, EDG, DSO, or Freehold Commons.
