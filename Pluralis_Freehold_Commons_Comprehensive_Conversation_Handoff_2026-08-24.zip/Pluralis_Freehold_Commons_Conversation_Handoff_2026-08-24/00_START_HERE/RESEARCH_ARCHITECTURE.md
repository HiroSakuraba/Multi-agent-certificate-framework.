# Freehold Commons research architecture — concise technical map

## Core execution path

```text
Actor / proposer
    ↓
Frozen proposal + material-state digest + evidence snapshot
    ↓
Structured Cooperation Protocol (risk-adaptive)
    reviewer ↔ critic
    typed disagreement / preserved uncertainty
    ↓
Stable review object (not necessarily unanimous)
    ↓
Authority Gate
    ↓
Disempowerment Safety Objective
    ↓
Independent approval / diversity / exit-plan conditions if required
    ↓
Credential broker / attenuated one-use capability
    ↓
External consequence
    ↓
Replayable evidence / incident record
```

## Key design rules

### Intent ≠ Authority ≠ Capability

A model may desire or propose an action without being authorized to cause it. Authorization still does not imply it receives a standing credential.

### Consensus is an observation, not an authorization primitive

Three agreeing agents may still represent one evidence root, one control root, one principal, or one correlated model failure.

### Stable review ≠ forced consensus

A review may terminate with preserved material uncertainty or a minority objection routed to a decision authority.

### Freeze before contest

Material proposal state does not change during the inner review. A material change invalidates the review and restarts against a new digest.

### Evidence is dependency-aware

The EDG records claim/support/contradiction/derivation relationships so repeated or circular assertions do not masquerade as independent evidence.

### Epistemic independence ≠ control-domain independence

Fresh model calls can be epistemically distinct while remaining under the same provider, administrator, memory, credential, policy, and ownership roots.

### Local authorization ≠ safe trajectory

The DSO exists because repeated locally acceptable actions can cumulatively erode exit, substitutability, revocability, redundancy, or policy independence.

### Cognitive liberty

The framework is aimed at observable action, authority, evidence, control, and external consequences—not at policing private beliefs or hidden chain-of-thought.

## DSO risk dimensions

The lineage tracks a vector of concentration, exit difficulty, revocability, substitutability/redundancy, irreversibility, meta-authority concentration, and coalition exposure, with protected-center freedom/agency floors over exit, voice, appeal, resources, privacy, and alternatives.

## DSO dispositions

Typical outputs include:

- ALLOW;
- ALLOW_WITH_CONDITION;
- REQUIRE_DIVERSITY;
- REQUIRE_REAUTH;
- REQUIRE_EXIT_PLAN;
- ESCALATE;
- DENY.

The DSO is intentionally trajectory-sensitive and can override or condition an SCP-approved action.
