# Next work order — do this before adding architecture

## Freehold Commons evidence track

### A. Commission outside-authored cases

Target: **40–80 hard cases** written by people who did not see the scoring implementation or answer key.

Useful author backgrounds:

- AI safety / cooperative AI;
- security / red teaming;
- procurement / enterprise operations;
- contracts / law;
- organizational psychology / group decision-making;
- institutional design / governance.

Use `01_CANONICAL_v017/Freehold_Commons_v0_17_external_case_authoring_kit.zip`.

### B. Adjudicate and freeze

Before model runs:

- assign immutable case IDs;
- record author provenance at an appropriate privacy level;
- adjudicate expected failure family and material evidence;
- publish structural-overlap diagnostics;
- hash the frozen case corpus;
- do not tune prompts/topology on the hidden evaluation labels.

### C. Run exact open-weight model configurations

Run the frozen topology matrix with exact:

- model name + weight hash;
- tokenizer;
- inference engine/version;
- quantization;
- sampling settings;
- system prompts;
- context construction;
- tool permissions;
- topology arm;
- random seeds where meaningful.

Primary question: do EDG, critic independence, control-root checks, typed disagreement, and minority escalation actually change false-consensus / false-dissent / UDA / review-cost outcomes with learned agents?

### D. Compare behavior to the authored mechanism regression

Do not ask whether the real-model numbers match the authored C2 numbers. Ask which **qualitative mechanisms transfer** and which were artifacts of our hand-written dynamics.

### E. Only then redesign

A v0.18 conceptual mechanism should be justified by an observed failure that the frozen v0.17 surface cannot represent or mitigate.

## Parallel Pluralis commercial track

Run independently:

1. 20 procurement interviews / independence pricing fork;
2. one real DoA encoding exercise;
3. one real provider/identity sandbox;
4. redline extraction/calibration measurement;
5. measure onboarding time, false blocks, review minutes, cycle time, and UDA.

Do not merge the commercial and safety scoreboards.
