# Pluralis / Freehold Commons — Conversation Handoff Bundle

Start with:

1. `00_START_HERE/CONVERSATION_HANDOFF.md`
2. `00_START_HERE/CURRENT_STATE_AT_A_GLANCE.md`
3. `00_START_HERE/EVIDENCE_LEDGER.md`
4. `00_START_HERE/AUDIT_AND_DECISION_LOG.md`
5. `00_START_HERE/NEXT_WORK_ORDER.md`
6. `00_START_HERE/NEXT_CHAT_PROMPT.md`

Canonical runnable research artifact:

`01_CANONICAL_v017/Freehold_Commons_v0_17_evidence_freeze_topology.zip`

Important naming:

- Pluralis = company.
- Freehold Commons = framework.
- `SwarmGlue` / `Relay` names inside historical/frozen files are preserved for reproducibility.

Important evidence boundary:

- v0.17 numerical results are C2 authored regressions.
- the 60 hard cases are provisional/project-authored, not independent.
- next major step is outside-authored frozen cases + real model runs.
- no new major framework layer should be added before that evidence unless an observed failure justifies a freeze exception.

The `03_COMMUNICATION` folder contains refreshed v0.17 HTML decks; these are communication artifacts, not scientific evidence.
