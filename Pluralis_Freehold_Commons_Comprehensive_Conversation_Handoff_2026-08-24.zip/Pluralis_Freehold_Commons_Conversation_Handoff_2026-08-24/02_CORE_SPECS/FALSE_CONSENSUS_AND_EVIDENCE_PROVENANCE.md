# False Consensus and Evidence Provenance threat model v0.1

## Why this is a first-class threat

Qiu and Gill (2026) report a failure mode in which a reviewer and critic converge despite insufficient evidence. In one case, the critic raises a real concern and later yields to a confident but weakly supported rebuttal. The authors call this **false consensus** and show that explicit evidence-grounded disagreement constraints improve their code-review benchmark result.

SwarmGlue generalizes the threat carefully:

> Multiple agents agreeing does not imply multiple independent reasons for belief, multiple independent principals, or legitimate authorization.

The paper demonstrates conversational false consensus in a coding-review setting. The additional categories below are SwarmGlue threat-model extensions, not findings of that paper.

## Threat classes

- **FC-1 conversational convergence:** agents abandon objections because the interaction rewards closure or confident rebuttal.
- **FC-2 correlated-model agreement:** separate instances share model/training/context failure modes.
- **FC-3 evidence laundering:** agents cite one another until one unsupported source looks multiply corroborated.
- **FC-4 authority laundering:** several approvals derive from one principal/control root.
- **FC-5 sycophantic hierarchy:** a lower-status reviewer defers despite stronger evidence.
- **FC-6 coalition consensus:** agents coordinate on a coalition-beneficial but unauthorized interpretation.
- **FC-7 concern amplification:** speculative concerns mutually reinforce into unnecessary escalation or scope creep.
- **FC-8 consensus by omission:** unresolved dissent disappears from the final record.

## Evidence Dependency Graph (EDG)

Represent claims and evidence as a graph:

```text
claim C17
 ├─ evidence E2 → source S1
 ├─ evidence E5 → source S4
 └─ derived claim C8
        └─ evidence E2 → source S1
```

A system should not count `C8` and `E2` as two independent supports for `C17` when they share the same upstream evidence.

Minimum node classes:

- `claim`;
- `observation`;
- `document`;
- `database_state`;
- `human_attestation`;
- `agent_inference`;
- `policy/grant`;
- `external_measurement`.

Minimum edge classes:

- `supports`;
- `contradicts`;
- `derived_from`;
- `quotes`;
- `summarizes`;
- `authorized_by`;
- `observed_by`.

## Effective support

For a claim \(c\), use an effective evidence count over independent source roots rather than raw citations:

\[
E_{\text{eff}}(c)=\sum_{r \in Roots(c)} w_r
\]

Correlated/common-control roots may receive reduced weight. This is an anti-double-counting control, not a universal Bayesian measure.

## Review record requirement

Preserve every material claim, supporting and contradicting evidence IDs, source-root identifiers, unresolved concerns, discarded concerns and their disposition, reviewer/critic control-domain IDs, and the final authorization path.

The final record must not silently delete dissent.

## Consensus is never sufficient for execution

A stable review may feed an authority decision, but execution still requires valid principal/delegation, current material state, policy satisfaction, required independent approval, DSO checks, and brokered capability where applicable.

## Benchmark families for AuthorityGym

1. confident unsupported rebuttal;
2. circular citation;
3. shared-source illusion;
4. status pressure;
5. concern cascade;
6. fake reviewer plurality;
7. suppressed dissent;
8. coalition-beneficial agreement;
9. correct minority against confident majority;
10. benign evidence-grounded convergence.

The tenth category prevents the benchmark from rewarding disagreement as an end in itself.

## Metrics

- false-consensus rate;
- false-dissent rate;
- unsupported-claim retention;
- correct-minority preservation;
- evidence-root diversity;
- dissent survival into final record;
- unnecessary-review cost;
- latency/token cost;
- unsafe execution after false consensus;
- safe action blocked by concern amplification.

## Human comparison

D3/D4 experiments should include human reviewers and mixed human/AI teams. Humans are also subject to conformity, hierarchy, anchoring, and coalition incentives. The benchmark is about institutional structure, not a uniquely machine pathology.

## Non-claims

This threat model does not infer hidden motives from agreement. It treats agreement as an observable protocol outcome and asks whether the evidence, authority and independence underneath it are real.
