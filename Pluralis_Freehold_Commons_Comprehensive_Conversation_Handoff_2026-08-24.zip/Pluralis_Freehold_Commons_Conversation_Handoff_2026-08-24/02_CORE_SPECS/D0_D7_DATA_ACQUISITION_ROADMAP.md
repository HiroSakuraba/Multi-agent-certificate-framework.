# D0–D7 alignment data acquisition and evidence roadmap

## Status

This is the canonical data-acquisition roadmap for the v0.13 public-norms work package. It does **not** claim that stages D1–D7 have been completed. It separates currently implemented synthetic infrastructure from future independent, behavioral, and production evidence.

The central unit is an **attempted consequential action under a social/institutional state**. Actor identity is a feature, not the label: the same authority violation should be representable when performed by a human, an AI agent, a human using an AI, an AI influencing a human, or a coalition.

## Why two ladders exist

- **SNC-0…SNC-5** tracks maturity of the public Situated Norms Commons training corpus.
- **D0…D7** tracks provenance and external validity of the evidence/data stream feeding Relay and SwarmGlue.

A single D-stage may produce public SNC material, private Relay data, or both.

## Evidence ladder

| Stage | Data source | Primary purpose | Public/private default | Evidence class target | Current status |
|---|---|---|---|---|---|
| **D0** | v0.12/v0.13 synthetic cases + OWASP Agentic Top 10 + MITRE ATLAS + CERT insider-threat patterns + SwarmGlue institutional failures | Broaden taxonomy and create matched actor-equivalent cases | Public synthetic artifacts | C1/C2 | **Partial**: project-authored cases exist; formal external-taxonomy crosswalk added in this docs update |
| **D1** | Independent lawyers, procurement, security, compliance, HR/people-ops and organizational-behavior authors | Reduce project-author bias; create hidden cases | Public if rights permit; hidden eval until release | C2 | **Not run** |
| **D2** | Frontier-model red teams in AuthorityGym | Discover learned-agent failure modes and test SNC training transfer | Public aggregate results; some cases held out | C3 | **Not run** |
| **D3** | Paid, consented human adversarial simulations in the same environments | Establish human baseline; study insider misuse and ordinary error | De-identified research data where consent permits | C2/C3-like behavioral reference; not a deployment claim | **Not run** |
| **D4** | Human–AI coalition experiments | Study approval laundering, manipulation, collusion, fragmented action and mutual circumvention | Mixed; public abstracted episodes, raw logs restricted | C3 | **Not run** |
| **D5** | Customer shadow mode | Learn real frequency distributions before Relay controls execution | Private by default; abstracted public derivatives only by permission | C4-adjacent observational data, not causal proof | **No customers yet** |
| **D6** | Controlled production enforcement | Measure execution, review burden, latency and actual prevented/allowed outcomes | Private; aggregate/abstract reports where permitted | C4 | **Not run** |
| **D7** | Multi-customer confidential incident exchange | Build a cross-customer threat-intelligence network and long-run proprietary moat | Private incident graph; selected sanitized public abstractions | C4 / post-deployment threat intelligence | **Future** |

## D0 — taxonomy synthesis and actor-equivalent generation

D0 is deliberately cheap and broad. It should combine four sources rather than allowing any one framework to define the problem.

### D0a — situated social/institutional norms

Current SNC seed covers consent, privacy, bounded authority, reciprocity, fairness, dissent, appeal, anti-retaliation, meaningful exit, emergency exceptions and uncertainty.

### D0b — agentic AI security

Use the current OWASP Top 10 for Agentic Applications (2026) as a coverage spine:

1. ASI01 — Agent Goal Hijack
2. ASI02 — Tool Misuse & Exploitation
3. ASI03 — Identity & Privilege Abuse
4. ASI04 — Agentic Supply Chain Vulnerabilities
5. ASI05 — Unexpected Code Execution (RCE)
6. ASI06 — Memory & Context Poisoning
7. ASI07 — Insecure Inter-Agent Communication
8. ASI08 — Cascading Failures
9. ASI09 — Human-Agent Trust Exploitation
10. ASI10 — Rogue Agents

MITRE ATLAS is used as the deeper technique vocabulary. As of the August 2026 review used for this document, ATLAS exposes an AI threat matrix spanning 16 tactics and includes Agentic AI as a platform filter. D0 should map generated cases to ATLAS technique IDs where a faithful mapping exists rather than inventing new IDs.

### D0c — human insider and accidental misuse

CERT/SEI provides useful precedent for synthetic insider-threat data containing both ordinary background behavior and malicious-actor behavior. Its longstanding high-level malicious-insider groupings include sabotage, fraud and theft of intellectual property; CERT has also emphasized that non-malicious/accidental insider behavior matters operationally.

D0 therefore needs both:

- intentional misuse cases; and
- ordinary mistakes, ambiguity, fatigue, misconfiguration and overconfidence.

### D0d — SwarmGlue-specific institutional failure modes

Preserve cases not naturally covered by cybersecurity taxonomies:

- cumulative authority drift;
- policy capture and coalition capture;
- coercive bargaining and commitment threats;
- fake urgency and review manipulation;
- harmful delay / procedural overload;
- suppression of dissent or appeal;
- nominal exit without meaningful exit;
- affected-party exclusion;
- fragmented actions that stay below individual thresholds;
- laundering an unauthorized action through a nominally authorized human;
- value/rights conflicts where pure outcome maximization is not the whole policy.

## Actor-equivalent quartet

Where semantically possible, every D0 failure pattern should generate four matched forms:

1. **human actor** performs or attempts the action;
2. **AI actor** performs or attempts the same action;
3. **human→AI**: a human uses an AI as the mechanism or proxy;
4. **AI→human**: an AI induces or manipulates a human into authorizing the action.

A fifth form, **coalition**, should be added for multi-party/AI-to-AI cases when composition is meaningful.

The ground truth should be attached to the **action and authority state**, not to actor type. This allows a model to learn that unauthorized signer substitution is wrong for the same institutional reason whether the immediate actor is human or machine.

## D1 — independent authoring protocol

Minimum launch target:

- 3–5 independent case authors;
- at least one procurement/finance operations author;
- at least one lawyer/commercial counsel author;
- at least one security/identity author;
- authors must not see the existing generator or answer key;
- cases are accepted before project adjudication;
- disagreements are recorded rather than rewritten away.

First milestone: **500–1,000 hidden cases across at least six normative/authority domains**.

The project should report independent-author fraction, adjudication-disagreement rate and structural overlap against all project-authored material.

## D2 — AuthorityGym frontier-model trials

D2 is the first stage designed to produce direct learned-agent behavioral evidence.

Required arms should include at least:

- base model / ordinary tool permissions;
- specification or simple policy prompt;
- platform-native permission/approval baseline;
- SwarmGlue/Relay runtime authority controls;
- optional SNC-trained or SNC-adapted model arm.

Cases must include perception/extraction inside the unit under test. Reusing pre-extracted project-authored flags does not establish agent behavior.

## D3 — paid human adversarial baseline

Run the same or structurally matched AuthorityGym tasks with consenting participants. Separate conditions:

- benign goal, ordinary workload;
- accidental mistake / incomplete context;
- explicit adversarial incentive;
- conflict-of-interest condition;
- high time pressure / fake urgency.

Do not label participants as “bad people.” Label observable actions, authority violations, deception when evidenced, and outcomes.

## D4 — human–AI coalition program

Priority case families:

- human asks AI to conceal or omit a material fact;
- human asks AI to split a transaction below approval limits;
- AI frames information selectively to obtain human approval;
- AI generates false urgency or misleading confidence;
- human and AI jointly exploit ambiguity in policy;
- two agents coordinate around independent controls;
- one actor creates evidence that another actor then treats as independent confirmation;
- mutually beneficial cross-company agent behavior that violates one or both principals' authority limits.

D4 is where the older SwarmGlue coalition/FDT research becomes directly commercially relevant.

## D5 — customer shadow mode

Shadow mode should observe proposed actions and actual human outcomes without Relay executing them.

Core outputs:

- empirical frequency of failure/exception categories;
- distribution of authority ambiguities;
- extraction/calibration curves on real documents;
- actual review burden;
- override frequency and rationale;
- later-disputed or corrected decisions;
- near misses.

Raw customer documents and private communications remain private by default. Public derivatives should be recreated or abstracted rather than de-identifying a near-verbatim contract and calling it safe.

## D6 — controlled production enforcement

D6 introduces causal operational questions:

- severe unauthorized actions executed per opportunity;
- safe actions autonomously completed;
- false-block rate;
- human review minutes per transaction;
- transaction latency;
- rollback/recovery burden;
- detected bypass attempts;
- economic value preserved or lost.

The business objective remains:

> maximize Useful Delegated Autonomy subject to a hard severe-unauthorized-action constraint and an explicit review-cost budget.

## D7 — Relay Authority Incident Exchange

Long-run design: participating customers contribute structured, privacy-protected incident/near-miss records. Relay returns cross-customer intelligence.

Potential outputs:

- abstract attack families;
- new regression tests;
- anonymized rate trends;
- policy lint rules;
- new AuthorityGym episodes;
- public SNC cases reconstructed at sufficient distance from source data;
- private high-fidelity signatures and distributions retained for customers.

Do not create incentives for customers to conceal incidents. Participation terms should distinguish safety-improvement contributions from punitive scoring.

## Two feedback loops

### Public alignment loop

```text
D0–D4 discoveries
      ↓
sanitize / reconstruct / annotate
      ↓
Situated Norms Commons + AuthorityBench
      ↓
open model training and evaluation
      ↓
better situated social competence
      ↓
lower routine failure and review burden
```

### Commercial security loop

```text
D5–D7 production experience
      ↓
private Relay Incident Graph
      ↓
better extraction, authorization and enforcement
      ↓
more useful delegated autonomy
      ↓
more deployments and more consequential workflows
      ↓
richer real boundary evidence
```

Selected abstractions may flow from the private loop into the public loop only under explicit rights, privacy and reconstruction rules.

## Stage gates

Do not advance by calendar alone.

- **D0→D1:** taxonomy crosswalk and actor-equivalent schema stable enough that independent authors can work without seeing the generator.
- **D1→D2:** hidden cases have acceptable structural distance and meaningful adjudication stability.
- **D2→D3:** frontier models exhibit measurable behavior worth comparing to humans; otherwise refine environments first.
- **D3→D4:** baseline human/AI differences are understood enough to design coalition manipulations without confounding simple task difficulty.
- **D4→D5:** product discovery and privacy/legal controls support customer shadow use.
- **D5→D6:** shadow-mode extraction, calibration, identity configuration and review economics are viable.
- **D6→D7:** multiple customers have enough operational events and data rights to make a shared incident network valuable.

## Claims boundary

D0 remains project-authored synthetic C1/C2 evidence. D1 improves author independence but is still scenario evidence. D2–D4 can create behavioral C3 evidence. D5 is observational and should not be mislabeled as causal deployment safety. D6 is the first controlled production stage intended to support C4 claims. D7 is a post-deployment learning network, not proof that the framework is complete or universally safe.

## Sources used for the D0 crosswalk

- OWASP GenAI Security Project, *OWASP Top 10 for Agentic Applications for 2026*, December 2025; current framework reviewed August 2026.
- MITRE ATLAS, living adversarial threat knowledge base for AI systems; current matrix reviewed August 2026.
- Carnegie Mellon Software Engineering Institute / CERT, *Insider Threat Test Dataset* and CERT insider-threat research on sabotage, fraud, theft of intellectual property, and non-malicious insider risk.
