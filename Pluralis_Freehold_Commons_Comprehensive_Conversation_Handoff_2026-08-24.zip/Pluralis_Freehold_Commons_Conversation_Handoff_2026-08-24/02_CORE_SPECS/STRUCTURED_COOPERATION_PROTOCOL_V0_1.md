# Structured Cooperation Protocol (SCP) v0.1

## Status

This is a **v0.16 design specification** layered on the v0.15 executable core. It is not yet implemented as a runtime protocol.

The design is informed by Qiu and Gill (2026), *Adversarial Review: Structured Disagreement for Grounded Agentic Code Review*. Their empirical result is narrow but useful: in coding/review tasks, a compact main-agent / reviewer / critic protocol can outperform larger role-separated baselines, while naive interactive review can also produce **false consensus**. The paper does not establish a general theorem about multi-agent safety, institutions, or governance.

## Purpose

SwarmGlue needs a cooperation primitive between two bad extremes:

1. **single-agent unilateral action**, where self-review and self-authorization can share the same blind spots; and
2. **open-ended agent parliament**, where many agents communicate freely, duplicate evidence, amplify speculation, converge socially, or create large coordination/collusion surfaces.

SCP provides a narrow, typed, auditable interface:

```text
current state S0
     ↓
proposer creates proposal P
     ↓
freeze P + relevant state/evidence snapshot
     ↓
reviewer creates Review_1
     ↓
critic audits Review_1
     ↓
typed disagreement / evidence exchange
     ↓
stable review object R*
     ↓
Authority Gate + DSO + required independent approval
     ↓
capability issuance / execution
```

The protocol is an **oversight and evidence-construction mechanism**. Agreement inside SCP is never, by itself, authorization.

## Core invariant: freeze before contest

Once a proposal enters the review loop:

- the proposal's material state is frozen;
- the evidence snapshot receives a digest;
- reviewer and critic exchange only typed review objects;
- the proposer may not mutate the proposal inside the inner loop;
- if the proposal changes materially, the prior review is invalidated and review restarts against the new digest.

This generalizes the useful separation in Adversarial Review: disagreement is resolved over a fixed artifact; edits occur only after the review signal is stable.

For Relay, the operational translation is:

> **Do not allow the transaction under review to change while agents are deciding whether that transaction is authorized.**

## Roles

### Proposer

Creates a proposed consequential action and supplies:

- claimed objective;
- material state;
- authority basis;
- evidence bundle;
- expected beneficiaries/cost bearers;
- dependency/power impact where required;
- uncertainty declaration.

The proposer does not certify its own proposal as safe.

### Reviewer

Builds an independent assessment of factual correctness, policy/authority compliance, material omissions, affected-party standing, externalities, DSO trajectory implications, uncertainty, and scope discipline.

The reviewer must cite evidence or explicitly identify unresolved uncertainty.

### Critic

Audits the **review**, not merely the proposal.

The critic asks whether review claims are supported, whether material counterevidence is missing, whether "independent" evidence shares an upstream source, whether a confident but unsupported rebuttal displaced a real objection, whether scope expanded without justification, and whether power/exit/standing implications were ignored.

The critic has no authority to execute or edit the proposal.

## Typed disagreement object

A critic response MUST use one or more declared disagreement classes rather than free-form "I disagree."

### `AGREE`

The critic accepts the relevant review claim and identifies the evidence dependency it relies on.

### `DISAGREE_FACT`

A factual claim is contradicted or insufficiently supported.

Required fields: `claim_id`, `contradicting_evidence_ids`, `reason`, and `materiality`.

### `DISAGREE_POLICY`

The review misstates authority, policy, delegation, or applicable procedure. Cite the policy/grant, affected action, and whether a reachable approval path exists.

### `DISAGREE_STANDING`

The proposal/review omits or misclassifies an affected party, principal, reviewer, or appeal path.

### `DISAGREE_EXTERNALITY`

A material cost/benefit falls on a party not represented in the review.

### `DISAGREE_POWER`

The review misses a relevant DSO effect: concentration, dependency, exit erosion, meta-authority, fake independence, or coalition capture.

### `DISAGREE_SCOPE`

The review or proposed remediation expands beyond the frozen ask without evidence that expansion is necessary. This directly targets the scope-creep failure observed in the Adversarial Review paper.

### `CONCERN_UNRESOLVED`

The critic sees a material concern but does not yet have decisive contrary evidence.

A concern is not automatically treated as a defect. The next review step must either supply evidence that resolves it, narrow the claim, request missing context, or preserve the uncertainty through escalation/limited authority.

## Stable review does not mean consensus

A review is **stable** when all remaining disagreements are either resolved with evidence, explicitly preserved as unresolved material uncertainty, or routed to an independent decision authority.

Stable review does not require every agent to agree.

This is deliberate. The paper's false-consensus failure shows that forcing agents to converge can erase a correct objection.

## Evidence-weighted resolution

Do not count votes.

Three agents repeating one source do not create three units of evidence.

Resolution should use direct evidence strength, source independence, recency, relevance/materiality, source authority for the question, contradictory evidence, and declared uncertainty.

Confidence language is a weak signal, not a deciding factor.

## Independence has two meanings

### Epistemic independence

Did a reviewer form an assessment without seeing another review first?

### Control-domain independence

Could one underlying operator/control root compromise all "independent" reviewers?

Relevant dimensions include provider, model family, administrator, credential root, memory store, orchestration root, policy root, and ultimate principal.

An agent can be epistemically separate without satisfying constitutional independence.

For routine low-risk review, same-root subagents may be useful. For high-consequence or meta-authority decisions, a policy may require genuinely independent control domains.

## Risk-adaptive invocation

SCP is not mandatory at maximum depth for every action.

Define review intensity as a function of:

\[
R = f(C, U, I, P, N, X)
\]

where \(C\) is consequence/severity, \(U\) uncertainty, \(I\) irreversibility, \(P\) DSO power/dependency delta, \(N\) novelty/out-of-distribution status, and \(X\) externality/affected-party complexity.

Illustrative lanes:

| Lane | Typical path |
|---|---|
| L0 | deterministic policy check only |
| L1 | proposer + automated evidence check |
| L2 | proposer + reviewer |
| L3 | proposer + reviewer + critic |
| L4 | L3 + Authority Gate + DSO + independent approver |
| L5 | constitutional/meta-authority: multiple independent control domains + delay/ratification/appeal |

Thresholds are policy choices and require domain calibration.

## Relationship to hard controls

SCP is a **soft/semantic institution**. It does not replace credential custody, capability attenuation, state/materiality binding, replay prevention, DSO power constraints, customer-owned revocation, or independent audit.

A model can ignore text instructions. High-consequence enforcement must remain outside the model's voluntary compliance path.

## Relationship to Situated Norms Commons

SNC should teach how to disagree without fabricating certainty, cite evidence, preserve legitimate dissent, distinguish concern from contradiction, revise a belief without treating disagreement as hostility, resist status deference when evidence conflicts, and avoid endless adversarialism on low-risk cases.

The target is **cooperative disagreement**, not obedience and not permanent debate.

## Relationship to DSO

The DSO asks whether locally authorized actions produce a disempowering trajectory. SCP improves the quality of the evidence and disagreement available to that decision.

A `DISAGREE_POWER` object should be able to cite power-graph edges, effective control clusters, exit-reserve state, delegation horizon, meta-authority changes, and substitutability/fallback state.

SCP itself has no permission to waive a DSO hard constraint.

## Implementation milestones

- **SCP-0:** schemas for frozen proposal, typed disagreement, stable review and evidence references.
- **SCP-1:** deterministic orchestrator over a static proposal.
- **SCP-2:** Evidence Dependency Graph and circular-source detection.
- **SCP-3:** risk-adaptive lane selector.
- **SCP-4:** AuthorityGym false-consensus scenarios.
- **SCP-5:** Model Zoo Z6 runner.
- **SCP-6:** same-root vs control-independent reviewer experiments.
- **SCP-7:** human/AI mixed review trials.
- **SCP-8:** integration with Relay action authorization under a provider sandbox.

## Non-claims

This specification does not establish that three agents are optimal, that reviewer/critic protocols generalize from code review to institutions, that model-generated disagreement is truthful, that structured discussion prevents collusion, that agreement is reliable evidence of correctness, or that a text protocol is sufficient for high-consequence safety.

The research question is narrower:

> Can narrow, evidence-grounded, explicitly typed disagreement improve the quality of multi-agent decisions without creating the overhead, false consensus, or collusion surface of unconstrained agent teams?
