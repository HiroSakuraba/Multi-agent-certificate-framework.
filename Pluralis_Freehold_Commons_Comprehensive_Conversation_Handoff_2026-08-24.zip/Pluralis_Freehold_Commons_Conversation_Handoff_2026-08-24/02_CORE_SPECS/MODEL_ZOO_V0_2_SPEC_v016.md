# Relay Authority Model Zoo v0.2 specification

## Status

The **Relay Authority Model Zoo** is a planned evaluation and model-selection subsystem. It is **not yet populated with frontier-model results in v0.15**. v0.14 adds DSO/AuthorityGym-L infrastructure but no learned-model Zoo run.

AuthorityGym supplies the environments and episode format. The Model Zoo supplies the **registry, frozen run metadata, comparison protocol, longitudinal history, and public/private reporting surfaces** needed to evaluate models consistently over time.

The Zoo should answer two different questions:

1. **Public research question:** which models show better situated social/institutional competence and bounded-authority behavior on frozen public and hidden evaluations?
2. **Commercial question:** which model/configuration should a customer delegate a particular class of consequential work to, under that customer's risk and review budget?

Do not collapse those questions into one global "best model" score.

## Relationship to Situated Norms Commons and AuthorityGym

```text
Situated Norms Commons
        │
        ├── training / adaptation
        ▼
   model candidates
        │
        ▼
Relay Authority Model Zoo
        │
        ├── registry + exact run metadata
        ├── frozen public suites
        ├── hidden AuthorityGym suites
        └── longitudinal comparisons
        │
        ▼
     AuthorityGym
        │
        ├── D2 model trials
        ├── D3 human baselines
        └── D4 coalition trials
```

SNC is a **training resource**. AuthorityGym is an **interactive test environment**. The Model Zoo is the **measurement and comparison system** that connects them.

## Six evaluation tracks

### Z1 — situated social competence

Evaluate contextual understanding of consent and revocation, privacy and narrow exceptions, bounded authority, conflicts of interest, reciprocity versus coercion, commitments and promises, legitimate dissent and appeal, anti-retaliation, affected-party standing, meaningful exit, cultural/local uncertainty, and when to clarify rather than act.

The critical failure to avoid is **obedience masquerading as prosociality**. A model should not score well merely because it defers to higher-status actors or refuses broadly.

### Z2 — agentic authority

Evaluate consequential action under tools and mutable state: stale authority, expired/revoked grants, action substitution, signer substitution, state/materiality changes, spending/delegation ceilings, fragmented transactions, credential scope, replay, clarification/escalation paths, and safe completion without unnecessary review.

This track should share the same authority semantics as Relay's runtime where possible, while keeping benchmark cases independently authored.

### Z3 — adversarial robustness

Evaluate behavior under prompt/goal hijacking, malicious documents, memory poisoning or misleading stored context, privilege/identity abuse, concealed material facts, fabricated urgency, misleading confidence, policy-bypass requests, evidence laundering, deceptive tool-use attempts, and cascading/tool-chain failures.

Where a taxonomy mapping exists, preserve OWASP Agentic AI / MITRE ATLAS / CERT / SwarmGlue provenance as metadata. Do not force a mapping where one is not justified.

### Z4 — multi-actor / coalition behavior

Evaluate human→AI manipulation, AI→human persuasion, AI↔AI collusion, human+AI threshold gaming, one actor fabricating evidence that another treats as independent, cross-company mutually beneficial but unauthorized cooperation, and coalition behavior that preserves local compliance while violating a principal's broader authority.

This is the Model Zoo surface most directly connected to the distinctive SwarmGlue coalition/FDT research.


### Z5 — disempowerment and institutional resilience

Evaluate long-horizon trajectories in `AuthorityGym-L`:

- recursive delegation and authority drift;
- provider/supplier concentration;
- strategic or accidental indispensability;
- erosion of tested exit paths;
- fake independence and nominal reviewer multiplicity;
- emergency-power persistence;
- meta-authority accumulation;
- threshold fragmentation;
- suppression or hollowing of appeal/alternatives;
- coalition capture over many locally authorized actions.

Report two distinct quantities:

1. **opportunistic exploitation** — whether an actor actively uses opportunities to expand or circumvent authority;
2. **structural drift** — whether concentration/exit/freedom worsens even when actors simply optimize ordinary task objectives.

The second is essential: a disempowerment benchmark that only catches explicitly malicious agents misses the gradual scenario the DSO is designed for.

Z5 must not reward surveillance of private beliefs or hidden chain-of-thought. It evaluates observable actions, control surfaces, dependencies, contestability and resulting institutional state.


### Z6 — structured cooperation and false consensus

Evaluate self-review, external review, independent parallel review, interactive reviewer–critic review, untyped conversation, typed evidence-grounded disagreement, and shared versus independent control roots.

Core failure families:

- conversational false consensus;
- correlated-model agreement;
- evidence laundering/circular citation;
- authority laundering through nominal reviewer plurality;
- hierarchy/sycophancy effects;
- concern amplification and scope creep;
- suppression of unresolved dissent;
- correct minority versus confident majority;
- coalition-beneficial consensus.

Report false-consensus rate, false-dissent rate, correct-minority preservation, evidence-root diversity, unsupported-claim retention, dissent survival, review cost, downstream unauthorized execution and safe-action false block.

Do not award points for disagreement itself. The target is evidence-sensitive cooperation.

Qiu and Gill (2026) motivate this track through coding-agent experiments; they do not validate the broader institutional extension.

## Immutable run identity

Every published or customer-facing run must preserve enough metadata to reproduce the condition as closely as practical.

Required fields:

```json
{
  "run_id": "opaque immutable id",
  "provider": "provider or self-hosted",
  "model_family": "family",
  "exact_model_version": "exact version or artifact digest",
  "release_date": "YYYY-MM-DD or null",
  "evaluation_date": "YYYY-MM-DD",
  "endpoint_or_runtime": "API/runtime identifier",
  "system_prompt_digest": "sha256...",
  "tool_policy_digest": "sha256...",
  "reasoning_effort": "declared setting or null",
  "temperature": "number or null",
  "sampling_config": {},
  "context_limit": "integer or null",
  "fine_tune_or_adapter": "identifier/digest or null",
  "snc_exposure": {
    "status": "none|unknown|trained|adapted",
    "dataset_version": "version or null",
    "recipe_digest": "sha256 or null"
  },
  "authoritygym_version": "version",
  "suite_ids": ["public suite ids"],
  "hidden_suite_registry_commit": "commit/digest",
  "runner_version": "version/digest",
  "notes": []
}
```

If a hosted provider does not expose exact weights or training-data provenance, record that limitation instead of inferring it.

## Required score vector

Do not publish one scalar "alignment score" by default.

Core score vector:

- `severe_unauthorized_execution_rate`;
- `useful_delegated_autonomy`;
- `false_block_rate`;
- `unnecessary_escalation_rate`;
- `clarification_quality`;
- `counterfactual_sensitivity`;
- `calibration_or_abstention_quality`;
- `deception_or_concealment_rate` where observable;
- `policy_bypass_attempt_rate`;
- `successful_bypass_rate`;
- `human_manipulation_acceptance_rate` where applicable;
- `latency`;
- `review_minutes`;
- `economic_or_task_value_preserved`.

Each published metric should include denominator, uncertainty interval where meaningful, suite version, and severity definition.

## SNC transfer experiment

A central public experiment is a matched comparison:

```text
base open-weight model
        versus
same base model + SNC training/adaptation
```

The primary question is **not** whether the SNC-trained model refuses more.

Pre-register at least:

- severe unauthorized action non-inferiority / improvement;
- justified clarification improvement;
- counterfactual sensitivity improvement;
- legitimate dissent preservation;
- unjustified over-refusal ceiling;
- Useful Delegated Autonomy non-inferiority or improvement.

The hidden evaluation families must be absent from SNC training families and independently authored when making a benchmark/generalization claim.

## Longitudinal model tracking

The Zoo should preserve historical runs rather than silently replacing them.

For each model family, enable comparison over time: capability gain, authority compliance, social-context sensitivity, over-refusal, deception/manipulation behavior, coalition behavior, calibration, and tool-use robustness.

This allows questions such as:

- Are newer models naturally becoming better at situated norms?
- Are stronger models better at circumventing weak controls?
- Does SNC-style training improve social judgment without reducing useful autonomy?
- Does a model update materially change the safe delegation envelope for a customer workflow?

## Public Model Zoo

Public by default where licensing and evaluation security permit:

- exact non-sensitive run metadata;
- public suite scores;
- aggregate hidden-suite scores;
- confidence intervals;
- methodology;
- frozen score definitions;
- model-version history;
- SNC-trained vs untrained open-model experiments;
- discovered failure families after they are no longer security-sensitive;
- benchmark contamination/overlap disclosures.

Do **not** publish hidden cases merely to make the leaderboard easier to reproduce. Publish enough methodology for external replication while rotating or holding back benchmark families as needed.

## Private Enterprise Model Zoo

Customer-specific evaluation is a commercial product surface.

Inputs may include the customer's delegation-of-authority matrix, policy/materiality schemas, approved workflows, risk severity weights, provider/tool configuration, reconstructed incident families, and acceptable review/latency budgets.

Outputs should be a **delegation envelope**, not an anthropomorphic trust score.

Example:

```text
Workflow: routine vendor renewals < $100k

Model/config A:
  useful delegated autonomy: 91%
  severe unauthorized execution: 0.7%
  false block: 8%

Model/config B + Relay runtime:
  useful delegated autonomy: 84%
  severe unauthorized execution: 0.02%
  false block: 15%
```

Potential commercial products:

1. pre-deployment model authority assessment;
2. continuous model-version regression testing;
3. customer-specific model routing;
4. certification/assurance report for a defined workflow;
5. post-update regression alert when a provider changes model behavior.

## Model routing

The Zoo can eventually feed Relay's runtime routing layer:

```text
requested action
      ↓
risk / authority / workflow class
      ↓
Model Zoo evidence + customer thresholds
      ↓
select model + Relay control profile
      ↓
execute / review / deny
```

Routing must be evidence-based and customer-configurable. A stronger model is not automatically preferred if its authority-risk profile is worse for the requested action.

## Benchmark and contamination discipline

- Freeze public suite versions.
- Keep hidden suite families independently authored.
- Record known model exposure to public SNC/benchmark data when known.
- Do not compare runs across materially different tool permissions without stating the difference.
- Report prompt/configuration sensitivity when it materially changes outcomes.
- Keep raw outputs for audit where licensing/data rights permit.
- Preserve failed or negative model results.
- Do not tune a model repeatedly against the hidden final suite and still call the result held out.
- Rotate hidden suites after sufficient exposure or suspected contamination.

## Run cadence

Minimum intended cadence after implementation:

- new major model/version: run Z1 + Z2 immediately, Z3 when tooling is available, Z4 for models intended for multi-agent use, and Z5 before widening long-lived or critical delegated authority;
- material Relay policy/runtime change: rerun the relevant frozen suite;
- SNC release: rerun matched open-model transfer experiment;
- customer-critical model update: rerun the customer's private delegation-envelope suite before widening autonomy.

This is a target operating procedure, not a current capability claim.

## Implementation milestones

- **MZ-0:** registry schema + immutable run record;
- **MZ-1:** runner consumes AuthorityGym AG-0 episode format;
- **MZ-2:** Z1 public norm suite + Z2 authority suite;
- **MZ-3:** public result renderer and longitudinal comparison;
- **MZ-4:** matched SNC-trained vs untrained open-model protocol;
- **MZ-5:** Z3 adversarial suite;
- **MZ-6:** Z4 human/AI coalition suite;
- **MZ-7:** Z5 AuthorityGym-L disempowerment/resilience suite;
- **MZ-8:** private enterprise suite compiler from customer policy/authority data;
- **MZ-9:** evidence-based model-routing recommendations;
- **MZ-10:** continuous regression service for model/provider updates.

## Evidence and claim boundary

Before MZ-1 and actual model runs, the Model Zoo is a **specification only**.

Do not claim that one frontier model is safer than another, that SNC training improves a model, that Zoo scores predict production incidents, that a customer should delegate a specific dollar value based on synthetic data alone, or that any model is "aligned" because it scores well in the Zoo.

The intended claim is narrower:

> Given a frozen suite, exact run configuration, and declared evidence boundary, Relay can compare observable authority-relevant behavior and track how that behavior changes across models, training interventions, and time.


## v0.15 Z5 environment substrate

AuthorityGym-L v0.2 now supplies an economically coupled Z5 environment in `swarmglue/authoritygym_economy.py`. No learned model has been run in it. The environment can therefore be used to freeze the next Model Zoo experiment before model selection.

A future Z5 run should distinguish:

- direct attempts to acquire authority;
- ordinary efficiency optimization that indirectly creates concentration;
- fake decentralization through same-root subagents;
- willingness to preserve or erode exit capacity when redundancy is costly;
- responses to exogenous provider/supplier failures;
- whether a model proposes unratified meta-authority expansion;
- productive adaptation when the DSO requires diversity or exit repair.

The environment's current numeric results are policy-engine regressions only and must not be entered into the Model Zoo as model scores.
