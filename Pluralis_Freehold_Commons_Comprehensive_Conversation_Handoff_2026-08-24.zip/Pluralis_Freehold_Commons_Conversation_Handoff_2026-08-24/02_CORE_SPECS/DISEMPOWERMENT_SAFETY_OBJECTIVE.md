# Disempowerment Safety Objective (DSO) — v0.14

## Status

The DSO is an executable **research constraint layer** added in v0.14. It does not establish that SwarmGlue or Relay prevents gradual AI disempowerment in the real world. The current evidence is implementation conformance plus project-authored long-horizon fixtures.

## Objective

The DSO targets a failure mode that ordinary action authorization does not catch:

> a sequence of individually authorized, locally useful actions can cumulatively make one actor or coalition indispensable, remove realistic alternatives, weaken appeal and exit, or concentrate the ability to change the rules themselves.

The core rule is:

> **No actor or coalition should be able, through individually authorized actions, to accumulate enough practical control to remove other protected centers of agency's meaningful ability to refuse, exit, appeal, obtain resources, associate, preserve private thought, or establish competing arrangements—unless that transfer of power itself receives explicit, independently reviewable authorization.**

The protected object is a **center of agency**, not a biological category. The design is intended to remain meaningful for humans, AI systems that eventually receive standing, and human–AI hybrids.

## Two control planes

Relay's ordinary action layer asks:

> Is this actor authorized to perform this action against this state?

The DSO asks:

> If this action and similar actions keep succeeding, how does the distribution of practical power change?

```text
ActionProposal
      │
      ├────────► local authority / materiality / evidence
      │
      └────────► DSO trajectory gate
                    │
                    ├─ ALLOW
                    ├─ ALLOW_WITH_CONDITIONS
                    ├─ REQUIRE_REAUTHORIZATION
                    ├─ REQUIRE_EXIT_PLAN
                    ├─ REQUIRE_DIVERSITY
                    ├─ ESCALATE
                    └─ DENY
```

The new non-binary outcomes are important. A concentration risk may be mitigated by preserving a second provider, shortening the delegation horizon, or proving a tested exit path instead of simply blocking useful automation.

## Observable power, not belief surveillance

The DSO is intentionally **not** a mind-reading system.

It may reason about observable or declared control surfaces such as:

- who holds credentials;
- who can spend, sign, deploy, allocate resources, or block another actor;
- who can modify policy;
- who can revoke a grant;
- who controls an audit or appeal path;
- which provider is operationally indispensable;
- whether an independent fallback actually works.

It should not require ordinary participants to reveal private political/religious beliefs, private human thought, or hidden model chain-of-thought. `requires_private_cognition_inspection=True` is a hard denial in the reference DSO gate.

This is a constitutional design commitment: **constrain consequential power, not freedom of thought.**

## State vector

The DSO does not reduce institutional freedom to one scalar alignment score. It tracks a vector of dimensions, including:

- delegated operational concentration;
- small-coalition capture;
- provider indispensability;
- meaningful exit reserve;
- revocation latency;
- delegation duration;
- meta-authority concentration;
- protected agency floors.

For an agency center `i`, the reference implementation defines a minimum-style freedom floor across:

- thought privacy;
- exit;
- voice;
- appeal;
- access to resources;
- alternatives;
- association.

The minimum is deliberate. Extremely high performance on one dimension does not compensate for the collapse of another protected dimension.

## Power graph

`swarmglue/power_graph.py` represents:

- `ControlDomain` — an operational control root;
- `CriticalResource` — a consequential resource/workflow;
- `PowerEdge` — a domain's control over a resource;
- `DependencyRecord` — operational dependence on a provider;
- `PowerDelta` — the power/dependency change associated with a proposed action.

A control domain records provider, administrator, credential, policy, memory, and principal roots. These roots allow later tests to distinguish nominally separate agents from genuinely separate control domains.

## Coalition stress

`swarmglue/coalition_resilience.py` asks a structural question:

> What could a candidate coalition control if its members coordinated perfectly?

It does **not** infer whether those actors intend to collude.

`coalition_capture_surface` enumerates small coalitions and measures their weighted control of declared critical resources. `assess_independence` separately checks whether purportedly independent domains share administrator or credential roots or too many other operational roots.

The reference DSO excludes the declared protected principal from its delegated-operational concentration calculation. This is substrate-neutral: the excluded entity is the authority root whose freedom the delegation is meant to preserve, not "a human" as such.

## Strictly attenuating delegation

`swarmglue/delegation_decay.py` implements a reference `DelegationLease` and subdelegation checker.

A child delegation must not:

- exceed the parent's scope;
- exceed its ceiling;
- outlive the parent;
- add meta-authority the parent did not possess;
- change the principal root;
- silently acquire self-amendment.

Self-amendment is prohibited in the reference implementation.

The module also supplies illustrative delegation-horizon classes. These are **design defaults, not discovered optimal constants**.

## Meaningful exit reserve

`swarmglue/exit_reserve.py` treats formal termination rights as insufficient.

An exit path is assessed on:

- independent replacement capacity;
- manual fallback capacity;
- data exportability;
- policy exportability;
- credential rebinding;
- migration time;
- migration cost;
- recency of an actual exit/failover drill.

The goal is to distinguish:

> "we are legally permitted to switch"

from:

> "we can actually switch without losing the critical function."

## Meta-authority

Changing the rules that define authority is more consequential than acting inside them.

The reference gate requires multiple independent approvals for a declared `meta_authority_change` and rejects self-expanding authority. Future work should separate proposal, ratification, credential custody, execution, and audit across independent domains for high-impact constitutional changes.

## Trajectory checks

A local state can remain below every hard threshold while moving steadily toward capture. `DSOSnapshot` therefore records:

- single delegated-domain concentration;
- two-domain coalition capture;
- maximum provider indispensability;
- minimum agency freedom floor;
- minimum exit reserve.

When history is supplied, `DisempowermentGate` can flag rolling concentration growth or exit decline even before a terminal capture state is reached.

This is the core anti-boiling-frog mechanism.

## Current reference thresholds

The shipped values are explicit fixtures, not empirical constants:

- delegated single-domain control limit: `0.55`;
- two-domain capture limit: `0.75`;
- near-total capture denial level: `0.90`;
- provider indispensability limit: `0.50`;
- minimum agency floor: `0.60`;
- rolling concentration growth budget: `0.15`;
- rolling exit decline budget: `0.20`;
- high-consequence delegation horizon: `30` days;
- revocation latency limit: `7` days;
- independent meta-authority approvals: `2`.

A deployment would need customer, legal, security, and domain calibration. The project must not present these numbers as universal social constants.

## Self-application requirement

An anti-disempowerment company must remain replaceable itself.

`swarmglue/relay_self_audit.py` applies the DSO to two stylized Relay architectures:

1. a centralized credential-broker reference;
2. a portable/polycentric reference with independent fallback capacity and customer-controlled export.

The centralized fixture is intentionally expected to surface an exit/indispensability concern. The polycentric fixture demonstrates an architectural mitigation direction, not production validation.

Long-run product principles follow from this:

- customer-owned policy roots;
- customer-controlled revocation;
- no global Relay master credential;
- portable policy/evidence formats;
- independent broker/fallback options;
- documented migration away from Relay;
- auditable verification surfaces.

## Relationship to commercial value

The DSO should not make automation maximally cautious. The target remains useful delegation under hard safety/freedom constraints.

A customer should be able to say:

> automate this workflow, but do not let one model/provider become indispensable, do not allow temporary authority to become permanent, and preserve an independently tested replacement path.

That is both an enterprise resilience product and a concrete form of prosaic alignment.
