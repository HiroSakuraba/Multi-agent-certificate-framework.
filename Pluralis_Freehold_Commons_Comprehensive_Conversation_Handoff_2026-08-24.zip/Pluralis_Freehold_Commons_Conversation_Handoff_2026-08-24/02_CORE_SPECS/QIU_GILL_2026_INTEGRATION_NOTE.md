# Qiu–Gill 2026 Adversarial Review — integration note

## Source

Eric S. Qiu and Joyce Gill, **“Adversarial Review: Structured Disagreement for Grounded Agentic Code Review,”** ICML 2026 / arXiv:2608.18167v1 (16 August 2026).

## What the paper actually supports

Within the paper's tested coding/review settings:

1. Adding more role-separated agents does not monotonically improve performance.
2. A compact main-agent / reviewer / critic protocol can outperform larger tested baselines.
3. On LiveCodeBench, reported AR scores 87% vs. 82% for the five-agent MARS baseline.
4. Naive interactive review can fail through **false consensus**.
5. Explicitly typed, evidence-grounded disagreement improves reported SWE-PRBench F1 from 0.457 for naive AR to 0.533 for the constrained variant.
6. Freezing the artifact during the reviewer–critic inner loop separates deliberation from modification.
7. In the SWE-bench Verified experiment, AR improves pass rate over tested baselines but uses roughly 4.5× the tokens of zero-shot.
8. The authors explicitly describe their cooperation claims as empirical rather than formal and suggest adaptive invocation for uncertain/high-risk tasks.

## What SwarmGlue infers from it

These are **design hypotheses**, not source findings:

- consensus should not be treated as authorization;
- disagreement should be typed and retained as an auditable object;
- evidence provenance should be represented explicitly;
- model/provider plurality should be separated from real control-domain independence;
- cooperation interfaces should be narrow rather than all-to-all by default;
- review depth should scale with consequence, uncertainty, irreversibility and DSO power impact;
- false-consensus cases belong in AuthorityGym and Model Zoo;
- social-norm training should teach cooperative dissent, not authority deference.

## What the paper does not support

The paper does not establish a general solution to multi-agent alignment, resistance to strategic collusion, governance legitimacy, safe delegation of money/credentials/legal authority, long-horizon disempowerment resistance, genuine control-domain independence, a universal optimum of three agents, or sufficiency of text-only protocols for high-consequence safety.

SwarmGlue must test these extensions independently.
