# Build note

This handoff bundle is a packaging and communications update. It does **not** modify the frozen v0.17 runnable release.

The two HTML decks in `03_COMMUNICATION` were refreshed to reflect v0.17 status and naming; they are not part of the preregistered/frozen scientific artifact.

Historical `SwarmGlue` / `Relay` identifiers remain where needed for reproducibility.
