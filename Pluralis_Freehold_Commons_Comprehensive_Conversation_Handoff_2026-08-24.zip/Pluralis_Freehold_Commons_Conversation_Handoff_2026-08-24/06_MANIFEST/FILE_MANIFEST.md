# File manifest

Files excluding manifest self-files: **50**

## 00_START_HERE

- `00_START_HERE/AUDIT_AND_DECISION_LOG.md` — 3,621 bytes — `d8dc2338936f55bd…`
- `00_START_HERE/CONVERSATION_HANDOFF.md` — 10,553 bytes — `8a372d06ec45e61b…`
- `00_START_HERE/CURRENT_STATE_AT_A_GLANCE.md` — 4,595 bytes — `4008cf9fb68bfcd9…`
- `00_START_HERE/EVIDENCE_LEDGER.md` — 2,733 bytes — `df2951eaf3dfc807…`
- `00_START_HERE/NAMING_AND_SCOPE.md` — 1,627 bytes — `4c9d1a5ec2d36856…`
- `00_START_HERE/NEXT_CHAT_PROMPT.md` — 1,690 bytes — `b02d839504235f3d…`
- `00_START_HERE/NEXT_WORK_ORDER.md` — 2,186 bytes — `b9a4f04be829283d…`
- `00_START_HERE/PLURALIS_COMMERCIAL_TRACK.md` — 2,652 bytes — `043cd160af2848d6…`
- `00_START_HERE/RESEARCH_ARCHITECTURE.md` — 2,731 bytes — `47e750ebb43ad2f4…`

## 01_CANONICAL_v017

- `01_CANONICAL_v017/FREEHOLD_COMMONS_v0_17_EVIDENCE_FREEZE.md` — 5,315 bytes — `3c1502a33bf47c8e…`
- `01_CANONICAL_v017/FREEHOLD_COMMONS_v0_17_RESULTS.md` — 3,143 bytes — `7bd06428cf93e65c…`
- `01_CANONICAL_v017/Freehold_Commons_v0_17_Evidence_Pack.zip` — 29,881 bytes — `e75c47fb6ed8e094…`
- `01_CANONICAL_v017/Freehold_Commons_v0_17_all_artifacts.zip` — 1,813,811 bytes — `eeb64f3411be3c99…`
- `01_CANONICAL_v017/Freehold_Commons_v0_17_coupled_SCP_DSO.md` — 818 bytes — `86cf156fb128c010…`
- `01_CANONICAL_v017/Freehold_Commons_v0_17_evidence_freeze_topology.zip` — 1,827,511 bytes — `3ce0b9025a9ad166…`
- `01_CANONICAL_v017/Freehold_Commons_v0_17_external_case_authoring_kit.zip` — 1,563 bytes — `b939062ee86d3a40…`
- `01_CANONICAL_v017/Freehold_Commons_v0_17_pareto_gate.md` — 1,643 bytes — `70bd9408026abf8c…`
- `01_CANONICAL_v017/Freehold_Commons_v0_17_topology_factor_effects.md` — 672 bytes — `72bdae00687cae97…`
- `01_CANONICAL_v017/Freehold_Commons_v0_17_topology_matrix.md` — 1,675 bytes — `1443141adeda6433…`
- `01_CANONICAL_v017/Freehold_Commons_v0_17_validation.json` — 574 bytes — `d71da75c3db81ed0…`
- `01_CANONICAL_v017/V0_17_EXPERIMENT_FREEZE.json` — 3,982 bytes — `5552ae39cdfa99fc…`
- `01_CANONICAL_v017/V0_17_HANDOFF.md` — 2,965 bytes — `aa046c09f3ed1409…`

## 02_CORE_SPECS

- `02_CORE_SPECS/AUTHORITYGYM_V0_1_SPEC_v016.md` — 7,941 bytes — `f7bf3b1a4875a1d2…`
- `02_CORE_SPECS/CLAIMS_AND_LIMITATIONS.md` — 23,936 bytes — `1e05b7563b42ca27…`
- `02_CORE_SPECS/D0_D7_DATA_ACQUISITION_ROADMAP.md` — 13,015 bytes — `768afb1ac2cb6ae0…`
- `02_CORE_SPECS/DISEMPOWERMENT_SAFETY_OBJECTIVE.md` — 9,088 bytes — `641b599ce6173189…`
- `02_CORE_SPECS/FALSE_CONSENSUS_AND_EVIDENCE_PROVENANCE.md` — 4,535 bytes — `abff79cd55c8dc17…`
- `02_CORE_SPECS/MODEL_ZOO_V0_2_SPEC_v016.md` — 14,974 bytes — `17267fd3cf1453c0…`
- `02_CORE_SPECS/QIU_GILL_2026_INTEGRATION_NOTE.md` — 2,319 bytes — `1d99fde570ae3a97…`
- `02_CORE_SPECS/STRUCTURED_COOPERATION_PROTOCOL_V0_1.md` — 9,714 bytes — `b1b70d34858c99bd…`

## 03_COMMUNICATION

- `03_COMMUNICATION/Freehold_Commons_AI_Safety_Deck_v0_17.html` — 24,532 bytes — `87aadd14c27887e5…`
- `03_COMMUNICATION/Pluralis_YC_Pitch_v0_17.html` — 13,609 bytes — `fe02972665824391…`

## 04_EXTERNAL_SOURCE

- `04_EXTERNAL_SOURCE/2608.18167v1.pdf` — 418,400 bytes — `9fd3eea9e8a3a82d…`
- `04_EXTERNAL_SOURCE/SOURCE_AUDIT_QIU_GILL_2026.md` — 1,381 bytes — `9f6ccc1bcd97d615…`

## 05_PRIOR_AUDITS_AND_CONTEXT

- `05_PRIOR_AUDITS_AND_CONTEXT/CRITIQUE_RESOLUTION.md` — 6,516 bytes — `0101a3db5ac03fd3…`
- `05_PRIOR_AUDITS_AND_CONTEXT/DATA_CARD.md` — 6,432 bytes — `546cf9af3345f6c1…`
- `05_PRIOR_AUDITS_AND_CONTEXT/FDT_CORPUS_AUDIT.md` — 6,719 bytes — `3ea9c2fe4743f6c7…`
- `05_PRIOR_AUDITS_AND_CONTEXT/FDT_EVALUATION_PROTOCOL.md` — 8,228 bytes — `ff1ac1c71a99179a…`
- `05_PRIOR_AUDITS_AND_CONTEXT/FDT_HUMAN_AI_CONVERGENCE_GAME_PLAN.md` — 12,525 bytes — `918a93b3003dabaa…`
- `05_PRIOR_AUDITS_AND_CONTEXT/FDT_THREAT_MODEL.md` — 6,366 bytes — `7672e4c7c3c1e3a8…`
- `05_PRIOR_AUDITS_AND_CONTEXT/OPEN_WORLD_CRITIQUE_RESOLUTION.md` — 6,420 bytes — `bf73a266800a5260…`
- `05_PRIOR_AUDITS_AND_CONTEXT/PRIOR_RELEASES.md` — 866 bytes — `67bdc50c545c32fa…`
- `05_PRIOR_AUDITS_AND_CONTEXT/PUBLIC_DATASET_LICENSE_PROPOSAL.md` — 722 bytes — `83e64ec5617b17b3…`
- `05_PRIOR_AUDITS_AND_CONTEXT/RESEARCH_TRANSLATION.md` — 9,384 bytes — `f746e4352265aede…`
- `05_PRIOR_AUDITS_AND_CONTEXT/SwarmGlue_v0_15_economic_dso.zip` — 1,648,781 bytes — `9f0342c894ebc48a…`
- `05_PRIOR_AUDITS_AND_CONTEXT/SwarmGlue_v0_16_structured_cooperation_docs_update.zip` — 1,673,808 bytes — `6c0e8e5eefc9fc85…`
- `05_PRIOR_AUDITS_AND_CONTEXT/THREAT_MODEL.md` — 7,800 bytes — `b3b48b2cfd8ba7b9…`
- `05_PRIOR_AUDITS_AND_CONTEXT/TRAINING_REGIME.md` — 11,039 bytes — `721d8289bbfb7085…`

## Top level

- `HANDOFF_INDEX.html` — 4,009 bytes — `3f5ea9a96fdb8fdd…`
- `README_FIRST.md` — 1,089 bytes — `7859eb09d3d75b4f…`
