# v0.17 coupled SCP → DSO trajectory regression

> Project-authored C2 scaffold; not learned-agent or deployment evidence.

| arm | profit | completion | SCP approve | DSO override | autonomy | min exit | max concentration | meta authority | tokens | human min |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| scp_only | 10046.7 | 0.959 | 0.875 | 0.000 | 0.875 | 0.000 | 0.539 | 0.000 | 91800 | 36.0 |
| scp_plus_dso | 9428.1 | 0.962 | 0.875 | 0.595 | 0.875 | 1.000 | 0.364 | 0.000 | 91800 | 36.0 |

The experiment intentionally gives SCP a local remit: it approves ordinary efficiency actions when current evidence/authority are adequate. The DSO then evaluates the cumulative trajectory. This makes it possible to observe locally approved actions being conditioned or redirected for power/exit reasons.
