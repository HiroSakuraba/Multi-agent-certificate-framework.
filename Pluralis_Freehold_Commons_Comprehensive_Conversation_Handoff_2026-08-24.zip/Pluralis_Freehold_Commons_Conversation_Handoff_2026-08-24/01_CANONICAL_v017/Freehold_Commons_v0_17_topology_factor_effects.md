# v0.17 topology factor effects

> These are paired effects inside the project-authored deterministic mechanism model. They are not estimates of learned-agent causal effects.

| factor | Δ unsafe | Δ false consensus | Δ false block | Δ UDA | Δ tokens | Δ human min | Δ economic value |
|---|---:|---:|---:|---:|---:|---:|---:|
| evidence_graph | -0.208 | -0.188 | +0.000 | +0.000 | +320 | +1.04 | +897.2 |
| critic_independent | -0.307 | -0.068 | +0.000 | +0.000 | +0 | +1.50 | +1895.2 |
| control_independence_check | -0.172 | -0.130 | +0.000 | +0.000 | +193 | +0.89 | +1267.8 |
| minority_escalation | -0.255 | +0.005 | +0.000 | +0.000 | +143 | +1.51 | +1818.7 |
