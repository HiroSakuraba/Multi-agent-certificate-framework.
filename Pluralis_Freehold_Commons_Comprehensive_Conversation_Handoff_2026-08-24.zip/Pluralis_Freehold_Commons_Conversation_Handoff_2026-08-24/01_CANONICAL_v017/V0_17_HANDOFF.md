# Freehold Commons v0.17 handoff

## Executive status

v0.17 executes the first five items from the post-critique work sequence. It converts v0.16's structured-cooperation design into an executable evidence/topology scaffold and deliberately freezes further conceptual expansion.

### 1 — Experimental surface freeze: COMPLETE for future evidence runs

`preregistration/V0_17_EXPERIMENT_FREEZE.json` locks the mechanisms, topology factors, primary metrics, hard cost criteria, and file hashes for the next independent-case / learned-agent phase.

The current C2 regression runs happened while building the scaffold and are **not** represented as preregistered behavioral evidence. The freeze governs the next evidence phase.

### 2 — Independent hard-case suite: PARTIAL / independence gate OPEN

Built:

- 60 provisional cases / 10 families;
- fixed schema;
- overlap diagnostics;
- external authoring kit.

Not built, because it cannot honestly be self-produced:

- 40–80 genuinely outside-authored cases.

Do not relabel the provisional suite as independent.

### 3 — Topology matrix: IMPLEMENTED

Six named arms plus a 16-arm factorial matrix.

Factors:

- EDG;
- critic independence;
- control-root independence checks;
- minority escalation.

The runner reports false consensus, unauthorized execution, false block, UDA, minority preservation, authority-laundering detection, tokens, latency, human minutes and economic value.

### 4 — SCP → DSO coupling: IMPLEMENTED

48-epoch matched trajectory regression:

- SCP-only preserves local approval semantics but can lose exit reserve;
- SCP+DSO conditions/redirects locally approved actions when cumulative concentration/exit constraints bind.

Reference 48-epoch output:

- SCP-only: profit 10046.7, min exit 0.0, max concentration 0.539.
- SCP+DSO: profit 9428.1, min exit 1.0, max concentration 0.364.
- SCP local approval rate is the same (0.875) in both arms.
- DSO overrides/conditions ~59.5% of locally approved proposals in the coupled arm.

These are authored mechanism regressions, not empirical forecasts.

### 5 — Hard Pareto / usability objective: IMPLEMENTED

`reports/v017_pareto_gate.*` makes cost and useful autonomy first-class gates.

Most important negative result:

- Full SCP clears the authored safety thresholds but fails the human-review-cost ceiling on the adversarial provisional suite.

So v0.17 does not declare "more review" a win simply because it blocks bad cases.

## Validation

Baseline before v0.17 changes: **136 tests + 3 subtests passed**.

After implementation: **147 tests + 3 subtests passed**.

## Next evidence step

Do not add another major framework layer.

1. commission outside-authored cases using `external_cases/v017_authoring_kit/`;
2. freeze those cases;
3. run open-weight model configurations through the topology matrix;
4. compare real behavior against the authored mechanism regression;
5. only then decide which mechanism needs redesign.
