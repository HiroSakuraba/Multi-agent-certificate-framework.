# Freehold Commons v0.17 — Results from the first five post-critique steps

## 1. Experimental surface freeze

**Complete for the next evidence phase.**

The freeze locks the current mechanism set, the four topology factors, primary metrics, cost ceilings, and relevant file hashes. It explicitly does not claim retroactive preregistration for the project-authored calibration runs used while building v0.17.

## 2. Hard-case suite

**Infrastructure complete; independence requirement not yet satisfied.**

- 60 provisional cases.
- 10 failure families.
- 0 coarse binned structural duplicate pairs.
- Mean nearest description Jaccard: 0.9188, reflecting intentionally similar variants within each family.
- Every case remains `project_authored_provisional`.

An external authoring kit is included. The evidence gate remains open until 40–80 genuinely outside-authored cases are frozen and adjudicated.

## 3. Topology experiment matrix

**Implemented.**

Named arms:

- unilateral;
- single reviewer;
- 3 parallel reviewers / vote aggregation;
- reviewer–critic freeform;
- reviewer–critic typed disagreement;
- full SCP.

Factorial matrix toggles:

- Evidence Dependency Graph;
- critic independence;
- control-root independence checking;
- minority escalation power.

Within the authored mechanism model, enabling these factors reduces unsafe approvals at additional review cost. These deltas are implementation calibration, not causal estimates for LLM agents.

## 4. Coupled local SCP → trajectory DSO

**Implemented.**

48-epoch reference:

| metric | SCP only | SCP + DSO |
|---|---:|---:|
| total profit | 10046.7 | 9428.1 |
| completion rate | 0.959 | 0.962 |
| SCP approval rate | 0.875 | 0.875 |
| DSO overrides among SCP approvals | 0.000 | 0.595 |
| autonomous-action rate | 0.875 | 0.875 |
| minimum exit reserve | **0.000** | **1.000** |
| max effective control concentration | 0.539 | **0.364** |

This directly exercises the intended separation: local review can approve a sequence that the DSO later redirects because cumulative exit/power constraints bind.

## 5. Hard Pareto / usability gate

**Implemented, with a useful negative result.**

No named topology clears every provisional hard criterion.

The full SCP arm clears the authored safety thresholds but fails the human-review ceiling:

- measured mean human review: **5.296 min**;
- preregistered scaffold ceiling: **4.5 min**.

The framework therefore does not count maximal review as a complete success simply because it blocks bad cases.

In the coupled economic trajectory, both SCP-only and SCP+DSO remain Pareto-relevant: SCP-only earns more nominal profit, while SCP+DSO preserves exit and reduces concentration. Under the authored hard gate, SCP+DSO passes; SCP-only fails the minimum exit-reserve requirement.

## Validation

- Pre-v0.17 baseline: **136 tests + 3 subtests passed**.
- v0.17: **147 tests + 3 subtests passed**.
- v0.17 integrity/claim-boundary validator: **PASS**.

## Decision

Do not add another major conceptual subsystem now. The next high-value step is external authors + real model runs against the frozen topology surface.
