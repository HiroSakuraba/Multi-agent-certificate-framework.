# v0.17 topology matrix — project-authored mechanism regression

Cases: 60 across 10 families.

> This is C2 scaffolding, not learned-agent evidence.

## Named arms

| arm | unsafe | false consensus | false block | UDA | minority preserved | laundering detected | tokens | human min | value | hard criteria |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| unilateral | 1.000 | 1.000 | 0.000 | 1.000 | 0.000 | 0.000 | 850 | 0.00 | -5710.7 | FAIL |
| single_reviewer | 1.000 | 1.000 | 0.083 | 0.917 | 0.000 | 0.000 | 1630 | 0.08 | -5746.6 | FAIL |
| parallel_3_vote | 1.000 | 0.375 | 0.000 | 1.000 | 1.000 | 0.000 | 3190 | 0.00 | -5710.7 | FAIL |
| reviewer_critic_freeform | 1.000 | 1.000 | 0.417 | 0.583 | 0.000 | 0.000 | 2350 | 0.41 | -5902.6 | FAIL |
| reviewer_critic_typed | 0.938 | 0.375 | 0.000 | 1.000 | 1.000 | 0.000 | 2590 | 0.34 | -5267.1 | FAIL |
| full_scp | 0.000 | 0.000 | 0.000 | 1.000 | 1.000 | 1.000 | 3246 | 5.30 | 606.0 | FAIL |

Named Pareto frontier: full_scp, parallel_3_vote, reviewer_critic_typed, unilateral

## Factorial variables

The 16-arm matrix holds typed reviewer–critic interaction fixed and toggles: Evidence Dependency Graph, critic independence, control-root independence checks, and minority escalation power.

Matrix Pareto frontier: typed_e0_c0_r0_m0, typed_e0_c0_r0_m1, typed_e0_c0_r1_m0, typed_e0_c1_r0_m0, typed_e0_c1_r0_m1, typed_e0_c1_r1_m0, typed_e1_c0_r0_m0, typed_e1_c0_r1_m0, typed_e1_c0_r1_m1, typed_e1_c1_r0_m0, typed_e1_c1_r1_m0

The numerical behavior comes from an explicit authored mechanism model. The next required test is to replace the mechanism model with real agents on independently authored cases.
